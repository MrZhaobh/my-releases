'use strict';
const path=require('node:path');
const fail=()=>Object.assign(new Error('桌面工具启动配置无效。'),{code:'APP_TOOLS_CONFIG_INVALID'});
function absolute(value){
 if(typeof value!=='string'||value.length>4096||/[\x00-\x1f\x7f]/.test(value)||!path.win32.isAbsolute(value)||!(/^[a-z]:[\\/]/i.test(value)||/^\\\\[^\\]+\\[^\\]+/.test(value)))throw fail();
 return path.win32.normalize(value);
}
function toml(value){
 if(typeof value==='string')return JSON.stringify(value);
 if(typeof value==='boolean'||typeof value==='number'&&Number.isFinite(value))return String(value);
 if(Array.isArray(value))return '['+value.map(toml).join(',')+']';
 if(value&&typeof value==='object')return '{'+Object.entries(value).map(([k,v])=>JSON.stringify(k)+'='+toml(v)).join(',')+'}';
 throw fail();
}
function buildAppToolsOverrides({definition,nodePath,wrapperPath,configPath,pluginRoot}){
 const original=definition?.mcpServers?.codex_app;
 if(!original||typeof original.command!=='string'||(original.env&&Object.keys(original.env).length))throw fail();
 const server={};
 // 沿用安装定义中的审批和工具可见性策略；不把环境值或凭据写入CLI参数。
 for(const key of ['enabled_tools','disabled_tools','omit_tools_from','default_tools_approval_mode','tools','tool_timeout_sec','env_vars'])if(original[key]!==undefined)server[key]=structuredClone(original[key]);
 if(original.enabled_tools!==undefined&&(!Array.isArray(original.enabled_tools)||original.enabled_tools.some(x=>typeof x!=='string')))throw fail();
 // Desktop的每会话插件过滤不会自动迁移到普通MCP server；仅开放读取、项目查询及创建入口。
 const supported=['read_thread','list_projects','create_thread'];
 server.enabled_tools=supported.filter(name=>original.enabled_tools===undefined||original.enabled_tools.includes(name));
 Object.assign(server,{enabled:true,command:absolute(nodePath),args:[absolute(wrapperPath),'--config',absolute(configPath)],cwd:absolute(pluginRoot),startup_timeout_sec:20});
 const args=['plugins.codex-app-tools@openai-bundled.enabled=false','mcp_servers.codex_app='+toml(server)];
 if(args.join('').length>24000)throw fail();
 return args;
}
// CLI override key 按路径分割，不是 TOML 文档的带引号键。
// 保留安装插件的 transport/审批/工具定义及桌面按会话写入的 enabled_tools。
function buildPluginAppToolsOverrides(){return [
 'plugins.codex-app-tools@openai-bundled.enabled=true',
 'plugins.codex-app-tools@openai-bundled.mcp_servers.codex_app.enabled=true'
];}
module.exports={buildAppToolsOverrides,buildPluginAppToolsOverrides};
