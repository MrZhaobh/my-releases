'use strict';

const http = require('node:http');
const crypto = require('node:crypto');
const {spawn: spawnProcess} = require('node:child_process');
const {win32} = require('node:path');

const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const protocolToken = /^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$/;
const digest = value => crypto.createHash('sha256').update(value).digest();
function validExtensions(value) {
  if (value.length > 4096 || /[^\x20-\x7e]/.test(value)) return false;
  let index = 0;
  const space = () => { while (value[index] === ' ') index++; };
  const token = () => { const start = index; while (index < value.length && protocolToken.test(value[index])) index++; return index > start; };
  while (index < value.length) {
    space(); if (!token()) return false; space();
    while (value[index] === ';') {
      index++; space(); if (!token()) return false; space();
      if (value[index] === '=') {
        index++; space();
        if (value[index] === '"') {
          index++; let closed = false;
          while (index < value.length) { const next = value[index++]; if (next === '"') { closed = true; break; } if (next === '\\' && ++index > value.length) return false; }
          if (!closed) return false;
        } else if (!token()) return false;
        space();
      }
    }
    if (index === value.length) return true;
    if (value[index++] !== ',') return false;
    space(); if (index === value.length) return false;
  }
  return false;
}

function createBroker({token, binary = 'codex', socketPath, spawn = spawnProcess, maxClients = 8, handshakeMs = 10000, maxPendingBytes = 256 * 1024, drainTimeoutMs = 10000, killGraceMs = 1000, exitTimeoutMs = 1000} = {}) {
  if (typeof token !== 'string' || Buffer.byteLength(token) < 32 || /[\r\n:]/.test(token)) throw new Error('token 必须至少为32字节且不含换行或冒号');
  if (typeof binary !== 'string' || !binary.trim()) throw new Error('binary 无效');
  if (socketPath !== undefined && (typeof socketPath !== 'string' || !socketPath.trim() || /[\x00-\x1f\x7f]/.test(socketPath) || !win32.isAbsolute(socketPath) || !(/^[A-Za-z]:[\\/]/.test(socketPath) || /^\\\\[^\\/]+[\\/][^\\/]+[\\/]/.test(socketPath)))) throw new Error('socketPath 必须是非空的完全限定Windows绝对路径且不含控制字符');
  if (!Number.isInteger(maxClients) || maxClients < 1 || maxClients > 8) throw new Error('maxClients 必须为1至8');
  for (const value of [handshakeMs, maxPendingBytes, drainTimeoutMs, killGraceMs, exitTimeoutMs]) if (!Number.isSafeInteger(value) || value < 1) throw new Error('连接限额无效');
  // 一个配额仅在连接关闭且已确认 proxy 退出之后释放。
  const expected = digest(`codex:${token}`), connections = new Set(), httpSockets = new Set();
  let spawnedClients = 0, closing = false, closePromise, killFailures = 0, exitTimeouts = 0, lastError = null;
  const reject = (socket, status = 400) => {
    if (socket.destroyed) return;
    const reason = http.STATUS_CODES[status] ?? 'Error';
    socket.end(`HTTP/1.1 ${status} ${reason}\r\nConnection: close\r\nContent-Length: 0\r\n\r\n`);
  };
  const hostOkay = req => {
    const port = server.address()?.port;
    return port && [`127.0.0.1:${port}`, `localhost:${port}`].includes(req.headers.host);
  };
  const authenticated = req => {
    const match = /^Basic ([A-Za-z0-9+/]+={0,2})$/i.exec(req.headers.authorization ?? '');
    let credentials = Buffer.alloc(0);
    if (match) { try { credentials = Buffer.from(match[1], 'base64'); } catch {} }
    return crypto.timingSafeEqual(digest(credentials), expected) && !!match;
  };
  const validUpgrade = req => {
    if (req.method !== 'GET' || req.url !== '/rpc' || req.httpVersion !== '1.1' || !hostOkay(req)) return false;
    const sensitive = new Set(['host', 'authorization', 'origin', 'upgrade', 'connection', 'sec-websocket-key', 'sec-websocket-version', 'sec-websocket-protocol', 'sec-websocket-extensions']);
    const seen = new Set();
    for (let i = 0; i < req.rawHeaders.length; i += 2) {
      const key = req.rawHeaders[i].toLowerCase();
      if (sensitive.has(key) && seen.has(key)) return false;
      seen.add(key);
    }
    if (req.headers.origin !== undefined) {
      let origin;
      try { origin = new URL(req.headers.origin); } catch { return false; }
      if (origin.origin !== `http://${req.headers.host}` || origin.href !== `${origin.origin}/` || origin.username || origin.password) return false;
    }
    if (req.headers.upgrade?.toLowerCase() !== 'websocket' || !req.headers.connection?.toLowerCase().split(',').map(value => value.trim()).includes('upgrade') || req.headers['sec-websocket-version'] !== '13') return false;
    const key = req.headers['sec-websocket-key'];
    if (typeof key !== 'string' || !/^[A-Za-z0-9+/]{22}==$/.test(key) || Buffer.from(key, 'base64').length !== 16 || Buffer.from(key, 'base64').toString('base64') !== key) return false;
    if (req.headers['transfer-encoding'] || (req.headers['content-length'] !== undefined && req.headers['content-length'] !== '0')) return false;
    const protocols = req.headers['sec-websocket-protocol'];
    if (protocols !== undefined) {
      const parts = protocols.split(',').map(value => value.trim());
      if (!parts.length || new Set(parts).size !== parts.length || parts.some(value => !protocolToken.test(value))) return false;
    }
    const extensions = req.headers['sec-websocket-extensions'];
    return extensions === undefined || validExtensions(extensions);
  };
  const server = http.createServer({headersTimeout: handshakeMs, requestTimeout: handshakeMs, maxHeaderSize: 16384}, (req, res) => {
    const ok = !closing && hostOkay(req) && req.method === 'GET' && req.url === '/health';
    const payload = JSON.stringify(ok ? {ok: true, service: 'codex-shared-engine-broker'} : {error: 'not found'});
    res.writeHead(ok ? 200 : 404, {'content-type': 'application/json', 'cache-control': 'no-store', 'content-length': Buffer.byteLength(payload)}); res.end(payload);
  });
  const listen = server.listen.bind(server);
  server.listen = (...args) => {
    const host = args[0] && typeof args[0] === 'object' ? args[0].host : args[1];
    if (host !== '127.0.0.1') throw new Error('broker 只允许显式监听127.0.0.1');
    return listen(...args);
  };
  server.on('connection', socket => { httpSockets.add(socket); socket.once('close', () => httpSockets.delete(socket)); socket.setTimeout(handshakeMs, () => socket.destroy()); });
  server.on('clientError', (_error, socket) => reject(socket));
  server.on('upgrade', (req, socket, head) => {
    if (!authenticated(req)) return reject(socket, 401);
    if (closing || !validUpgrade(req) || head.length > maxPendingBytes) return reject(socket, 400);
    if (connections.size >= maxClients) return reject(socket, 503);
    // HTTP头已完整校验，改用下方独立的上游握手期限。
    socket.setTimeout(0);
    socket.pause();
    const entry = {socket, child: null, closed: false, processSettled: false, ready: false, failed: false, timers: new Set(), lifecycleTimers: new Set(), drains: new Map(), cleanups: []};
    entry.done = new Promise(resolve => { entry.resolveDone = resolve; });
    const timer = (fn, ms) => { const value = setTimeout(fn, ms); value.unref?.(); entry.timers.add(value); return value; };
    const on = (emitter, event, fn) => { emitter.on(event, fn); entry.cleanups.push(() => emitter.off(event, fn)); };
    const lifecycleTimer = (fn, ms) => { const value = setTimeout(() => { entry.lifecycleTimers.delete(value); fn(); }, ms); entry.lifecycleTimers.add(value); return value; };
    const settled = () => {
      if (entry.processSettled) return;
      entry.processSettled = true;
      for (const value of entry.lifecycleTimers) clearTimeout(value);
      entry.lifecycleTimers.clear();
      if (entry.child?.off) { entry.child.off('exit', settled); entry.child.off('close', settled); entry.child.off('error', processError); entry.child.on('error', () => {}); }
      if (!entry.closed) close();
      connections.delete(entry); entry.resolveDone();
    };
    const processError = () => { lastError = 'PROXY_ERROR'; if (!entry.closed) fail(502); };
    const kill = signal => {
      if (entry.processSettled) return;
      try { if (entry.child.kill(signal) !== true) { killFailures++; lastError = 'PROXY_KILL_FAILED'; } }
      catch { killFailures++; lastError = 'PROXY_KILL_FAILED'; }
    };
    const close = () => {
      if (entry.closed) return;
      entry.closed = true;
      for (const value of entry.timers) clearTimeout(value);
      for (const [stream, pending] of entry.drains) stream.off('drain', pending.drain);
      entry.drains.clear();
      for (const cleanup of entry.cleanups) cleanup();
      socket.destroy();
      if (entry.child) {
        for (const stream of [entry.child.stdin, entry.child.stdout, entry.child.stderr]) { stream?.on('error', () => {}); stream?.destroy(); }
        if (entry.processSettled) { connections.delete(entry); entry.resolveDone(); return; }
        // 只结束本连接直接创建的 proxy；kill 返回成功也不等于进程已退出。
        kill('SIGTERM');
        if (!entry.processSettled) lifecycleTimer(() => {
          kill('SIGKILL');
          if (!entry.processSettled) lifecycleTimer(() => {
            exitTimeouts++; lastError = 'PROXY_EXIT_TIMEOUT';
            // 退出未确认：报告错误但继续占配额，不允许新连接累积子进程。
            entry.resolveDone();
          }, exitTimeoutMs);
        }, killGraceMs);
      } else settled();
    };
    entry.close = close; connections.add(entry);
    const fail = status => {
      if (entry.closed || entry.failed) return;
      entry.failed = true;
      if (!entry.ready && !socket.destroyed) { entry.child?.stdout?.pause(); reject(socket, status); socket.once('finish', close); timer(close, 100); }
      else close();
    };
    on(socket, 'error', close); on(socket, 'close', close); on(socket, 'end', close);
    const handshakeTimer = timer(() => fail(504), handshakeMs);
    let child;
    const args = ['app-server', 'proxy'];
    if (socketPath !== undefined) args.push('--sock', socketPath);
    try { child = spawn(binary, args, {stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true}); entry.child = child; spawnedClients++; }
    catch { fail(502); return; }
    if (!child?.stdin || !child?.stdout || !child?.stderr || typeof child.kill !== 'function') { fail(502); return; }
    child.on('error', processError); child.once('exit', settled); child.once('close', settled);
    on(child.stdin, 'error', close); on(child.stdout, 'error', close); on(child.stderr, 'error', close);
    on(child.stdout, 'end', close); on(child.stdin, 'close', close);
    // stderr 不记录，持续排空，防止 proxy 因诊断缓冲区填满而挂起。
    child.stderr.resume();
    const forward = (source, destination, chunk) => {
      if (entry.closed) return;
      if (destination.destroyed || destination.writableEnded || destination.writableLength + chunk.length > maxPendingBytes) return close();
      let accepted;
      try { accepted = destination.write(chunk); } catch { close(); return; }
      if (!accepted) {
        source.pause();
        if (entry.drains.has(destination)) return;
        const timeout = timer(close, drainTimeoutMs);
        const drain = () => { entry.drains.delete(destination); clearTimeout(timeout); entry.timers.delete(timeout); if (!entry.closed) source.resume(); };
        entry.drains.set(destination, {drain}); destination.once('drain', drain);
      }
    };
    let upstreamHeaders = Buffer.alloc(0);
    on(child.stdout, 'data', chunk => {
      if (entry.ready) return forward(child.stdout, socket, chunk);
      upstreamHeaders = Buffer.concat([upstreamHeaders, chunk]);
      const split = upstreamHeaders.indexOf('\r\n\r\n');
      if (split < 0) { if (upstreamHeaders.length > 16384) fail(502); return; }
      if (split > 16384) return fail(502);
      const lines = upstreamHeaders.subarray(0, split).toString('latin1').split('\r\n'), headers = new Map();
      if (!/^HTTP\/1\.[01] 101(?: |$)/.test(lines.shift())) return fail(502);
      for (const line of lines) { const index = line.indexOf(':'); if (index < 1) return fail(502); const name = line.slice(0, index).toLowerCase(); if (headers.has(name)) return fail(502); headers.set(name, line.slice(index + 1).trim()); }
      const accept = crypto.createHash('sha1').update(req.headers['sec-websocket-key'] + GUID).digest('base64');
      if (headers.get('sec-websocket-accept') !== accept || headers.get('upgrade')?.toLowerCase() !== 'websocket' || !headers.get('connection')?.toLowerCase().split(',').map(value => value.trim()).includes('upgrade')) return fail(502);
      if (headers.has('sec-websocket-protocol') && !req.headers['sec-websocket-protocol']?.split(',').map(value => value.trim()).includes(headers.get('sec-websocket-protocol'))) return fail(502);
      entry.ready = true; clearTimeout(handshakeTimer); entry.timers.delete(handshakeTimer); socket.setTimeout(0);
      forward(child.stdout, socket, upstreamHeaders); upstreamHeaders = null;
      if (!entry.closed && !entry.drains.has(child.stdin)) socket.resume();
    });
    on(socket, 'data', chunk => forward(socket, child.stdin, chunk));
    const headers = ['GET / HTTP/1.1', 'Host: localhost', 'Connection: Upgrade', 'Upgrade: websocket', `Sec-WebSocket-Key: ${req.headers['sec-websocket-key']}`, 'Sec-WebSocket-Version: 13'];
    for (const name of ['sec-websocket-protocol', 'sec-websocket-extensions']) if (req.headers[name] !== undefined) headers.push(`${name}: ${req.headers[name]}`);
    forward(socket, child.stdin, Buffer.from(headers.join('\r\n') + '\r\n\r\n', 'latin1'));
    if (head.length) forward(socket, child.stdin, head);
  });
  const close = () => {
    if (closePromise) return closePromise;
    closing = true;
    for (const entry of [...connections]) entry.close();
    for (const socket of httpSockets) socket.destroy();
    closePromise = Promise.all([new Promise(resolve => server.close(() => resolve())), ...[...connections].map(entry => entry.done)]).then(() => {
      const remainingProxies = [...connections].filter(entry => entry.child && !entry.processSettled).length;
      return {ok: remainingProxies === 0, remainingProxies, killFailures, exitTimeouts};
    });
    return closePromise;
  };
  return {server, close, getStats: () => ({activeClients: [...connections].filter(entry => !entry.closed).length, activeProxies: [...connections].filter(entry => entry.child && !entry.processSettled).length, occupiedSlots: connections.size, spawnedClients, maxClients, killFailures, exitTimeouts, lastError})};
}

module.exports = {createBroker};
if (require.main === module) {
  const broker = createBroker({token: process.env.SHARED_ENGINE_TOKEN ?? process.env.BROKER_TOKEN, binary: process.env.CODEX_BINARY ?? 'codex', socketPath: process.env.SHARED_ENGINE_SOCKET_PATH});
  const port = Number(process.env.PORT ?? 29441);
  broker.server.listen(port, '127.0.0.1', () => console.log(`Shared engine broker listening on 127.0.0.1:${broker.server.address().port}`));
  for (const signal of ['SIGINT', 'SIGTERM']) process.once(signal, () => broker.close().then(report => { if (!report.ok) console.error('PROXY_CLEANUP_INCOMPLETE'); process.exit(report.ok ? 0 : 1); }));
}
