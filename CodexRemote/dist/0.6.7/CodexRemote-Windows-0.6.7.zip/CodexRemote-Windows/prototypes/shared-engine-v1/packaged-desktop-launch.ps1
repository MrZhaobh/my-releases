#requires -Version 7.0

function ConvertTo-PackagedDesktopArgument([string]$Value) {
    if ($Value -match '["\x00-\x1f\x7f]') { throw 'PACKAGED_DESKTOP_ARGUMENT_INVALID' }
    return '"' + $Value + '"'
}

function Start-PackagedDesktopHost([Diagnostics.ProcessStartInfo]$StartInfo) {
    $hostProcess = [Diagnostics.Process]::Start($StartInfo)
    $hostProcess | Add-Member -NotePropertyName SafeOutputTask -NotePropertyValue ($hostProcess.StandardOutput.ReadToEndAsync())
    $null = $hostProcess.StandardError.ReadToEndAsync()
    return $hostProcess
}

function Assert-PackagedDesktopPrivatePath([string]$Path) {
    $currentSid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    $acl = Get-Acl -LiteralPath $Path
    foreach ($rule in $acl.Access) {
        if ($rule.AccessControlType -eq [Security.AccessControl.AccessControlType]::Allow -and
            @($currentSid, 'S-1-5-18', 'S-1-5-32-544') -notcontains $rule.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value) { throw 'PACKAGED_DESKTOP_CONFIG_NOT_PRIVATE' }
    }
}

function Start-PackagedDesktop {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ConfigPath,
        [Parameter(Mandatory)][ValidateSet('Shared', 'Original')][string]$Mode,
        [switch]$ProbeOnly
    )
    $ErrorActionPreference = 'Stop'
    $hostProcess = $null
    $resultPath = $null
    try {
        if ($ProbeOnly -and $Mode -ne 'Shared') { throw 'PACKAGED_PROBE_MODE_INVALID' }
        if (-not $ProbeOnly -and (Get-Process -Name ChatGPT -ErrorAction SilentlyContinue)) { throw 'PACKAGED_DESKTOP_ALREADY_RUNNING' }
        $ConfigPath = (Resolve-Path -LiteralPath $ConfigPath).Path
        if (-not (Test-Path -LiteralPath $ConfigPath -PathType Leaf)) { throw 'PACKAGED_DESKTOP_CONFIG_INVALID' }
        $root = Split-Path -Parent $ConfigPath
        Assert-PackagedDesktopPrivatePath $ConfigPath
        Assert-PackagedDesktopPrivatePath $root
        $resultPath = Join-Path $root ('packaged-desktop-result-' + [Guid]::NewGuid().ToString() + '.json')
        $script = Join-Path $PSScriptRoot 'invoke-packaged-desktop.ps1'
        $powershell = Join-Path $env:SystemRoot 'System32/WindowsPowerShell/v1.0/powershell.exe'
        if (-not (Test-Path -LiteralPath $script -PathType Leaf) -or -not (Test-Path -LiteralPath $powershell -PathType Leaf)) { throw 'PACKAGED_DESKTOP_HELPER_MISSING' }
        $start = [Diagnostics.ProcessStartInfo]::new()
        $start.FileName = $powershell
        $start.WorkingDirectory = [IO.Path]::GetDirectoryName($powershell)
        $start.UseShellExecute = $false
        $start.CreateNoWindow = $true
        $start.WindowStyle = [Diagnostics.ProcessWindowStyle]::Hidden
        $start.RedirectStandardOutput = $true
        $start.RedirectStandardError = $true
        # Process.Start 不会像 PowerShell 原生命令调用那样修正 PSModulePath。
        # 避免 PS5 继承 PS7 模块目录，导致 Get-Acl/Appx 等系统命令无法自动加载。
        $start.Environment.Remove('PSModulePath') | Out-Null
        $start.Arguments = '-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File ' + (ConvertTo-PackagedDesktopArgument $script) + ' -ConfigPath ' + (ConvertTo-PackagedDesktopArgument $ConfigPath) + ' -ResultPath ' + (ConvertTo-PackagedDesktopArgument $resultPath) + ' -Mode ' + $Mode
        if ($ProbeOnly) { $start.Arguments += ' -ProbeOnly' }
        if (-not $ProbeOnly -and (Get-Process -Name ChatGPT -ErrorAction SilentlyContinue)) { throw 'PACKAGED_DESKTOP_ALREADY_RUNNING' }
        # 覆盖 PS5 启动、包激活以及内层18秒等待，避免外层提前抹去失败回执。
        $deadline = [DateTime]::UtcNow.AddSeconds(45)
        $hostProcess = Start-PackagedDesktopHost $start
        while ([DateTime]::UtcNow -lt $deadline) {
            if ($hostProcess.HasExited) { break }
            Start-Sleep -Milliseconds 100
        }
        if (-not $hostProcess.HasExited) {
            [IO.File]::WriteAllText($resultPath + '.cancel', 'cancelled')
            if (-not $hostProcess.HasExited) { try { $hostProcess.Kill() } catch { } }
            throw 'PACKAGED_DESKTOP_RESULT_TIMEOUT'
        }
        if (-not (Test-Path -LiteralPath $resultPath -PathType Leaf)) { throw 'PACKAGED_DESKTOP_HOST_EXITED_WITHOUT_RESULT' }
        $resultFile = Get-Item -LiteralPath $resultPath
        if ($resultFile.Length -gt 4096) { throw 'PACKAGED_DESKTOP_RESULT_INVALID' }
        $result = Get-Content -Raw -LiteralPath $resultPath | ConvertFrom-Json
        if ([bool]$result.probeOnly -ne [bool]$ProbeOnly) { throw 'PACKAGED_DESKTOP_RESULT_INVALID' }
        if ($result.ok -ne $true -or $result.mode -ne $Mode -or $result.pid -isnot [long] -and $result.pid -isnot [int] -or $result.pid -le 0) { throw 'PACKAGED_DESKTOP_START_FAILED' }
        return [pscustomobject]@{ ok = $true; mode = $Mode; pid = $result.pid; resultPath = $resultPath; probeOnly = [bool]$ProbeOnly }
    } catch {
        if ($resultPath) {
            $knownCodes = @('PACKAGED_DESKTOP_RESULT_TIMEOUT','PACKAGED_DESKTOP_HOST_EXITED_WITHOUT_RESULT','PACKAGED_DESKTOP_RESULT_INVALID','PACKAGED_DESKTOP_START_FAILED')
            $code = if ($_.Exception.Message -in $knownCodes) { $_.Exception.Message } else { 'PACKAGED_DESKTOP_LAUNCH_FAILED' }
            $diagnostic = @{code=$code;at=[DateTimeOffset]::Now.ToString('o');probeOnly=[bool]$ProbeOnly}
            if ($hostProcess -and $hostProcess.HasExited -and $hostProcess -is [Diagnostics.Process]) { $diagnostic.hostExitCode=$hostProcess.ExitCode }
            if ($hostProcess.SafeOutputTask -and $hostProcess.SafeOutputTask.IsCompletedSuccessfully) {
                # 仅提取由 parent 生成的固定标记，绝不持久化原始 stdout/stderr。
                $safeOutput = $hostProcess.SafeOutputTask.Result
                $lineMatch = [regex]::Match($safeOutput,'(?m)^PACKAGED_PARENT_ERROR_LINE_([0-9]{1,6})\r?$')
                if ($lineMatch.Success) { $diagnostic.parentLine=[int]$lineMatch.Groups[1].Value }
                $typeMatch = [regex]::Match($safeOutput,'(?m)^(System\.[A-Za-z.]{1,150}Exception)\r?$')
                if ($typeMatch.Success) { $diagnostic.parentExceptionType=$typeMatch.Groups[1].Value }
            }
            try { $diagnostic | ConvertTo-Json | Set-Content -LiteralPath ($resultPath+'.launcher.json') -Encoding utf8 } catch { Write-Warning 'PACKAGED_LAUNCH_DIAGNOSTIC_WRITE_FAILED' }
        }
        # 外层固定失败码；绝不将配置、环境、命令或原始 exception message 输出。
        throw 'PACKAGED_DESKTOP_LAUNCH_FAILED'
    } finally {
        if ($null -ne $hostProcess -and $hostProcess -is [Diagnostics.Process]) { $hostProcess.Dispose() }
    }
}
