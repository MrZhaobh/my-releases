'use strict';

const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const childProcess = require('node:child_process');

const failure = (code, message) => Object.assign(new Error(message), {code});
const bounded = (value, fallback, minimum, maximum, name) => {
  const result = value ?? fallback;
  if (!Number.isSafeInteger(result) || result < minimum || result > maximum) throw failure('BAD_INPUT', `${name} 超出范围。`);
  return result;
};

function validateSocketPath(value) {
  if (typeof value !== 'string' || /[\x00-\x1f\x7f]/u.test(value) || Buffer.byteLength(value, 'utf8') >= 104) throw failure('BAD_INPUT', 'socketPath 必须为短的 Windows 完整绝对路径。');
  const normalized = path.win32.normalize(value);
  const drive = /^[a-zA-Z]:[\\/]/u.test(value);
  const unc = /^\\\\[^\\/?]+\\[^\\/?]+\\[^\\]+/u.test(value) && !/^\\\\[?.]\\/u.test(value);
  if ((!drive && !unc) || !path.win32.isAbsolute(value) || /[<>"|?*]/u.test(value) || value.slice(drive ? 2 : 0).includes(':') || /[\\/]$/u.test(value) || Buffer.byteLength(normalized, 'utf8') >= 104) throw failure('BAD_INPUT', 'socketPath 必须为 Windows 完整绝对路径。');
  return normalized;
}

function probeSocket(socketPath, {signal, timeoutMs = 250} = {}) {
  return new Promise(resolve => {
    if (signal?.aborted) { resolve(false); return; }
    let socket, timer, finished = false;
    const done = ready => {
      if (finished) return; finished = true;
      clearTimeout(timer); signal?.removeEventListener('abort', cancelled);
      socket?.destroy(); resolve(ready);
    };
    const cancelled = () => done(false);
    try {
      socket = net.connect({path:socketPath});
      socket.once('connect', () => done(true)); socket.once('error', () => done(false));
      timer = setTimeout(() => done(false), timeoutMs);
      signal?.addEventListener('abort', cancelled, {once:true});
    } catch { done(false); }
  });
}

function directoryEntryExists(socketPath) {
  try { return fs.readdirSync(path.win32.dirname(socketPath)).includes(path.win32.basename(socketPath)); }
  catch { return false; }
}

class OwnedEngine {
  constructor({binary, socketPath, spawn = childProcess.spawn, probe, startupMs, graceMs, killMs, configOverrides = [], envOverrides = {}} = {}) {
    if (typeof binary !== 'string' || !binary.trim() || binary.length > 4096 || /[\x00-\x1f\x7f]/u.test(binary) || typeof spawn !== 'function' || (probe !== undefined && typeof probe !== 'function')) throw failure('BAD_INPUT', '必须提供有效的引擎程序和启动配置。');
    this.binary = binary; this.socketPath = validateSocketPath(socketPath);
    if(!Array.isArray(configOverrides)||configOverrides.length>16||configOverrides.some(x=>typeof x!=='string'||!x||/[\x00-\x1f\x7f]/.test(x))||configOverrides.join('').length>24000)throw failure('BAD_INPUT','引擎启动覆盖超出限制。');
    this.configOverrides=[...configOverrides];
    if(!envOverrides||typeof envOverrides!=='object'||Array.isArray(envOverrides)||Object.entries(envOverrides).some(([key,value])=>!['CODEX_APP_TOOLS_PIPE_PATH','CODEX_MCP_NODE_PATH'].includes(key)||typeof value!=='string'||!value||value.length>4096||/[\x00-\x1f\x7f]/.test(value)))throw failure('BAD_INPUT','引擎子环境覆盖无效。');
    this.envOverrides={...envOverrides};
    this.spawn = spawn;
    this.probeKind = probe ? 'injected' : process.platform === 'win32' ? 'directoryEntry' : 'netConnect';
    // Windows Node 对原生 AF_UNIX reparse point 的 lstat/connect 可能报 EACCES。
    // entry 仅代表候选就绪；调用方仍需通过 native proxy 完成 initialize 验收。
    this.probe = probe ?? (process.platform === 'win32' ? directoryEntryExists : probeSocket);
    this.startupMs = bounded(startupMs, 15000, 1, 120000, 'startupMs');
    this.graceMs = bounded(graceMs, 1500, 0, 30000, 'graceMs');
    this.killMs = bounded(killMs, 1500, 0, 30000, 'killMs');
    this.child = null; this.state = 'stopped'; this.stopRequested = false;
    this.startPromise = null; this.stopPromise = null; this.abort = null; this.errorCode = null;
  }

  status() {
    const child = this.child;
    return {state:this.state, pid:child?.proc?.pid ?? null, running:!!child && !child.exited, startedByUs:!!child, started:!!child && Number.isInteger(child.proc.pid) && child.proc.pid > 0, exited:child?.exited === true, probeKind:this.probeKind, candidateReady:['candidateReady','ready'].includes(this.state) && !!child && !child.exited, ready:this.state === 'ready' && !!child && !child.exited, killFailed:child?.killFailed === true, ...(this.errorCode ? {errorCode:this.errorCode} : {}), ...(child?.socketCleanup ? {socketCleanup:child.socketCleanup} : {})};
  }

  _captureSocket(child) {
    if (child.exited || child.socketIdentity) return;
    try {
      const stat = fs.lstatSync(this.socketPath);
      // 不认领目录、普通文件或链接；仅保存启动后出现的 socket 身份。
      if (stat.isSocket()) child.socketIdentity = {dev:stat.dev, ino:stat.ino, birthtimeMs:stat.birthtimeMs};
      else child.socketCleanup = 'retained-nonSocket';
    } catch (error) {
      if (process.platform === 'win32' && error?.code === 'EACCES' && directoryEntryExists(this.socketPath)) child.socketCleanup = 'retained-uninspectable';
    }
  }

  _cleanupSocket(child) {
    if (!child.exited || !child.socketIdentity) return;
    try {
      const stat = fs.lstatSync(this.socketPath), saved = child.socketIdentity;
      const same = saved.ino !== 0 && stat.ino !== 0 ? saved.dev === stat.dev && saved.ino === stat.ino : saved.dev === stat.dev && saved.birthtimeMs === stat.birthtimeMs;
      if (!stat.isSocket() || !same) { child.socketCleanup = 'retained'; return; }
      fs.unlinkSync(this.socketPath); child.socketCleanup = 'removed';
    } catch (error) { child.socketCleanup = error?.code === 'ENOENT' ? 'absent' : 'failed'; }
  }

  _launch() {
    if (process.platform === 'win32' && directoryEntryExists(this.socketPath)) throw failure('SOCKET_EXISTS', '专用 socket 路径已存在，已拒绝启动且不会删除。');
    try { fs.lstatSync(this.socketPath); throw failure('SOCKET_EXISTS', '专用 socket 路径已存在，已拒绝启动且不会删除。'); }
    catch (error) { if (error?.code !== 'ENOENT') throw error?.code === 'SOCKET_EXISTS' ? error : failure('SOCKET_CHECK_FAILED', '无法确认专用 socket 路径可用。'); }
    let proc;
    try { proc = this.spawn(this.binary, ['app-server', '--listen', 'unix://' + this.socketPath, '-c', 'thread_unload_delay_secs=1',...this.configOverrides.flatMap(value=>['-c',value])], {windowsHide:true, stdio:['ignore','ignore','ignore'],...(Object.keys(this.envOverrides).length?{env:{...process.env,...this.envOverrides}}:{})}); }
    catch { throw failure('SPAWN_FAILED', '专用共享引擎启动失败。'); }
    if (!proc || typeof proc.on !== 'function' || typeof proc.kill !== 'function') throw failure('SPAWN_FAILED', '专用共享引擎未返回有效进程句柄。');
    const child = {proc, exited:false, stopPromise:null, socketIdentity:null, socketCleanup:null};
    child.exitPromise = new Promise(resolve => { child.resolveExit = resolve; });
    this.child = child;
    const ended = () => {
      if (child.exited) return;
      child.exited = true; child.resolveExit();
      if (this.child === child) { this.abort?.abort(); this.state = this.stopRequested ? 'stopped' : 'exited'; }
      this._cleanupSocket(child);
    };
    proc.once('exit', ended); proc.once('close', ended);
    proc.on('error', () => {
      // kill 的 error 不能当成退出；只有未获得 PID 的 spawn 失败可确认未启动。
      child.hadError = true;
      if (!proc.pid) ended();
    });
    return child;
  }

  async _probeOnce(child, remaining) {
    const signal = this.abort.signal;
    return new Promise(resolve => {
      let done = false;
      const finish = result => { if (done) return; done = true; clearTimeout(timer); signal.removeEventListener('abort', cancelled); resolve(result === true); };
      const cancelled = () => finish(false);
      const timer = setTimeout(() => finish(false), Math.min(remaining, 250));
      signal.addEventListener('abort', cancelled, {once:true});
      if (signal.aborted) { finish(false); return; }
      Promise.resolve().then(() => this.probe(this.socketPath, {signal, timeoutMs:Math.min(remaining,250), child:child.proc})).then(finish, () => finish(false));
    });
  }

  async start() {
    if (this.stopRequested) throw failure('START_CANCELLED', '专用引擎已停止，不会再次启动。');
    if (['candidateReady','ready'].includes(this.state) && this.child && !this.child.exited) return this.status();
    if (this.startPromise) return this.startPromise;
    if (this.child && !this.child.exited) throw failure('PROCESS_STILL_RUNNING', '上次专用引擎尚未确认退出，不能重复启动。');
    const task = (async () => {
      this.state = 'starting'; this.errorCode = null; this.abort = new AbortController();
      let child;
      try {
        child = this._launch();
        const deadline = Date.now() + this.startupMs;
        while (Date.now() < deadline) {
          if (this.stopRequested) throw failure('START_CANCELLED', '专用引擎启动已取消。');
          if (child.exited || child.hadError) throw failure('START_EXITED', '专用引擎在就绪前退出或启动失败。');
          this._captureSocket(child);
          const ready = await this._probeOnce(child, deadline - Date.now());
          if (this.stopRequested) throw failure('START_CANCELLED', '专用引擎启动已取消。');
          if (child.exited || child.hadError) throw failure('START_EXITED', '专用引擎在就绪前退出或启动失败。');
          if (ready) { this._captureSocket(child); this.state = this.probeKind === 'directoryEntry' ? 'candidateReady' : 'ready'; return this.status(); }
          await new Promise(resolve => setTimeout(resolve, Math.min(10, Math.max(0,deadline-Date.now()))));
        }
        throw failure('START_TIMEOUT', '等待专用共享引擎就绪超时。');
      } catch (error) {
        const safe = ['SOCKET_EXISTS','SOCKET_CHECK_FAILED','SPAWN_FAILED','START_CANCELLED','START_EXITED','START_TIMEOUT'].includes(error?.code) ? error : failure('START_FAILED', '专用共享引擎启动失败。');
        this.errorCode = safe.code;
        if (child && !child.exited) { this._captureSocket(child); await this._stopChild(child); }
        this.state = child && !child.exited ? 'stillRunning' : this.stopRequested ? 'stopped' : 'failed';
        if (child && !child.exited) { this.errorCode = 'PROCESS_STILL_RUNNING'; throw failure('PROCESS_STILL_RUNNING', '启动未完成且专用引擎尚未确认退出。'); }
        throw safe;
      }
    })();
    this.startPromise = task;
    try { return await task; } finally { if (this.startPromise === task) this.startPromise = null; }
  }

  async _waitExit(child, timeoutMs) {
    if (child.exited) return true;
    await new Promise(resolve => {
      const timer = setTimeout(resolve, timeoutMs);
      child.exitPromise.then(() => { clearTimeout(timer); resolve(); });
    });
    return child.exited;
  }

  async _stopChild(child) {
    if (child.exited) { this._cleanupSocket(child); return true; }
    if (child.stopPromise) return child.stopPromise;
    const task = (async () => {
      this._captureSocket(child);
      try { if (child.proc.kill('SIGTERM') === false) child.killFailed = true; } catch { child.killFailed = true; }
      if (await this._waitExit(child, this.graceMs)) return true;
      try { if (child.proc.kill('SIGKILL') === false) child.killFailed = true; } catch { child.killFailed = true; }
      return this._waitExit(child, this.killMs);
    })();
    child.stopPromise = task;
    try { return await task; } finally { if (!child.exited && child.stopPromise === task) child.stopPromise = null; }
  }

  async stop() {
    this.stopRequested = true; this.abort?.abort();
    if (this.stopPromise) return this.stopPromise;
    const task = (async () => {
      const child = this.child;
      if (!child) { this.state = 'stopped'; return {...this.status(), ok:true}; }
      this.state = 'stopping';
      const stopped = await this._stopChild(child);
      if (stopped) { this.state = 'stopped'; this._cleanupSocket(child); return {...this.status(), ok:true}; }
      this.state = 'stillRunning'; this.errorCode = 'PROCESS_STILL_RUNNING';
      return {...this.status(), ok:false};
    })();
    this.stopPromise = task;
    try { return await task; } finally { if (this.stopPromise === task) this.stopPromise = null; }
  }
}

module.exports = {OwnedEngine};
