'use strict';
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto');
const FIELDS=['instanceConfigPath','instanceConfigFingerprint','instanceConfigModulePath','instanceConfigModuleFingerprint','isolatedCodexHome','apiKeyEnvironmentVariable','enhancedRuntimeDirectory'];
const fail=code=>Object.assign(new Error(code),{code});
const safe=value=>typeof value==='string'&&value.length>0&&value.length<4096&&path.isAbsolute(value)&&!/["\x00-\x1f\x7f]/.test(value);
const same=(a,b)=>path.resolve(a).toLowerCase()===path.resolve(b).toLowerCase();
function inside(root,file){const relative=path.relative(root,file);return !!relative&&relative!=='..'&&!relative.startsWith('..'+path.sep)&&!path.isAbsolute(relative);}
function checkedFile(file,limit,code){
  if(!safe(file))throw fail(code);
  const resolved=fs.realpathSync(file),stat=fs.lstatSync(file);
  if(!same(resolved,file)||stat.isSymbolicLink()||!stat.isFile()||stat.size>limit)throw fail(code);
  const buffer=fs.readFileSync(file);if(buffer.length>limit)throw fail(code);return buffer;
}
function parseInstanceJson(bytes){
  const text=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(bytes).replace(/^\uFEFF/,'');
  const result=JSON.parse(text),keys=new Set();let index=0;
  const whitespace=()=>{while(/[\t\r\n ]/.test(text[index]??'\u0000'))index++;};
  const string=()=>{const pattern=/"(?:[^"\\\x00-\x1f]|\\(?:["\\/bfnrt]|u[0-9a-fA-F]{4}))*"/y;pattern.lastIndex=index;const match=pattern.exec(text);if(!match)throw Error();index=pattern.lastIndex;return JSON.parse(match[0]);};
  whitespace();if(text[index++]!=='{')throw Error();whitespace();
  if(text[index]!=='}')for(;;){const key=string();if(keys.has(key))throw Error();keys.add(key);whitespace();if(text[index++]!==':')throw Error();whitespace();if(text[index]==='"')string();else if(text.slice(index,index+4)==='null')index+=4;else throw Error();whitespace();if(text[index]!==',')break;index++;whitespace();}
  if(text[index++]!=='}')throw Error();whitespace();if(index!==text.length)throw Error();return result;
}
function readIsolatedInstance(config){
  try{
    if(!config||!FIELDS.every(key=>typeof config[key]==='string')||!safe(config.enhancedProfileDirectory)||!safe(config.enhancedLauncher))throw Error();
    if(!same(config.instanceConfigModulePath,path.join(path.dirname(config.enhancedLauncher),'src','instance-config.ps1')))throw Error();
    if(!/^[a-f0-9]{64}$/i.test(config.instanceConfigFingerprint)||!/^[a-f0-9]{64}$/i.test(config.instanceConfigModuleFingerprint))throw Error();
    const bytes=checkedFile(config.instanceConfigPath,32768,'ISOLATED_INSTANCE_INVALID');
    const moduleBytes=checkedFile(config.instanceConfigModulePath,262144,'ISOLATED_INSTANCE_INVALID');
    if(crypto.createHash('sha256').update(bytes).digest('hex')!==config.instanceConfigFingerprint.toLowerCase()||crypto.createHash('sha256').update(moduleBytes).digest('hex')!==config.instanceConfigModuleFingerprint.toLowerCase())throw Error();
    const raw=parseInstanceJson(bytes);
    if(!raw||Array.isArray(raw)||Object.keys(raw).some(key=>!['runtimeRoot','profileRoot','codexHome','apiKeyEnvironmentVariable','usageProvider'].includes(key)))throw Error();
    if(!/^CODEX_[A-Z0-9_]+_API_KEY$/.test(raw.apiKeyEnvironmentVariable??'')||raw.apiKeyEnvironmentVariable.length>128||raw.apiKeyEnvironmentVariable!==config.apiKeyEnvironmentVariable)throw Error();
    if(raw.usageProvider!==undefined&&raw.usageProvider!==null&&!['litellm-user-budget','bailian-local-usage'].includes(raw.usageProvider))throw Error();
    const root=path.dirname(fs.realpathSync(config.instanceConfigPath)),paths={};
    for(const key of ['runtimeRoot','profileRoot','codexHome']){
      const value=raw[key];if(typeof value!=='string'||!value||value.length>=4096||/[<>:"|?*\x00-\x1f\x7f]/.test(value)||/^[\\/]/.test(value))throw Error();
      const parts=value.replace(/[\\/]+$/,'').split(/[\\/]+/);if(parts.some(part=>!part||part==='.'||part==='..'||/[. ]$/.test(part)||/^(?:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)/i.test(part)))throw Error();
      const target=path.resolve(root,value);if(!inside(root,target))throw Error();
      const protectedRoots=[path.join(path.dirname(path.dirname(config.instanceConfigModulePath)),'.runtime'),path.join(os.homedir(),'.codex')];
      if(protectedRoots.some(protectedRoot=>same(target,protectedRoot)||inside(protectedRoot,target)||inside(target,protectedRoot)))throw Error();
      let existing=target;while(!fs.existsSync(existing)){const parent=path.dirname(existing);if(parent===existing)throw Error();existing=parent;}
      if(!same(fs.realpathSync(existing),existing)||(!same(existing,root)&&!inside(root,fs.realpathSync(existing))))throw Error();
      if(!fs.statSync(existing).isDirectory())throw Error();
      paths[key]=target;
    }
    const values=Object.values(paths);for(let a=0;a<values.length;a++)for(let b=a+1;b<values.length;b++)if(same(values[a],values[b])||inside(values[a],values[b])||inside(values[b],values[a]))throw Error();
    if(!same(paths.codexHome,config.isolatedCodexHome)||!same(paths.profileRoot,config.enhancedProfileDirectory)||!same(paths.runtimeRoot,config.enhancedRuntimeDirectory))throw Error();
    return {...paths,apiKeyEnvironmentVariable:raw.apiKeyEnvironmentVariable};
  }catch{throw fail('ISOLATED_INSTANCE_INVALID');}
}
function createIsolatedSpawn(config,spawn){
  if(!FIELDS.some(key=>config?.[key]!==undefined))return spawn;
  // 凭据仅在实际创建引擎子进程时读取，不放入持久配置、参数或状态。
  return (binary,args,options={})=>{
    const isolated=readIsolatedInstance(config);let key;
    try{
      const file=path.join(isolated.codexHome,'auth.json'),bytes=checkedFile(file,65536,'ISOLATED_AUTH_INVALID');
      if(!inside(fs.realpathSync(isolated.codexHome),fs.realpathSync(file)))throw Error();
      key=JSON.parse(new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(bytes).replace(/^\uFEFF/,''))?.OPENAI_API_KEY;
      if(typeof key!=='string'||!/^[\x21-\x7e]{1,8192}$/.test(key))throw Error();
    }catch{throw fail('ISOLATED_AUTH_INVALID');}
    const env={...(options.env??process.env)};
    const replaced=new Set(['CODEX_HOME','CODEX_ELECTRON_USER_DATA_PATH',isolated.apiKeyEnvironmentVariable].map(x=>x.toLowerCase()));
    for(const name of Object.keys(env))if(replaced.has(name.toLowerCase()))delete env[name];
    env.CODEX_HOME=isolated.codexHome;env.CODEX_ELECTRON_USER_DATA_PATH=isolated.profileRoot;env[isolated.apiKeyEnvironmentVariable]=key;
    return spawn(binary,args,{...options,cwd:path.dirname(config.instanceConfigPath),env});
  };
}
module.exports={FIELDS,readIsolatedInstance,createIsolatedSpawn};
