﻿#requires -Version 7.0
function Start-EnhancedDesktop {
    param(
        [Parameter(Mandatory)][string]$ConfigPath,
        [Parameter(Mandatory)][ValidateSet('Shared','Original')][string]$Mode,
        [switch]$PrepareOnly,
        [scriptblock]$ProcessLauncher = {param($path,$mode) Start-PackagedDesktop -ConfigPath $path -Mode $mode},
        [scriptblock]$PortListening = {param($port) @([Net.NetworkInformation.IPGlobalProperties]::GetIPGlobalProperties().GetActiveTcpListeners()|Where-Object Port -eq $port).Count -gt 0}
    )
    $ErrorActionPreference='Stop'
    $integrationConfigPath=(Resolve-Path -LiteralPath $ConfigPath).Path
    $integrationConfig=Get-Content -Raw -LiteralPath $integrationConfigPath|ConvertFrom-Json
    $integrationModule=Join-Path $PSScriptRoot 'packaged-desktop-launch.ps1'
    $integrationLauncher=[string]$integrationConfig.enhancedLauncher
    $integrationProfile=[string]$integrationConfig.enhancedProfileDirectory
    $integrationPort=$integrationConfig.enhancedPort
    if(-not [IO.Path]::IsPathFullyQualified($integrationLauncher) -or -not (Test-Path -LiteralPath $integrationLauncher -PathType Leaf) -or
        -not [IO.Path]::IsPathFullyQualified($integrationProfile) -or -not (Test-Path -LiteralPath $integrationProfile -PathType Container) -or
        $integrationProfile -match '["\x00-\x1f\x7f]' -or $integrationPort -isnot [long] -and $integrationPort -isnot [int] -or
        $integrationPort -lt 1 -or $integrationPort -gt 65535){throw 'ENHANCED_CONFIG_INVALID'}
    . (Join-Path $PSScriptRoot 'isolated-desktop-config.ps1')
    $integrationSelection=Read-IsolatedDesktopSelection $integrationConfig
    if($PrepareOnly){return [pscustomobject]@{ok=$true;preparedOnly=$true;mode=$Mode}}
    if(Get-Process -Name ChatGPT -ErrorAction SilentlyContinue){throw 'ENHANCED_DESKTOP_ALREADY_RUNNING'}
    # 启动器清理PSModulePath后，原增强工具仍依赖NetTCPIP检查旧记录和端口归属。
    # 显式载入系统模块，保留原工具的完整身份校验，不将查询失败当作端口空闲。
    Import-Module -Name (Join-Path $env:SystemRoot 'System32/WindowsPowerShell/v1.0/Modules/NetTCPIP/NetTCPIP.psd1') -ErrorAction Stop
    # 只在本次适配器作用域载入原工具；status不启动/注入，原仓库文件保持不变。
    if($integrationSelection){. $integrationLauncher -Command status -InstanceConfigPath $integrationSelection.configPath | Out-Null}else{. $integrationLauncher -Command status | Out-Null}
    if((Get-IsolatedDesktopCanonicalPath $ProfileRoot) -ine (Get-IsolatedDesktopCanonicalPath $integrationProfile)){throw 'ENHANCED_PROFILE_MISMATCH'}
    if($integrationSelection){
        if(-not $InstanceConfig -or (Get-IsolatedDesktopCanonicalPath ([string]$InstanceConfig.configPath)) -ine $integrationSelection.configPath -or (Get-IsolatedDesktopCanonicalPath ([string]$InstanceConfig.codexHome)) -ine $integrationSelection.codexHome -or (Get-IsolatedDesktopCanonicalPath ([string]$InstanceConfig.runtimeRoot)) -ine $integrationSelection.runtimeRoot -or (Get-IsolatedDesktopCanonicalPath ([string]$InstanceConfig.profileRoot)) -ine $integrationSelection.profileRoot -or [string]$InstanceConfig.apiKeyEnvironmentVariable -cne $integrationSelection.apiKeyEnvironmentVariable){throw 'ENHANCED_PROFILE_MISMATCH'}
        $ProfileRoot=$integrationSelection.profileRoot;$RuntimeRoot=$integrationSelection.runtimeRoot
        $InstanceConfig.profileRoot=$integrationSelection.profileRoot;$InstanceConfig.runtimeRoot=$integrationSelection.runtimeRoot;$InstanceConfig.codexHome=$integrationSelection.codexHome
        if(-not (Get-Command Assert-IsolatedCodexModelConfig -CommandType Function -ErrorAction SilentlyContinue)){throw 'ENHANCED_ISOLATED_MODEL_VALIDATOR_MISSING'}
        Assert-IsolatedCodexModelConfig $InstanceConfig
        $null=Read-IsolatedDesktopSelection $integrationConfig
    }elseif($InstanceConfig){throw 'ENHANCED_PROFILE_MISMATCH'}
    . $integrationModule
    function Get-FreeLoopbackPort {
        if(& $PortListening $integrationPort){throw 'ENHANCED_EXISTING_PORT_IN_USE'}
        return [int]$integrationPort
    }
    function Start-PackagedCodex([string]$Arguments){
        $expected='--remote-debugging-address=127.0.0.1 --remote-debugging-port='+$integrationPort+' --user-data-dir="'+$ProfileRoot+'"'
        if($Arguments -cne $expected){throw 'ENHANCED_ARGUMENTS_MISMATCH'}
        $receipt=& $ProcessLauncher $integrationConfigPath $Mode
        if($receipt.ok -ne $true -or $receipt.pid -le 0){throw 'ENHANCED_PACKAGE_START_FAILED'}
        return [int]$receipt.pid
    }
    # 原工具继续负责其既有profile、UI增强、watcher与身份核验；本工具不新增CDP端口/注入逻辑。
    try{$response=Start-ManagedCodex}catch{throw 'ENHANCED_START_FAILED'}
    if(-not $response.running -or $response.state.rootPid -le 0){throw 'ENHANCED_START_NOT_CONFIRMED'}
    return [pscustomobject]@{ok=$true;mode=$Mode;pid=[int]$response.state.rootPid;enhanced=$true;port=[int]$integrationPort}
}
