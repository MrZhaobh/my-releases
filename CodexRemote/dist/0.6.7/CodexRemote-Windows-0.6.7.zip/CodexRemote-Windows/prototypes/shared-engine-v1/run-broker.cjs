'use strict';
const fs = require('node:fs');
const path = require('node:path');
const {createBroker} = require('./broker.cjs');
const {OwnedEngine} = require('./owned-engine.cjs');
const {createIsolatedSpawn}=require('./isolated-instance.cjs');
const {SharedClient} = require('./client.cjs');
const {buildAppToolsOverrides,buildPluginAppToolsOverrides}=require('./app-tools-config.cjs');
const {discoverOwners,selectOwner}=require('./app-tools-bridge.cjs');
const configPath = process.argv[2];
const stateRoot = path.dirname(path.resolve(configPath));
const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
if (config.engineMode !== undefined && config.engineMode !== 'owned') throw new Error('未知研究引擎模式');
const endpoint = new URL(config.url);
if (endpoint.protocol !== 'ws:' || endpoint.hostname !== '127.0.0.1' || endpoint.pathname !== '/rpc' || endpoint.search || endpoint.hash || endpoint.username || endpoint.password || !endpoint.port) throw new Error('固定本机研究端点无效');
const stateFile = path.join(stateRoot, 'broker-status.json');
const stopFile = path.join(stateRoot, 'stop-broker.request');
if (fs.existsSync(stopFile)) throw new Error('请先处理旧停止请求，再显式启动试验');
let configOverrides=[],envOverrides={},appToolsPipe=null;
if(config.engineMode==='owned'&&config.appToolsBridge?.enabled===true){
 const pluginRoot=path.join(path.dirname(config.desktopExecutable),'resources/plugins/openai-bundled/plugins/codex-app-tools');
 const definition=JSON.parse(fs.readFileSync(path.join(pluginRoot,'.mcp.json'),'utf8'));
 const mode=config.appToolsBridge.mode??'legacy';
 if(mode==='plugin-pipe'){
  const nodePath=config.appToolsBridge.nodePath,vars=definition?.mcpServers?.codex_app?.env_vars;
  if(typeof nodePath!=='string'||!path.win32.isAbsolute(nodePath)||/[\x00-\x1f\x7f]/.test(nodePath)||!fs.statSync(nodePath).isFile()||!Array.isArray(vars)||!vars.includes('CODEX_APP_TOOLS_PIPE_PATH')||!vars.includes('CODEX_MCP_NODE_PATH'))throw new Error('APP_TOOLS_PLUGIN_CONFIG_INVALID');
  const {createAppToolsPipe}=require('./app-tools-pipe.cjs');
  appToolsPipe=createAppToolsPipe({maxClients:config.appToolsBridge.maxClients,resolveOwner:async({signal})=>selectOwner(await discoverOwners({deadline:Date.now()+10000,signal}),config.enhancedProfileDirectory)});
  configOverrides=buildPluginAppToolsOverrides();
  envOverrides={CODEX_APP_TOOLS_PIPE_PATH:appToolsPipe.pipePath,CODEX_MCP_NODE_PATH:nodePath};
 }else if(mode==='legacy')configOverrides=buildAppToolsOverrides({definition,pluginRoot,nodePath:config.appToolsBridge.nodePath,wrapperPath:path.join(__dirname,'app-tools-bridge.cjs'),configPath:path.resolve(configPath)});
 else throw new Error('APP_TOOLS_BRIDGE_MODE_INVALID');
}
const engine = config.engineMode === 'owned' ? new OwnedEngine({binary:config.binary,socketPath:config.socketPath,configOverrides,envOverrides,spawn:createIsolatedSpawn(config,require('node:child_process').spawn)}) : null;
const broker = createBroker({token:config.token, binary:config.binary,socketPath:engine ? config.socketPath : undefined});
let stopping = false, ready = false;
let stopPromise;
let failureCode = null;
const save = extra => {
  try {
    const temp = stateFile + '.tmp';
    fs.writeFileSync(temp, JSON.stringify({pid:process.pid, at:new Date().toISOString(), ready, backend:engine?'owned':'managed', engine:engine?.status(), ...(appToolsPipe?{appToolsPipe:appToolsPipe.getStats()}:{}),failureCode, ...broker.getStats(), ...extra}));
    fs.renameSync(temp, stateFile);
    return true;
  } catch {
    // 诊断文件异常不能拆掉正在使用的桌面连接，也不输出异常原文。
    if (!save.failed) process.stderr.write('BROKER_STATUS_WRITE_FAILED\n');
    save.failed = true; return false;
  }
};
async function stop() {
  if (stopPromise) return stopPromise;
  stopping = true; clearInterval(timer);
  stopPromise = (async()=>{
    const report = await broker.close();
    const engineReport = await engine?.stop();
    const appToolsReport=await appToolsPipe?.close();
    ready = false; save({stopped:true, cleanup:report, engineCleanup:engineReport,...(appToolsReport?{appToolsCleanup:appToolsReport}:{})});
    process.exitCode = report.ok && engineReport?.ok !== false && appToolsReport?.ok !== false && !failureCode ? 0 : 1;
  })();
  return stopPromise;
}
const timer = setInterval(() => {
  if (ready && engine && !engine.status().running) { failureCode='OWNED_ENGINE_EXITED';stop().catch(()=>{process.exitCode=1;}); return; }
  if (ready && fs.existsSync(stopFile) && broker.getStats().occupiedSlots === 0) { stop().catch(()=>{process.exitCode=1;}); return; }
  save({stopRequested:fs.existsSync(stopFile)});
}, 500);
(async()=>{
  await appToolsPipe?.start();
  if(stopping)return;
  await engine?.start();
  if(stopping) return;
  await new Promise((resolve,reject)=>{broker.server.once('error',reject);broker.server.listen(Number(endpoint.port),'127.0.0.1',resolve);});
  if(stopping) return;
  // Windows AF_UNIX 文件只作为候选就绪；真正门禁须通过 native proxy 完成协议初始化。
  const preflight = new SharedClient({url:config.url,token:config.token,name:'shared_engine_startup_probe'});
  try { await preflight.connect();await preflight.request('thread/loaded/list',{}); }
  finally { await preflight.close(); }
  if(stopping) return;
  ready=true;save({});
})().catch(async()=>{failureCode='BROKER_START_FAILED';save({});await stop();process.exitCode=1;});
for (const signal of ['SIGINT','SIGTERM']) process.once(signal,()=>stop().catch(()=>{process.exitCode=1;}));
