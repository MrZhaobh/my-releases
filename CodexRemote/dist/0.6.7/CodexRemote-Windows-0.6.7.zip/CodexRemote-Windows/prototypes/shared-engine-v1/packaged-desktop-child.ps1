﻿#requires -Version 5.1
param(
    [Parameter(Mandatory = $true)][string]$ConfigPath,
    [Parameter(Mandatory = $true)][string]$ResultPath,
    [Parameter(Mandatory = $true)][ValidateSet('Shared', 'Original')][string]$Mode,
    [switch]$ProbeOnly
)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$resultLocationVerified = $false
if ($ProbeOnly -and $Mode -ne 'Shared') { exit 1 }

function Write-PackagedChildResult([hashtable]$Value) {
    $json = $Value | ConvertTo-Json -Depth 5 -Compress
    $temporary = $ResultPath + '.' + [Guid]::NewGuid().ToString() + '.tmp'
    $stream = [IO.File]::Open($temporary, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::Read)
    try {
        $writer = New-Object IO.StreamWriter($stream, (New-Object Text.UTF8Encoding($false)))
        try { $writer.Write($json); $writer.Flush() } finally { $writer.Dispose() }
    } finally { $stream.Dispose() }
    try { [IO.File]::Move($temporary, $ResultPath) }
    finally { if (Test-Path -LiteralPath $temporary) { [IO.File]::Delete($temporary) } }
}

function Assert-PackagedPrivateConfig([string]$File) {
    $acl = Get-Acl -LiteralPath $File
    $currentSid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    $allowed = @($currentSid, 'S-1-5-18', 'S-1-5-32-544')
    foreach ($rule in $acl.Access) {
        if ($rule.AccessControlType -ne [Security.AccessControl.AccessControlType]::Allow) { continue }
        $sid = $rule.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value
        if ($allowed -notcontains $sid) { throw 'PACKAGED_CONFIG_NOT_PRIVATE' }
    }
}

function Get-PackagedChildDiagnostic($Failure) {
    $exception = $Failure.Exception
    $native = $null
    $inner = $exception
    for ($i = 0; $i -lt 5 -and $null -ne $inner; $i++) {
        if ($inner -is [ComponentModel.Win32Exception]) { $native = $inner.NativeErrorCode; break }
        $inner = $inner.InnerException
    }
    return @{ type = $exception.GetType().FullName; hresult = $exception.HResult; nativeErrorCode = $native; script = [IO.Path]::GetFileName($Failure.InvocationInfo.ScriptName); line = $Failure.InvocationInfo.ScriptLineNumber; parameter = $(if ($Failure.Exception.ParameterName -match '^[A-Za-z]{1,80}$') { $Failure.Exception.ParameterName } else { $null }) }
}

function Set-PackagedDesktopTransportEnvironment([Diagnostics.ProcessStartInfo]$StartInfo,$Config,[string]$SelectedMode) {
    if ($SelectedMode -eq 'Shared') {
        $endpoint = [uri]$Config.url
        $StartInfo.EnvironmentVariables['CODEX_APP_SERVER_WS_URL'] = 'ws://codex:' + [string]$Config.token + '@127.0.0.1:' + $endpoint.Port + '/rpc'
        $StartInfo.EnvironmentVariables.Remove('CODEX_APP_SERVER_FORCE_CLI')
        # 外部共享引擎不能继承桌面随后创建的浏览器认证环境。
        # 沿用桌面现有分支，为每个会话的 cua_repl 生成带认证信息的配置。
        $StartInfo.EnvironmentVariables['CODEX_APP_SERVER_USE_LOCAL_DAEMON'] = '1'
    } elseif ($SelectedMode -eq 'Original') {
        if ($null -eq $Config.originalDesktopEnvironment -or
            $null -eq $Config.originalDesktopEnvironment.PSObject.Properties['ws'] -or
            $null -eq $Config.originalDesktopEnvironment.PSObject.Properties['forceCli']) { throw 'PACKAGED_ORIGINAL_ENV_MISSING' }
        foreach ($pair in @(@('CODEX_APP_SERVER_WS_URL', 'ws'), @('CODEX_APP_SERVER_FORCE_CLI', 'forceCli'))) {
            $value = $Config.originalDesktopEnvironment.($pair[1])
            if ($null -eq $value) { $StartInfo.EnvironmentVariables.Remove($pair[0]) }
            elseif ($value -is [string] -and $value.Length -le 8192 -and $value -notmatch '[\x00\r\n]') { $StartInfo.EnvironmentVariables[$pair[0]] = $value }
            else { throw 'PACKAGED_ORIGINAL_ENV_INVALID' }
        }
    } else {throw 'PACKAGED_MODE_INVALID'}
}

function Get-PackagedEnhancedArguments($Config) {
    $hasProfile = $null -ne $Config.PSObject.Properties['enhancedProfileDirectory']
    $hasPort = $null -ne $Config.PSObject.Properties['enhancedPort']
    if ($hasProfile -ne $hasPort) { throw 'PACKAGED_ENHANCED_CONFIG_INCOMPLETE' }
    if (-not $hasProfile) { return '' }
    $profile = $Config.enhancedProfileDirectory
    $port = $Config.enhancedPort
    if ($profile -isnot [string] -or $profile -match '["\x00-\x1f\x7f]' -or
        ($profile -notmatch '^[A-Za-z]:[\\/]' -and $profile -notmatch '^\\\\[^\\/?]+\\[^\\/?]+\\') -or
        $profile -match '^\\\\[?.]\\' -or
        [IO.Path]::GetFullPath($profile) -ne $profile -or
        -not (Test-Path -LiteralPath $profile -PathType Container) -or
        ($port -isnot [int] -and $port -isnot [long]) -or $port -lt 1 -or $port -gt 65535) { throw 'PACKAGED_ENHANCED_CONFIG_INVALID' }
    # 仅复用配置内已记录的增强端口与 profile；不接受任意命令参数或自行选择端口。
    $quotedProfile = [regex]::Replace($profile, '(\\+)$', '$1$1')
    return '--remote-debugging-address=127.0.0.1 --remote-debugging-port=' + $port + ' --user-data-dir="' + $quotedProfile + '"'
}

try {
    $ConfigPath = [IO.Path]::GetFullPath($ConfigPath)
    $ResultPath = [IO.Path]::GetFullPath($ResultPath)
    if ([IO.Path]::GetDirectoryName($ConfigPath) -ne [IO.Path]::GetDirectoryName($ResultPath) -or
        [IO.Path]::GetFileName($ResultPath) -notmatch '^packaged-desktop-result-[a-f0-9-]{36}\.json$' -or
        $ConfigPath -match '[\x00-\x1f\x7f]' -or $ResultPath -match '[\x00-\x1f\x7f]') { throw 'PACKAGED_RESULT_PATH_INVALID' }
    Assert-PackagedPrivateConfig $ConfigPath
    Assert-PackagedPrivateConfig ([IO.Path]::GetDirectoryName($ConfigPath))
    $resultLocationVerified = $true
    if (Test-Path -LiteralPath ($ResultPath + '.cancel')) { throw 'PACKAGED_LAUNCH_CANCELLED' }
    if (-not $ProbeOnly -and (Get-Process -Name ChatGPT -ErrorAction SilentlyContinue)) { throw 'PACKAGED_DESKTOP_ALREADY_RUNNING' }
    $config = Get-Content -Raw -LiteralPath $ConfigPath | ConvertFrom-Json
    . (Join-Path $PSScriptRoot 'isolated-desktop-config.ps1')
    $null = Read-IsolatedDesktopSelection $config
    $endpoint = New-Object Uri([string]$config.url)
    if ($endpoint.Scheme -ne 'ws' -or $endpoint.Host -ne '127.0.0.1' -or $endpoint.Port -lt 1 -or
        $endpoint.AbsolutePath -ne '/rpc' -or $endpoint.Query -or $endpoint.Fragment -or $endpoint.UserInfo -or
        [string]$config.token -notmatch '^[A-Za-z0-9_-]{43}$') { throw 'PACKAGED_CONFIG_INVALID' }
    if ([string]$config.desktopExecutable -match '[\x00-\x1f\x7f]' -or
        -not [IO.Path]::IsPathRooted([string]$config.desktopExecutable) -or
        [IO.Path]::GetFileName([string]$config.desktopExecutable) -ne 'ChatGPT.exe' -or
        -not (Test-Path -LiteralPath $config.desktopExecutable -PathType Leaf)) { throw 'PACKAGED_TARGET_INVALID' }
    $target = (Resolve-Path -LiteralPath $config.desktopExecutable).Path
    # 目标必须属于调用包；不接受配置中指向其他安装或普通可执行文件的同名目标。
    $packageRoot = Split-Path -Parent (Split-Path -Parent $target)
    $manifestPath = Join-Path $packageRoot 'AppxManifest.xml'
    if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) { throw 'PACKAGED_TARGET_INVALID' }
    $settings = New-Object Xml.XmlReaderSettings
    $settings.DtdProcessing = [Xml.DtdProcessing]::Prohibit
    $settings.XmlResolver = $null
    $reader = [Xml.XmlReader]::Create($manifestPath, $settings)
    try { $manifest = New-Object Xml.XmlDocument; $manifest.XmlResolver = $null; $manifest.Load($reader) } finally { $reader.Dispose() }
    if ($manifest.DocumentElement.Identity.Name -ne 'OpenAI.Codex') { throw 'PACKAGED_TARGET_INVALID' }
    $matching = @($manifest.DocumentElement.Applications.Application | Where-Object {
        $_.Executable -and ([IO.Path]::GetFullPath((Join-Path $packageRoot ([string]$_.Executable)))) -eq $target
    })
    if ($matching.Count -ne 1) { throw 'PACKAGED_TARGET_INVALID' }

    $start = New-Object Diagnostics.ProcessStartInfo
    $start.FileName = $target
    $start.WorkingDirectory = [IO.Path]::GetDirectoryName($target)
    $start.Arguments = Get-PackagedEnhancedArguments $config
    $start.UseShellExecute = $false
    Set-PackagedDesktopTransportEnvironment $start $config $Mode
    if (-not $ProbeOnly) { Set-IsolatedDesktopEnvironment $start $config }
    # 检查必须紧邻最终启动，避免两个准备中的 launcher 重复拉起桌面。
    if ((Test-Path -LiteralPath ($ResultPath + '.cancel')) -or (Test-Path -LiteralPath $ResultPath)) { throw 'PACKAGED_LAUNCH_CANCELLED' }
    if ($ProbeOnly) {
        # 同一启动链与环境构造，仅替换最终目标为无害的 PowerShell 子进程。
        $start.FileName = Join-Path $env:SystemRoot 'System32/WindowsPowerShell/v1.0/powershell.exe'
        $start.CreateNoWindow = $true
        $start.WindowStyle = [Diagnostics.ProcessWindowStyle]::Hidden
        $probe = 'if ($env:CODEX_APP_SERVER_WS_URL -match ''^ws://codex:[A-Za-z0-9_-]{43}@127\.0\.0\.1:[0-9]+/rpc$'' -and -not $env:CODEX_APP_SERVER_FORCE_CLI -and $env:CODEX_APP_SERVER_USE_LOCAL_DAEMON -eq ''1'') { exit 0 } else { exit 2 }'
        # 探针代码固定且不含配置值；直接传脚本，避免 EncodedCommand 路径在本机超时。
        $start.Arguments = '-NoProfile -NonInteractive -WindowStyle Hidden -Command "' + $probe + '"'
        $process = [Diagnostics.Process]::Start($start)
        if (-not $process.WaitForExit(12000)) { $process.Kill(); throw 'PACKAGED_PROBE_TIMEOUT' }
        Write-PackagedChildResult @{ ok = ($process.ExitCode -eq 0); mode = $Mode; probeOnly = $true; pid = $process.Id; exitCode = $process.ExitCode }
        exit 0
    }
    if (Get-Process -Name ChatGPT -ErrorAction SilentlyContinue) { throw 'PACKAGED_DESKTOP_ALREADY_RUNNING' }
    $desktop = [Diagnostics.Process]::Start($start)
    Write-PackagedChildResult @{ ok = $true; mode = $Mode; pid = $desktop.Id }
    exit 0
} catch {
    if ($resultLocationVerified) { try { Write-PackagedChildResult @{ ok = $false; mode = $Mode; diagnostic = (Get-PackagedChildDiagnostic $_) } } catch { } }
    exit 1
}
