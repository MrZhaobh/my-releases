﻿#requires -Version 5.1
# 此模块只返回路径/身份信息；凭据仅写入即将启动的子进程环境，不返回或序列化。
function Get-IsolatedDesktopCanonicalPath([string]$Path){
 if([string]::IsNullOrWhiteSpace($Path) -or $Path -match '["\x00-\x1f\x7f*?]' -or $Path -match '^\\\\[?.]\\' -or $Path -notmatch '^(?:[A-Za-z]:\\|\\\\[^\\]+\\[^\\]+(?:\\|$))'){throw 'ISOLATED_CONFIG_INVALID'}
 $full=[IO.Path]::GetFullPath($Path);$root=[IO.Path]::GetPathRoot($full);if($full.Length -gt $root.Length){$full=$full.TrimEnd('\')};return $full
}
function Assert-IsolatedDesktopPath([string]$Path,[bool]$MustBeFile=$false){
 $current=Get-IsolatedDesktopCanonicalPath $Path
 if($MustBeFile -and -not (Test-Path -LiteralPath $current -PathType Leaf)){throw 'ISOLATED_CONFIG_INVALID'}
 $isLeaf=$true
 while($current){if(Test-Path -LiteralPath $current){$item=Get-Item -LiteralPath $current -Force;if(($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -or (-not $isLeaf -and -not $item.PSIsContainer)){throw 'ISOLATED_CONFIG_INVALID'}};$next=Split-Path -Parent $current;if($next -eq $current){break};$current=$next;$isLeaf=$false}
}
function Read-IsolatedDesktopBoundedText([string]$Path,[int]$MaximumBytes){
 Assert-IsolatedDesktopPath $Path $true
 if((Get-Item -LiteralPath $Path).Length -gt $MaximumBytes){throw 'ISOLATED_CONFIG_INVALID'}
 $bytes=[IO.File]::ReadAllBytes($Path);if($bytes.Length -gt $MaximumBytes){throw 'ISOLATED_CONFIG_INVALID'}
 try{$encoding=New-Object Text.UTF8Encoding($false,$true);$body=$encoding.GetString($bytes);if($body.Length -and $body[0] -eq [char]0xFEFF){$body=$body.Substring(1)};if($body.Length -and $body[0] -eq [char]0xFEFF){throw 'ISOLATED_CONFIG_INVALID'}}catch{throw 'ISOLATED_CONFIG_INVALID'}
 $sha=[Security.Cryptography.SHA256]::Create();try{$fingerprint=([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-','')}finally{$sha.Dispose()}
 return [pscustomobject]@{body=$body;fingerprint=$fingerprint}
}
function Read-IsolatedDesktopConfigValues([string]$Body){
 $token='"(?:[^"\\\x00-\x1f]|\\(?:["\\/bfnrt]|u[0-9A-Fa-f]{4}))*"';$pair='(?<key>'+$token+')\s*:\s*(?<value>'+$token+'|null)'
 $object=[regex]::Match($Body,('\A\s*\{\s*(?:'+$pair+'(?:\s*,\s*'+$pair+')*)?\s*\}\s*\z'));if(-not $object.Success){throw 'ISOLATED_CONFIG_INVALID'}
 $values=@{}
 for($index=0;$index -lt $object.Groups['key'].Captures.Count;$index++){
  $key=([string]('{"v":'+$object.Groups['key'].Captures[$index].Value+'}')|ConvertFrom-Json).v
  if(@('runtimeRoot','profileRoot','codexHome','apiKeyEnvironmentVariable','usageProvider') -cnotcontains $key -or $values.ContainsKey($key)){throw 'ISOLATED_CONFIG_INVALID'}
  $values[$key]=([string]('{"v":'+$object.Groups['value'].Captures[$index].Value+'}')|ConvertFrom-Json).v
 }
 return $values
}
function Read-IsolatedDesktopSelection($Config){
 $fields=@('instanceConfigPath','instanceConfigFingerprint','instanceConfigModulePath','instanceConfigModuleFingerprint','isolatedCodexHome','apiKeyEnvironmentVariable','enhancedRuntimeDirectory')
 $present=@($fields|Where-Object {$null -ne $Config.PSObject.Properties[$_]})
 if(-not $present.Count){return $null}
 if($present.Count -ne $fields.Count -or -not $Config.enhancedLauncher -or -not $Config.enhancedProfileDirectory){throw 'ISOLATED_CONFIG_INVALID'}
 $path=Get-IsolatedDesktopCanonicalPath ([string]$Config.instanceConfigPath);$module=Get-IsolatedDesktopCanonicalPath ([string]$Config.instanceConfigModulePath)
 Assert-IsolatedDesktopPath $path $true;Assert-IsolatedDesktopPath $module $true
 $expectedModule=Join-Path (Split-Path -Parent ([string]$Config.enhancedLauncher)) 'src\instance-config.ps1'
 if($module -ine (Get-IsolatedDesktopCanonicalPath $expectedModule) -or [string]$Config.instanceConfigFingerprint -notmatch '^[A-Fa-f0-9]{64}$' -or [string]$Config.instanceConfigModuleFingerprint -notmatch '^[A-Fa-f0-9]{64}$'){throw 'ISOLATED_CONFIG_INVALID'}
 $text=Read-IsolatedDesktopBoundedText $path 32768;$moduleText=Read-IsolatedDesktopBoundedText $module 262144
 if($text.fingerprint -ne $Config.instanceConfigFingerprint -or $moduleText.fingerprint -ne $Config.instanceConfigModuleFingerprint){throw 'ISOLATED_SELECTION_CHANGED'}
 $raw=Read-IsolatedDesktopConfigValues $text.body
 $root=Split-Path -Parent $path;$paths=@{}
 foreach($key in @('runtimeRoot','profileRoot','codexHome')){
  $relative=$raw.$key
  if($relative -isnot [string] -or [string]::IsNullOrWhiteSpace($relative) -or [IO.Path]::IsPathRooted($relative) -or $relative -match '[\x00-\x1f\x7f:*?"<>|]' -or $relative -match '(?:^|[\\/])[^\\/]*[ .](?:[\\/]|$)' -or $relative -match '(?i)(?:^|[\\/])(?:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.[^\\/]*)?(?:[\\/]|$)' -or $relative -match '(^|[\\/])\.\.?([\\/]|$)'){throw 'ISOLATED_CONFIG_INVALID'}
  $resolved=Get-IsolatedDesktopCanonicalPath (Join-Path $root $relative);Assert-IsolatedDesktopPath $resolved
  if((Test-Path -LiteralPath $resolved) -and -not (Test-Path -LiteralPath $resolved -PathType Container)){throw 'ISOLATED_CONFIG_INVALID'}
  if(-not $resolved.StartsWith($root.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'ISOLATED_CONFIG_INVALID'}
  foreach($protected in @((Join-Path (Split-Path -Parent ([string]$Config.enhancedLauncher)) '.runtime'),(Join-Path $env:USERPROFILE '.codex'))){$protected=[IO.Path]::GetFullPath($protected);if($resolved -ieq $protected -or $resolved.StartsWith($protected+'\',[StringComparison]::OrdinalIgnoreCase) -or $protected.StartsWith($resolved+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'ISOLATED_CONFIG_INVALID'}}
  $paths[$key]=$resolved
 }
 foreach($first in $paths.Values){foreach($second in $paths.Values){if($first -eq $second){continue};if($first.StartsWith($second+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'ISOLATED_CONFIG_INVALID'}}}
 if(@($paths.Values|Select-Object -Unique).Count -ne 3 -or $raw.apiKeyEnvironmentVariable -isnot [string] -or $raw.apiKeyEnvironmentVariable.Length -gt 128 -or $raw.apiKeyEnvironmentVariable -cnotmatch '^CODEX_[A-Z0-9_]+_API_KEY$' -or ($null -ne $raw.usageProvider -and @('litellm-user-budget','bailian-local-usage') -cnotcontains $raw.usageProvider)){throw 'ISOLATED_CONFIG_INVALID'}
 if($paths.profileRoot -ine [string]$Config.enhancedProfileDirectory -or $paths.codexHome -ine [string]$Config.isolatedCodexHome -or $paths.runtimeRoot -ine [string]$Config.enhancedRuntimeDirectory -or $raw.apiKeyEnvironmentVariable -cne [string]$Config.apiKeyEnvironmentVariable){throw 'ISOLATED_SELECTION_CHANGED'}
 return [pscustomobject]@{configPath=$path;runtimeRoot=$paths.runtimeRoot;profileRoot=$paths.profileRoot;codexHome=$paths.codexHome;apiKeyEnvironmentVariable=$raw.apiKeyEnvironmentVariable}
}
function Set-IsolatedDesktopEnvironment([Diagnostics.ProcessStartInfo]$StartInfo,$Config){
 $selection=Read-IsolatedDesktopSelection $Config;if(-not $selection){return}
 $authPath=Join-Path $selection.codexHome 'auth.json';Assert-IsolatedDesktopPath $authPath $true
 try{$authText=Read-IsolatedDesktopBoundedText $authPath 65536;$auth=$authText.body|ConvertFrom-Json -ErrorAction Stop}catch{throw 'ISOLATED_AUTH_INVALID'}
 if($auth.OPENAI_API_KEY -isnot [string] -or [string]::IsNullOrWhiteSpace($auth.OPENAI_API_KEY) -or $auth.OPENAI_API_KEY.Length -gt 8192 -or $auth.OPENAI_API_KEY -match '[^\x21-\x7e]'){throw 'ISOLATED_AUTH_INVALID'}
 $StartInfo.EnvironmentVariables['CODEX_HOME']=$selection.codexHome
 $StartInfo.WorkingDirectory=Split-Path -Parent $selection.configPath
 $StartInfo.EnvironmentVariables['CODEX_ELECTRON_USER_DATA_PATH']=$selection.profileRoot
 $StartInfo.EnvironmentVariables[$selection.apiKeyEnvironmentVariable]=$auth.OPENAI_API_KEY
 $auth=$null
}
