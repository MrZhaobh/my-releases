'use strict';

// 只读升级预检：不会启动引擎、创建会话、恢复会话、发送提示词或答复审批。
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const {execFile} = require('node:child_process');
const {promisify} = require('node:util');
const execute = promisify(execFile);
const PLUGIN_ID = 'codex-app-tools@openai-bundled';
const POLICY_PATH = 'plugins.' + PLUGIN_ID;
const REQUIRED_ENV = ['CODEX_APP_TOOLS_PIPE_PATH', 'CODEX_MCP_NODE_PATH'];
const MARKERS = [...REQUIRED_ENV, 'enabled_tools', 'default_tools_approval_mode', POLICY_PATH, 'mcpServerStatus/list'];
const fail = code => Object.assign(new Error(code), {code});
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
function canonical(value) {
  if (Array.isArray(value)) return value.map(canonical);
  if (!object(value)) return value;
  return Object.fromEntries(Object.keys(value).sort().map(key => [key, canonical(value[key])]));
}
const hash = value => crypto.createHash('sha256').update(JSON.stringify(canonical(value))).digest('hex');
const version = value => typeof value === 'string' && /^\d+\.\d+(?:\.\d+)*(?:[-+][\w.-]+)?$/.test(value) ? value : null;

function readAsar(file) {
  const fd = fs.openSync(file, 'r');
  try {
    const size = fs.fstatSync(fd).size;
    const read = (offset, length) => {
      if (!Number.isSafeInteger(offset) || !Number.isSafeInteger(length) || offset < 0 || length < 0 || offset + length > size || length > 16 * 1024 * 1024) throw fail('DESKTOP_ASAR_INVALID');
      const result = Buffer.alloc(length);
      if (fs.readSync(fd, result, 0, length, offset) !== length) throw fail('DESKTOP_ASAR_INVALID');
      return result;
    };
    const prefix = read(0, 16), headerSize = prefix.readUInt32LE(4), jsonSize = prefix.readUInt32LE(12);
    if (prefix.readUInt32LE(0) !== 4 || headerSize < jsonSize + 8 || headerSize > 16 * 1024 * 1024) throw fail('DESKTOP_ASAR_INVALID');
    const header = JSON.parse(read(16, jsonSize).toString('utf8'));
    const entry = name => {
      let node = header;
      for (const component of name.split('/')) node = node?.files?.[component];
      if (!node || node.link || node.unpacked || !Number.isSafeInteger(node.size) || !/^\d+$/.test(node.offset)) throw fail('DESKTOP_ASAR_ENTRY_MISSING');
      return read(8 + headerSize + Number(node.offset), node.size).toString('utf8');
    };
    const pkg = JSON.parse(entry('package.json'));
    const candidates = Object.keys(header.files?.['.vite']?.files?.build?.files ?? {}).filter(name => /^main(?:-[\w-]+)?\.js$/.test(name));
    if (candidates.length !== 1) throw fail('DESKTOP_MAIN_MISSING');
    const source = entry('.vite/build/' + candidates[0]);
    return {version: version(pkg.version), markers: Object.fromEntries(MARKERS.map(marker => [marker, source.includes(marker)])), mainHash: hash(source)};
  } finally { fs.closeSync(fd); }
}

function inspectPlugin(definition, manifest) {
  const server = definition?.mcpServers?.codex_app;
  if (!object(server) || manifest?.name !== 'codex-app-tools' || manifest.mcpServers !== './.mcp.json') throw fail('PLUGIN_STRUCTURE_MISSING');
  if (typeof server.command !== 'string' || !server.command || !Array.isArray(server.args) || server.args.some(arg => typeof arg !== 'string') || typeof server.enabled !== 'boolean' || typeof server.default_tools_approval_mode !== 'string' || !server.default_tools_approval_mode || !object(server.tools)) throw fail('PLUGIN_STRUCTURE_MISSING');
  if (!Array.isArray(server.env_vars) || server.env_vars.some(name => typeof name !== 'string') || REQUIRED_ENV.some(name => !server.env_vars.includes(name))) throw fail('PLUGIN_ENV_MISSING');
  for (const name of ['create_thread', 'send_message_to_thread']) {
    if (typeof server.tools[name]?.approval_mode !== 'string') throw fail('PLUGIN_APPROVAL_MISSING');
  }
  // 只保存不可逆摘要，避免把未来插件 env/args 中的凭据写进诊断或基线。
  return {version: version(manifest.version), fingerprint: hash(server), policyPath: POLICY_PATH, requiredEnvPresent: true, approvalFingerprint: hash({default:server.default_tools_approval_mode, tools:server.tools}), explicitPrompts: ['create_thread', 'send_message_to_thread'].every(name => server.tools[name].approval_mode === 'prompt')};
}

function shape(value, depth = 0) {
  if (depth > 6) return 'bounded';
  if (Array.isArray(value)) return ['array', ...[...new Set(value.slice(0, 10).map(item => JSON.stringify(shape(item, depth + 1))))].sort()];
  if (object(value)) return Object.fromEntries(Object.keys(value).sort().map(key => [key, shape(value[key], depth + 1)]));
  return value === null ? 'null' : typeof value;
}

async function onlineCheck(config, options, deps) {
  if (!options.online) return {status:'unknown', code:'ONLINE_NOT_REQUESTED'};
  if (typeof options.threadId !== 'string' || !/^[a-zA-Z0-9_-]{1,128}$/.test(options.threadId)) return {status:'incompatible', code:'DEDICATED_THREAD_REQUIRED'};
  let client;
  try {
    client = deps.createClient ? deps.createClient(config) : new (require('./client.cjs').SharedClient)({url:config.url, token:config.token, name:'compatibility_readonly_probe', requestTimeoutMs:10000, initializeTimeoutMs:10000});
    const initialized = await client.connect();
    if (!object(initialized) || typeof initialized.userAgent !== 'string') throw fail('INITIALIZE_STRUCTURE_MISSING');
    const response = await client.request('mcpServerStatus/list', {threadId:options.threadId, serverName:'codex_app', detail:'toolsAndAuthOnly'});
    if (!object(response) || !Array.isArray(response.data)) throw fail('MCP_DIRECTORY_STRUCTURE_MISSING');
    const original = response.data.filter(server => server?.pluginId === PLUGIN_ID && server.name === 'codex_app');
    if (!original.length && !response.data.some(server => server?.name === 'codex_app')) return {status:'unknown', code:'MCP_PLUGIN_NOT_DISCOVERED'};
    if (original.length !== 1) throw fail('ORIGINAL_PLUGIN_REGISTRATION_MISSING');
    const server = original[0];
    if (server.toolsError != null) return {status:'unknown', code:'MCP_TOOLS_UNAVAILABLE'};
    if (server.runtimeStatus === 'failed' || server.runtimeStatus === 'stopped') return {status:'unknown', code:'MCP_RUNTIME_UNAVAILABLE'};
    if (!object(server.tools)) throw fail('MCP_TOOLS_STRUCTURE_MISSING');
    const tools = Object.keys(server.tools).sort();
    if (!tools.length || tools.some(name => !/^[a-zA-Z0-9_]{1,128}$/.test(name))) throw fail('MCP_TOOLS_STRUCTURE_MISSING');
    if (response.nextCursor != null) return {status:'unknown', code:'MCP_DIRECTORY_PAGINATED'};
    const expected = options.expectedTools;
    const filterMatches = expected ? JSON.stringify([...new Set(expected)].sort()) === JSON.stringify(tools) : null;
    return {status:filterMatches === false ? 'incompatible' : 'supported', code:filterMatches === false ? 'THREAD_TOOL_FILTER_MISMATCH' : 'READONLY_PROTOCOL_VERIFIED', initializeFingerprint:hash(shape(initialized)), directoryFingerprint:hash(shape(response)), catalogFingerprint:hash(tools), toolCount:tools.length, originalPlugin:true, filterMatches, approvalRoundtrip:'not_tested', toolExecution:'not_tested'};
  } catch (error) {
    const structural = ['INITIALIZE_STRUCTURE_MISSING', 'MCP_DIRECTORY_STRUCTURE_MISSING', 'ORIGINAL_PLUGIN_REGISTRATION_MISSING', 'MCP_TOOLS_STRUCTURE_MISSING'];
    return {status:structural.includes(error.code) ? 'incompatible' : 'unknown', code:structural.includes(error.code) ? error.code : 'ONLINE_UNAVAILABLE'};
  } finally { try { await client?.close(); } catch {} }
}

async function checkCompatibility(config, options = {}, deps = {}) {
  const readJson = deps.readJson ?? (file => JSON.parse(fs.readFileSync(file, 'utf8')));
  const checks = {};
  try {
    if (typeof config.binary !== 'string' || !path.isAbsolute(config.binary)) throw fail('CLI_BINARY_INVALID');
    const output = deps.cliVersion ? await deps.cliVersion(config.binary) : (await execute(config.binary, ['--version'], {timeout:10000, maxBuffer:4096, windowsHide:true, shell:false})).stdout;
    const parsed = /^codex(?:-cli)? (\S+)\s*$/.exec(output.trim());
    if (!parsed || !version(parsed[1])) throw fail('CLI_VERSION_INVALID');
    checks.cli = {status:'supported', version:parsed[1]};
  } catch { checks.cli = {status:'unknown', code:'CLI_VERSION_UNAVAILABLE'}; }
  let resources;
  try {
    if (typeof config.desktopExecutable !== 'string' || !path.isAbsolute(config.desktopExecutable)) throw fail('DESKTOP_CONFIG_INVALID');
    resources = path.join(path.dirname(config.desktopExecutable), 'resources');
    const desktop = (deps.readAsar ?? readAsar)(path.join(resources, 'app.asar'));
    checks.desktop = {status:desktop.version && MARKERS.every(marker => desktop.markers[marker]) ? 'supported' : 'incompatible', ...desktop};
  } catch (error) {
    const known = ['DESKTOP_ASAR_INVALID','DESKTOP_ASAR_ENTRY_MISSING','DESKTOP_MAIN_MISSING','DESKTOP_CONFIG_INVALID'];
    checks.desktop = {status:'incompatible', code:known.includes(error.code) ? error.code : 'DESKTOP_STRUCTURE_UNREADABLE'};
  }
  try {
    if (!resources) throw fail('DESKTOP_CONFIG_INVALID');
    const root = path.join(resources, 'plugins/openai-bundled/plugins/codex-app-tools');
    checks.plugin = {status:'supported', ...inspectPlugin(readJson(path.join(root, '.mcp.json')), readJson(path.join(root, '.codex-plugin/plugin.json')))};
    if (!checks.plugin.explicitPrompts) checks.plugin.status = 'incompatible';
  } catch (error) {
    // 异常原文可能携带安装目录、pipe或秘密；诊断只使用封闭代码。
    const known = ['PLUGIN_STRUCTURE_MISSING','PLUGIN_ENV_MISSING','PLUGIN_APPROVAL_MISSING','DESKTOP_CONFIG_INVALID'];
    checks.plugin = {status:'incompatible', code:known.includes(error.code) ? error.code : 'INSTALLATION_STRUCTURE_UNREADABLE'};
  }
  checks.protocol = await onlineCheck(config, options, deps);
  const snapshot = {schema:1, cli:checks.cli.version ?? null, desktop:checks.desktop?.version ?? null, desktopFingerprint:checks.desktop?.mainHash ?? null, pluginFingerprint:checks.plugin.fingerprint ?? null, approvalFingerprint:checks.plugin.approvalFingerprint ?? null, protocol:checks.protocol.status === 'supported' ? {initialize:checks.protocol.initializeFingerprint, directory:checks.protocol.directoryFingerprint, catalog:checks.protocol.catalogFingerprint} : null};
  const baseline = options.baseline;
  const changes = [];
  if (baseline) {
    if (!object(baseline) || baseline.schema !== 1) checks.baseline = {status:'unknown', code:'BASELINE_INVALID'};
    else {
      for (const field of ['cli','desktop','desktopFingerprint','pluginFingerprint','approvalFingerprint']) if (snapshot[field] !== null && baseline[field] !== snapshot[field]) changes.push(field);
      if (snapshot.protocol && baseline.protocol && hash(snapshot.protocol) !== hash(baseline.protocol)) changes.push('protocol');
      checks.baseline = {status:changes.length ? 'changed' : 'supported', changes};
    }
  } else checks.baseline = {status:'unknown', code:'BASELINE_NOT_RECORDED'};
  const statuses = Object.values(checks).map(check => check.status);
  const status = statuses.includes('incompatible') ? 'incompatible' : statuses.includes('changed') ? 'changed' : statuses.includes('unknown') ? 'unknown' : 'supported';
  return {schema:1, status, scope:'readonly_preflight', checks, baselineCandidate:snapshot, fullCompatibility:'not_verified', remaining:['real_approval_roundtrip','real_tool_execution','desktop_session_filter_behavior']};
}

function privatePath(file, root = path.resolve(__dirname, '../../.local')) {
  const absolute = path.resolve(file), relative = path.relative(root, absolute);
  if (!relative || relative.startsWith('..') || path.isAbsolute(relative)) throw fail('PRIVATE_PATH_REQUIRED');
  // 校验已有父目录的真实路径，拒绝以junction/symlink逃离私有目录。
  const realRoot = fs.realpathSync(root), realParent = fs.realpathSync(path.dirname(absolute));
  const realRelative = path.relative(realRoot, realParent);
  if (realRelative.startsWith('..') || path.isAbsolute(realRelative)) throw fail('PRIVATE_PATH_REQUIRED');
  if (fs.existsSync(absolute)) {
    const targetRelative = path.relative(realRoot, fs.realpathSync(absolute));
    if (targetRelative.startsWith('..') || path.isAbsolute(targetRelative)) throw fail('PRIVATE_PATH_REQUIRED');
  }
  return absolute;
}

function parseArgs(argv) {
  const options = {online:false, recordBaseline:false};
  const fields = {'--config':'configPath','--baseline':'baselinePath','--thread-id':'threadId','--expected-tools':'expectedTools'};
  for (let index = 0; index < argv.length; index++) {
    const flag = argv[index];
    if (flag === '--online') options.online = true;
    else if (flag === '--record-baseline') options.recordBaseline = true;
    else if (fields[flag] && argv[index + 1] && !argv[index + 1].startsWith('--')) options[fields[flag]] = argv[++index];
    else throw fail('ARGUMENT_INVALID');
  }
  options.configPath ??= path.resolve(__dirname, '../../.local/shared-engine-v1/config.json');
  options.baselinePath ??= path.join(path.dirname(path.resolve(options.configPath)), 'compatibility-baseline.json');
  if (options.expectedTools !== undefined) {
    options.expectedTools = options.expectedTools.split(',');
    if (!options.expectedTools.length || options.expectedTools.some(name => !/^[a-zA-Z0-9_]{1,128}$/.test(name))) throw fail('ARGUMENT_INVALID');
  }
  if (options.expectedTools && !options.online || options.threadId && !options.online) throw fail('ARGUMENT_INVALID');
  return options;
}

async function main(argv = process.argv.slice(2)) {
  try {
    const options = parseArgs(argv);
    const configPath = privatePath(options.configPath), baselinePath = privatePath(options.baselinePath);
    const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
    if (fs.existsSync(baselinePath)) {
      try { options.baseline = JSON.parse(fs.readFileSync(baselinePath, 'utf8')); }
      catch { options.baseline = {schema:0}; }
    }
    const report = await checkCompatibility(config, options);
    if (options.recordBaseline) {
      if (report.checks.cli.status !== 'supported' || report.checks.desktop?.status !== 'supported' || report.checks.plugin.status !== 'supported' || options.online && report.checks.protocol.status !== 'supported') report.baselineWrite = 'refused_incomplete';
      else {
        // 明确开关才覆盖基线；这里只记录当前观察，不声称已验收真实审批和操作。
        fs.writeFileSync(baselinePath, JSON.stringify(report.baselineCandidate, null, 2) + '\n', {mode:0o600});
        report.baselineWrite = 'recorded_observation';
      }
    }
    process.stdout.write(JSON.stringify(report) + '\n');
    process.exitCode = report.status === 'incompatible' ? 2 : 0;
  } catch {
    process.stdout.write(JSON.stringify({schema:1,status:'unknown',scope:'readonly_preflight',code:'CHECK_INPUT_OR_IO_FAILED',fullCompatibility:'not_verified'}) + '\n');
    process.exitCode = 1;
  }
}

module.exports = {checkCompatibility, inspectPlugin, readAsar, parseArgs, privatePath, shape, hash, main, PLUGIN_ID, MARKERS};
if (require.main === module) main();
