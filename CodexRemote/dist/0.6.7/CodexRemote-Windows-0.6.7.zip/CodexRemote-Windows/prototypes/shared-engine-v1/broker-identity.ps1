﻿function Read-BrokerProcessArguments([string]$CommandLine) {
    if([string]::IsNullOrWhiteSpace($CommandLine)){return @()}
    if(-not ('CodexRemote.BrokerCommandLine' -as [type])){
        Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
namespace CodexRemote {
 public static class BrokerCommandLine {
  [DllImport("shell32.dll", SetLastError=true)] static extern IntPtr CommandLineToArgvW([MarshalAs(UnmanagedType.LPWStr)] string command, out int count);
  [DllImport("kernel32.dll")] static extern IntPtr LocalFree(IntPtr value);
  public static string[] Parse(string command) {
   int count; IntPtr memory=CommandLineToArgvW(command,out count);
   if(memory==IntPtr.Zero) throw new InvalidOperationException("COMMAND_LINE_UNAVAILABLE");
   try {var result=new string[count];for(int i=0;i<count;i++)result[i]=Marshal.PtrToStringUni(Marshal.ReadIntPtr(memory,i*IntPtr.Size));return result;}
   finally {LocalFree(memory);}
  }
 }
}
'@
    }
    return [CodexRemote.BrokerCommandLine]::Parse($CommandLine)
}

function Test-BrokerRuntimeTuple([string]$Executable,[string]$Script,$Candidate) {
    try {
        foreach($value in @($Candidate.nodeExecutable,$Candidate.runtimeRoot)){
            if($value -isnot [string] -or -not [IO.Path]::IsPathFullyQualified($value) -or $value -match '["\x00-\x1f\x7f]'){return $false}
        }
        return [IO.Path]::GetFullPath($Candidate.nodeExecutable) -ieq $Executable -and
            [IO.Path]::GetFullPath((Join-Path $Candidate.runtimeRoot 'run-broker.cjs')) -ieq $Script
    } catch {return $false}
}

function Test-SelectedManagedBroker($Broker,[string]$ConfigPath,$CurrentRequest,[string]$CurrentRequestPath) {
    # 历史请求只是来源候选；必须与当前真实进程的完整 argv 逐项交叉核对。
    try {
        if(-not $Broker -or $Broker.Name -ine 'node.exe' -or -not $Broker.ExecutablePath){return $false}
        $argv=@(Read-BrokerProcessArguments ([string]$Broker.CommandLine))
        if($argv.Count -ne 3){return $false}
        foreach($value in @($Broker.ExecutablePath)+$argv+@($ConfigPath,$CurrentRequestPath)){
            if(-not [IO.Path]::IsPathFullyQualified($value) -or $value -match '["\x00-\x1f\x7f]'){return $false}
        }
        $executable=[IO.Path]::GetFullPath($Broker.ExecutablePath)
        $selected=[IO.Path]::GetFullPath($ConfigPath)
        if([IO.Path]::GetFullPath($argv[0]) -ine $executable -or [IO.Path]::GetFullPath($argv[2]) -ine $selected){return $false}
        $script=[IO.Path]::GetFullPath($argv[1])
        if(Test-BrokerRuntimeTuple $executable $script $CurrentRequest){return $true}

        $manager=[IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($CurrentRequestPath))
        $run=[IO.Path]::GetDirectoryName($selected)
        # 仅为同一受管 run 提供跨目录兼容；外部导入文件不能借用历史记录。
        if([IO.Path]::GetFileName($selected) -ine 'config.json' -or
            [IO.Path]::GetDirectoryName($run) -ine (Join-Path $manager 'runs') -or
            [IO.Path]::GetFileName($run) -notmatch '^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$'){return $false}
        Assert-PackagedDesktopPrivatePath $manager
        $files=@(Get-ChildItem -LiteralPath $manager -Filter 'request-*.json' -File | Sort-Object LastWriteTime -Descending | Select-Object -First 512)
        foreach($file in $files){
            if($file.Name -notmatch '^request-([a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12})\.json$' -or $file.Length -gt 65536){continue}
            $launchId=$matches[1]
            try {
                Assert-PackagedDesktopPrivatePath $file.FullName
                $prior=Get-Content -LiteralPath $file.FullName -Raw | ConvertFrom-Json
                if($prior.schema -ne 1 -or $prior.runtimeMode -ne 'shared-engine' -or $prior.launchId -cne $launchId -or
                    -not $prior.sharedEngineConfigFile -or [IO.Path]::GetFullPath([string]$prior.sharedEngineConfigFile) -ine $selected -or
                    -not $prior.statusFile -or [IO.Path]::GetFullPath([string]$prior.statusFile) -ine (Join-Path $manager ('launch-'+$launchId+'.json'))){continue}
                if(Test-BrokerRuntimeTuple $executable $script $prior){return $true}
            } catch {continue}
        }
    } catch {return $false}
    return $false
}
