﻿#requires -Version 5.1
param(
    [Parameter(Mandatory = $true)][string]$ConfigPath,
    [Parameter(Mandatory = $true)][string]$ResultPath,
    [Parameter(Mandatory = $true)][ValidateSet('Shared', 'Original')][string]$Mode,
    [switch]$ProbeOnly
)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$resultLocationVerified = $false
if ($ProbeOnly -and $Mode -ne 'Shared') { exit 1 }

function ConvertTo-PackagedParentArgument([string]$Value) {
    if ($Value -match '["\x00-\x1f\x7f]') { throw 'PACKAGED_ARGUMENT_INVALID' }
    return '"' + $Value + '"'
}

function Write-PackagedParentFailure($Failure) {
    if (Test-Path -LiteralPath $ResultPath) { return }
    $exception = $Failure.Exception
    $native = $null; $inner = $exception
    for ($i = 0; $i -lt 5 -and $null -ne $inner; $i++) {
        if ($inner -is [ComponentModel.Win32Exception]) { $native = $inner.NativeErrorCode; break }
        $inner = $inner.InnerException
    }
    $record = @{ ok = $false; mode = $Mode; diagnostic = @{ type = $exception.GetType().FullName; hresult = $exception.HResult; nativeErrorCode = $native; script = [IO.Path]::GetFileName($Failure.InvocationInfo.ScriptName); line = $Failure.InvocationInfo.ScriptLineNumber; parameter = $(if ($Failure.Exception.ParameterName -match '^[A-Za-z]{1,80}$') { $Failure.Exception.ParameterName } else { $null }) } }
    $temporary = $ResultPath + '.' + [Guid]::NewGuid().ToString() + '.tmp'
    $stream = [IO.File]::Open($temporary, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::Read)
    try {
        $writer = New-Object IO.StreamWriter($stream, (New-Object Text.UTF8Encoding($false)))
        try { $writer.Write(($record | ConvertTo-Json -Depth 5 -Compress)); $writer.Flush() } finally { $writer.Dispose() }
    } finally { $stream.Dispose() }
    try { [IO.File]::Move($temporary, $ResultPath) }
    finally { if (Test-Path -LiteralPath $temporary) { [IO.File]::Delete($temporary) } }
}

try {
    $ConfigPath = [IO.Path]::GetFullPath($ConfigPath)
    $ResultPath = [IO.Path]::GetFullPath($ResultPath)
    if ([IO.Path]::GetDirectoryName($ConfigPath) -ne [IO.Path]::GetDirectoryName($ResultPath) -or
        [IO.Path]::GetFileName($ResultPath) -notmatch '^packaged-desktop-result-[a-f0-9-]{36}\.json$') { throw 'PACKAGED_RESULT_PATH_INVALID' }
    $currentSid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    foreach ($privatePath in @($ConfigPath, [IO.Path]::GetDirectoryName($ConfigPath))) {
        $acl = Get-Acl -LiteralPath $privatePath
        foreach ($rule in $acl.Access) {
            if ($rule.AccessControlType -eq [Security.AccessControl.AccessControlType]::Allow -and
                @($currentSid, 'S-1-5-18', 'S-1-5-32-544') -notcontains $rule.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value) { throw 'PACKAGED_CONFIG_NOT_PRIVATE' }
        }
    }
    $resultLocationVerified = $true
    if ((Test-Path -LiteralPath $ResultPath) -or (Test-Path -LiteralPath ($ResultPath + '.cancel'))) { throw 'PACKAGED_LAUNCH_CANCELLED' }
    if (-not $ProbeOnly -and (Get-Process -Name ChatGPT -ErrorAction SilentlyContinue)) { throw 'PACKAGED_DESKTOP_ALREADY_RUNNING' }
    $config = Get-Content -Raw -LiteralPath $ConfigPath | ConvertFrom-Json
    . (Join-Path $PSScriptRoot 'isolated-desktop-config.ps1')
    $null = Read-IsolatedDesktopSelection $config
    $hasProfile = $null -ne $config.PSObject.Properties['enhancedProfileDirectory']
    $hasPort = $null -ne $config.PSObject.Properties['enhancedPort']
    if ($hasProfile -ne $hasPort) { throw 'PACKAGED_ENHANCED_CONFIG_INCOMPLETE' }
    if ($hasProfile) {
        $profile = $config.enhancedProfileDirectory
        $port = $config.enhancedPort
        if ($profile -isnot [string] -or $profile -match '["\x00-\x1f\x7f]' -or
            ($profile -notmatch '^[A-Za-z]:[\\/]' -and $profile -notmatch '^\\\\[^\\/?]+\\[^\\/?]+\\') -or
            $profile -match '^\\\\[?.]\\' -or [IO.Path]::GetFullPath($profile) -ne $profile -or
            -not (Test-Path -LiteralPath $profile -PathType Container) -or
            ($port -isnot [int] -and $port -isnot [long]) -or $port -lt 1 -or $port -gt 65535) { throw 'PACKAGED_ENHANCED_CONFIG_INVALID' }
    }
    $target = (Resolve-Path -LiteralPath ([string]$config.desktopExecutable)).Path
    if ([IO.Path]::GetFileName($target) -ne 'ChatGPT.exe') { throw 'PACKAGED_TARGET_INVALID' }
    $packageRoot = Split-Path -Parent (Split-Path -Parent $target)
    $manifestPath = Join-Path $packageRoot 'AppxManifest.xml'
    $settings = New-Object Xml.XmlReaderSettings
    $settings.DtdProcessing = [Xml.DtdProcessing]::Prohibit; $settings.XmlResolver = $null
    $reader = [Xml.XmlReader]::Create($manifestPath, $settings)
    try { $manifest = New-Object Xml.XmlDocument; $manifest.XmlResolver = $null; $manifest.Load($reader) } finally { $reader.Dispose() }
    $identityName = [string]$manifest.DocumentElement.Identity.Name
    $packageFolder = Split-Path -Leaf $packageRoot
    $publisher = ($packageFolder -split '_')[-1]
    if ($identityName -ne 'OpenAI.Codex' -or -not $packageFolder.StartsWith($identityName + '_') -or $publisher -notmatch '^[a-z0-9]{13}$') { throw 'PACKAGED_IDENTITY_INVALID' }
    $matching = @($manifest.DocumentElement.Applications.Application | Where-Object {
        $_.Executable -and ([IO.Path]::GetFullPath((Join-Path $packageRoot ([string]$_.Executable)))) -eq $target
    })
    if ($matching.Count -ne 1 -or [string]$matching[0].Id -notmatch '^[A-Za-z0-9._-]{1,100}$') { throw 'PACKAGED_APP_ID_INVALID' }
    $family = $identityName + '_' + $publisher
    $appId = [string]$matching[0].Id
    $powershell = Join-Path $env:SystemRoot 'System32/WindowsPowerShell/v1.0/powershell.exe'
    $childScript = Join-Path $PSScriptRoot 'packaged-desktop-child.ps1'
    if (-not (Test-Path -LiteralPath $powershell -PathType Leaf) -or -not (Test-Path -LiteralPath $childScript -PathType Leaf)) { throw 'PACKAGED_HELPER_MISSING' }
    $childArguments = '-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File ' + (ConvertTo-PackagedParentArgument $childScript) + ' -ConfigPath ' + (ConvertTo-PackagedParentArgument $ConfigPath) + ' -ResultPath ' + (ConvertTo-PackagedParentArgument $ResultPath) + ' -Mode ' + $Mode
    if ($ProbeOnly) { $childArguments += ' -ProbeOnly' }
    if (-not $ProbeOnly -and (Get-Process -Name ChatGPT -ErrorAction SilentlyContinue)) { throw 'PACKAGED_DESKTOP_ALREADY_RUNNING' }
    if (Test-Path -LiteralPath ($ResultPath + '.cancel')) { throw 'PACKAGED_LAUNCH_CANCELLED' }
    $null = Invoke-CommandInDesktopPackage -PackageFamilyName $family -AppId $appId -Command $powershell -Args $childArguments -PreventBreakaway -ErrorAction Stop
    $deadline = [DateTime]::UtcNow.AddSeconds(18)
    while (-not (Test-Path -LiteralPath $ResultPath)) {
        if ([DateTime]::UtcNow -gt $deadline -or (Test-Path -LiteralPath ($ResultPath + '.cancel'))) { throw 'PACKAGED_CHILD_RESULT_TIMEOUT' }
        Start-Sleep -Milliseconds 100
    }
    exit 0
} catch {
    Write-Output ('PACKAGED_PARENT_ERROR_LINE_' + $_.InvocationInfo.ScriptLineNumber)
    Write-Output ($_.Exception.GetType().FullName)
    if ($resultLocationVerified) { try { Write-PackagedParentFailure $_ } catch { } }
    exit 1
}
