'use strict';

const fs = require('node:fs');
const path = require('node:path');
const childProcess = require('node:child_process');
const os = require('node:os');

const PIPE = /^codex-app-tools-[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
const MAX_PIPES = 16;
const MAX_METADATA = 65536;
const fail = () => Object.assign(new Error('APP_TOOLS_BRIDGE_FAILED'), {code:'APP_TOOLS_BRIDGE_FAILED'});
const exitUnknown = () => Object.assign(new Error('APP_TOOLS_BRIDGE_CHILD_EXIT_UNKNOWN'), {code:'APP_TOOLS_BRIDGE_CHILD_EXIT_UNKNOWN'});
const discoveryAborted = () => Object.assign(new Error('APP_TOOLS_BRIDGE_DISCOVERY_ABORTED'), {code:'APP_TOOLS_BRIDGE_DISCOVERY_ABORTED'});
const discoveryExitUnknown = () => Object.assign(new Error('APP_TOOLS_BRIDGE_DISCOVERY_EXIT_UNKNOWN'), {code:'APP_TOOLS_BRIDGE_DISCOVERY_EXIT_UNKNOWN'});
const defaultHelper = path.resolve(__dirname, '../../windows-agent/discover-pipes.ps1');
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

function windowsPath(value, canonical = false) {
  if (typeof value !== 'string' || !value || /["\x00-\x1f\x7f]/.test(value)) throw fail();
  const separators = value.replaceAll('/', '\\');
  if (!/^(?:[a-z]:\\|\\\\[^\\/?]+\\[^\\/?]+\\)/i.test(separators) || /^\\\\[?.]\\/.test(separators)) throw fail();
  const normalized = path.win32.normalize(separators);
  if (canonical && normalized !== separators) throw fail();
  return normalized;
}

function profileKey(value) {
  const normalized = windowsPath(value);
  return (normalized.length > path.win32.parse(normalized).root.length ? normalized.replace(/\\+$/, '') : normalized).toLowerCase();
}

function deriveServerPath(config, fileSystem = fs) {
  const executable = windowsPath(config?.desktopExecutable, true);
  if (path.win32.basename(executable).toLowerCase() !== 'chatgpt.exe' || !fileSystem.statSync(executable).isFile()) throw fail();
  const server = path.win32.join(path.win32.dirname(executable), 'resources', 'plugins', 'openai-bundled', 'plugins', 'codex-app-tools', 'server.mjs');
  if (!fileSystem.statSync(server).isFile()) throw fail();
  if (config.enhancedProfileDirectory != null) {
    const profile = windowsPath(config.enhancedProfileDirectory, true);
    if (!fileSystem.statSync(profile).isDirectory()) throw fail();
  }
  return server;
}

function selectOwner(owners, profile) {
  if (!Array.isArray(owners) || owners.length > MAX_PIPES) throw fail();
  const target = profile == null ? null : profileKey(profile);
  const names = new Set();
  for (const owner of owners) {
    if (!owner || typeof owner !== 'object' || !PIPE.test(owner.name) || !Number.isSafeInteger(owner.pid) || owner.pid <= 0
      || names.has(owner.name.toLowerCase()) || typeof owner.isDefault !== 'boolean') throw fail();
    names.add(owner.name.toLowerCase());
  }
  const matches = owners.filter(owner => target === null
    ? owner.isDefault === true && owner.profile == null
    : owner.isDefault === false && typeof owner.profile === 'string' && profileKey(owner.profile) === target);
  if (matches.length > 1) throw fail();
  return matches[0] ?? null;
}

// 两个 helper 均只输出元数据；stdout/stderr 有界，不传播子进程原始异常。
function helper(binary, args, input, {deadline, budget, execFile, now, env, signal, cancelTimeoutMs}) {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) { reject(discoveryAborted()); return; }
    const timeout = deadline - now();
    if (timeout <= 0 || budget.bytes >= MAX_METADATA) { reject(fail()); return; }
    let child, settled = false, stopping = false, stopError, deadlineTimer, cancellationTimer;
    const cleanup = () => {
      clearTimeout(deadlineTimer); clearTimeout(cancellationTimer);
      signal?.removeEventListener('abort', abort);
      child?.off('exit', stopped); child?.off('close', stopped);
    };
    const finish = (error, value) => {
      if (settled) return;
      settled = true; cleanup();
      error ? reject(error) : resolve(value);
    };
    const stopped = () => { if (stopping) finish(stopError); };
    const stop = error => {
      if (settled || stopping) return;
      stopping = true; stopError = error;
      clearTimeout(deadlineTimer);
      // 只终止此处创建的 PowerShell；kill 返回值和 error 都不等于确认退出。
      cancellationTimer = setTimeout(() => finish(discoveryExitUnknown()), cancelTimeoutMs);
      if (child?.exitCode != null || child?.signalCode != null) { finish(stopError); return; }
      try { child?.kill('SIGKILL'); } catch {}
    };
    const abort = () => stop(discoveryAborted());
    try {
      signal?.addEventListener('abort', abort, {once:true});
      if (signal?.aborted) { finish(discoveryAborted()); return; }
      const helperEnv = {...env};
      for (const key of Object.keys(helperEnv)) if (key.toLowerCase() === 'psmodulepath') delete helperEnv[key];
      child = execFile(binary, args, {windowsHide:true, timeout:Math.min(timeout, 10000), maxBuffer:MAX_METADATA,
        encoding:'utf8', killSignal:'SIGKILL', env:helperEnv}, (error, stdout) => {
        if (settled || stopping) return;
        if (signal?.aborted) { abort(); return; }
        if (error || typeof stdout !== 'string') { finish(fail()); return; }
        budget.bytes += Buffer.byteLength(stdout);
        if (budget.bytes > MAX_METADATA || now() >= deadline) { finish(fail()); return; }
        try { finish(null, JSON.parse(stdout.replace(/^\uFEFF/, ''))); } catch { finish(fail()); }
      });
      if (settled) return;
      child.once('exit', stopped); child.once('close', stopped);
      // execFile 正常会处理 error；额外保留空监听，覆盖取消后的晚到注入错误。
      child.on('error', () => {});
      deadlineTimer = setTimeout(() => stop(fail()), Math.min(timeout, 10000));
      if (stopping || signal?.aborted) {
        // 注入execFile也可能在返回child前同步触发abort。
        if (!stopping) abort();
        else { try { child.kill('SIGKILL'); } catch {} }
        return;
      }
      child.stdin.on('error', () => {});
      child.stdin.end(input);
    } catch {
      if (child && !settled) stop(fail());
      else finish(fail());
    }
  });
}

async function discoverOwners({deadline, budget = {bytes:0}, execFile = childProcess.execFile, now = Date.now,
  powershell = path.win32.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe'), helperPath = defaultHelper, env = process.env,
  signal, cancelTimeoutMs = 1000} = {}) {
  if (!Number.isFinite(deadline) || !Number.isSafeInteger(cancelTimeoutMs) || cancelTimeoutMs < 1 || cancelTimeoutMs > 1000
    || signal != null && (typeof signal.aborted !== 'boolean' || typeof signal.addEventListener !== 'function' || typeof signal.removeEventListener !== 'function')) throw fail();
  if (signal?.aborted) throw discoveryAborted();
  const query = "$ErrorActionPreference='Stop';$names=@([IO.Directory]::EnumerateFiles('\\\\.\\pipe\\') | ForEach-Object {[IO.Path]::GetFileName($_)} | Where-Object {$_ -match '^codex-app-tools-[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$'} | Select-Object -First 17);if($names.Count -gt 16){exit 1};ConvertTo-Json -InputObject @($names) -Compress";
  const options = {deadline, budget, execFile, now, env, signal, cancelTimeoutMs};
  const names = await helper(powershell, ['-NoProfile','-NonInteractive','-Command',query], '', options);
  if (signal?.aborted) throw discoveryAborted();
  if (!Array.isArray(names) || names.length > MAX_PIPES || names.some(name => typeof name !== 'string' || !PIPE.test(name))
    || new Set(names.map(name => name.toLowerCase())).size !== names.length) throw fail();
  if (!names.length) return [];
  const result = await helper(powershell, ['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',helperPath], JSON.stringify(names), options);
  if (signal?.aborted) throw discoveryAborted();
  if (!Array.isArray(result) || result.length > MAX_PIPES || result.some(owner => !names.includes(owner?.name))) throw fail();
  return result;
}

function launchServer(server, owner, {spawn = childProcess.spawn, env = process.env} = {}) {
  return spawn(process.execPath, [server], {stdio:'inherit', windowsHide:true, shell:false,
    env:{...env, CODEX_APP_TOOLS_PIPE_PATH:'\\\\.\\pipe\\' + owner.name, CODEX_APP_TOOLS_CALLER_HOST_ID:'local'}});
}

function childExit(child, {signals = process, killMs = 2000} = {}) {
  return new Promise((resolve, reject) => {
    let timer, settled = false, stopping = false;
    const subscriptions = [];
    const finish = (error, code) => {
      if (settled) return;
      settled = true; clearTimeout(timer);
      for (const [signal, listener] of subscriptions) signals.off(signal, listener);
      child.off('error', errored); child.off('exit', exited);
      if (error?.code === 'APP_TOOLS_BRIDGE_CHILD_EXIT_UNKNOWN') {
        // 模块调用方仍在运行时，未退出 child 的晚到 error 不能崩溃宿主或泄露原文。
        const ignoreLateError = () => {};
        child.on('error', ignoreLateError);
        child.once('exit', () => child.off('error', ignoreLateError));
      }
      error ? reject(error) : resolve(code);
    };
    // kill 的异步 error 也不能冒充 exit；停止过程中继续等退出确认。
    const errored = () => { if (!stopping) finish(fail()); };
    const exited = (code, signal) => finish(null, Number.isInteger(code) && code >= 0 && code <= 255 ? code
      : signal && os.constants.signals[signal] ? 128 + os.constants.signals[signal] : 1);
    child.on('error', errored); child.once('exit', exited);
    for (const signal of ['SIGINT','SIGTERM','SIGHUP']) {
      const listener = () => {
        if (stopping || settled) return;
        stopping = true;
        try { child.kill('SIGTERM'); } catch {}
        if (settled) return;
        timer = setTimeout(() => {
          try { child.kill('SIGKILL'); } catch {}
          // 两次等待都结束仍无 exit：可能遗留本工具的 MCP child，绝不返回成功。
          if (!settled) timer = setTimeout(() => finish(exitUnknown()), killMs);
        }, killMs);
      };
      signals.on(signal, listener); subscriptions.push([signal, listener]);
    }
    if (child.exitCode != null) exited(child.exitCode, child.signalCode);
  });
}

async function run({configPath, discover = discoverOwners, launch = launchServer, fileSystem = fs,
  now = Date.now, delay = sleep, signals = process, killMs = 2000} = {}) {
  try {
    if (!Number.isSafeInteger(killMs) || killMs < 1 || killMs > 10000) throw fail();
    if (typeof configPath !== 'string' || !configPath || /[\x00-\x1f\x7f]/.test(configPath)) throw fail();
    const stat = fileSystem.statSync(configPath);
    if (!stat.isFile() || !Number.isSafeInteger(stat.size) || stat.size < 2 || stat.size > MAX_METADATA) throw fail();
    const contents = fileSystem.readFileSync(configPath, 'utf8');
    if (Buffer.byteLength(contents) > MAX_METADATA) throw fail();
    const config = JSON.parse(contents.replace(/^\uFEFF/, ''));
    if (!config || typeof config !== 'object' || Array.isArray(config)) throw fail();
    const server = deriveServerPath(config, fileSystem);
    const deadline = now() + 10000, budget = {bytes:0};
    let owner, ownerMetadataBytes = 0;
    while (!owner) {
      if (now() >= deadline) throw fail();
      const owners = await discover({deadline, budget, now});
      // 注入发现器也必须遵守总元数据上界。
      ownerMetadataBytes += Buffer.byteLength(JSON.stringify(owners));
      if (ownerMetadataBytes > MAX_METADATA || budget.bytes > MAX_METADATA) throw fail();
      owner = selectOwner(owners, config.enhancedProfileDirectory);
      if (!owner) await delay(Math.min(200, Math.max(0, deadline - now())));
    }
    if (now() >= deadline) throw fail();
    const child = launch(server, owner);
    if (!child || typeof child.once !== 'function' || typeof child.kill !== 'function') throw fail();
    return await childExit(child, {signals, killMs});
  } catch (error) { throw error?.code === 'APP_TOOLS_BRIDGE_CHILD_EXIT_UNKNOWN' ? exitUnknown() : fail(); }
}

if (require.main === module) {
  const args = process.argv.slice(2);
  if (args.length !== 2 || args[0] !== '--config') {
    process.stderr.write('APP_TOOLS_BRIDGE_FAILED\n'); process.exitCode = 1;
  } else run({configPath:args[1]}).then(code => { process.exitCode = code; }, error => {
    const unknown = error?.code === 'APP_TOOLS_BRIDGE_CHILD_EXIT_UNKNOWN';
    process.stderr.write((unknown ? 'APP_TOOLS_BRIDGE_CHILD_EXIT_UNKNOWN' : 'APP_TOOLS_BRIDGE_FAILED') + '\n');
    // 未确认退出时只结束 wrapper 自身；不能宣称 child 已退出，也不追杀 PID 树。
    if (unknown) process.exit(1);
    else process.exitCode = 1;
  });
}

module.exports = {run, discoverOwners, selectOwner, deriveServerPath, launchServer};
