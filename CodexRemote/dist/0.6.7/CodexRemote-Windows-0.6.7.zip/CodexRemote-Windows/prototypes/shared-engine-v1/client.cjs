'use strict';

const {EventEmitter} = require('node:events');
const crypto = require('node:crypto');
const WebSocket = require('ws');

const error = (code, message) => Object.assign(new Error(message), {code});
const boundedInteger = (value, fallback, min, max, name) => {
  const result = value ?? fallback;
  if (!Number.isSafeInteger(result) || result < min || result > max) throw error('BAD_INPUT', `${name} 超出范围。`);
  return result;
};

/** 独立研究客户端；断开只关闭自己的 WebSocket，不管理 daemon 生命周期。 */
class SharedClient extends EventEmitter {
  #authorization;
  #token;

  constructor({url, token, name = 'codex_remote_shared', maxPayload, maxPayloadBytes, maxPending, maxWriteBufferBytes, maxQueuedMessages, writeTimeoutMs, requestTimeoutMs, connectTimeoutMs, initializeTimeoutMs, closeTimeoutMs} = {}) {
    super();
    let endpoint;
    try { if (typeof url !== 'string' || url.length > 4096) throw new Error(); endpoint = new URL(url); }
    catch { throw error('BAD_INPUT', '共享引擎 URL 无效。'); }
    if (endpoint.protocol !== 'ws:' || !['127.0.0.1', '[::1]', 'localhost'].includes(endpoint.hostname) || endpoint.pathname !== '/rpc' || endpoint.search || endpoint.hash) throw error('BAD_INPUT', '共享引擎仅允许本机 ws://loopback:<port>/rpc。');
    let user = '', password = '';
    try { user = decodeURIComponent(endpoint.username); password = decodeURIComponent(endpoint.password); }
    catch { throw error('BAD_INPUT', '共享引擎 URL 用户信息无效。'); }
    if ((user || password) && user !== 'codex') throw error('BAD_INPUT', '共享引擎 Basic 用户名必须为 codex。');
    if (token !== undefined && password && token !== password) throw error('BAD_INPUT', 'URL 与参数中的共享引擎凭据不一致。');
    const secret = token ?? password;
    if (typeof secret !== 'string' || secret.length < 1 || secret.length > 512 || /[\s\x00-\x1f\x7f]/u.test(secret)) throw error('BAD_INPUT', '共享引擎需要有效 token。');
    if (typeof name !== 'string' || !/^[a-zA-Z0-9_.-]{1,64}$/.test(name)) throw error('BAD_INPUT', '客户端名称无效。');
    // 本机别名固定解析到 loopback；凭据从公开 URL 中移除，避免异常消息泄露。
    if (endpoint.hostname === 'localhost') endpoint.hostname = '127.0.0.1';
    endpoint.username = ''; endpoint.password = '';
    this.url = endpoint.href; this.name = name;
    this.#token = secret;
    this.#authorization = 'Basic ' + Buffer.from('codex:' + secret).toString('base64');
    this.maxPayload = boundedInteger(maxPayloadBytes ?? maxPayload, 4 * 1024 * 1024, 1024, 16 * 1024 * 1024, 'maxPayload');
    this.maxPending = boundedInteger(maxPending, 256, 1, 1024, 'maxPending');
    this.maxWriteBufferBytes = boundedInteger(maxWriteBufferBytes, 8 * 1024 * 1024, 1024, 64 * 1024 * 1024, 'maxWriteBufferBytes');
    this.maxQueuedMessages = boundedInteger(maxQueuedMessages, 256, 1, 1024, 'maxQueuedMessages');
    this.writeTimeoutMs = boundedInteger(writeTimeoutMs, 10000, 1, 30000, 'writeTimeoutMs');
    this.requestTimeoutMs = boundedInteger(requestTimeoutMs, 30000, 1, 120000, 'requestTimeoutMs');
    this.connectTimeoutMs = boundedInteger(connectTimeoutMs, 10000, 1, 30000, 'connectTimeoutMs');
    this.initializeTimeoutMs = boundedInteger(initializeTimeoutMs, 15000, 1, 120000, 'initializeTimeoutMs');
    this.closeTimeoutMs = boundedInteger(closeTimeoutMs, 1000, 1, 5000, 'closeTimeoutMs');
    this.clientId = crypto.randomUUID(); this.sequence = 0; this.pending = new Map();
    this.serverRequests = new Map(); this.seenServerRequests = new Set();
    this.writeQueue = []; this.activeWrite = null; this.queuedWriteBytes = 0;
    this.socket = null; this.connected = false; this.closed = false; this.connecting = null; this.closePromise = null;
  }

  _safeMessage(value) { return (typeof value === 'string' ? value : '共享引擎请求失败。').replaceAll(this.#token, '[已隐藏]').replaceAll(this.#authorization, '[已隐藏]').slice(0,2000); }

  _settle(id, failure, result) {
    const pending = this.pending.get(id);
    if (!pending) return;
    this.pending.delete(id); clearTimeout(pending.timer);
    if (failure) this._cancelQueuedWrite(id, failure);
    failure ? pending.reject(failure) : pending.resolve(result);
  }

  _rejectPending(failure) {
    this.serverRequests.clear();
    for (const id of [...this.pending.keys()]) this._settle(id, failure);
  }

  _transportError(code = 'DISCONNECTED') {
    return error(code, code === 'AUTH_FAILED' ? '共享引擎鉴权失败。' : code === 'CLOSED' ? '共享引擎客户端已关闭。' : '共享引擎 WebSocket 连接已断开。');
  }

  _report(failure) {
    // EventEmitter 的 error 无订阅时会抛出，传输异常不能因此终止宿主进程。
    if (this.listenerCount('error')) this.emit('error', failure);
  }

  _invalid(socket) {
    if (socket !== this.socket) return;
    const failure = error('INVALID_MESSAGE', '共享引擎返回了无效 JSON-RPC 帧。');
    this.connected = false; this._rejectPending(failure); this._discardWrites(failure); this.emit('protocolError', failure);
    try { socket.close(1002, 'Invalid JSON-RPC'); } catch { socket.terminate(); }
  }

  _message(socket, bytes, isBinary) {
    if (socket !== this.socket || this.closed) return;
    let message;
    // app-server 每个 WebSocket message 只包含一个 JSON 对象，不接受数组或 JSONL。
    try { const source = isBinary ? new TextDecoder('utf-8', {fatal:true}).decode(bytes) : bytes.toString('utf8'); message = JSON.parse(source); }
    catch { this._invalid(socket); return; }
    if (!message || typeof message !== 'object' || Array.isArray(message)) { this._invalid(socket); return; }
    if (message.id !== undefined && message.id !== null && !((typeof message.id === 'string' && message.id.length <= 256) || Number.isSafeInteger(message.id))) { this._invalid(socket); return; }
    if (typeof message.method === 'string' && message.method.length > 0 && message.method.length <= 256) {
      if (message.id !== undefined && message.id !== null) {
        // 审批归属由调用方决定；此处只通知，绝不自动替其他客户端答复。
        if (this.seenServerRequests.has(message.id)) return;
        if (this.serverRequests.size >= this.maxPending || this.seenServerRequests.size >= 4096) { this._invalid(socket); return; }
        this.seenServerRequests.add(message.id);
        this.serverRequests.set(message.id, {socket, threadId:message.params?.threadId});
        this.emit('serverRequest', message);
      } else {
        if (message.method === 'serverRequest/resolved') {
          const request = this.serverRequests.get(message.params?.requestId);
          if (request?.threadId === message.params?.threadId) this.serverRequests.delete(message.params.requestId);
        }
        this.emit('notification', message);
      }
      return;
    }
    const hasResult = Object.hasOwn(message, 'result'), hasError = Object.hasOwn(message, 'error');
    if (message.method !== undefined || message.id === undefined || message.id === null || hasResult === hasError || (hasError && (!message.error || typeof message.error !== 'object'))) { this._invalid(socket); return; }
    if (hasError) {
      const failure = error('RPC_ERROR', this._safeMessage(message.error.message));
      if (typeof message.error.code === 'number') failure.rpcCode = message.error.code;
      this._settle(message.id, failure);
    } else this._settle(message.id, null, message.result);
  }

  async connect() {
    if (this.closed) throw this._transportError('CLOSED');
    if (this.connected) return this.initializeResult;
    if (this.connecting) return this.connecting;
    const task = (async () => {
      const socket = new WebSocket(this.url, {headers:{Authorization:this.#authorization}, followRedirects:false, maxPayload:this.maxPayload, perMessageDeflate:false, handshakeTimeout:this.connectTimeoutMs});
      this.serverRequests.clear(); this.seenServerRequests.clear();
      this.socket = socket;
      socket.on('message', (bytes, binary) => this._message(socket, bytes, binary));
      socket.on('error', () => {
        if (socket !== this.socket) return;
        this.connected = false; const failure = this._transportError(); this._rejectPending(failure); this._discardWrites(failure); this._report(failure);
      });
      socket.on('close', (code) => {
        if (socket !== this.socket) return;
        this.connected = false; const failure = this._transportError(this.closed ? 'CLOSED' : 'DISCONNECTED'); this._rejectPending(failure); this._discardWrites(failure);
        this.emit('disconnect', {code});
      });
      try {
        await new Promise((resolve, reject) => {
          const cleanup = () => { clearTimeout(timer); socket.off('open', opened); socket.off('error', failed); socket.off('close', ended); socket.off('unexpected-response', rejected); };
          const opened = () => { cleanup(); resolve(); };
          const failed = () => { cleanup(); reject(this._transportError()); };
          const ended = () => { cleanup(); reject(this._transportError(this.closed ? 'CLOSED' : 'DISCONNECTED')); };
          const rejected = (_request, response) => { cleanup(); response.resume(); socket.terminate(); reject(this._transportError(response.statusCode === 401 || response.statusCode === 403 ? 'AUTH_FAILED' : 'CONNECT_FAILED')); };
          const timer = setTimeout(() => { cleanup(); socket.terminate(); reject(error('CONNECT_TIMEOUT', '共享引擎连接超时。')); }, this.connectTimeoutMs);
          timer.unref?.();
          socket.once('open', opened); socket.once('error', failed); socket.once('close', ended); socket.once('unexpected-response', rejected);
        });
        if (this.closed) throw this._transportError('CLOSED');
        const result = await this._request('initialize', {clientInfo:{name:this.name, title:'Codex Remote shared-engine research', version:'0.1.0'}, capabilities:{experimentalApi:true}}, this.initializeTimeoutMs);
        if (this.closed || socket !== this.socket || socket.readyState !== WebSocket.OPEN) throw this._transportError(this.closed ? 'CLOSED' : 'DISCONNECTED');
        await this._write(socket, JSON.stringify({method:'initialized', params:{}}));
        this.initializeResult = result; this.connected = true;
        return result;
      } catch (failure) {
        this.connected = false; this._rejectPending(failure); this._discardWrites(failure);
        if (socket.readyState !== WebSocket.CLOSED) socket.terminate();
        throw failure;
      }
    })();
    this.connecting = task;
    try { return await task; } finally { if (this.connecting === task) this.connecting = null; }
  }

  _discardWrites(failure) {
    const writes = [...this.writeQueue, ...(this.activeWrite ? [this.activeWrite] : [])];
    this.writeQueue = []; this.activeWrite = null; this.queuedWriteBytes = 0;
    for (const write of writes) if (!write.done) { write.done = true; clearTimeout(write.timer); write.serialized = null; write.reject(failure); }
  }

  _abortWrites(socket, failure) {
    if (socket !== this.socket) return;
    this.connected = false;
    // 先清发送状态，再结算 RPC，避免结算时递归触发同一待写项。
    this._discardWrites(failure); this._rejectPending(failure);
    try { socket.terminate(); } catch { /* 仅终止当前客户端的 socket。 */ }
  }

  _cancelQueuedWrite(id, failure) {
    const index = this.writeQueue.findIndex(write => write.id === id);
    if (index >= 0) {
      const [write] = this.writeQueue.splice(index, 1);
      if (!write.done) { write.done = true; clearTimeout(write.timer); this.queuedWriteBytes -= write.bytes; write.serialized = null; write.reject(failure); }
    }
    // send callback 未确认时不能撤回 ws 已接收的数据；关闭连接避免超时后继续堆积。
    if (failure.code === 'RPC_TIMEOUT' && this.activeWrite?.id === id) this._abortWrites(this.activeWrite.socket, error('WRITE_TIMEOUT', '共享引擎写入未确认，连接已关闭；不会自动重发。'));
  }

  _pumpWrites(socket) {
    if (this.activeWrite || !this.writeQueue.length || socket !== this.socket || this.closed) return;
    if (socket.readyState !== WebSocket.OPEN) { this._abortWrites(socket, this._transportError()); return; }
    const buffered = socket.bufferedAmount;
    if (!Number.isFinite(buffered) || buffered < 0 || this.queuedWriteBytes + buffered > this.maxWriteBufferBytes) { this._abortWrites(socket, error('SEND_BACKPRESSURE', '共享引擎发送缓冲已达上限，连接已关闭。')); return; }
    const write = this.writeQueue.shift(); this.activeWrite = write;
    // initialized 等无 RPC ID 的通知同样必须在有界时间内完成写入。
    write.timer = setTimeout(() => this._abortWrites(socket, error('WRITE_TIMEOUT', '共享引擎写入超时，连接已关闭；不会自动重发。')), this.writeTimeoutMs);
    write.timer.unref?.();
    const complete = failure => {
      if (write.done) return;
      write.done = true; clearTimeout(write.timer); write.serialized = null;
      this.queuedWriteBytes -= write.bytes;
      if (this.activeWrite === write) this.activeWrite = null;
      if (failure) { const disconnected = this._transportError(); write.reject(disconnected); this._abortWrites(socket, disconnected); }
      else { write.resolve(); this._pumpWrites(socket); }
    };
    try { socket.send(write.serialized, complete); } catch { complete(true); }
  }

  _write(socket, serialized, id) {
    if (socket !== this.socket || socket.readyState !== WebSocket.OPEN || this.closed) return Promise.reject(this._transportError(this.closed ? 'CLOSED' : 'DISCONNECTED'));
    const bytes = Buffer.byteLength(serialized), buffered = socket.bufferedAmount;
    if (!Number.isFinite(buffered) || buffered < 0 || this.writeQueue.length + (this.activeWrite ? 1 : 0) >= this.maxQueuedMessages || this.queuedWriteBytes + buffered + bytes > this.maxWriteBufferBytes) {
      const failure = error('SEND_BACKPRESSURE', '共享引擎发送缓冲已达上限，连接已关闭。');
      this._abortWrites(socket, failure); return Promise.reject(failure);
    }
    return new Promise((resolve, reject) => {
      this.writeQueue.push({socket, serialized, id, bytes, resolve, reject, done:false});
      this.queuedWriteBytes += bytes; this._pumpWrites(socket);
    });
  }

  _request(method, params, timeoutMs) {
    const socket = this.socket;
    if (!socket || socket.readyState !== WebSocket.OPEN || this.closed) return Promise.reject(this._transportError(this.closed ? 'CLOSED' : 'NOT_CONNECTED'));
    if (typeof method !== 'string' || !method || method.length > 256) return Promise.reject(error('BAD_INPUT', 'JSON-RPC 方法名称无效。'));
    if (this.pending.size >= this.maxPending) return Promise.reject(error('PENDING_LIMIT', '共享引擎并发请求已达上限。'));
    if (!Number.isSafeInteger(this.sequence + 1)) return Promise.reject(error('SEQUENCE_LIMIT', '客户端请求序列已达上限。'));
    const id = `${this.clientId}:${++this.sequence}`;
    let serialized;
    try { serialized = JSON.stringify({id, method, params:params ?? {}}); }
    catch { return Promise.reject(error('BAD_INPUT', 'JSON-RPC 参数无法序列化。')); }
    if (Buffer.byteLength(serialized) > this.maxPayload) return Promise.reject(error('REQUEST_TOO_LARGE', '共享引擎请求超过大小限制。'));
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => this._settle(id, error('RPC_TIMEOUT', `共享引擎请求超时：${this._safeMessage(method)}`)), timeoutMs);
      timer.unref?.(); this.pending.set(id, {resolve, reject, timer});
      this._write(socket, serialized, id).catch(failure => this._settle(id, failure));
    });
  }

  request(method, params = {}, timeoutMs = this.requestTimeoutMs) {
    if (!this.connected) return Promise.reject(this._transportError(this.closed ? 'CLOSED' : 'NOT_CONNECTED'));
    try { timeoutMs = boundedInteger(timeoutMs, this.requestTimeoutMs, 1, 120000, 'timeoutMs'); }
    catch (failure) { return Promise.reject(failure); }
    return this._request(method, params, timeoutMs);
  }

  async respond(id, result) {
    if (!this.connected || this.closed) throw this._transportError(this.closed ? 'CLOSED' : 'NOT_CONNECTED');
    const request = this.serverRequests.get(id), socket = this.socket;
    if (!request || request.socket !== socket) throw error('SERVER_REQUEST_NOT_PENDING', '本连接没有可答复的请求，或请求已答复或失效。');
    let serialized;
    try { serialized = JSON.stringify({id, result}); }
    catch { throw error('BAD_INPUT', 'JSON-RPC 响应无法序列化。'); }
    if (result === undefined || !Object.hasOwn(JSON.parse(serialized), 'result') || Buffer.byteLength(serialized) > this.maxPayload) throw error('BAD_INPUT', 'JSON-RPC 响应无效或超过大小限制。');
    // 写出前即消费权限；写入结果未知时也不能自动或手动重放。
    this.serverRequests.delete(id);
    await this._write(socket, serialized);
    return {sent:true};
  }

  async close() {
    if (this.closePromise) return this.closePromise;
    this.closed = true; this.connected = false; this._rejectPending(this._transportError('CLOSED'));
    this._discardWrites(this._transportError('CLOSED'));
    const socket = this.socket;
    this.closePromise = new Promise(resolve => {
      if (!socket || socket.readyState === WebSocket.CLOSED) { resolve(); return; }
      let settled = false;
      const finish = () => { if (settled) return; settled = true; clearTimeout(timer); socket.off('close', finish); resolve(); };
      const timer = setTimeout(() => { socket.terminate(); finish(); }, this.closeTimeoutMs);
      timer.unref?.(); socket.once('close', finish);
      try { if (socket.readyState === WebSocket.CONNECTING) socket.terminate(); else socket.close(1000, 'Client closed'); }
      catch { socket.terminate(); finish(); }
    });
    return this.closePromise;
  }
}

module.exports = {SharedClient};
