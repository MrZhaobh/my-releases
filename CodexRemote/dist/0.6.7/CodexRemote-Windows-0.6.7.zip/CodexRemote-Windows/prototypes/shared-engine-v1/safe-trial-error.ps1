function Get-SafeTrialError {
    param([System.Management.Automation.ErrorRecord]$Record)
    $chain=@();$exception=$Record.Exception
    for($i=0;$i -lt 4 -and $null -ne $exception;$i++){
        $entry=@{type=$exception.GetType().FullName;hresult=$exception.HResult}
        if($exception -is [System.ComponentModel.Win32Exception]){$entry.nativeErrorCode=$exception.NativeErrorCode}
        $chain+=$entry;$exception=$exception.InnerException
    }
    return @{exceptions=$chain;script=[IO.Path]::GetFileName($Record.InvocationInfo.ScriptName);line=$Record.InvocationInfo.ScriptLineNumber}
}
