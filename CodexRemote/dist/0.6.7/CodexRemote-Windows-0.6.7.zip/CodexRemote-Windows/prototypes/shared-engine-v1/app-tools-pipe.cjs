'use strict';

const nativeNet = require('node:net');
const {randomUUID} = require('node:crypto');

const OWNER_NAME = /^codex-app-tools-[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
const ENDPOINT = /^\\\\\.\\pipe\\codex-remote-tools-[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
const failure = code => Object.assign(new Error(code), {code});
function bounded(value, fallback, maximum) {
  const n = value ?? fallback;
  if (!Number.isSafeInteger(n) || n < 1 || n > maximum) throw failure('APP_TOOLS_PIPE_BAD_INPUT');
  return n;
}

// 仅转发原生协议字节；owner 的进程身份与 profile 核验由注入的 resolver 完成。
function createAppToolsPipe({resolveOwner, pipePath = `\\\\.\\pipe\\codex-remote-tools-${randomUUID()}`,
  maxClients, connectTimeoutMs, closeTimeoutMs, net = nativeNet} = {}) {
  if (typeof resolveOwner !== 'function' || typeof pipePath !== 'string' || !ENDPOINT.test(pipePath)) throw failure('APP_TOOLS_PIPE_BAD_INPUT');
  // 每个已加载会话可能持有独立 MCP 连接；不能沿用外部客户端的 8 个配额。
  maxClients = bounded(maxClients, 32, 64);
  connectTimeoutMs = bounded(connectTimeoutMs, 10000, 60000);
  closeTimeoutMs = bounded(closeTimeoutMs, 2000, 10000);
  const sessions = new Set(), sockets = new Set(), resolverTasks = new Set();
  const counters = {accepted:0, rejected:0, failed:0, completed:0, ownerExitUnknown:0};
  let server, startPromise, closePromise, closing = false, listening = false, lastError = null, closeFailed = false, unsafeOwnerExit = false;
  let notifyCleanup = () => {};
  function getStats() {
    return {...counters, maxClients, activeClients:sessions.size, activeSockets:sockets.size, activeResolvers:resolverTasks.size, listening, closing, lastError};
  }
  function track(socket) {
    sockets.add(socket);
    // 错误监听在 close 后仍保留，避免晚到 error 成为未处理异常。
    socket.on('error', () => {});
    socket.once('close', () => { sockets.delete(socket); notifyCleanup(); });
    return socket;
  }
  function destroy(socket) {
    try { socket?.destroy(); } catch { closeFailed = true; if (!unsafeOwnerExit) lastError = 'APP_TOOLS_PIPE_CLOSE_FAILED'; }
  }
  function accept(inbound) {
    track(inbound);
    if (closing || unsafeOwnerExit || sessions.size >= maxClients) { counters.rejected++; destroy(inbound); return; }
    counters.accepted++;
    const session = {inbound, upstream:null, connected:false, ended:false, resolving:true, outcome:null, timer:null, abort:new AbortController()};
    sessions.add(session);
    const removeClosed = () => {
      if (session.ended && !session.resolving && !sockets.has(inbound) && (!session.upstream || !sockets.has(session.upstream))) {
        clearTimeout(session.timer); sessions.delete(session); notifyCleanup();
      }
    };
    function finish(failed = false, drain = false) {
      if (session.ended) return;
      session.ended = true;
      clearTimeout(session.timer);
      session.abort.abort();
      if (failed) counters.failed++;
      else counters.completed++;
      session.outcome = failed ? 'failed' : 'completed';
      if (drain && session.connected) {
        // 正常 EOF 排空另一端的写缓冲；错误和显式关闭仍立即销毁。
        for (const socket of [inbound, session.upstream]) {
          if (!socket || socket.destroyed) continue;
          try { typeof socket.destroySoon === 'function' ? socket.destroySoon() : destroy(socket); }
          catch { destroy(socket); }
        }
        session.timer = setTimeout(() => { destroy(inbound); destroy(session.upstream); }, closeTimeoutMs);
      } else { destroy(inbound); destroy(session.upstream); }
      removeClosed();
    }
    session.finish = finish;
    inbound.on('error', () => finish(true));
    inbound.once('close', () => { finish(false, true); removeClosed(); });
    inbound.pause();
    session.timer = setTimeout(() => finish(true), connectTimeoutMs);
    const task = Promise.resolve().then(() => session.abort.signal.aborted ? null : resolveOwner({signal:session.abort.signal})).then(owner => {
      if (session.ended || closing) return;
      if (!owner || !OWNER_NAME.test(owner.name) || !Number.isSafeInteger(owner.pid) || owner.pid <= 0) { finish(true); return; }
      const upstream = track(net.createConnection(`\\\\.\\pipe\\${owner.name}`));
      session.upstream = upstream;
      upstream.on('error', () => finish(true));
      upstream.once('close', () => { finish(false, true); removeClosed(); });
      upstream.once('connect', () => {
        if (session.ended || closing) { destroy(upstream); return; }
        clearTimeout(session.timer);
        session.connected = true;
        // Socket.pipe 使用 Node 的背压；建立连接前没有消费入站正文。
        inbound.pipe(upstream); upstream.pipe(inbound); inbound.resume();
      });
    }).catch(error => {
      if (error?.code === 'APP_TOOLS_BRIDGE_DISCOVERY_EXIT_UNKNOWN') {
        // 发现任务已结算不等于 helper 已退出；隔离整个转发器，避免新连接继续累积未知进程。
        unsafeOwnerExit = true; lastError = 'APP_TOOLS_BRIDGE_DISCOVERY_EXIT_UNKNOWN'; counters.ownerExitUnknown++;
        if (session.outcome === 'completed') { counters.completed--; counters.failed++; session.outcome = 'failed'; }
        finish(true);
      } else if (error?.code === 'APP_TOOLS_BRIDGE_DISCOVERY_ABORTED' && session.abort.signal.aborted) finish();
      else finish(true);
    }).finally(() => {
      session.resolving = false; resolverTasks.delete(task); removeClosed(); notifyCleanup();
    });
    resolverTasks.add(task);
  }
  function start() {
    if (closing) return Promise.reject(failure('APP_TOOLS_PIPE_CLOSED'));
    if (startPromise) return startPromise;
    startPromise = new Promise((resolve, reject) => {
      let settled = false;
      const rejectStart = () => {
        if (settled) return;
        settled = true; reject(failure('APP_TOOLS_PIPE_LISTEN_FAILED'));
      };
      try {
        server = net.createServer(accept);
        server.on('error', () => {
          if (!unsafeOwnerExit) lastError = 'APP_TOOLS_PIPE_LISTEN_FAILED';
          rejectStart();
          for (const session of [...sessions]) session.finish(true);
        });
        server.once('close', () => { listening = false; rejectStart(); });
        server.listen(pipePath, () => {
          if (closing) { rejectStart(); return; }
          listening = true; settled = true; resolve({pipePath});
        });
      } catch { rejectStart(); }
    });
    return startPromise;
  }
  function close() {
    if (closePromise) return closePromise;
    closing = true;
    closePromise = (async () => {
      for (const session of [...sessions]) session.finish();
      for (const socket of [...sockets]) destroy(socket);
      let serverClosed = !server;
      await new Promise(resolve => {
        let timer;
        const complete = () => { clearTimeout(timer); notifyCleanup = () => {}; resolve(); };
        const check = () => { if (serverClosed && sockets.size === 0 && resolverTasks.size === 0 && sessions.size === 0) complete(); };
        notifyCleanup = check;
        timer = setTimeout(complete, closeTimeoutMs);
        for (const socket of sockets) socket.once('close', check);
        if (server) {
          try { server.close(() => { serverClosed = true; listening = false; check(); }); }
          catch { serverClosed = !listening; }
        }
        check();
      });
      const stats = getStats();
      const timedOut = !serverClosed || sockets.size !== 0 || resolverTasks.size !== 0 || sessions.size !== 0;
      return {...stats, ok:!timedOut && !closeFailed && !unsafeOwnerExit, timedOut};
    })();
    return closePromise;
  }
  return {pipePath, start, close, getStats};
}

module.exports = {createAppToolsPipe};
