@echo off
setlocal
if exist "%~dp0CodexRemote.exe" (
  start "" "%~dp0CodexRemote.exe"
  exit /b 0
)
if exist "%~dp0windows-agent\tray.ps1" (
  set "ROOT=%~dp0"
  set "TRAY=%~dp0windows-agent\tray.ps1"
) else (
  set "ROOT=%~dp0..\"
  set "TRAY=%~dp0tray.ps1"
)
if not exist "%ROOT%node.exe" (
  if exist "%ROOT%.local\node-v24.19.0-release\node.exe" (
    set "NODE=%ROOT%.local\node-v24.19.0-release\node.exe"
  ) else (
    for %%I in (node.exe) do set "NODE=%%~$PATH:I"
  )
) else (
  set "NODE=%ROOT%node.exe"
)
powershell.exe -NoLogo -NoProfile -STA -WindowStyle Hidden -ExecutionPolicy Bypass -File "%TRAY%" -NodePath "%NODE%"
exit /b %errorlevel%

