"use strict";

const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const crypto = require("node:crypto");
const { BridgeError } = require("./errors.cjs");
const { normalizeHistory } = require("./desktop.cjs");
const { sharedQuestionIndex } = require("./question-index.cjs");
const { SharedCatalog } = require("./shared-catalog.cjs");
const { review, approvalSpec } = require("./shared-approvals.cjs");
const { generateTitle } = require("./shared-title.cjs");
const {
  registerHistoryImage,
  readHistoryImage,
  MediaError,
} = require("./media.cjs");
const {
  registerHistoryVisualization,
  readHistoryVisualization,
  VisualizationError,
} = require("./visualizations.cjs");
const {
  registerAttachment,
  readAttachmentChunk,
  AttachmentError,
} = require("./attachments.cjs");
const UUID = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
const terminal = (status) =>
  ["completed", "cancelled", "failed"].includes(status);
const statusOf = (status) =>
  ({
    inProgress: "running",
    completed: "completed",
    interrupted: "cancelled",
    failed: "failed",
    waiting: "waiting",
  })[status] ?? "unknown";
const fail = (code, message) =>
  Object.assign(new BridgeError(code, message), {
    statusCode:
      code === "RESPONSE_TOO_LARGE"
        ? 413
        : [
              "APPROVAL_EXPIRED",
              "APPROVAL_CONFLICT",
              "APPROVAL_UNSUPPORTED",
              "CURSOR_EXPIRED",
              "BUSY",
              "TURN_NOT_ACTIVE",
              "TURN_STEER_REJECTED",
              "STEER_UNSUPPORTED",
              "CONNECTION_LIMIT",
              "DELIVERY_UNKNOWN",
            ].includes(code)
          ? 409
          : code === "APPROVAL_NOT_FOUND"
            ? 404
            : [
                  "BAD_INPUT",
                  "INVALID_APPROVAL",
                  "INVALID_MODEL",
                  "INVALID_THINKING",
                  "REQUEST_CONFLICT",
                ].includes(code)
              ? 400
              : 503,
  });
const MAX_APPROVALS = 32,
  APPROVAL_MS = 600000;
const TOOL_PREVIEW_BYTES = 8 * 1024,
  PAGE_TARGET_BYTES = 512 * 1024,
  PAGE_MAX_BYTES = 2 * 1024 * 1024,
  EVENT_MAX_BYTES = 240 * 1024;
const TOOL_PREVIEW_NOTICE =
  "\n[工具输出仅显示有界预览；完整日志请在桌面查看。]";
const PAGE_HISTORY = Symbol("native-history-page");
const bytes = (value) =>
  Buffer.byteLength(
    typeof value === "string" ? value : JSON.stringify(value),
    "utf8",
  );
const ACTIVITY_TITLES = Object.freeze({
  thinking: "正在思考",
  compacting: "正在压缩上下文",
  command: "正在运行命令",
  editing: "正在修改文件",
  tool: "正在使用工具",
  responding: "正在回复",
  waiting: "等待审批",
  processing: "正在处理",
  syncing: "正在同步",
  idle: "已完成",
  failed: "运行失败",
  cancelled: "已停止",
});
const itemTerminal = (status) =>
  ["completed", "failed", "declined", "cancelled", "interrupted"].includes(
    status,
  );
const itemFinished = (item) =>
  Number.isFinite(item.completedAtMs) || itemTerminal(item.status);
const itemRunning = (item) =>
  !itemFinished(item) &&
  (item.status === "inProgress" ||
    (Number.isFinite(item.startedAtMs) && item.completedAtMs === null));
const itemStatus = (item) =>
  itemFinished(item)
    ? itemTerminal(item.status)
      ? item.status
      : "completed"
    : (item.status ?? (itemRunning(item) ? "inProgress" : undefined));
function activityKind(type) {
  if (typeof type !== "string" || !type) return null;
  if (type === "reasoning") return "thinking";
  if (type === "contextCompaction") return "compacting";
  if (type === "agentMessage") return "responding";
  if (type === "commandExecution") return "command";
  if (type === "fileChange") return "editing";
  return ["userMessage", "user_message"].includes(type) ? null : "tool";
}
function utf8Prefix(value, limit) {
  const buffer = Buffer.from(String(value), "utf8");
  let end = Math.max(0, Math.min(Math.floor(limit), buffer.length));
  while (end > 0 && end < buffer.length && (buffer[end] & 0xc0) === 0x80) end--;
  return buffer.subarray(0, end).toString("utf8");
}
function toolPreview(item, limit = TOOL_PREVIEW_BYTES) {
  if (item.role !== "tool") return item;
  const source = typeof item.text === "string" ? item.text : "",
    text = source.endsWith(TOOL_PREVIEW_NOTICE)
      ? source.slice(0, -TOOL_PREVIEW_NOTICE.length)
      : source;
  const originalBytes = item.originalBytes ?? bytes(text),
    metaLimit = Math.min(1024, Math.max(64, Math.floor(limit / 2)));
  const result = {
    id: item.id,
    type: item.type,
    role: "tool",
    phase: item.phase ?? null,
    originalBytes,
  };
  let metadataTruncated = !!item.metadataTruncated;
  for (const key of [
    "status",
    "exitCode",
    "command",
    "tool",
    "server",
    "title",
    "cwd",
    "toolName",
    "arguments",
    "success",
    "error",
    "contentItems",
    "commandActions",
    "actionSummary",
    "fileCount",
    "paths",
    "pathsTruncated",
    "path",
    "kind",
    "agentPath",
    "agentThreadId",
    "model",
    "reasoningEffort",
    "source",
    "durationMs",
    "action",
  ])
    if (item[key] !== undefined) {
      const value = item[key];
      if (bytes(value) > metaLimit) {
        result[key] = utf8Prefix(
          typeof value === "string" ? value : JSON.stringify(value),
          metaLimit,
        );
        metadataTruncated = true;
      } else result[key] = value;
    }
  if (item.changes !== undefined) {
    if (bytes(item.changes) <= metaLimit) result.changes = item.changes;
    else {
      result.changesPreview = utf8Prefix(
        JSON.stringify(item.changes),
        metaLimit,
      );
      metadataTruncated = true;
    }
  } else if (item.changesPreview !== undefined) {
    result.changesPreview = utf8Prefix(item.changesPreview, metaLimit);
    metadataTruncated = true;
  }
  // Descriptors remain structured even when the unrelated raw tool metadata is truncated.
  for (const key of ["toolFiles", "toolImages"])
    if (Array.isArray(item[key])) result[key] = item[key].slice(0, 4);
  const truncated =
    !!item.outputTruncated || originalBytes > limit || metadataTruncated;
  result.text = truncated
    ? utf8Prefix(text, Math.max(0, limit - bytes(TOOL_PREVIEW_NOTICE))) +
      TOOL_PREVIEW_NOTICE
    : text;
  if (truncated) result.outputTruncated = true;
  if (metadataTruncated) result.metadataTruncated = true;
  return result;
}

const privateRoots = () => [
  path.resolve(__dirname, "../.local"),
  path.join(os.homedir(), ".codex"),
  path.join(
    process.env.LOCALAPPDATA ?? path.join(os.homedir(), "AppData", "Local"),
    "CodexRemote",
  ),
];
function readSharedConfig(filename, roots = privateRoots()) {
  try {
    if (typeof filename !== "string" || !path.isAbsolute(filename))
      throw Error();
    const resolved = fs.realpathSync(filename);
    if (
      !roots.some((root) => {
        try {
          const relative = path.relative(fs.realpathSync(root), resolved);
          return (
            relative && !relative.startsWith("..") && !path.isAbsolute(relative)
          );
        } catch {
          return false;
        }
      })
    )
      throw Error();
    if (!fs.statSync(resolved).isFile() || fs.statSync(resolved).size > 65536)
      throw Error();
    const value = JSON.parse(
      fs.readFileSync(resolved, "utf8").replace(/^\uFEFF/, ""),
    );
    if (
      !value ||
      Array.isArray(value) ||
      typeof value.url !== "string" ||
      typeof value.token !== "string"
    )
      throw Error();
    return { url: value.url, token: value.token };
  } catch {
    throw fail(
      "SHARED_CONFIG_INVALID",
      "共享引擎私有配置不可读、越界或格式无效。",
    );
  }
}

/** 连接已经运行的 broker；本模块不启动、停止或复制 Codex 引擎与会话。 */
class SharedRuntime {
  constructor(config = {}, options = {}) {
    this.config = config;
    this.titleGenerator = options.titleGenerator ?? generateTitle;
    this.mediaMap = new Map();
    this.visualizationMap = new Map();
    this.attachmentMap = new Map();
    this.settings =
      options.settings ??
      readSharedConfig(config.sharedEngineConfigFile, [
        ...privateRoots(),
        ...(config.dataDirectory ? [path.resolve(config.dataDirectory)] : []),
      ]);
    this.factory =
      options.clientFactory ??
      config.sharedClientFactory ??
      ((opts) => new (require("./shared-client.cjs").SharedClient)(opts));
    this.maxThreads = config.sharedMaxThreadConnections ?? 3;
    if (
      !Number.isInteger(this.maxThreads) ||
      this.maxThreads < 1 ||
      this.maxThreads > 4
    )
      throw fail("BAD_INPUT", "共享线程连接上限必须为 1 至 4。");
    this.instanceId = crypto.randomUUID();
    this.streamId = this.instanceId;
    this.secret = crypto.randomBytes(32);
    this.sessions = new Map();
    this.sequences = new Map();
    this.catalog = new SharedCatalog({
      request: async (method, args) =>
        (await this._control()).request(method, args),
      instanceId: this.instanceId,
      secret: this.secret,
    });
    this.creates = new Map();
    this.creatingClients = new Set();
    this.closed = false;
    this.lock = Promise.resolve();
    this.requests = new Map();
  }
  setEventListener(listener) {
    this.listener = typeof listener === "function" ? listener : null;
  }
  _safe(value) {
    return JSON.parse(
      JSON.stringify(value, (_key, part) =>
        typeof part === "string" && this.settings.token
          ? part.replaceAll(this.settings.token, "[已隐藏]")
          : part,
      ),
    );
  }
  _emit(session, data) {
    if (this.closed || session.retired) return;
    data = this._safe(data);
    const envelope = (part) => ({
      streamId: this.streamId,
      seq: session.seq + 1,
      threadId: session.id,
      ...part,
      at: Date.now(),
    });
    if (bytes(envelope(data)) > EVENT_MAX_BYTES) {
      if (data.type === "item.delta") {
        let remaining = data.delta;
        while (remaining) {
          const chunk = utf8Prefix(remaining, 24 * 1024);
          this._emit(session, { ...data, delta: chunk });
          remaining = remaining.slice(chunk.length);
        }
        return;
      }
      if (data.type === "item.upsert") {
        const item = data.item,
          text = typeof item.text === "string" ? item.text : "";
        let base = { ...item, text: "" };
        delete base.segments;
        const deferred =
          item.segments !== undefined ||
          bytes(envelope({ ...data, item: base })) > EVENT_MAX_BYTES;
        if (deferred)
          base = {
            id: item.id,
            type: item.type,
            role: item.role,
            phase: item.phase ?? null,
            text: "",
            streamMetadataDeferred: true,
          };
        this._emit(session, { ...data, item: base });
        if (text)
          this._emit(session, {
            type: "item.delta",
            turnId: data.turnId,
            itemId: item.id,
            delta: text,
          });
        if (deferred)
          this._status(
            session,
            "此条消息的结构化内容较大；实时正文完整保留，图片或附件排版请刷新回读。",
          );
        return;
      }
      this._status(
        session,
        "实时事件的结构化内容超过大小限制，请刷新同一会话确认。",
      );
      return;
    }
    session.seq++;
    this.sequences.set(session.id, session.seq);
    try {
      this.listener?.({ ...envelope(data), seq: session.seq });
    } catch {
      /* 消费者不能中断传输。 */
    }
  }
  _cursor(session) {
    return `${this.streamId}:${session.seq}`;
  }
  _activity(session, emit = false) {
    let kind, itemId;
    if (!session.ready || session.recovering) kind = "syncing";
    else if (session.pending.size || session.status === "waiting")
      kind = "waiting";
    else if (!session.activeTurn)
      kind = ["failed", "cancelled"].includes(session.status)
        ? session.status
        : terminal(session.status)
          ? "idle"
          : "syncing";
    else {
      const active = [...(session.activityItems ?? new Map()).values()].filter(
        (item) => item.turnId === session.activeTurn,
      );
      const item =
        [...active]
          .reverse()
          .find((item) =>
            ["compacting", "command", "editing", "tool"].includes(item.kind),
          ) ??
        [...active].reverse().find((item) => item.kind === "responding") ??
        active.find((item) => item.kind === "thinking");
      kind = item?.kind ?? "processing";
      itemId = item?.itemId;
    }
    const changed =
      session.activity?.kind !== kind || session.activity?.itemId !== itemId;
    if (changed) {
      session.activity = {
        kind,
        title: ACTIVITY_TITLES[kind],
        ...(itemId ? { itemId } : {}),
        updatedAt: Date.now(),
      };
      session.activityRevision = (session.activityRevision ?? 0) + 1;
      if (emit) this._status(session);
    }
    return session.activity;
  }
  _clearActivity(session) {
    session.activityItems = new Map();
    session.completedActivity = new Set();
    session.activityRevision = (session.activityRevision ?? 0) + 1;
  }
  _trackActivity(session, turnId, itemId, kind, completed = false) {
    if (typeof itemId !== "string" || !itemId || itemId.length > 512 || !kind)
      return;
    const items = (session.activityItems ??= new Map()),
      done = (session.completedActivity ??= new Set()),
      key = JSON.stringify([turnId, itemId]);
    if (completed) {
      done.add(key);
      if (items.delete(key))
        session.activityRevision = (session.activityRevision ?? 0) + 1;
    } else if (!done.has(key) && !items.has(key)) {
      items.set(key, { turnId, itemId, kind });
      session.activityRevision = (session.activityRevision ?? 0) + 1;
    }
    this._activity(session, true);
  }
  _notice(session) {
    return session.notice || session.retryNotice?.text || "";
  }
  _clearRetry(session, turnId, emit = true) {
    if (
      !session.retryNotice ||
      session.retryNotice.client !== session.client ||
      session.retryNotice.turnId !== turnId
    )
      return;
    session.retryNotice = null;
    if (emit) this._status(session);
  }
  _status(session, notice) {
    this._emit(session, {
      type: "status",
      status: session.status,
      activity: this._activity(session),
      notice: notice ?? this._notice(session),
      ...(typeof session.meta?.title === "string" ? { title: session.meta.title } : {}),
      ...(session.meta
        ? {
            settings: Object.fromEntries(
              ["model", "reasoningEffort", "modelProvider"].map((k) => [
                k,
                session.meta[k] ?? null,
              ]),
            ),
          }
        : {}),
    });
  }
  _encode(threadId, before) {
    const body = Buffer.from(
      JSON.stringify({ instanceId: this.instanceId, threadId, before }),
    ).toString("base64url");
    return `${body}.${crypto.createHmac("sha256", this.secret).update(body).digest("base64url")}`;
  }
  _decode(cursor, threadId) {
    try {
      if (typeof cursor !== "string" || cursor.length > 2048) throw Error();
      const [body, signature, extra] = cursor.split("."),
        expected = crypto
          .createHmac("sha256", this.secret)
          .update(body)
          .digest("base64url");
      if (
        extra !== undefined ||
        !signature ||
        signature.length !== expected.length ||
        !crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))
      )
        throw Error();
      const data = JSON.parse(Buffer.from(body, "base64url").toString("utf8"));
      if (
        data.threadId !== threadId ||
        data.instanceId !== this.instanceId ||
        typeof data.before !== "string"
      )
        throw Error();
      return data.before;
    } catch {
      throw fail("CURSOR_EXPIRED", "历史游标已失效，请刷新同一会话。");
    }
  }
  async _locked(action) {
    const previous = this.lock;
    let release;
    this.lock = new Promise((resolve) => {
      release = resolve;
    });
    await previous;
    try {
      return await action();
    } finally {
      release();
    }
  }
  _newClient() {
    return this.factory({
      ...this.settings,
      name: "codex_remote_shared_agent",
      maxPayloadBytes: 16 * 1024 * 1024,
    });
  }
  async _readHistory(client, threadId, options = {}) {
    // 同一连接的历史读取按序归并；不同会话仍能独立处理。
    const task = (client.historyRead ?? Promise.resolve())
      .catch(() => {})
      .then(() => this._readHistoryPage(client, threadId, options));
    client.historyRead = task;
    try {
      return await task;
    } finally {
      if (client.historyRead === task) client.historyRead = null;
    }
  }
  async _readHistoryPage(client, threadId, options) {
    if (client.legacyHistory)
      return client.request(
        "thread/read",
        { threadId, includeTurns: true },
        60000,
      );
    const invalid = () =>
      fail("INVALID_HISTORY", "共享引擎分页历史无效或未返回完整同会话条目。");
    const pages = async (method, args, accept) => {
      let cursor;
      const seen = new Set();
      do {
        const page = await client.request(
          method,
          { ...args, ...(cursor ? { cursor } : {}) },
          60000,
        );
        if (
          !Array.isArray(page?.data) ||
          !(
            page.nextCursor === null ||
            (typeof page.nextCursor === "string" && page.nextCursor.length > 0)
          )
        )
          throw invalid();
        for (const value of page.data) accept(value);
        cursor = page.nextCursor;
        if (cursor) {
          if (seen.has(cursor)) throw invalid();
          seen.add(cursor);
        }
      } while (cursor);
    };
    try {
      const turns = new Map();
      await pages(
        "thread/turns/list",
        { threadId, limit: 50, sortDirection: "asc", itemsView: "notLoaded" },
        (turn) => {
          if (!turn || typeof turn.id !== "string" || !turn.id) throw invalid();
          turns.set(turn.id, { ...turn, items: [], itemsView: "notLoaded" });
        },
      );
      const ordered = [...turns.values()],
        limit = Math.max(
          1,
          Math.min(Number.isInteger(options.limit) ? options.limit : 10, 10),
        );
      let end = ordered.length;
      if (options.before !== undefined) {
        end = ordered.findIndex((turn) => turn.id === options.before);
        if (end < 0) throw fail("CURSOR_EXPIRED", "历史游标已失效，请刷新。");
      }
      const selected =
        options.targetTurnId !== undefined
          ? ordered.filter((turn) => turn.id === options.targetTurnId)
          : ordered.slice(Math.max(0, end - limit), end);
      const liveCorrections = new Set(),
        hydrateTurns = [...selected];
      if (options.older) {
        const active = turns.get(options.activeTurn),
          latest = ordered.at(-1);
        // 旧页读取仍须校正先前活动回合的终态及新出现的最新回合，不能只凭
        // 元数据先标成已完成，再把仍在途的正文通知当成迟到事件丢弃。
        for (const turn of [
          active && terminal(statusOf(active.status)) ? active : null,
          latest && !options.loadedTurns?.has(latest.id) ? latest : null,
        ]) {
          if (!turn) continue;
          liveCorrections.add(turn.id);
          if (!hydrateTurns.some((value) => value.id === turn.id))
            hydrateTurns.push(turn);
        }
      }
      const cached = new Map(
          client.historyLoaded?.threadId === threadId
            ? client.historyLoaded.turns
            : [],
        ),
        pending = new Map(),
        reused = new Set(),
        fresh = new Set();
      const revision = (id) => client.historyRevisions?.get(id) ?? 0;
      const signature = (turn) =>
        JSON.stringify(
          Object.fromEntries(
            Object.entries(turn).filter(
              ([key]) => key !== "items" && key !== "itemsView",
            ),
          ),
        );
      for (const id of cached.keys()) if (!turns.has(id)) cached.delete(id);
      // 只保留完整读取的签名；巨大原生工具输出不另存一份无界 raw 缓存。
      const hydrate = async (turn) => {
        const stamp = signature(turn),
          epoch = revision(turn.id),
          prior = cached.get(turn.id);
        if (
          options.older &&
          !liveCorrections.has(turn.id) &&
          terminal(statusOf(turn.status)) &&
          options.loadedTurns?.has(turn.id) &&
          prior?.signature === stamp &&
          prior.revision === epoch &&
          options.canReuse?.(turn.id) !== false
        ) {
          reused.add(turn.id);
          return;
        }
        // 重新读取开始即撤销旧签名；原正文可保留供显示，但不能在失败后再被
        // 当成本次已验证的完整缓存。新签名等 normalize/归并成功后才发布。
        cached.delete(turn.id);
        client.historyLoaded?.turns.delete(turn.id);
        const items = new Map();
        await pages(
          "thread/items/list",
          { threadId, turnId: turn.id, limit: 16, sortDirection: "asc" },
          (entry) => {
            if (
              entry?.turnId !== turn.id ||
              typeof entry.item?.id !== "string" ||
              !entry.item.id
            )
              throw invalid();
            items.set(entry.item.id, {
              ...entry.item,
              ...Object.fromEntries(
                ["startedAtMs", "completedAtMs"]
                  .filter(
                    (key) => entry[key] === null || Number.isFinite(entry[key]),
                  )
                  .map((key) => [key, entry[key]]),
              ),
            });
          },
        );
        turn.items = [...items.values()];
        turn.itemsView = "full";
        fresh.add(turn.id);
        if (revision(turn.id) === epoch)
          pending.set(turn.id, { signature: stamp, revision: epoch });
      };
      // 页内有界并发，单回合内部的原生游标仍顺序读取；失败后等待本批结束才回退。
      for (let offset = 0; offset < hydrateTurns.length; offset += 4) {
        const results = await Promise.allSettled(
          hydrateTurns.slice(offset, offset + 4).map(hydrate),
        );
        const rejected = results.find((result) => result.status === "rejected");
        if (rejected) throw rejected.reason;
      }
      const response = await client.request(
        "thread/read",
        { threadId, includeTurns: false },
        60000,
      );
      if (response?.thread?.id !== threadId) throw invalid();
      return {
        ...response,
        thread: { ...response.thread, turns: ordered },
        [PAGE_HISTORY]: {
          metadataOnly: new Set(
            ordered
              .filter((turn) => turn.itemsView === "notLoaded")
              .map((turn) => turn.id),
          ),
          selected: new Set(selected.map((turn) => turn.id)),
          fresh,
          reused,
          liveCorrections,
          older: !!options.older,
          client,
          cached,
          pending,
        },
      };
    } catch (error) {
      // 仅明确的旧协议方法缺失允许回退；超时、无效分页和传输错误不得伪称完整。
      if (error.code !== "RPC_ERROR" || error.rpcCode !== -32601) throw error;
      client.legacyHistory = true;
      client.historyLoaded = null;
      return client.request(
        "thread/read",
        { threadId, includeTurns: true },
        60000,
      );
    }
  }
  _publishHistoryCache(session, response) {
    const paging = response?.[PAGE_HISTORY];
    if (
      !paging ||
      paging.client !== session.client ||
      !session.client.connected
    )
      return;
    const revision = (id) => session.client.historyRevisions?.get(id) ?? 0;
    for (const [id, stamp] of paging.cached)
      if (stamp.revision !== revision(id)) paging.cached.delete(id);
    for (const [id, stamp] of paging.pending)
      if (session.loadedTurns?.has(id) && stamp.revision === revision(id))
        paging.cached.set(id, stamp);
    session.client.historyLoaded = {
      threadId: session.id,
      turns: paging.cached,
    };
  }
  async _control() {
    if (this.closed) throw fail("CLOSED", "共享运行时已关闭。");
    if (this.control?.connected) return this.control;
    if (this.controlTask) return this.controlTask;
    this.controlTask = (async () => {
      await this.control?.close();
      if (this.closed) throw fail("CLOSED", "共享运行时已关闭。");
      const client = this._newClient();
      this.control = client;
      client.on("error", () => {});
      await client.connect();
      if (this.closed) {
        await client.close();
        throw fail("CLOSED", "共享运行时已关闭。");
      }
      return client;
    })();
    try {
      return await this.controlTask;
    } finally {
      this.controlTask = null;
    }
  }
  async _makeConnectionRoom(creatingClient = null) {
    while (
      this.sessions.size +
        this.creatingClients.size -
        (this.creatingClients.has(creatingClient) ? 1 : 0) >=
      this.maxThreads
    ) {
      const victim = [...this.sessions.values()]
        .filter(
          (session) =>
            !session.leases &&
            !session.sending &&
            (!session.activeTurn || session.passive) &&
            !session.unknownDelivery &&
            ![...session.approvals.values()].some((approval) =>
              ["pending", "submitting"].includes(approval.state),
            ),
        )
        .sort((left, right) => left.used - right.used)[0];
      if (!victim) {
        throw fail(
          "CONNECTION_LIMIT",
          "共享会话连接已达上限，请等待其他回合结束。",
        );
      }
      this._clearPassiveProbe(victim);
      this._expire(victim);
      this.sessions.delete(victim.id);
      await victim.client?.close();
    }
  }
  async _lease(threadId, action, historyOptions = {}) {
    if (!UUID.test(threadId ?? "")) throw fail("BAD_INPUT", "会话 ID 无效。");
    const session = await this._locked(async () => {
      if (this.closed) throw fail("CLOSED", "共享运行时已关闭。");
      let value = this.sessions.get(threadId);
      if (
        value &&
        historyOptions.createdClient &&
        value.client !== historyOptions.createdClient
      ) {
        if (
          value.sending ||
          value.activeTurn ||
          value.unknownDelivery ||
          [...value.approvals.values()].some((approval) =>
            ["pending", "submitting"].includes(approval.state),
          )
        ) {
          throw fail("BUSY", "新建会话已被其他写入使用，请核对原会话。");
        }
        // 目录可能先发现原生空会话并开始恢复；旧租约保留旧对象，不能让它发布到创建连接。
        value.retired = true;
        value.ready = false;
        this._clearPassiveProbe(value);
        this._expire(value);
        this.sessions.delete(threadId);
        await value.client?.close();
        value = null;
      }
      if (!value) {
        await this._makeConnectionRoom(historyOptions.createdClient);
        if (this.closed) throw fail("CLOSED", "共享运行时已关闭。");
        value = {
          id: threadId,
          turns: [],
          approvals: new Map(),
          pending: new Map(),
          reviews: new Map(),
          seq: this.sequences.get(threadId) ?? 0,
          leases: 0,
          used: Date.now(),
          status: "unknown",
        };
        if (historyOptions.createdClient)
          value.createdConnection = historyOptions;
        this.sessions.set(threadId, value);
        if (historyOptions.createdClient)
          this.creatingClients.delete(historyOptions.createdClient);
      }
      value.leases++;
      return value;
    });
    const justConnected = !(session.client?.connected && session.ready);
    try {
      await this._connect(session, historyOptions);
      // 首读和写入可以并发等待同一个连接；纯读完成后，写入仍须明确恢复原生会话。
      if (historyOptions.resume && session.passive)
        await this._connect(session, historyOptions);
      if (session.retired)
        throw fail(
          "SHARED_CONNECT_FAILED",
          "空会话恢复已由创建连接接管，请重新读取。",
        );
      const result = await action(session, justConnected);
      if (session.retired)
        throw fail(
          "SHARED_CONNECT_FAILED",
          "空会话恢复已由创建连接接管，请重新读取。",
        );
      return result;
    } finally {
      session.leases--;
      session.used = Date.now();
    }
  }
  _clearPassiveProbe(session) {
    clearTimeout(session.passiveTimer);
    session.passiveTimer = null;
  }
  _schedulePassiveProbe(session) {
    this._clearPassiveProbe(session);
    if (this.closed || !session.passive || !session.ready || session.retired)
      return;
    // 纯历史读取不订阅原生事件；有界探测外部启动，随后接入既有实时通知链。
    session.passiveTimer = setTimeout(() => this._probePassive(session), 5000);
    session.passiveTimer.unref?.();
  }
  async _probePassive(session) {
    this._clearPassiveProbe(session);
    if (
      this.closed ||
      this.sessions.get(session.id) !== session ||
      session.retired ||
      !session.passive ||
      !session.ready
    ) return;
    session.leases++;
    try {
      await this._connect(session);
    } catch {
      // 元数据RPC失败也必须撤销就绪状态；关闭本工具的读取连接会发布unknown并触发回读。
      // 不把探测失败转换为resume或发送输入。
      if (this.sessions.get(session.id) === session && session.passive)
        await session.client?.close();
    } finally {
      session.leases--;
      if (this.sessions.get(session.id) === session)
        this._schedulePassiveProbe(session);
    }
  }
  async _readMetadata(client, threadId) {
    const response = await client.request(
      "thread/read", { threadId, includeTurns: false }, 60000,
    );
    if (response?.thread?.id !== threadId)
      throw fail("INVALID_HISTORY", "共享引擎元数据未返回同一会话。");
    return response.thread;
  }
  _notLoaded(thread) {
    return (typeof thread?.status === "string" ? thread.status : thread?.status?.type)
      === "notLoaded";
  }
  async _connect(session, historyOptions = {}) {
    if (session.retired)
      throw fail(
        "SHARED_CONNECT_FAILED",
        "空会话恢复已由创建连接接管，请重新读取。",
      );
    if (session.client?.connected && session.ready && !session.passive) return;
    if (session.connecting) return session.connecting;
    historyOptions = session.createdConnection ?? historyOptions;
    session.connecting = (async () => {
      const reuse = session.client?.connected && session.passive;
      let metadata;
      if (reuse && session.ready && !historyOptions.resume) {
        metadata = await this._readMetadata(session.client, session.id);
        if (session.client.connected && session.ready && this._notLoaded(metadata))
          return;
      }
      this._clearPassiveProbe(session);
      this._expire(session);
      if (!reuse) await session.client?.close();
      if (this.closed || session.retired)
        throw fail("CLOSED", "共享连接已关闭。");
      const client = reuse
        ? session.client
        : historyOptions.createdClient ?? this._newClient();
      session.client = client;
      session.liveTurns = new Set();
      session.retryNotice = null;
      session.ready = false;
      session.recovering = true;
      session.events = [];
      session.approvalWaits = new Map();
      this._clearActivity(session);
      this._activity(session, true);
      delete session.createdConnection;
      const disconnected = () => {
        if (session.client !== client || this.closed || session.retired) return;
        session.ready = false;
        session.recovering = false;
        this._clearPassiveProbe(session);
        this._expire(session);
        session.reviews.clear();
        session.status = "unknown";
        this._clearActivity(session);
        session.retryNotice = null;
        session.notice =
          "共享连接已断开；回合结果待确认，重新连接只回读同一会话，不会重发输入。";
        for (const turn of session.turns)
          if (!terminal(turn.status)) turn.status = "unknown";
        this._status(session);
      };
      if (!reuse)
        for (const event of ["disconnect", "error", "protocolError"])
          client.on(event, disconnected);
      const incoming = (message) => {
        if (session.client !== client || this.closed || session.retired) return;
        if (session.recovering) {
          if (session.events.length < 2048) session.events.push(message);
          else session.overflow = true;
        } else
          try {
            this._message(session, message);
          } catch (error) {
            session.notice =
              error.code === "RESPONSE_TOO_LARGE"
                ? error.message
                : "实时内容归并失败，请刷新同一会话确认。";
            this._status(session);
          }
      };
      if (!reuse) {
        client.on("notification", incoming);
        client.on("serverRequest", incoming);
      }
      try {
        if (!client.connected) await client.connect();
        if (this.closed || session.retired || session.client !== client) {
          throw fail("RECOVERY_FAILED", "共享会话恢复已失效。");
        }
        let response;
        if (historyOptions.createdClient) {
          session.passive = false;
          // 空会话尚无 rollout；必须保留创建端连接发送首轮，不能先交给第二个客户端恢复。
          response = {
            ...historyOptions.createdResponse,
            thread: {
              ...historyOptions.createdResponse.thread,
              turns: historyOptions.createdResponse.thread.turns ?? [],
            },
          };
        } else {
          metadata ??= await this._readMetadata(client, session.id);
          session.passive = !historyOptions.resume && this._notLoaded(metadata);
          if (!session.passive)
            await client.request(
              "thread/resume",
              { threadId: session.id, excludeTurns: true },
              60000,
            );
          response = await this._readHistory(client, session.id, {
            limit: historyOptions.limit,
          });
          // 元数据读取与历史分页之间，桌面可能已经启动此会话；此时恢复只附加订阅。
          if (session.passive && !this._notLoaded(response.thread)) {
            await client.request(
              "thread/resume", { threadId: session.id, excludeTurns: true }, 60000,
            );
            session.passive = false;
            response = await this._readHistory(client, session.id, {
              limit: historyOptions.limit,
            });
          }
        }
        if (
          this.closed ||
          session.retired ||
          session.client !== client ||
          !client.connected ||
          session.overflow
        )
          throw fail("RECOVERY_FAILED", "共享会话恢复未完成。");
        this._replace(session, response);
        const recovered = new Set(
          response[PAGE_HISTORY]?.fresh ?? session.loadedTurns,
        );
        const dropped = session.events.filter(
          (m) =>
            recovered.has(m.params?.turnId) &&
            ["item/agentMessage/delta", "item/commandExecution/outputDelta"].includes(
              m.method,
            ),
        );
        session.recoveryPending = new Set(
          dropped.map((m) =>
            JSON.stringify([m.params.turnId, m.params.itemId]),
          ),
        );
        session.notice = dropped.length
          ? "已回读同一会话；恢复期间的正文尾部待完整条目或终态回读校正，不会重放增量或输入。"
          : "";
        const pending = session.events.filter(
          (m) =>
            m.id != null ||
            !recovered.has(m.params?.turn?.id ?? m.params?.turnId) ||
            [
              "turn/completed",
              "item/completed",
              "serverRequest/resolved",
              // 这些通知仅更新活动/重试状态；历史正文delta仍不重放。
              "item/reasoning/textDelta",
              "item/reasoning/summaryTextDelta",
              "item/reasoning/summaryPartAdded",
              "item/mcpToolCall/progress",
              "item/fileChange/outputDelta",
              "thread/compacted",
              "error",
            ].includes(m.method),
        );
        session.recovering = false;
        session.events = [];
        session.ready = true;
        for (const message of pending) this._message(session, message);
        this._status(session);
        this._schedulePassiveProbe(session);
      } catch (error) {
        session.recovering = false;
        session.ready = false;
        this._clearPassiveProbe(session);
        session.events = [];
        session.overflow = false;
        this._expire(session);
        await client.close();
        if (error.code === "RESPONSE_TOO_LARGE") throw error;
        throw fail(
          "SHARED_CONNECT_FAILED",
          "共享引擎连接或同会话恢复失败；未启动引擎、未重发消息。",
        );
      }
    })();
    try {
      await session.connecting;
    } finally {
      session.connecting = null;
    }
  }
  _normalize(session, item) {
    if (
      !item ||
      typeof item.id !== "string" ||
      /reasoning/i.test(item.type ?? "")
    )
      return null;
    if (
      ["functionCallOutput", "function_call_output"].includes(item.type) &&
      ["create_thread", "send_message_to_thread"].includes(item.name)
    )
      return null;
    if (
      ["agentMessage", "userMessage", "functionCall", "function_call"].includes(
        item.type,
      )
    ) {
      const result = normalizeHistory(
        {
          thread: { id: session.id },
          turns: [{ id: "normalization", items: [item] }],
        },
        {
          registerImage: (id, file) =>
            registerHistoryImage(this.mediaMap, id, file),
          registerVisualization: (id, file) =>
            registerHistoryVisualization(this.visualizationMap, id, file),
          registerAttachment: (id, file) =>
            registerAttachment(this.attachmentMap, id, file),
        },
      ).turns[0].items[0];
      if (!result) return null;
      const normalized = { ...result, id: item.id };
      if (
        normalized.role === "user" &&
        typeof item.clientId === "string" &&
        UUID.test(item.clientId)
      )
        normalized.clientRequestId = item.clientId;
      if (normalized.role === "tool")
        return toolPreview({
          ...normalized,
          ...(item.name ? { toolName: item.name } : {}),
          ...(item.arguments !== undefined
            ? { arguments: item.arguments }
            : {}),
          ...(itemStatus(item) ? { status: itemStatus(item) } : {}),
        });
      if (bytes(normalized) > PAGE_MAX_BYTES - 16 * 1024)
        throw fail(
          "RESPONSE_TOO_LARGE",
          "单条用户或助手正文超过移动端 2 MiB 读取上限；已有内容保留，请在桌面查看完整正文。",
        );
      return normalized;
    }
    const output =
      item.aggregatedOutput ?? item.text ?? item.output ?? item.result;
    const fields = Object.fromEntries(
      [
        "command",
        "status",
        "exitCode",
        "tool",
        "server",
        "changes",
        "title",
        "cwd",
        "arguments",
        "success",
        "error",
        "contentItems",
        "commandActions",
        "path",
        "kind",
        "agentPath",
        "agentThreadId",
        "model",
        "reasoningEffort",
        "source",
        "durationMs",
        "action",
      ]
        .filter((k) => item[k] !== undefined)
        .map((k) => [k, item[k]]),
    );
    if (itemStatus(item) !== undefined) fields.status = itemStatus(item);
    if (Array.isArray(item.commandActions)) {
      fields.actionSummary = { read: 0, list: 0, search: 0, run: 0 };
      for (const action of item.commandActions)
        fields.actionSummary[
          { read: "read", listFiles: "list", search: "search" }[action?.type] ??
            "run"
        ]++;
    }
    if (
      item.type === "fileChange" &&
      Array.isArray(item.changes) &&
      item.changes.every((c) => typeof c?.path === "string" && c.path)
    ) {
      const paths = [...new Set(item.changes.map((c) => c.path))];
      fields.fileCount = paths.length;
      fields.paths = paths.slice(0, 4).map((p) => utf8Prefix(p, 200));
      fields.pathsTruncated =
        paths.length > 4 || paths.some((p) => bytes(p) > 200);
      fields.toolFiles = paths
        .slice(0, 4)
        .map((file) => this._toolFile(session, item, file, false))
        .filter(Boolean);
    }
    if (item.type === "imageView" && typeof item.path === "string") {
      const image = this._toolFile(session, item, item.path, true);
      if (image) fields.toolImages = [image];
    }
    return toolPreview({
      id: item.id,
      type: item.type ?? "unknown",
      role: "tool",
      text:
        output == null
          ? ""
          : typeof output === "string"
            ? output
            : JSON.stringify(output),
      phase: null,
      ...fields,
      ...(item.name ? { toolName: item.name } : {}),
    });
  }
  _toolFile(session, item, file, image) {
    if (typeof file !== "string" || !file || file.length > 32768) return null;
    const cwd = item.cwd ?? session.meta?.cwd;
    // Never interpret a relative native path against the Agent's own working directory.
    if (!path.isAbsolute(file)) {
      if (typeof cwd !== "string" || !path.isAbsolute(cwd)) return null;
      file = path.resolve(cwd, file);
    }
    const descriptor = image
      ? registerHistoryImage(this.mediaMap, session.id, file)
      : registerAttachment(this.attachmentMap, session.id, file);
    if (!descriptor) return null;
    return {
      ...Object.fromEntries(
        ["id", "mime", "size", "unavailable"]
          .filter((k) => descriptor[k] !== undefined)
          .map((k) => [k, descriptor[k]]),
      ),
      name: utf8Prefix(descriptor.name ?? "file", 255),
    };
  }
  _review(session, turnId, itemId, changes) {
    const value = review([["拟修改内容", changes]], this.settings.token);
    value.complete =
      value.complete &&
      Array.isArray(changes) &&
      changes.length > 0 &&
      changes.every(
        (c) =>
          typeof c.path === "string" &&
          c.path &&
          typeof c.diff === "string" &&
          ["add", "update", "delete"].includes(c.kind?.type),
      );
    if (!value.complete)
      value.details += "\n拟修改内容缺失或超出显示上限，请在原客户端完整审阅。";
    const key = JSON.stringify([turnId, itemId]);
    if (session.reviews.get(key)?.details !== value.details)
      this._expire(
        session,
        (r) =>
          r.turnId === turnId &&
          r.itemId === itemId &&
          r.spec.kind === "fileChange",
      );
    session.reviews.set(key, value);
    while (session.reviews.size > MAX_APPROVALS)
      session.reviews.delete(session.reviews.keys().next().value);
  }
  _turn(session, id) {
    (session.liveTurns ??= new Set()).add(id);
    let turn = session.turns.find((t) => t.id === id);
    if (!turn) {
      turn = { id, status: "running", items: [] };
      session.turns.push(turn);
    }
    return turn;
  }
  _canReuseHistoryTurn(turn) {
    // 描述符有有界登记和过期时间；旧媒体页重新读取目标回合以校验文件并恢复登记。
    return (
      !!turn &&
      !turn.items.some(
        (item) =>
          item.type === "fileChange" ||
          ["images", "toolImages", "toolFiles"].some(
            (key) => Array.isArray(item[key]) && item[key].length,
          ) ||
          (Array.isArray(item.segments) &&
            item.segments.some((part) => part.type !== "text")),
      )
    );
  }
  _upsert(session, turn, raw) {
    if (raw?.type === "fileChange")
      this._review(session, turn.id, raw.id, raw.changes);
    const item = this._normalize(session, raw);
    if (!item) return;
    const index = turn.items.findIndex((v) => v.id === item.id);
    if (index < 0) turn.items.push(item);
    else turn.items[index] = item;
    this._emit(session, {
      type: "item.upsert",
      turnId: turn.id,
      item: structuredClone(item),
    });
  }
  _replace(session, response, preserveConcurrent = false, baseline = null) {
    const thread = response?.thread,
      paging = response?.[PAGE_HISTORY];
    if (
      thread?.id !== session.id ||
      !Array.isArray(thread.turns) ||
      thread.turns.some(
        (turn) =>
          !Array.isArray(turn.items) ||
          (turn.itemsView != null &&
            turn.itemsView !== "full" &&
            !(
              paging?.metadataOnly.has(turn.id) &&
              turn.itemsView === "notLoaded" &&
              turn.items.length === 0
            )),
      )
    )
      throw fail(
        "INVALID_HISTORY",
        "共享引擎未返回完整同会话历史或只返回条目摘要。",
      );
    const previous = session.turns,
      previousById = new Map(previous.map((turn) => [turn.id, turn])),
      rawById = new Map(thread.turns.map((turn) => [turn.id, turn]));
    const previousItems = new Map(
      previous.map((turn) => [
        turn.id,
        new Map(turn.items.map((item) => [item.id, item])),
      ]),
    );
    const loaded = new Set(),
      previousLoaded = session.loadedTurns ?? new Set();
    const settings = Object.fromEntries(
      ["model", "reasoningEffort", "modelProvider"].map((k) => [
        k,
        typeof thread[k] === "string" ? thread[k] : null,
      ]),
    );
    const settingsChanged =
      preserveConcurrent &&
      baseline?.settings !== undefined &&
      baseline.settings !==
        JSON.stringify(
          Object.fromEntries(
            ["model", "reasoningEffort", "modelProvider"].map((k) => [
              k,
              session.meta?.[k] ?? null,
            ]),
          ),
        );
    session.meta = {
      title: thread.title ?? thread.name ?? "",
      cwd: thread.cwd,
      ...(settingsChanged
        ? Object.fromEntries(
            ["model", "reasoningEffort", "modelProvider"].map((k) => [
              k,
              session.meta?.[k] ?? null,
            ]),
          )
        : settings),
    };
    const turns = [],
      positions = new Map();
    for (const raw of thread.turns) {
      const old = previousById.get(raw.id),
        metadataOnly = paging?.metadataOnly.has(raw.id),
        reuse = metadataOnly && old;
      const turn = {
        id: raw.id,
        status: statusOf(raw.status),
        items: reuse ? old.items : [],
      };
      if (metadataOnly) {
        if (previousLoaded.has(raw.id)) loaded.add(raw.id);
      } else loaded.add(raw.id);
      if (paging?.reused.has(raw.id) && !previousLoaded.has(raw.id))
        throw fail("INVALID_HISTORY", "历史缓存不完整，请重新读取同一会话。");
      for (const key of ["startedAt", "completedAt", "durationMs"])
        if (Number.isFinite(raw[key])) turn[key] = raw[key];
      for (const item of raw.items ?? []) {
        const prior = previousItems.get(raw.id)?.get(item.id);
        // 刷新期间的 SSE 已更新此条目时保留整个新条目，不能只保留更长正文。
        if (
          preserveConcurrent &&
          baseline &&
          prior &&
          baseline.get(JSON.stringify([raw.id, item.id])) !==
            JSON.stringify(prior)
        ) {
          turn.items.push(prior);
          continue;
        }
        const reviewKey = JSON.stringify([raw.id, item.id]),
          reviewChanged =
            baseline &&
            baseline.get(JSON.stringify(["review", reviewKey])) !==
              JSON.stringify(session.reviews.get(reviewKey));
        if (
          item.type === "fileChange" &&
          !(preserveConcurrent && reviewChanged)
        )
          this._review(session, raw.id, item.id, item.changes);
        const value = this._normalize(session, item);
        if (value) turn.items.push(value);
      }
      if (
        !metadataOnly &&
        bytes({
          ...turn,
          items: turn.items.filter((item) => item.role !== "tool"),
        }) >
          PAGE_MAX_BYTES - 16 * 1024
      )
        throw fail(
          "RESPONSE_TOO_LARGE",
          "单回合用户与助手正文超过移动端 2 MiB 读取上限；已有内容保留，请在桌面查看完整正文。",
        );
      positions.set(turn.id, turns.length);
      turns.push(turn);
    }
    if (preserveConcurrent) {
      for (const old of previous) {
        const index = positions.get(old.id),
          fresh = index === undefined ? null : turns[index];
        if (!fresh) {
          positions.set(old.id, turns.length);
          turns.push(old);
          if (previousLoaded.has(old.id)) loaded.add(old.id);
          continue;
        }
        if (terminal(old.status) && !terminal(fresh.status)) {
          turns[index] = old;
          continue;
        }
        if (!terminal(fresh.status) && fresh.items !== old.items) {
          const items = new Map(
            fresh.items.map((item, index) => [item.id, index]),
          );
          for (const prior of old.items) {
            const i = items.get(prior.id);
            if (i === undefined) {
              items.set(prior.id, fresh.items.length);
              fresh.items.push(prior);
            } else if (
              prior.role === "tool" &&
              [
                "completed",
                "failed",
                "declined",
                "cancelled",
                "interrupted",
              ].includes(prior.status) &&
              ![
                "completed",
                "failed",
                "declined",
                "cancelled",
                "interrupted",
              ].includes(fresh.items[i].status)
            )
              fresh.items[i] = prior;
            else if (
              typeof prior.text === "string" &&
              prior.text.startsWith(fresh.items[i].text ?? "") &&
              prior.text.length > (fresh.items[i].text ?? "").length
            )
              fresh.items[i] = { ...fresh.items[i], text: prior.text };
          }
        }
      }
    }
    session.turns = turns;
    session.loadedTurns = loaded;
    const turnsById = new Map(turns.map((turn) => [turn.id, turn]));
    const latest = turns.at(-1);
    session.status = latest?.status ?? "unknown";
    session.activeTurn = ["running", "waiting"].includes(latest?.status)
      ? latest.id
      : null;
    const retryCleared =
      !!session.retryNotice &&
      session.retryNotice.turnId !== session.activeTurn;
    if (retryCleared)
      this._clearRetry(session, session.retryNotice.turnId, false);
    if (session.unknownDelivery && session.deliveryProbe) {
      const probe = session.deliveryProbe,
        matches =
          probe.kind === "steer"
            ? turns.filter(
                (turn) =>
                  turn.id === probe.expectedTurnId &&
                  turn.items.some(
                    (item) =>
                      item.role === "user" &&
                      item.clientRequestId === probe.clientUserMessageId,
                  ),
              )
            : turns.filter(
                (t) =>
                  !probe.baseline.has(t.id) &&
                  t.items.some(
                    (i) => i.role === "user" && i.text === probe.prompt,
                  ),
              );
      if (matches.length === 1) {
        session.unknownDelivery = false;
        session.deliveryProbe = null;
      }
    }
    for (const [nativeId, turnId] of session.approvalWaits ?? [])
      if (terminal(turnsById.get(turnId)?.status))
        session.approvalWaits.delete(nativeId);
    this._expire(session, (r) => r.turnId !== session.activeTurn);
    if (
      session.activeTurn &&
      (session.pending.size ||
        [...(session.approvalWaits ?? new Map()).values()].includes(
          session.activeTurn,
        ))
    ) {
      session.status = "waiting";
      latest.status = "waiting";
    }
    // 快照只恢复原生明确标记运行的条目；reasoning 的存在本身不能证明仍在思考。
    if (
      !session.activeTurn ||
      !(
        preserveConcurrent &&
        baseline?.activityRevision !== undefined &&
        baseline.activityRevision !== session.activityRevision
      )
    ) {
      if (!session.activeTurn || session.activityTurn !== session.activeTurn)
        this._clearActivity(session);
      else
        for (const [key, item] of session.activityItems ?? []) {
          const raw = rawById
            .get(item.turnId)
            ?.items.find((value) => value.id === item.itemId);
          if (raw && itemFinished(raw)) {
            session.activityItems.delete(key);
            (session.completedActivity ??= new Set()).add(key);
          }
        }
      if (session.activeTurn)
        for (const raw of rawById.get(session.activeTurn)?.items ?? []) {
          const kind = activityKind(raw.type),
            key = JSON.stringify([session.activeTurn, raw.id]);
          if (kind && itemFinished(raw)) {
            session.completedActivity.add(key);
            continue;
          }
          if (
            kind &&
            itemRunning(raw) &&
            !session.completedActivity.has(key) &&
            !session.activityItems.has(key)
          ) {
            session.activityItems.set(key, {
              turnId: session.activeTurn,
              itemId: raw.id,
              kind,
            });
            session.activityRevision = (session.activityRevision ?? 0) + 1;
          }
        }
    }
    session.activityTurn = session.activeTurn;
    this._activity(session, true);
    if (retryCleared) this._status(session);
    for (const turn of turns) {
      if (
        !loaded.has(turn.id) ||
        (paging?.older &&
          paging.selected.has(turn.id) &&
          turn.id !== session.activeTurn &&
          !paging.liveCorrections.has(turn.id))
      )
        continue;
      const old = previousById.get(turn.id),
        changed = old?.status !== turn.status;
      if (changed && !terminal(turn.status))
        this._emit(session, {
          type: "turn.upsert",
          turnId: turn.id,
          turnStatus: turn.status,
        });
      if (turn.items !== old?.items)
        for (const item of turn.items)
          if (
            JSON.stringify(previousItems.get(turn.id)?.get(item.id)) !==
            JSON.stringify(item)
          )
            this._emit(session, { type: "item.upsert", turnId: turn.id, item });
      if (changed && terminal(turn.status))
        this._emit(session, {
          type: "turn.upsert",
          turnId: turn.id,
          turnStatus: turn.status,
        });
    }
    this._publishHistoryCache(session, response);
  }
  _expire(session, predicate = () => true) {
    let changed = false,
      uncertain = false;
    for (const [id, request] of session.pending) {
      if (!predicate(request)) continue;
      changed = true;
      uncertain ||=
        request.turnId === session.activeTurn &&
        session.approvalWaits?.has(request.nativeId);
      clearTimeout(request.timer);
      session.pending.delete(id);
      const entry = session.approvals.get(id);
      if (entry?.state === "pending") entry.state = "expired";
      else if (entry?.state === "submitting") {
        entry.state = "error";
        entry.details += "\n响应投递结果待确认，不会重发。";
      }
      if (entry)
        this._emit(session, { type: "approval.upsert", approval: entry });
    }
    if (changed) {
      if (uncertain && session.ready && session.status === "waiting") {
        session.approvalNotice =
          "手机端审批已过期或不可继续确认；原生审批仍待确认，请在原客户端处理。";
        session.notice = session.approvalNotice;
        this._status(session);
      } else this._activity(session, true);
    }
  }
  _resumeAfterApprovals(session) {
    const turn = session.turns.find((turn) => turn.id === session.activeTurn);
    if (
      session.pending.size ||
      [...(session.approvalWaits ?? new Map()).values()].includes(
        session.activeTurn,
      ) ||
      !session.ready ||
      session.recovering ||
      session.status !== "waiting" ||
      !turn ||
      terminal(turn.status)
    )
      return false;
    if (session.notice === session.approvalNotice) session.notice = "";
    session.approvalNotice = null;
    session.status = "running";
    turn.status = "running";
    this._emit(session, {
      type: "turn.upsert",
      turnId: turn.id,
      turnStatus: "running",
    });
    this._status(session);
    return true;
  }
  _message(session, message) {
    const p = message.params ?? {};
    if (p.threadId !== session.id) return;
    if (message.method === "thread/name/updated") {
      session.nameRevision = (session.nameRevision ?? 0) + 1;
      if (typeof p.threadName === "string" || p.threadName === null)
        session.meta = { ...session.meta, title: p.threadName ?? "" };
      this._status(session);
      return;
    }
    const turnId = p.turn?.id ?? p.turnId;
    if (turnId) {
      const revisions = (session.client.historyRevisions ??= new Map());
      revisions.set(turnId, (revisions.get(turnId) ?? 0) + 1);
      session.client.historyLoaded?.turns.delete(turnId);
    }
    if (message.method === "thread/settings/updated") {
      const source = p.threadSettings;
      if (!source || typeof source !== "object" || Array.isArray(source))
        return;
      const patch = {};
      for (const [native, key] of [
        ["model", "model"],
        ["effort", "reasoningEffort"],
        ["modelProvider", "modelProvider"],
      ])
        if (
          Object.hasOwn(source, native) &&
          (source[native] === null || typeof source[native] === "string")
        )
          patch[key] = source[native];
      if (Object.keys(patch).length) {
        session.meta = { ...session.meta, ...patch };
        this._status(session);
      }
      return;
    }
    if (message.id != null) {
      if (
        !session.activeTurn ||
        terminal(
          session.turns.find((t) => t.id === session.activeTurn)?.status,
        ) ||
        (p.turnId && p.turnId !== session.activeTurn)
      )
        return;
      if (
        [...session.pending.values()].some(
          (r) => r.nativeId === message.id && r.client === session.client,
        )
      )
        return;
      const spec = approvalSpec(
        message.method,
        p,
        session.reviews.get(JSON.stringify([turnId, p.itemId])),
        this.settings.token,
      );
      if (!p.turnId) {
        spec.approve = null;
        spec.reject = null;
        spec.details += "\n请求未绑定明确回合，请在原客户端处理。";
      }
      if (spec.details.length > 16000) {
        spec.approve = null;
        spec.details =
          spec.details.slice(0, 15900) + "\n[内容超限，请在原客户端完整审阅]";
      }
      const id = crypto.randomUUID(),
        entry = {
          id,
          threadId: session.id,
          turnId: turnId ?? session.activeTurn,
          kind: spec.kind,
          title: spec.title,
          details: spec.details,
          ...(spec.summary ? { summary: spec.summary } : {}),
          ...(spec.rejectLabel ? { rejectLabel: spec.rejectLabel } : {}),
          ...(typeof spec.command === "string" ? { command: spec.command } : {}),
          ...(typeof spec.reason === "string" ? { reason: spec.reason } : {}),
          ...(typeof spec.cwd === "string" ? { cwd: spec.cwd } : {}),
          canApprove: !!spec.approve,
          canReject: !!spec.reject,
          state: "pending",
          expiresAt: Date.now() + APPROVAL_MS,
        };
      const request = {
        nativeId: message.id,
        client: session.client,
        turnId: entry.turnId,
        itemId: p.itemId,
        spec,
      };
      request.timer = setTimeout(
        () => this._expire(session, (r) => r === request),
        APPROVAL_MS,
      );
      request.timer.unref?.();
      session.pending.set(id, request);
      (session.approvalWaits ??= new Map()).set(message.id, entry.turnId);
      session.approvals.set(id, entry);
      while (session.approvals.size > MAX_APPROVALS) {
        const key = session.approvals.keys().next().value;
        this._expire(session, (r) => r === session.pending.get(key));
        session.approvals.delete(key);
      }
      this._clearRetry(session, entry.turnId, false);
      session.status = "waiting";
      this._turn(session, entry.turnId).status = "waiting";
      this._emit(session, { type: "approval.upsert", approval: entry });
      this._emit(session, {
        type: "turn.upsert",
        turnId: entry.turnId,
        turnStatus: "waiting",
      });
      this._status(session);
      return;
    }
    if (message.method === "serverRequest/resolved") {
      const known = session.approvalWaits?.delete(p.requestId);
      this._expire(session, (r) => r.nativeId === p.requestId);
      if (!known || !this._resumeAfterApprovals(session))
        this._activity(session, true);
      return;
    }
    if (!turnId) return;
    const existing = session.turns.find((t) => t.id === turnId);
    if (terminal(existing?.status) && message.method !== "turn/completed")
      return;
    if (
      message.method === "item/started" &&
      (session.completedActivity?.has(JSON.stringify([turnId, p.item?.id])) ||
        existing?.items.some(
          (item) => item.id === p.item?.id && itemFinished(item),
        ))
    )
      return;
    // 重试只绑定收到错误的连接与回合；仅原生进展能解除，普通刷新和配置事件不能证明恢复。
    const itemProgress =
      ["item/started", "item/completed"].includes(message.method) &&
      typeof p.item?.id === "string" &&
      !!p.item.id &&
      typeof p.item?.type === "string" &&
      !!p.item.type;
    const deltaProgress =
      [
        "item/agentMessage/delta",
        "item/commandExecution/outputDelta",
        "item/fileChange/outputDelta",
        "item/reasoning/textDelta",
        "item/reasoning/summaryTextDelta",
      ].includes(message.method) &&
      typeof p.itemId === "string" &&
      !!p.itemId &&
      typeof p.delta === "string" &&
      !!p.delta;
    const toolProgress =
      message.method === "item/mcpToolCall/progress" &&
      typeof p.itemId === "string" &&
      !!p.itemId;
    const patchProgress =
      message.method === "item/fileChange/patchUpdated" &&
      typeof p.itemId === "string" &&
      !!p.itemId &&
      Array.isArray(p.changes);
    if (itemProgress || deltaProgress || toolProgress || patchProgress)
      this._clearRetry(session, turnId);
    if (message.method === "turn/started") {
      if (session.retryNotice)
        this._clearRetry(session, session.retryNotice.turnId, false);
      if (session.activeTurn !== turnId) this._clearActivity(session);
      session.activityTurn = turnId;
      for (const [nativeId, waitingTurn] of session.approvalWaits ?? [])
        if (waitingTurn !== turnId) session.approvalWaits.delete(nativeId);
      if (session.notice === session.approvalNotice) session.notice = "";
      session.approvalNotice = null;
      this._expire(session, (r) => r.turnId !== turnId);
      session.activeTurn = turnId;
      session.status = "running";
      const turn = this._turn(session, turnId);
      turn.status = "running";
      const timing = Object.fromEntries(
        ["startedAt", "completedAt", "durationMs"]
          .filter((key) => Number.isFinite(p.turn[key]))
          .map((key) => [key, p.turn[key]]),
      );
      Object.assign(turn, timing);
      this._emit(session, {
        type: "turn.upsert",
        turnId,
        turnStatus: "running",
        ...timing,
      });
      this._status(session);
    } else if (message.method === "turn/completed") {
      const status = statusOf(p.turn.status);
      if (!terminal(status)) return;
      this._clearRetry(session, turnId, false);
      const current =
        session.activeTurn === turnId ||
        (!session.activeTurn &&
          (!session.turns.length || session.turns.at(-1).id === turnId));
      if (current) this._clearActivity(session);
      const turn = this._turn(session, turnId);
      for (const raw of p.turn.items ?? []) this._upsert(session, turn, raw);
      turn.status = status;
      const timing = Object.fromEntries(
        ["startedAt", "completedAt", "durationMs"]
          .filter((key) => Number.isFinite(p.turn[key]))
          .map((key) => [key, p.turn[key]]),
      );
      Object.assign(turn, timing);
      if (current) {
        session.status = status;
        if (session.activeTurn === turnId) session.activeTurn = null;
      }
      for (const [nativeId, waitingTurn] of session.approvalWaits ?? [])
        if (waitingTurn === turnId) session.approvalWaits.delete(nativeId);
      if (current && session.notice === session.approvalNotice) {
        session.notice = "";
        session.approvalNotice = null;
      }
      this._expire(session, (r) => r.turnId === turnId);
      this._emit(session, {
        type: "turn.upsert",
        turnId,
        turnStatus: status,
        ...timing,
      });
      if (current) this._status(session);
      this._canonical(session, turnId);
    } else if (message.method === "thread/compacted") {
      this._clearRetry(session, turnId);
      for (const active of [...(session.activityItems ?? new Map()).values()])
        if (active.turnId === turnId && active.kind === "compacting")
          this._trackActivity(
            session,
            turnId,
            active.itemId,
            "compacting",
            true,
          );
      for (const item of existing?.items ?? [])
        if (item.type === "contextCompaction" && !itemTerminal(item.status))
          this._upsert(session, existing, { ...item, status: "completed" });
    } else if (
      [
        "item/reasoning/summaryPartAdded",
        "item/reasoning/summaryTextDelta",
        "item/reasoning/textDelta",
      ].includes(message.method)
    ) {
      if (typeof p.itemId !== "string" || !p.itemId || p.itemId.length > 512)
        return;
      if (
        message.method === "item/reasoning/summaryPartAdded"
          ? !Number.isInteger(p.summaryIndex) || p.summaryIndex < 0
          : typeof p.delta !== "string"
      )
        return;
      this._clearRetry(session, turnId);
      // 只保存活动标识；原生推理文本和摘要不进入缓存、公开帧或历史。
      this._trackActivity(session, turnId, p.itemId, "thinking");
    } else if (
      message.method === "item/mcpToolCall/progress" ||
      message.method === "item/fileChange/outputDelta"
    ) {
      this._trackActivity(
        session,
        turnId,
        p.itemId,
        message.method === "item/mcpToolCall/progress" ? "tool" : "editing",
      );
    } else if (["item/started", "item/completed"].includes(message.method)) {
      this._trackActivity(
        session,
        turnId,
        p.item?.id,
        activityKind(p.item?.type),
        message.method === "item/completed",
      );
      const prior = existing?.items.find((item) => item.id === p.item?.id),
        priorFailure =
          itemTerminal(prior?.status) && prior.status !== "completed"
            ? prior.status
            : null;
      const raw = p.item
        ? {
            ...p.item,
            status:
              message.method === "item/completed"
                ? (priorFailure ??
                  (itemTerminal(p.item.status) ? p.item.status : "completed"))
                : (p.item.status ?? "inProgress"),
          }
        : p.item;
      this._upsert(session, this._turn(session, turnId), raw);
      if (
        message.method === "item/completed" &&
        session.recoveryPending?.delete(JSON.stringify([turnId, p.item?.id])) &&
        !session.recoveryPending.size &&
        session.notice?.startsWith("已回读同一会话；")
      ) {
        session.notice = "";
        this._status(session);
      }
    } else if (message.method === "item/fileChange/patchUpdated") {
      const turn = this._turn(session, turnId),
        prior = turn.items.find((i) => i.id === p.itemId);
      this._upsert(session, turn, {
        ...prior,
        id: p.itemId,
        type: "fileChange",
        changes: p.changes,
        status: prior?.status ?? "inProgress",
      });
      // 即使工具预览截断后内容看似相同，新的完整审阅上下文也必须使读快照失效。
      this._status(session);
    } else if (
      ["item/agentMessage/delta", "item/commandExecution/outputDelta"].includes(
        message.method,
      )
    ) {
      if (typeof p.itemId !== "string" || typeof p.delta !== "string") return;
      this._trackActivity(
        session,
        turnId,
        p.itemId,
        message.method.includes("agentMessage") ? "responding" : "command",
      );
      const turn = this._turn(session, turnId);
      let item = turn.items.find((i) => i.id === p.itemId);
      if (!item) {
        item = {
          id: p.itemId,
          type: message.method.includes("agentMessage")
            ? "agentMessage"
            : "commandExecution",
          role: message.method.includes("agentMessage") ? "assistant" : "tool",
          text: "",
          phase: null,
          ...(message.method.includes("commandExecution")
            ? { status: "inProgress" }
            : {}),
        };
        turn.items.push(item);
        this._emit(session, {
          type: "item.upsert",
          turnId,
          item: structuredClone(item),
        });
      }
      if (item.role === "tool") {
        const originalBytes =
          (item.originalBytes ?? bytes(item.text)) + bytes(p.delta);
        if (item.outputTruncated) {
          item.originalBytes = originalBytes;
          return;
        }
        const preview = toolPreview({
          ...item,
          text: item.text + p.delta,
          originalBytes,
        });
        turn.items[turn.items.indexOf(item)] = preview;
        this._emit(
          session,
          preview.outputTruncated
            ? { type: "item.upsert", turnId, item: preview }
            : { type: "item.delta", turnId, itemId: p.itemId, delta: p.delta },
        );
      } else {
        if (bytes(item.text) + bytes(p.delta) > PAGE_MAX_BYTES - 16 * 1024) {
          session.notice =
            "实时助手正文超过移动端 2 MiB 读取上限；已有内容保留，请在桌面查看完整正文。";
          this._status(session);
          return;
        }
        item.text += p.delta;
        this._emit(session, {
          type: "item.delta",
          turnId,
          itemId: p.itemId,
          delta: p.delta,
        });
      }
    } else if (message.method === "error") {
      if (p.willRetry) {
        if (session.activeTurn !== turnId) return;
        session.retryNotice = {
          turnId,
          client: session.client,
          text: "共享引擎正在重试。",
        };
      } else {
        this._clearRetry(session, turnId, false);
        session.notice = "共享引擎报告错误，等待明确回合终态。";
      }
      this._status(session);
    }
  }
  _canonical(session, turnId) {
    if (session.canonical?.has(turnId)) return;
    (session.canonical ??= new Set()).add(turnId);
    const client = session.client;
    const task = (async () => {
      try {
        const response = await this._readHistory(client, session.id, {
          targetTurnId: turnId,
        });
        if (this.closed || session.client !== client || !client.connected)
          return;
        const raw =
          response.thread?.id === session.id &&
          response.thread.turns?.find((t) => t.id === turnId);
        if (
          !raw ||
          !terminal(statusOf(raw.status)) ||
          !Array.isArray(raw.items) ||
          (raw.itemsView != null && raw.itemsView !== "full")
        )
          throw Error();
        const turn = this._turn(session, turnId);
        if (
          turn.items.some(
            (item) => !raw.items.some((value) => value.id === item.id),
          )
        )
          throw Error();
        for (const item of raw.items) this._upsert(session, turn, item);
        session.loadedTurns ??= new Set();
        session.loadedTurns.add(turnId);
        this._publishHistoryCache(session, response);
        for (const key of session.recoveryPending ?? [])
          if (JSON.parse(key)[0] === turnId)
            session.recoveryPending.delete(key);
        if (
          !session.recoveryPending?.size &&
          session.notice?.startsWith("已回读同一会话；")
        ) {
          session.notice = "";
          this._status(session);
        }
        this._emit(session, {
          type: "turn.upsert",
          turnId,
          turnStatus: turn.status,
        });
      } catch {
        if (this.closed || session.client !== client) return;
        session.notice = "终态正文尚未完整回读校正，请刷新确认；不会重发输入。";
        this._status(session);
      }
    })();
    (session.tasks ??= new Set()).add(task);
    task.finally(() => session.tasks.delete(task));
  }
  async _approval(session, args) {
    if (
      !UUID.test(args.approvalId ?? "") ||
      !["approve", "reject"].includes(args.decision) ||
      !UUID.test(args.requestId ?? "")
    )
      throw fail("INVALID_APPROVAL", "审批参数无效。");
    const entry = session.approvals.get(args.approvalId),
      request = session.pending.get(args.approvalId);
    if (!entry)
      throw fail("APPROVAL_NOT_FOUND", "审批不存在或已移出有界历史。");
    if (entry.state === "expired" || (entry.state === "pending" && !request))
      throw fail("APPROVAL_EXPIRED", "审批已失效，请确认当前连接请求。");
    if (entry.state !== "pending")
      throw fail("APPROVAL_CONFLICT", "审批已提交或正在提交，不能重复响应。");
    if (
      !session.ready ||
      !session.client.connected ||
      request.client !== session.client ||
      request.turnId !== session.activeTurn ||
      Date.now() >= entry.expiresAt
    ) {
      this._expire(session, (r) => r === request);
      throw fail("APPROVAL_EXPIRED", "审批连接、回合或有效期已变化。");
    }
    const result =
      args.decision === "approve" ? request.spec.approve : request.spec.reject;
    if (!result) throw fail("APPROVAL_UNSUPPORTED", "请在原客户端处理此请求。");
    entry.state = "submitting";
    this._emit(session, { type: "approval.upsert", approval: entry });
    let delivered = false;
    try {
      await request.client.respond(request.nativeId, result);
      if (entry.state === "submitting")
        entry.state = args.decision === "approve" ? "submitted" : "rejected";
      if (!["submitted", "rejected"].includes(entry.state)) throw Error();
      delivered = true;
      session.approvalWaits?.delete(request.nativeId);
      return { accepted: true, approvalId: entry.id, state: entry.state };
    } catch {
      if (entry.state === "submitting") entry.state = "error";
      if (session.ready && session.status === "waiting") {
        session.approvalNotice =
          "审批响应投递未知；原生审批仍待确认，请在原客户端处理。";
        session.notice = session.approvalNotice;
      }
      throw fail(
        "APPROVAL_SEND_FAILED",
        "审批响应失败或投递未知，不会重发，请重新连接确认。",
      );
    } finally {
      clearTimeout(request.timer);
      session.pending.delete(entry.id);
      this._emit(session, { type: "approval.upsert", approval: entry });
      if (!delivered || !this._resumeAfterApprovals(session))
        this._status(session);
    }
  }
  async _create(args) {
    if (
      typeof args.prompt !== "string" ||
      !args.prompt.trim() ||
      args.prompt.length > 16000 ||
      !UUID.test(args.requestId ?? "") ||
      (args.permissionMode !== undefined &&
        !["read-only", "workspace-write", "full-access"].includes(args.permissionMode)) ||
      (args.title !== undefined &&
        (typeof args.title !== "string" || args.title.length > 120)) ||
      (args.projectId != null &&
        (typeof args.projectId !== "string" || !args.projectId))
    )
      throw fail("BAD_INPUT", "创建会话需要有效消息、项目、标题及 requestId。");
    const hash = crypto
      .createHash("sha256")
      .update(
        JSON.stringify([
          args.prompt,
          args.title ?? null,
          args.projectId ?? null,
          args.model,
          args.thinking,
          args.permissionMode,
        ]),
      )
      .digest("hex");
    const previous = this.creates.get(args.requestId);
    if (previous) {
      if (previous.hash !== hash)
        throw fail("REQUEST_CONFLICT", "请求标识已用于其他创建请求。");
      return previous.promise;
    }
    if (this.requests.has(args.requestId))
      throw fail("REQUEST_CONFLICT", "请求标识已用于消息请求。");
    if (this.creates.size >= 10000)
      throw fail("REQUEST_LIMIT", "创建请求记录已达上限，请重新连接。");
    if (args.thinking !== undefined && args.model === undefined)
      throw fail("INVALID_THINKING", "推理配置需要同时选择模型。");
    if (args.model !== undefined) {
      const model = (await this.catalog.execute("models", {})).models.find(
        (m) => m.id === args.model,
      );
      if (!model) throw fail("INVALID_MODEL", "所选模型不可用。");
      if (
        args.thinking !== undefined &&
        !model.reasoningEfforts.some((e) => e.value === args.thinking)
      )
        throw fail("INVALID_THINKING", "推理配置不适用于此模型。");
    }
    let cwd;
    if (args.projectId != null) {
      const project = (
        await this.catalog.execute("projects", {})
      ).projects.find((p) => p.id === args.projectId);
      if (
        !project ||
        typeof project.path !== "string" ||
        (!path.isAbsolute(project.path) && !path.win32.isAbsolute(project.path))
      )
        throw fail("BAD_INPUT", "共享引擎项目不存在或没有本机工作目录。");
      cwd = project.path;
    }
    // 预检等待期间可能已有相同请求；再次核对后才允许发起原生创建。
    const concurrent = this.creates.get(args.requestId);
    if (concurrent) {
      if (concurrent.hash !== hash)
        throw fail("REQUEST_CONFLICT", "请求标识已用于其他创建请求。");
      return concurrent.promise;
    }
    const entry = { hash };
    entry.promise = (async () => {
      let threadId,
        client,
        creationStarted = false;
      try {
        client = await this._locked(async () => {
          if (this.closed) throw fail("CLOSED", "共享运行时已关闭。");
          await this._makeConnectionRoom();
          if (this.closed) throw fail("CLOSED", "共享运行时已关闭。");
          const creating = this._newClient();
          creating.on("error", () => {});
          this.creatingClients.add(creating);
          return creating;
        });
        await client.connect();
        if (this.closed) throw fail("CLOSED", "共享运行时已关闭。");
        creationStarted = true;
        const response = await client.request(
          "thread/start",
          {
            ephemeral: false,
            projectId: args.projectId ?? null,
            ...(cwd ? { cwd } : {}),
            ...(args.permissionMode !== undefined ? {
              sandbox: args.permissionMode === "full-access" ? "danger-full-access" : args.permissionMode,
              approvalPolicy: args.permissionMode === "full-access" ? "never" : "on-request",
            } : {}),
            ...(args.model !== undefined ? { model: args.model } : {}),
          },
          60000,
        );
        threadId = response?.thread?.id;
        if (!UUID.test(threadId ?? ""))
          throw fail(
            "DELIVERY_UNKNOWN",
            "共享引擎创建结果缺少会话标识，请检查目录，勿重复创建。",
          );
        const result = await this._lease(
          threadId,
          async (session) => {
            if (args.title?.trim()) {
              await session.client.request("thread/name/set", {
                threadId,
                name: args.title.trim(),
              });
            }
            const result = await this._send(session, { ...args, threadId });
            if (!args.title?.trim()) {
              const revision = session.nameRevision ?? 0;
              const task = this._autoTitle(session, args.prompt, cwd, revision)
                .catch(() => { /* 标题失败不改变首轮投递结果，也不重发。 */ });
              (session.tasks ??= new Set()).add(task);
              task.finally(() => session.tasks.delete(task)).catch(() => {});
            }
            return result;
          },
          { createdClient: client, createdResponse: response },
        );
        return { ...result, source: "shared-engine" };
      } catch (error) {
        // 一旦发起创建，不能把后续错误当作可重试预检失败，否则会生成重复会话。
        if (threadId)
          throw fail(
            "CREATE_INCOMPLETE",
            `共享引擎会话 ${threadId} 已创建，首条消息未确认；请打开该会话核对，勿重复创建。`,
          );
        if (!creationStarted) throw error;
        if (error.code === "RPC_ERROR")
          throw fail(
            "CREATE_REJECTED",
            "共享引擎未接受创建请求，请检查项目及模型配置。",
          );
        throw fail(
          "DELIVERY_UNKNOWN",
          "共享引擎创建结果未知，请刷新目录核对；不会自动重建或转交桌面。",
        );
      } finally {
        // 已交接的连接归会话生命周期；尚未取得ID或租约失败的连接由创建事务释放。
        if (client && this.creatingClients.delete(client)) await client.close();
      }
    })();
    this.creates.set(args.requestId, entry);
    return entry.promise;
  }
  async _autoTitle(session, prompt, cwd, revision) {
    const client = session.client;
    const unchanged = () => !this.closed && !session.retired && client.connected &&
      this.sessions.get(session.id) === session && session.client === client &&
      (session.nameRevision ?? 0) === revision;
    const models = (await this.catalog.execute("models", {})).models;
    const low = models.filter(model => model.reasoningEfforts.some(e => e.value === "low"));
    const model = low.find(model => model.id === "gpt-6-luna") ?? low.find(model => model.isDefault) ?? low[0];
    if (!model || !unchanged()) return;
    const title = await this.titleGenerator(client, { prompt, cwd, model: model.id });
    if (!title || !unchanged()) return;
    // 原生没有 compare-and-set；写前回读，已有名称或收到改名通知就保留用户名称。
    const current = await client.request("thread/read", { threadId: session.id, includeTurns: false });
    if (!unchanged() || current?.thread?.id !== session.id || current.thread.name?.trim()) return;
    await client.request("thread/name/set", { threadId: session.id, name: title });
    if (session.client === client) {
      session.meta = { ...session.meta, title };
      this._status(session);
    }
  }
  async _send(session, args) {
    if (
      typeof args.prompt !== "string" ||
      !args.prompt.trim() ||
      args.prompt.length > 16000 ||
      !UUID.test(args.requestId ?? "")
    )
      throw fail("BAD_INPUT", "请输入有效消息和 requestId。");
    const hash = crypto
      .createHash("sha256")
      .update(
        JSON.stringify([
          session.id,
          args.prompt,
          args.model,
          args.thinking,
          args.expectedTurnId,
        ]),
      )
      .digest("hex");
    const previous = this.requests.get(args.requestId);
    if (previous) {
      if (previous.hash !== hash)
        throw fail("REQUEST_CONFLICT", "请求标识已用于其他消息。");
      return previous.promise;
    }
    if (Object.hasOwn(args, "expectedTurnId"))
      return this._steer(session, args, hash);
    if (session.sending || session.activeTurn || session.unknownDelivery)
      throw fail("BUSY", "此会话仍在运行或投递待确认，请先回读。");
    if (this.requests.size >= 10000)
      throw fail("REQUEST_LIMIT", "本运行实例请求记录已达上限，请重新连接。");
    let override = {};
    if (args.thinking !== undefined && args.model === undefined)
      throw fail("INVALID_THINKING", "推理配置需要同时选择模型。");
    if (args.model !== undefined) {
      const catalog = await this.catalog.execute("models", {}),
        model = catalog.models?.find((m) => m.id === args.model);
      if (!model) throw fail("INVALID_MODEL", "所选模型不可用。");
      if (
        args.thinking !== undefined &&
        !model.reasoningEfforts?.some((e) => e.value === args.thinking)
      )
        throw fail("INVALID_THINKING", "推理配置不适用于此模型。");
      override = {
        model: args.model,
        ...(args.thinking !== undefined ? { effort: args.thinking } : {}),
      };
    }
    if (session.sending || session.activeTurn)
      throw fail("BUSY", "此会话正在运行。");
    session.sending = true;
    const beforeTurnId = session.turns.at(-1)?.id ?? null,
      entry = { hash };
    entry.promise = (async () => {
      try {
        session.unknownDelivery = true;
        session.deliveryProbe = {
          baseline: new Set(session.turns.map((t) => t.id)),
          prompt: args.prompt,
        };
        const response = await session.client.request(
          "turn/start",
          {
            threadId: session.id,
            input: [{ type: "text", text: args.prompt }],
            ...override,
          },
          60000,
        );
        if (typeof response.turn?.id !== "string") throw Error();
        const turn = this._turn(session, response.turn.id);
        if (!terminal(turn.status)) {
          session.activeTurn = turn.id;
          session.status = "running";
          this._emit(session, {
            type: "turn.upsert",
            turnId: turn.id,
            turnStatus: "running",
          });
        }
        for (const raw of response.turn.items ?? [])
          this._upsert(session, turn, raw);
        this._activity(session, true);
        session.unknownDelivery = false;
        session.deliveryProbe = null;
        return {
          threadId: session.id,
          turnId: turn.id,
          accepted: true,
          _submission: { prompt: args.prompt, turnId: turn.id, beforeTurnId },
        };
      } catch (error) {
        if (error.code === "RPC_ERROR") {
          session.unknownDelivery = false;
          session.deliveryProbe = null;
          throw fail(
            "TURN_START_REJECTED",
            "共享引擎未接受此发送，请刷新同一会话确认当前回合。",
          );
        }
        throw fail(
          "DELIVERY_UNKNOWN",
          "消息接受结果未知，请回读同一会话；不会自动重发。",
        );
      } finally {
        session.sending = false;
      }
    })();
    this.requests.set(args.requestId, entry);
    return entry.promise;
  }
  async _steer(session, args, hash) {
    if (
      typeof args.expectedTurnId !== "string" ||
      !args.expectedTurnId ||
      args.expectedTurnId.length > 512
    )
      throw fail("BAD_INPUT", "运行中补充消息需要明确的原回合标识。");
    if (args.model !== undefined || args.thinking !== undefined)
      throw fail(
        "BAD_INPUT",
        "运行中补充消息不能覆盖模型或推理强度，请保留到下一轮。",
      );
    if (
      session.activeTurn !== args.expectedTurnId ||
      terminal(
        session.turns.find((turn) => turn.id === args.expectedTurnId)?.status,
      )
    )
      throw fail(
        "TURN_NOT_ACTIVE",
        "原回合已结束或当前回合已变化；补充消息未转交新回合。",
      );
    if (session.sending || session.unknownDelivery)
      throw fail("BUSY", "上次发送仍在投递或结果未知，请先回读。");
    if (this.requests.size >= 10000)
      throw fail("REQUEST_LIMIT", "本运行实例请求记录已达上限，请重新连接。");
    session.sending = true;
    const entry = { hash };
    entry.promise = (async () => {
      try {
        session.unknownDelivery = true;
        session.deliveryProbe = {
          kind: "steer",
          expectedTurnId: args.expectedTurnId,
          clientUserMessageId: args.requestId,
        };
        const response = await session.client.request(
          "turn/steer",
          {
            threadId: session.id,
            expectedTurnId: args.expectedTurnId,
            clientUserMessageId: args.requestId,
            input: [{ type: "text", text: args.prompt }],
          },
          60000,
        );
        if (response?.turnId !== args.expectedTurnId)
          throw Error("steer acknowledgement mismatch");
        session.unknownDelivery = false;
        session.deliveryProbe = null;
        return {
          threadId: session.id,
          turnId: response.turnId,
          accepted: true,
          submissionKind: "steer",
          clientUserMessageId: args.requestId,
          _submission: {
            prompt: args.prompt,
            turnId: response.turnId,
            beforeTurnId: args.expectedTurnId,
            clientUserMessageId: args.requestId,
          },
        };
      } catch (error) {
        if (error.code === "RPC_ERROR") {
          session.unknownDelivery = false;
          session.deliveryProbe = null;
          throw fail(
            error.rpcCode === -32601
              ? "STEER_UNSUPPORTED"
              : "TURN_STEER_REJECTED",
            error.rpcCode === -32601
              ? "当前引擎未提供运行中补充消息；未新建回合。"
              : "原生引擎未接受此回合补充消息；请保留草稿并刷新原会话。",
          );
        }
        throw fail(
          "DELIVERY_UNKNOWN",
          "补充消息接受结果未知，请回读原会话；不会重发或新建回合。",
        );
      } finally {
        session.sending = false;
      }
    })();
    this.requests.set(args.requestId, entry);
    return entry.promise;
  }
  async execute(operation, args = {}) {
    if (this.closed) throw fail("CLOSED", "共享运行时已关闭。");
    if (operation === "read" && args.questionIndex !== undefined) {
      if (typeof args.questionIndex !== "boolean") throw fail("BAD_INPUT", "questionIndex必须是布尔值。");
      if (args.questionIndex) {
        if (!UUID.test(args.threadId ?? "") || args.cursor) throw fail("BAD_INPUT", "完整提问索引需要有效会话且不能指定分页游标。");
        try { return this._safe(await sharedQuestionIndex(await this._control(), args.threadId, normalizeHistory)); }
        catch (error) {
          if (error.rpcCode === -32601) throw fail("UNSUPPORTED_CAPABILITY", "原生引擎尚不支持轻量提问索引。");
          throw error;
        }
      }
    }
    if (operation === "ping") {
      await this._control();
      return { pong: true, fetchedAt: Date.now() };
    }
    if (
      ["threads", "statuses", "projects", "models", "usage"].includes(operation)
    )
      return this.catalog.execute(operation, args);
    if (operation === "create") return this._create(args);
    if (operation === "reconcile")
      throw fail(
        "UNSUPPORTED_CAPABILITY",
        "共享引擎模式不使用桌面归属登记；会话和项目归属由共享引擎维护。",
      );
    if (["media", "visualization", "attachment"].includes(operation)) {
      if (!UUID.test(args.threadId ?? ""))
        throw fail("BAD_INPUT", "会话ID无效。");
      try {
        if (operation === "media")
          return await readHistoryImage(
            this.mediaMap,
            args.threadId,
            args.imageId,
          );
        if (operation === "visualization")
          return readHistoryVisualization(
            this.visualizationMap,
            args.threadId,
            args.visualizationId,
          );
        return readAttachmentChunk(
          this.attachmentMap,
          args.threadId,
          args.fileId,
          args.offset,
          args.length,
        );
      } catch (error) {
        if (
          error instanceof MediaError ||
          error instanceof VisualizationError ||
          error instanceof AttachmentError
        )
          throw new BridgeError(error.code, error.message);
        throw error;
      }
    }
    if (
      !["read", "progress", "send", "interrupt", "respondApproval"].includes(
        operation,
      )
    )
      throw fail("BAD_INPUT", "不支持的共享引擎操作。");
    // 旧审批不得因重连而获得新的响应权限。
    if (operation === "respondApproval") {
      const session = this.sessions.get(args.threadId);
      if (!session) throw fail("APPROVAL_EXPIRED", "原审批连接已失效。");
      return this._approval(session, args);
    }
    const limit = Math.max(
      1,
      Math.min(Number.isInteger(args.turnLimit) ? args.turnLimit : 10, 10),
    );
    const before =
      operation === "read" && args.cursor
        ? this._decode(args.cursor, args.threadId)
        : undefined;
    return this._lease(
      args.threadId,
      async (session, justConnected) => {
        if (operation === "send") return this._send(session, args);
        if (operation === "interrupt") {
          if (
            !UUID.test(args.requestId ?? "") ||
            typeof args.turnId !== "string" ||
            !args.turnId
          )
            throw fail("BAD_INPUT", "中断需要回合和请求标识。");
          if (session.activeTurn !== args.turnId)
            throw fail("TURN_NOT_ACTIVE", "此回合当前未在运行。");
          await session.client.request("turn/interrupt", {
            threadId: session.id,
            turnId: args.turnId,
          });
          return {
            threadId: session.id,
            turnId: args.turnId,
            accepted: true,
            notice: "中断请求已送出；等待回合终态确认。",
          };
        }
        // 每次刷新真实元数据，正文仅读取目标页；恢复与刷新从不触发 turn/start。
        if (
          !justConnected ||
          before !== undefined ||
          (operation === "read" &&
            session.turns
              .slice(-limit)
              .some((turn) => !session.loadedTurns?.has(turn.id)))
        ) {
          const sequence = session.seq,
            normalized = new Map(session.turns.map((turn) => [turn.id, turn])),
            baseline = new Map([
              ...session.turns.flatMap((t) =>
                t.items.map((i) => [
                  JSON.stringify([t.id, i.id]),
                  JSON.stringify(i),
                ]),
              ),
              ...[...session.reviews].map(([k, v]) => [
                JSON.stringify(["review", k]),
                JSON.stringify(v),
              ]),
            ]);
          baseline.activityRevision = session.activityRevision;
          baseline.settings = JSON.stringify(
            Object.fromEntries(
              ["model", "reasoningEffort", "modelProvider"].map((k) => [
                k,
                session.meta?.[k] ?? null,
              ]),
            ),
          );
          const response = await this._readHistory(session.client, session.id, {
            limit,
            before,
            older: before !== undefined,
            loadedTurns: session.loadedTurns,
            activeTurn: session.activeTurn,
            canReuse: (id) => this._canReuseHistoryTurn(normalized.get(id)),
          });
          this._replace(session, response, session.seq !== sequence, baseline);
        }
        if (operation === "progress") {
          const turn = session.turns.at(-1),
            assistant = [...(turn?.items ?? [])]
              .reverse()
              .find((i) => i.role === "assistant");
          return {
            id: session.id,
            status: ["running", "waiting"].includes(session.status)
              ? "active"
              : terminal(session.status)
                ? "idle"
                : "unknown",
            turnId: turn?.id ?? null,
            turnStatus: turn?.status ?? null,
            text: assistant?.text ?? "",
            phase: assistant?.phase ?? null,
            cursor: this._cursor(session),
            eventCursor: this._cursor(session),
            textTruncated: false,
            activity: this._activity(session),
            ...Object.fromEntries(
              ["model", "reasoningEffort", "modelProvider"].map((k) => [
                k,
                session.meta?.[k] ?? null,
              ]),
            ),
          };
        }
        let end = session.turns.length;
        if (before !== undefined) {
          end = session.turns.findIndex((t) => t.id === before);
          if (end < 0) throw fail("CURSOR_EXPIRED", "历史游标已失效，请刷新。");
        }
        let start = Math.max(0, end - limit),
          turns = session.turns.slice(start, end);
        if (
          turns.some(
            (turn) =>
              !session.loadedTurns?.has(turn.id) &&
              !session.liveTurns?.has(turn.id),
          )
        )
          throw fail(
            "INVALID_HISTORY",
            "目标历史页尚未完整读取，请重试同一会话。",
          );
        const result = (page) => {
          const notice = this._notice(session);
          return this._safe({
            id: session.id,
            ...session.meta,
            status: ["running", "waiting"].includes(session.status)
              ? "active"
              : terminal(session.status)
                ? "idle"
                : "unknown",
            source: "shared-engine",
            activity: this._activity(session),
            turns: page,
            hasMore: start > 0,
            nextCursor: start > 0 ? this._encode(session.id, page[0].id) : null,
            eventCursor: this._cursor(session),
            approvals: [...session.approvals.values()],
            ...(notice ? { notice } : {}),
          });
        };
        // 优先减少每页回合数；单回合仍大时，只进一步缩短工具预览。
        while (turns.length > 1 && bytes(result(turns)) > PAGE_TARGET_BYTES) {
          start++;
          turns = session.turns.slice(start, end);
        }
        for (const budget of [4096, 2048, 1024, 512, 256, 128]) {
          if (bytes(result(turns)) <= PAGE_TARGET_BYTES) break;
          turns = turns.map((turn) => ({
            ...turn,
            items: turn.items.map((item) => toolPreview(item, budget)),
          }));
        }
        const page = result(turns);
        if (bytes(page) > PAGE_MAX_BYTES)
          throw fail(
            "RESPONSE_TOO_LARGE",
            "单回合完整正文或条目结构超过移动端 2 MiB 读取上限；已有内容保留，请在桌面查看。",
          );
        return page;
      },
      { limit, resume: operation === "send" || operation === "interrupt" },
    );
  }
  async getStatus() {
    const base = {
      backend: "shared-engine",
      instanceId: this.instanceId,
      pid: null,
      capabilities: {
        streaming: true,
        interrupt: true,
        approvals: true,
        createPermissionMode: true,
        steer: true,
        media: true,
        visualization: true,
        attachment: true,
      },
    };
    try {
      await this._control();
      return {
        ...base,
        connected: true,
        error: null,
        connections:
          1 +
          [...this.sessions.values()].filter((s) => s.client?.connected).length,
        maxConnections: 1 + this.maxThreads,
      };
    } catch {
      return {
        ...base,
        connected: false,
        error: "共享引擎尚未连接，请检查既有 broker 与私有配置。",
      };
    }
  }
  async close() {
    if (this.closeTask) return this.closeTask;
    this.closed = true;
    this.closeTask = (async () => {
      for (const session of this.sessions.values()) {
        this._clearPassiveProbe(session);
        this._expire(session);
      }
      await Promise.allSettled([
        ...[...this.sessions.values()].flatMap((session) => [
          session.client?.close(),
          session.createdConnection?.createdClient.close(),
        ]),
        ...[...this.creatingClients].map((client) => client.close()),
        this.control?.close(),
      ]);
      await Promise.allSettled(
        [...this.sessions.values()]
          .map((session) => session.connecting)
          .filter(Boolean),
      );
      await this.controlTask?.catch(() => {});
      await Promise.allSettled(
        [...this.creates.values()].map((entry) => entry.promise),
      );
      await Promise.allSettled(
        [...this.sessions.values()].flatMap((session) => [
          ...(session.tasks ?? []),
        ]),
      );
    })();
    return this.closeTask;
  }
}
module.exports = { SharedRuntime, readSharedConfig };
