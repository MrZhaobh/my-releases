'use strict';
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),net=require('node:net'),crypto=require('node:crypto');
const {execFile}=require('node:child_process');
const {createModelCatalog}=require('./catalog.cjs');
const {registerHistoryImage,readHistoryImage,MediaError}=require('./media.cjs');
const {registerAttachment,readAttachmentChunk,AttachmentError}=require('./attachments.cjs');
const {registerHistoryVisualization,readHistoryVisualization,VisualizationError}=require('./visualizations.cjs');
const {bridgeQuestionIndex}=require('./question-index.cjs');
const UUID=/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
const DISCOVERY_REFRESH_MS=10000,DISCOVERY_MAX_AGE_MS=60000,OWNER_TTL_MS=10000,HISTORY_LIMIT_TTL_MS=60000,CACHE_ENTRIES=256;
const pipeKey=pipe=>JSON.stringify([pipe.name,pipe.pid??null,pipe.profile??null]);
const recoverableReadError=error=>['DISCONNECTED','NOT_FOUND'].includes(error?.code);
const {BridgeError}=require('./errors.cjs');
function parseToolResponse(message){
 if(message.error)throw new BridgeError('DESKTOP_ERROR','Codex 桌面接口调用失败，请检查桌面状态');
 if(!message.result?.success){const chunks=message.result?.contentItems??message.result?.content??[];if(chunks.some(item=>typeof item?.text==='string'&&item.text.trim()==='Tool response exceeds the size limit. Request fewer turns or omit outputs. A single oversized turn cannot be returned by this tool.'))throw new BridgeError('RESPONSE_TOO_LARGE','会话记录过大，当前页无法完整读取');throw new BridgeError('DESKTOP_ERROR','Codex 桌面接口调用失败，请检查桌面状态')}
 const chunks=message.result.contentItems??message.result.content??[];
 for(const item of chunks){if(typeof item.text==='string'){try{const value=JSON.parse(item.text);if(value?.success===false)throw new BridgeError('DESKTOP_ERROR','Codex 桌面接口调用失败，请检查桌面状态');return value}catch(error){if(error instanceof BridgeError)throw error}}}
 throw new BridgeError('INCOMPATIBLE','当前 Codex 版本返回格式不受支持');
}
function rpc(pipe,message,timeoutMs=20000,signal){return new Promise((resolve,reject)=>{
 if(signal?.aborted)return reject(new BridgeError('CLOSED','桌面连接已关闭，请先核对会话状态'));
 const socket=net.createConnection('\\\\.\\pipe\\'+pipe.name);let buffer=Buffer.alloc(0),done=false;
 const finish=(err,result)=>{if(done)return;done=true;clearTimeout(timer);signal?.removeEventListener('abort',aborted);socket.destroy();err?reject(err):resolve(result)};
 const aborted=()=>finish(new BridgeError('CLOSED','桌面连接已关闭，请先核对会话状态'));
 const timer=setTimeout(()=>finish(new BridgeError('TIMEOUT','桌面调用超时，请先检查会话再决定是否重试')),timeoutMs);
 signal?.addEventListener('abort',aborted,{once:true});
 socket.on('error',()=>finish(new BridgeError('DISCONNECTED','Codex 桌面连接已断开')));
 socket.on('close',()=>{if(!done)finish(new BridgeError('DISCONNECTED','Codex 桌面连接已关闭'))});
 socket.on('connect',()=>{const body=Buffer.from(JSON.stringify(message));const header=Buffer.alloc(4);header.writeUInt32LE(body.length);socket.write(Buffer.concat([header,body]))});
 socket.on('data',chunk=>{buffer=Buffer.concat([buffer,chunk]);while(buffer.length>=4){const length=buffer.readUInt32LE(0);if(length>8*1024*1024)return finish(new BridgeError('TOO_LARGE','桌面响应过大'));if(buffer.length<length+4)break;let response;try{response=JSON.parse(buffer.subarray(4,length+4))}catch{return finish(new BridgeError('INCOMPATIBLE','桌面返回无效数据'))}buffer=buffer.subarray(length+4);if(response.id===message.id)return finish(null,response)}});
 });}
const status=s=>typeof s==='string'?s:s?.type??'unknown';
const millis=n=>typeof n==='number'?(n<1e12?n*1000:n):0;
function orderPipes(pipes,preferredProfile){return pipes.filter(p=>!preferredProfile||p.profile?.toLowerCase()===preferredProfile.toLowerCase()).sort((a,b)=>Number(b.hasVisibleWindow===true)-Number(a.hasVisibleWindow===true)||Number(b.isDefault)-Number(a.isDefault)||a.pid-b.pid)}
function normalizeThreads(raw,limit=30){const seen=new Set(),threads=[];for(const [rows,pinned]of [[raw.pinnedThreads,true],[raw.threads,false]]){let added=0;for(const t of rows??[]){if(!pinned&&added>=limit)break;if(t.kind!=='codex'||(t.hostId&&t.hostId!=='local')||!UUID.test(t.id)||seen.has(t.id))continue;seen.add(t.id);const cwd=typeof t.cwd==='string'&&t.cwd.trim()?t.cwd:undefined;threads.push({id:t.id,title:t.title||'未命名会话',preview:t.preview??t.summary??'',status:status(t.status),updatedAt:millis(t.updatedAt),...(cwd!==undefined?{cwd}:{}),projectName:t.projectName??null,pinned});added++}}return{threads}}
function databaseLastUpdatedAt(row){const ms=row.updated_at_ms;if(typeof ms==='number'&&Number.isFinite(ms)&&ms>0)return ms;const seconds=row.updated_at;return typeof seconds==='number'&&Number.isFinite(seconds)&&seconds>0?seconds*1000:null}
function cursorKey(bridgeKey){if(typeof bridgeKey!=='string'||bridgeKey.length<16)throw new BridgeError('BAD_INPUT','分页签名密钥不可用');return crypto.createHmac('sha256',bridgeKey).update('codex-remote:threads-cursor:v1').digest()}
function encodeCursor(row,key){const body=Buffer.from(JSON.stringify({v:1,at:row.at,id:row.id})).toString('base64url');const sig=crypto.createHmac('sha256',key).update(body).digest('base64url');return body+'.'+sig}
function decodeCursor(value,key){if(typeof value!=='string'||value.length>4096)throw new BridgeError('BAD_INPUT','分页游标无效');const [body,sig,...rest]=value.split('.'),expected=body?crypto.createHmac('sha256',key).update(body).digest('base64url'):'';if(!body||!sig||rest.length||Buffer.byteLength(sig)!==Buffer.byteLength(expected)||!crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(expected)))throw new BridgeError('BAD_INPUT','分页游标无效');let row;try{row=JSON.parse(Buffer.from(body,'base64url').toString())}catch{throw new BridgeError('BAD_INPUT','分页游标无效')}if(row.v!==1||!Number.isSafeInteger(row.at)||!UUID.test(row.id??''))throw new BridgeError('BAD_INPUT','分页游标无效');return row}
function threadOrder(a,b){return b.sortAt-a.sortAt||(a.id===b.id?0:(a.id<b.id?1:-1))}
const {usageResult}=require('./usage.cjs');
const LOCAL_IMAGE_EXTENSIONS=new Set(['.png','.jpg','.jpeg','.webp','.gif']);
const FENCE=/^\s{0,3}(`{3,}|~{3,})(.*)$/;
const AGENT_IMAGE=/!\[([^\]]*)\]\((<[^>\r\n]+>|[^)\s]+)(?:\s+["'][^)]*["'])?\)/g;
function safeImageAlt(value){return String(value).replace(/[\x00-\x1f\x7f]/g,'').replace(/[a-z]:[\\/][^\s)\]]*/gi,'[本机路径]').slice(0,120)}
function localFileTarget(value){
 let target=String(value??'').trim();
 if(target.startsWith('<')&&target.endsWith('>'))target=target.slice(1,-1);
 target=target.replace(/^file:\/\//i,'');
 if(/^\/[a-z]:[\\/]/i.test(target))target=target.slice(1);
 const match=/^([a-z]:[\\/].*?)(?::\d+(?::\d+)?)?(?:#L\d+(?:-L?\d+)?)?$/i.exec(target);
 return match?path.win32.normalize(match[1]):null;
}
function localPathKey(value){try{return path.win32.normalize(value).toLowerCase()}catch{return String(value).toLowerCase()}}
const VISUALIZE_REFERENCE=/^\s*visualize(\{.*\})\s*$/;
function normalizeAgentContent(text,threadId,registerImage,registerVisualization,registerAttachment=()=>null){
 const images=[],seen=new Set(),segments=[],output=[],lines=String(text??'').split('\n');let fence=null,hasVisualization=false;
 const addText=value=>{if(!value)return;const last=segments.at(-1);if(last?.type==='text')last.text+=value;else segments.push({type:'text',text:value})};
 for(let lineIndex=0;lineIndex<lines.length;lineIndex++){
  const line=lines[lineIndex],fenceMatch=FENCE.exec(line);let normalized=line;
  if(fenceMatch){const marker=fenceMatch[1];if(fence===null)fence=marker;else if(marker[0]===fence[0]&&marker.length>=fence.length&&fenceMatch[2].trim()==='')fence=null;addText(line);}
  else if(fence===null){
   const referenceMatch=VISUALIZE_REFERENCE.exec(line);
   if(referenceMatch){
    let reference=null;try{reference=JSON.parse(referenceMatch[1])}catch{}
    if(typeof reference?.path==='string'){
     const visualization=registerVisualization(threadId,reference.path),available=typeof visualization?.visualizationId==='string';
     const title=available&&typeof visualization.title==='string'?visualization.title:'可视化内容不可用';
     segments.push({type:'visualization',title,mime:visualization?.mime??'text/html',size:Number.isInteger(visualization?.size)?visualization.size:null,...(available?{visualizationId:visualization.visualizationId}:{unavailable:true})});
     hasVisualization=true;normalized=available?`[可视化预览：${title}]`:'[可视化内容不可用]';
    }else addText(line);
   }else{
    const chunks=[];let cursor=0,imageMatch;AGENT_IMAGE.lastIndex=0;
    while((imageMatch=AGENT_IMAGE.exec(line))!==null){
     const rawPath=imageMatch[2].startsWith('<')&&imageMatch[2].endsWith('>')?imageMatch[2].slice(1,-1):imageMatch[2];
     if(!/^[a-z]:[\\/]/i.test(rawPath)||!LOCAL_IMAGE_EXTENSIONS.has(path.win32.extname(rawPath).toLowerCase()))continue;
     const descriptor=registerImage(threadId,rawPath);if(!descriptor)continue;
     if(cursor<imageMatch.index){const before=line.slice(cursor,imageMatch.index);chunks.push({type:'text',text:before});addText(before)}
     const alt=safeImageAlt(imageMatch[1]);chunks.push({type:'image',image:descriptor,alt});segments.push({type:'image',image:descriptor,alt});
     if(!seen.has(descriptor.id)){seen.add(descriptor.id);images.push(descriptor)}
     chunks.push({type:'legacy',text:alt?`[图片：${alt}]`:'[图片]'});cursor=imageMatch.index+imageMatch[0].length;
    }
     if(chunks.some(chunk=>chunk.type==='image')){
     if(cursor<line.length){const tail=line.slice(cursor);chunks.push({type:'text',text:tail});addText(tail)}
     normalized=chunks.map(chunk=>chunk.type==='image'?'':chunk.text).join('');
    }else{
     const filePattern=/\[([^\]]+)\]\((<[^>\r\n]+>|[^)\s]+)(?:\s+["'][^)]*["'])?\)/g;let fileMatch,fileCursor=0,foundFile=false;filePattern.lastIndex=0;
     while((fileMatch=filePattern.exec(line))!==null){const target=localFileTarget(fileMatch[2]);if(!target)continue;const descriptor=registerAttachment(threadId,target);if(!descriptor)continue;foundFile=true;if(fileCursor<fileMatch.index){const before=line.slice(fileCursor,fileMatch.index);addText(before)}segments.push({type:'file',file:descriptor,label:fileMatch[1].slice(0,120)});fileCursor=fileMatch.index+fileMatch[0].length;}
     if(foundFile){normalized=line.replace(filePattern,(match,label,target)=>localFileTarget(target)?`[文件：${label}]`:match);if(fileCursor<line.length)addText(line.slice(fileCursor));}
     else addText(line);
    }
   }
  }else addText(line);
  output.push(normalized);if(lineIndex<lines.length-1)addText('\n');
 }
 return{text:output.join('\n'),images,segments,hasStructuredContent:images.length>0||hasVisualization||segments.some(x=>x.type==='file')};
}
function parseResponseAnnotations(source){
 const lines=String(source??'').replace(/\r\n/g,'\n').replace(/\r/g,'\n').split('\n');let open=-1,close=-1,request=-1,fence=null;
 for(let i=0;i<lines.length;i++){
  const marker=FENCE.exec(lines[i]);if(marker){if(fence===null)fence=marker[1];else if(marker[1][0]===fence[0]&&marker[1].length>=fence.length&&marker[2].trim()==='')fence=null;continue}if(fence!==null)continue;
  const line=lines[i].trim();if(open<0&&line==='<response-annotations>'){open=i;continue}if(open>=0&&close<0&&line==='</response-annotations>'){close=i;continue}if(close>=0&&/^#{1,3}\s*My request:\s*$/i.test(line)){request=i;break}
 }
 if(open<0||close<=open||request<=close)return null;
 const json=lines.slice(open+1,close).join('\n').trim();if(!json||json.length>64_000)return null;
 let raw;try{raw=JSON.parse(json)}catch{return null}if(!Array.isArray(raw)||raw.length<1||raw.length>32)return null;
 const annotations=[];
 for(const item of raw){const start=item?.source?.startOffset,end=item?.source?.endOffset;if(!item||typeof item.text!=='string'||!item.text.trim()||item.text.length>2000||typeof item.annotation!=='string'||!item.annotation.trim()||item.annotation.length>4000||typeof item.source?.messageId!=='string'||!item.source.messageId||item.source.messageId.length>256||!Number.isSafeInteger(start)||start<0||!Number.isSafeInteger(end)||end<start)return null;annotations.push({selectedText:item.text,comment:item.annotation})}
 return{annotations,request:lines.slice(request+1).join('\n').trim()};
}
function normalizeUserContent(text,threadId,registerAttachment,excludedImagePaths=new Set()){
 const envelope=parseResponseAnnotations(text);
 if(envelope){const body=normalizeUserContentPlain(envelope.request,threadId,registerAttachment,excludedImagePaths),bodySegments=body.segments.length?body.segments:(body.text?[{type:'text',text:body.text}]:[]);return{text:body.text,segments:[...envelope.annotations.map(annotation=>({type:'annotation',...annotation})),...bodySegments]}}
 return normalizeUserContentPlain(text,threadId,registerAttachment,excludedImagePaths);
}
function normalizeUserContentPlain(text,threadId,registerAttachment,excludedImagePaths=new Set()){
 const isImageAttachment=file=>excludedImagePaths.has(localPathKey(file));
 const source=String(text??''),lines=source.split('\n');let start=-1,request=-1;
 for(let i=0;i<Math.min(lines.length,20);i++){if(/^\s*#\s*Files mentioned by the user:\s*$/i.test(lines[i])){start=i;break}}
 if(start>=0){for(let i=start+1;i<lines.length;i++)if(/^\s*#{1,3}\s*My request:\s*$/i.test(lines[i])){request=i;break}}
 const refs=[];let imageRefs=0,unresolvedRefs=false;if(start>=0&&request>start){for(let i=start+1;i<request;i++){const m=/^\s*#{1,3}\s*([^:]{1,255}):\s*(.+?)\s*$/.exec(lines[i]);if(!m)continue;if(isImageAttachment(m[2])){imageRefs++;continue}const file=registerAttachment(threadId,m[2]);if(file)refs.push({type:'file',file,label:m[1].trim().slice(0,120)});else unresolvedRefs=true}if(refs.length||(imageRefs>0&&!unresolvedRefs)){const body=lines.slice(request+1).join('\n').trim();return{text:body,segments:[...(body?[{type:'text',text:body}]:[]),...refs]}}}
 const link=/\[([^\]]+)\]\((<[^>\r\n]+>|[^)\s]+)\)/g;let match,cursor=0,segments=[],display='';
 while((match=link.exec(source))!==null){const target=localFileTarget(match[2]);if(!target||isImageAttachment(target))continue;const file=registerAttachment(threadId,target);if(!file)continue;const prefix=source.slice(cursor,match.index);display+=prefix;segments.push({type:'text',text:prefix});segments.push({type:'file',file,label:match[1].slice(0,120)});display+=`[文件：${match[1]}]`;cursor=match.index+match[0].length}
 if(!segments.some(s=>s.type==='file'))return{text:source,segments:[]};const tail=source.slice(cursor);display+=tail;segments.push({type:'text',text:tail});return{text:display,segments};
}
function parseAssistantQuestionnaire(source,{allowLabelHeadings=false,requireAcknowledgement=true,allowSingleQuestion=false}={}){
 const lines=String(source??'').replace(/\r\n?/g,'\n').split('\n').map(line=>line.trim()).filter(Boolean);
 if(lines.length<(allowSingleQuestion?2:5)||lines.length>100)return null;
 const acknowledgement=lines.at(-1);
 const hasAcknowledgement=/(?:等你回答|等你回复|回答后再继续|回复后再继续|请一次回答这(?:三个|3个|些)问题)/.test(acknowledgement)&&acknowledgement.length<=180;
 if(requireAcknowledgement&&!hasAcknowledgement)return null;
 const body=hasAcknowledgement?lines.slice(0,-1):lines,questions=[];let i=0;
 while(i<body.length){
  const title=body[i++];if((!/[？?]$/.test(title)&&!allowLabelHeadings)||title.length>500)return null;
  const options=[];
  while(i<body.length){const match=/^[-*•]\s+(.+)$/.exec(body[i]);if(!match)break;const option=match[1].trim();if(option.length>300)return null;options.push(option);i++}
  if(options.length===0||options.length>12)return null;
  questions.push({title,question:title,options});if(questions.length>8)return null;
 }
 return questions.length>=(allowSingleQuestion?1:2)?questions:null;
}
function neighboringAssistantMessage(items,index,direction){for(let i=index+direction;i>=0&&i<items.length;i+=direction){const item=items[i];if(item?.type==='reasoning')continue;return item?.type==='agentMessage'?item:null}return null}
function isQuestionAcknowledgement(source){return/(?:等你回答|等你回复|回答后再继续|回复后再继续|请一次回答这(?:三个|3个|些)问题)/.test(String(source??''))}
function normalizeHistory(raw,{registerImage=()=>null,registerVisualization=()=>({unavailable:true}),registerAttachment=()=>null}={}){const t=raw.thread;if(!t)throw new BridgeError('NOT_FOUND','没有找到此会话');const cwd=typeof t.cwd==='string'&&t.cwd.trim()?t.cwd:undefined;return{id:t.id,title:t.title??t.name??'未命名会话',status:status(t.status),...(cwd!==undefined?{cwd}:{}),turns:[...(raw.turns??[])].reverse().map(turn=>({id:turn.id,status:status(turn.status),items:(turn.items??[]).map((item,itemIndex,allItems)=>{
 if(item.type==='agentMessage'){
  const text=item.text??'',itemId=String(item.id??''),nativeQuestionCall=/^call_[A-Za-z0-9_-]{8,}$/.test(itemId);
  const next=neighboringAssistantMessage(allItems,itemIndex,1),nextIsWait=next?.phase==='final_answer'&&isQuestionAcknowledgement(next.text);
  let questions=null;
  if(item.phase==='final_answer'){
   questions=parseAssistantQuestionnaire(text,nativeQuestionCall?{allowLabelHeadings:true,requireAcknowledgement:false,allowSingleQuestion:true}:undefined);
   if(!questions&&nextIsWait)questions=parseAssistantQuestionnaire(`${text}\n${next.text}`,nativeQuestionCall?{allowLabelHeadings:true,allowSingleQuestion:true}:{allowSingleQuestion:true});
  }
  if(questions){
   const callId=nativeQuestionCall?itemId:`text-question:${String(turn.id??'turn')}:${itemId||itemIndex}`.slice(0,160);
   return{type:'request_user_input_async',role:'assistant',id:`question:${callId}`,text:'需要你回答以下问题',callId,questions,phase:'question',source:'assistant_question_list'}
  }
  const previous=neighboringAssistantMessage(allItems,itemIndex,-1);
  const previousNativeQuestion=previous?.phase==='final_answer'&&/^call_[A-Za-z0-9_-]{8,}$/.test(String(previous.id??''))
    ?parseAssistantQuestionnaire(previous.text,{allowLabelHeadings:true,requireAcknowledgement:false,allowSingleQuestion:true}):null;
  const combinedAcknowledgement=previous?.phase==='final_answer'&&isQuestionAcknowledgement(text)
    &&parseAssistantQuestionnaire(`${previous.text??''}\n${text}`,{allowSingleQuestion:true});
  const redundantNativeAcknowledgement=!!previousNativeQuestion&&/一次回答这(?:三个|3个|些)问题/.test(text);
  if(combinedAcknowledgement||redundantNativeAcknowledgement)return null;
  const normalized=normalizeAgentContent(text,t.id,registerImage,registerVisualization,registerAttachment);
  return{type:item.type,role:'assistant',text:normalized.text,...(normalized.images.length?{images:normalized.images}:{}),...(normalized.hasStructuredContent?{segments:normalized.segments}:{}),phase:item.phase??null}
 }
 if(item.type==='userMessage'){
  const content=item.content??[],images=[],segments=[],registeredImages=new Map(),imageMarkers=new Map(),nonce=crypto.randomUUID().replace(/-/g,'');
  for(const part of content)if(part?.type==='localImage'&&typeof part.path==='string'){const key=localPathKey(part.path);if(!registeredImages.has(key)){const image=registerImage(t.id,part.path);if(image)registeredImages.set(key,image)}}
  const imagePaths=new Set(registeredImages.keys());let source='',blockIndex=0,seenText=false;
  for(const part of content){
   if(part?.type==='text'&&typeof part.text==='string'){if(seenText)source+='\n';source+=part.text;blockIndex++;seenText=true}
   else if(part?.type==='localImage'&&typeof part.path==='string'){
    const image=registeredImages.get(localPathKey(part.path));if(!image)continue;
    const marker=`\uE000CRIMAGE${nonce}${blockIndex++}\uE001`;imageMarkers.set(marker,image);source+=marker;
   }
  }
  const normalized=normalizeUserContent(source,t.id,registerAttachment,imagePaths),normalizedSegments=normalized.segments.length?normalized.segments:(normalized.text?[{type:'text',text:normalized.text}]:[]),emittedImages=new Set();
  const appendNormalized=segment=>{
   if(segment.type!=='text'){segments.push(segment);return}
   let cursor=0;
   for(const [marker,image]of imageMarkers){let at=segment.text.indexOf(marker,cursor);while(at>=0){if(at>cursor){let value=segment.text.slice(cursor,at);if(value.endsWith('\n'))value=value.slice(0,-1);if(value)segments.push({type:'text',text:value})}segments.push({type:'image',image,alt:image.name??'图片'});images.push(image);emittedImages.add(marker);cursor=at+marker.length;if(segment.text[cursor]==='\n')cursor++;at=segment.text.indexOf(marker,cursor)}}
   if(cursor<segment.text.length)segments.push({type:'text',text:segment.text.slice(cursor)});
  };
  for(const segment of normalizedSegments)appendNormalized(segment);
  for(const [marker,image]of imageMarkers)if(!emittedImages.has(marker)){segments.push({type:'image',image,alt:image.name??'图片'});images.push(image)}
  return{type:item.type,role:'user',text:segments.filter(c=>c.type==='text').map(c=>c.text).join('\n'),...(images.length||segments.some(x=>x.type==='file'||x.type==='annotation')?{images,segments}:{}),phase:null}
 }
 if(['functionCall','function_call'].includes(item.type)&&item.name==='request_user_input_async'){
  let args=item.arguments??{};if(typeof args==='string'){try{args=JSON.parse(args)}catch{args={}}}
  const questions=Array.isArray(args.questions)?args.questions.filter(q=>q&&typeof q==='object'&&typeof (q.title??q.question)==='string'&&Array.isArray(q.options??[])).slice(0,8).map(q=>({title:String(q.title??q.question).slice(0,500),...(typeof q.question==='string'?{question:q.question.slice(0,1000)}:{}),options:(Array.isArray(q.options)?q.options:[]).filter(x=>typeof x==='string').slice(0,12).map(x=>x.slice(0,300))})):[];
  if(questions.length){const callId=String(item.call_id??item.callId??'').slice(0,160);return{type:'request_user_input_async',role:'assistant',id:callId?`question:${callId}`:undefined,text:'需要你回答以下问题',callId,questions,phase:'question'};}
 }
 if(['functionCallOutput','function_call_output'].includes(item.type)&&['create_thread','send_message_to_thread'].includes(item.name))return null;
 return{type:item.type,role:'tool',text:item.title??item.name??item.type??'工具执行',phase:null};
 }).filter(Boolean)})),hasMore:raw.page?.hasMore??false,nextCursor:raw.page?.nextCursor??null}}
function projectDisplayName(project,id,projectPath){const label=[project.label,project.name,project.title].find(value=>typeof value==='string'&&value.trim());if(label)return label.trim();const finalPath=typeof projectPath==='string'?projectPath.split(/[\\/]/).filter(Boolean).at(-1):null;return finalPath||`未命名项目 · ${String(id).slice(-8)}`}
class Desktop{
 constructor(config={}, {backgroundDiscovery=true}={}){this.backgroundDiscovery=backgroundDiscovery;this.config=config;this.pipes=[];this.lastDiscovery=0;this.discoveryTask=null;this.discoveryTimer=null;this.discoveryRevision=0;this.discoveryRetryAt=0;this.closed=false;this.rpcControllers=new Set();this.clock=()=>Date.now();this.ownerCache=new Map();this.historyLimitCache=new Map();this.contextId=config.contextThreadId??null;this.turnId=crypto.randomUUID();this.lastError=null;this.lastTurns=new Map();this.modelCatalog=config.modelCatalog??createModelCatalog({provider:config.modelCatalogProvider??(()=>this.nativeCatalog())});this.usageCache=null;this.usageCacheAt=0;this.statusCache=new Map();this.statusBatchOffset=0;this.cursorSecret=null;this.modelCatalogCache=null;this.modelCatalogCacheAt=0;this.waitThreadsBackoffUntil=0;this.mediaMap=new Map();this.visualizationMap=new Map();this.attachmentMap=new Map();}
 signingKey(){return this.cursorSecret??(this.cursorSecret=cursorKey(this.config.bridgeKey))}
 db(){const {DatabaseSync}=require('node:sqlite');return new DatabaseSync(path.join(this.config.desktopCodexHome??path.join(os.homedir(),'.codex'),'state_5.sqlite'),{readOnly:true})}
 async threadPage(args={}){
  const limit=Math.max(1,Math.min(Number.isInteger(args.limit)?args.limit:30,50)),key=this.signingKey(),anchor=args.cursor?decodeCursor(args.cursor,key):null;
  const pipe=await this.primary(),raw=await this.tool(pipe,'list_threads',{limit:50}),live=normalizeThreads(raw,50).threads;
  // pinnedThreads 本身是完整目录；只有普通会话受桌面 limit 限制，不能再截断置顶元数据。
  const pinnedIds=new Set(live.filter(t=>t.pinned).map(t=>t.id)),pinnedAuthoritative=Array.isArray(raw.pinnedThreads);
  const db=this.db(),databaseRows=new Map(),byId=new Map();
  const orderExpr='COALESCE(recency_at_ms,updated_at_ms,created_at_ms,0)';
  const visible="(thread_source IS NULL OR thread_source NOT IN ('subagent','composer_link')) AND CASE WHEN json_valid(source) THEN json_type(source,'$.subagent') IS NULL ELSE 1 END";
  try{
   const availableColumns=new Set(db.prepare('PRAGMA table_info(threads)').all().map(column=>column.name));
   const optionalColumns=['cwd','updated_at_ms','updated_at'].filter(name=>availableColumns.has(name));
   const where=`archived=0 AND ${visible}`;
   const cols=`id,title,preview,${orderExpr} AS order_at,is_pinned,project_id${optionalColumns.length?`,${optionalColumns.join(',')}`:''},CASE WHEN ${where} THEN 1 ELSE 0 END AS catalog_visible`;
   const select=`SELECT ${cols} FROM threads`;
   const sql=`${select} WHERE ${where}${anchor?` AND (${orderExpr} < ? OR (${orderExpr} = ? AND id < ?))`:''} ORDER BY ${orderExpr} DESC,id DESC LIMIT ?`;
   const stmt=db.prepare(sql),rows=anchor?stmt.all(anchor.at,anchor.at,anchor.id,limit+1):stmt.all(limit+1);
   const normalizeDatabaseRow=t=>({id:t.id,title:t.title||'未命名会话',preview:t.preview??'',status:'unknown',updatedAt:Number(t.order_at??0),sortAt:Number(t.order_at??0),
    ...(typeof t.cwd==='string'&&t.cwd.trim()?{cwd:t.cwd}:{}),lastUpdatedAt:databaseLastUpdatedAt(t),projectName:null,
    pinned:pinnedAuthoritative?pinnedIds.has(t.id):!!t.is_pinned});
   for(const row of rows){databaseRows.set(row.id,row);if(UUID.test(row.id))byId.set(row.id,normalizeDatabaseRow(row))}
   // 补查 live 在当前页之外的 DB 状态，既保留真实 recency，也避免把已归档/隐藏的会话重新加入。
   const missingIds=live.filter(t=>!databaseRows.has(t.id)).map(t=>t.id);
   for(let offset=0;offset<missingIds.length;offset+=200){
    const ids=missingIds.slice(offset,offset+200);
    for(const row of db.prepare(`${select} WHERE id IN (${ids.map(()=>'?').join(',')})`).all(...ids))databaseRows.set(row.id,row);
   }
   for(const thread of live){
    const row=databaseRows.get(thread.id);
    if(row&&!row.catalog_visible)continue;
    const prior=row?normalizeDatabaseRow(row):null;
    // live 已经过本地 Codex/UUID 校验；不能依赖规范化时已移除的 kind 字段判断能否加入。
    byId.set(thread.id,{...prior,...thread,
     ...(typeof thread.cwd==='string'&&thread.cwd.trim()?{cwd:thread.cwd}:prior?.cwd!==undefined?{cwd:prior.cwd}:{}),
     lastUpdatedAt:prior?.lastUpdatedAt??null,updatedAt:prior?.updatedAt??thread.updatedAt,sortAt:prior?.sortAt??thread.updatedAt});
   }
  }finally{db.close()}
  const all=[...byId.values()].filter(t=>!anchor||t.sortAt<anchor.at||(t.sortAt===anchor.at&&t.id<anchor.id)).sort(threadOrder);
  const page=all.slice(0,limit),hasMore=all.length>limit;
  // 桌面普通目录最多 50 条。旧页只补当前页的原生标题，不把 DB 的首条提示词当成桌面标题。
  const liveIds=new Set(live.map(thread=>thread.id)),missingTitles=page.filter(thread=>!liveIds.has(thread.id));
  const deadline=Date.now()+8000;let nextTitle=0,metadataError=null;
  await Promise.all(Array.from({length:Math.min(4,missingTitles.length)},async()=>{
   while(nextTitle<missingTitles.length&&!metadataError){
    const thread=missingTitles[nextTitle++];
    try{
     const remaining=deadline-Date.now();
     if(remaining<=0)throw new BridgeError('TIMEOUT','会话标题同步超时，请刷新重试');
     const data=await this.tool(pipe,'read_thread',{threadId:thread.id,turnLimit:1,includeOutputs:false,maxOutputCharsPerItem:0},Math.min(3000,remaining));
     const metadata=data?.thread;
     if(metadata?.id!==thread.id||metadata.kind!=='codex'||metadata.hostId!=='local'||typeof metadata.title!=='string'){
      throw new BridgeError('INCOMPATIBLE','桌面会话标题不可用，请刷新重试');
     }
     thread.title=metadata.title||'未命名会话';
    }catch(error){metadataError??=error}
   }
  }));
  if(metadataError)throw metadataError;
  return{threads:page.map(({sortAt,...t})=>t),hasMore,nextCursor:hasMore?encodeCursor({at:page.at(-1).sortAt,id:page.at(-1).id},key):null,source:'codex-state-db+desktop-list',fetchedAt:Date.now()};
 }
 async statusPage(args={}){
  const ids=args.threadIds??[];
  if(!Array.isArray(ids)||ids.length<1||ids.length>50||new Set(ids).size!==ids.length||ids.some(id=>!UUID.test(id)))throw new BridgeError('BAD_INPUT','会话状态查询参数无效');
  const now=Date.now(),pipe=await this.primary(),live=normalizeThreads(await this.tool(pipe,'list_threads',{limit:50}),50).threads,byId=new Map(live.map(t=>[t.id,t])),transitions=[];
  for(const id of ids){
   const t=byId.get(id),old=this.statusCache.get(id);
   if(t){const sameVersion=old&&old.value.updatedAt===t.updatedAt,transitioned=old?.value.status==='active'&&t.status!=='active';if(transitioned)transitions.push(id);this.statusCache.set(id,{at:now,turnReadAt:sameVersion?old.turnReadAt:0,value:{id,status:t.status,turnStatus:sameVersion?old.value.turnStatus:null,updatedAt:t.updatedAt||null}})}
   else if(!old)this.statusCache.set(id,{at:now,turnReadAt:0,value:{id,status:'unknown',turnStatus:null,updatedAt:null}});
   else if(now-old.at>30000){old.value={id,status:'unknown',turnStatus:null,updatedAt:null};old.turnReadAt=0;old.at=now}
  }
  const eligible=ids.filter(id=>{const c=this.statusCache.get(id);return !c.turnReadAt||now-c.turnReadAt>=15000||transitions.includes(id)}),active=eligible.filter(id=>byId.get(id)?.status==='active'||this.statusCache.get(id)?.value.status==='active'),priority=[...new Set([...active,...transitions])],background=eligible.filter(id=>!priority.includes(id));
  if(background.length){const offset=this.statusBatchOffset%background.length;background.push(...background.splice(0,offset));this.statusBatchOffset=(this.statusBatchOffset+4)%Math.max(1,background.length)}
  const selected=[...priority,...background].slice(0,4),results=selected.length?await Promise.allSettled(selected.map(threadId=>this.tool(pipe,'read_thread',{threadId,turnLimit:1,includeOutputs:false,maxOutputCharsPerItem:0}))):[];
  for(let i=0;i<selected.length;i++){
   const id=selected[i],cached=this.statusCache.get(id);cached.turnReadAt=now;
   if(results[i].status!=='fulfilled'){cached.value={id,status:'unknown',turnStatus:null,updatedAt:null};cached.at=now;continue}
   const data=results[i].value,thread=data.thread,turn=data.turns?.[0];if(!thread||thread.kind!=='codex'||thread.hostId!=='local'){cached.value={id,status:'unknown',turnStatus:null,updatedAt:null};cached.at=now;continue}cached.value={id,status:status(thread.status),turnStatus:turn?status(turn.status):null,updatedAt:millis(thread.updatedAt)||null};cached.at=now;
  }
  for(const id of ids){const c=this.statusCache.get(id);if(c){this.statusCache.delete(id);this.statusCache.set(id,c)}}
  while(this.statusCache.size>1000)this.statusCache.delete(this.statusCache.keys().next().value);
  const rows=ids.map(id=>{const c=this.statusCache.get(id);return c&&now-c.at<=30000?c.value:{id,status:'unknown',turnStatus:null,updatedAt:null}});
  return{threads:rows,fetchedAt:now};
 }
 async usage(){const now=Date.now();if(this.usageCache&&now-this.usageCacheAt<10000)return{...this.usageCache,stale:false};try{const value=usageResult(await this.tool(await this.primary(),'get_usage_limits',{}),now);this.usageCache=value;this.usageCacheAt=now;return value}catch(e){if(this.usageCache)return{...this.usageCache,stale:true};throw new BridgeError('USAGE_UNAVAILABLE','暂时无法读取用量')}}
 async discoverPipes(){
  const names=fs.readdirSync('\\\\.\\pipe\\').filter(n=>/^codex-app-tools-[a-f0-9-]+$/i.test(n)).slice(0,12);
  if(!names.length)return[];
  return new Promise((resolve,reject)=>{const child=execFile('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',path.join(__dirname,'discover-pipes.ps1')],{windowsHide:true,timeout:12000,maxBuffer:65536},(error,stdout)=>{if(error)return reject(new BridgeError('DISCOVERY_FAILED','无法核对 Codex 桌面进程'));try{resolve(JSON.parse(stdout.replace(/^\uFEFF/,'')))}catch{reject(new BridgeError('DISCOVERY_FAILED','桌面发现结果无效'))}});child.stdin.end(JSON.stringify(names));});
 }
 scheduleDiscovery(){
  if(this.closed||!this.backgroundDiscovery||this.discoveryTimer)return;
  this.discoveryTimer=setTimeout(()=>{this.discoveryTimer=null;void this.refreshDiscovery().catch(()=>{});},DISCOVERY_REFRESH_MS);
  this.discoveryTimer.unref?.();
 }
 refreshDiscovery(){
  if(this.closed)return Promise.reject(new BridgeError('CLOSED','桌面连接已关闭'));
  if(this.discoveryTask){
   if(this.discoveryTaskRevision===this.discoveryRevision)return this.discoveryTask;
   // 旧一代发现仍拥有自己的 PowerShell；等其结束再启动新一代，避免断管恢复重叠扫描。
   return this.discoveryTask.catch(()=>{}).then(()=>this.refreshDiscovery());
  }
  const revision=this.discoveryRevision;
  const task=Promise.resolve().then(()=>this.closed||revision!==this.discoveryRevision?[]:this.discoverPipes()).then(pipes=>{
   if(this.closed||revision!==this.discoveryRevision)return[];
   const verified=orderPipes(pipes,this.config.preferredProfile),keys=new Set(verified.map(pipeKey));
   this.pipes=verified;this.lastDiscovery=this.clock();this.discoveryRetryAt=0;
   for(const [id,owner]of this.ownerCache)if(!keys.has(owner.key))this.ownerCache.delete(id);
   for(const [key,hint]of this.historyLimitCache)if(!keys.has(hint.pipeKey))this.historyLimitCache.delete(key);
   return verified;
  }).catch(error=>{if(revision===this.discoveryRevision)this.discoveryRetryAt=this.clock()+DISCOVERY_REFRESH_MS;throw error;}).finally(()=>{
   if(this.discoveryTask===task){this.discoveryTask=null;this.scheduleDiscovery();}
  });
  this.discoveryTaskRevision=revision;this.discoveryTask=task;return task;
 }
 async discover(force=false){
  if(this.closed)throw new BridgeError('CLOSED','桌面连接已关闭');
  const age=this.clock()-this.lastDiscovery;
  // 已核验的快照在短时间内可直接使用；刷新失败最多保留一分钟，不能永久信任旧归属。
  if(!force&&this.pipes.length&&age<DISCOVERY_MAX_AGE_MS){
   if(age>=DISCOVERY_REFRESH_MS&&this.clock()>=this.discoveryRetryAt)void this.refreshDiscovery().catch(()=>{});
   return this.pipes;
  }
  return this.refreshDiscovery();
 }
 invalidateDiscovery(){
  this.pipes=[];this.lastDiscovery=0;this.discoveryRevision++;
  clearTimeout(this.discoveryTimer);this.discoveryTimer=null;this.ownerCache.clear();this.historyLimitCache.clear();
 }
 close(){
  this.closed=true;for(const controller of this.rpcControllers)controller.abort();this.invalidateDiscovery();
 }
 remember(cache,key,value){
  cache.delete(key);cache.set(key,value);
  while(cache.size>CACHE_ENTRIES)cache.delete(cache.keys().next().value);
 }
 async withReadRoute(threadId,action){
  for(let attempt=0;attempt<2;attempt++)try{return await action(await this.route(threadId));}catch(error){
   if(attempt||!recoverableReadError(error))throw error;
   this.invalidateDiscovery();await this.discover(true);
  }
 }
 context(){
  if(this.contextId)return this.contextId;
  const db=this.db();
  try{const row=db.prepare("SELECT id FROM threads WHERE archived=0 AND (name LIKE 'Codex Remote%' OR title LIKE 'Codex Remote%' OR name LIKE 'LOCAL-%PROBE%' OR title LIKE 'LOCAL-%PROBE%') ORDER BY updated_at DESC LIMIT 1").get();if(!row||!UUID.test(row.id))throw new BridgeError('CONTEXT_REQUIRED','请先创建名为 Codex Remote 连接上下文的专用会话');this.contextId=row.id;return row.id}finally{db.close()}
 }
 async trackedRpc(pipe,message,timeoutMs=20000){
  if(this.closed)throw new BridgeError('CLOSED','桌面连接已关闭，请先核对会话状态');
  const controller=new AbortController();this.rpcControllers.add(controller);
  try{return await rpc(pipe,message,timeoutMs,controller.signal)}finally{this.rpcControllers.delete(controller)}
 }
 async tool(pipe,tool,args,timeoutMs=20000){return parseToolResponse(await this.trackedRpc(pipe,{jsonrpc:'2.0',id:crypto.randomUUID(),method:'tools/call',params:{callerSource:'codex',hostId:'local',callId:crypto.randomUUID(),namespace:'codex_app',threadId:this.context(),turnId:this.turnId,tool,arguments:args}},timeoutMs));}
 async progressSnapshot(pipe,threadId){const r=await this.tool(pipe,'read_thread',{threadId,turnLimit:1,includeOutputs:true,maxOutputCharsPerItem:2000});const turn=r.turns?.[0],items=turn?.items??[],assistant=[...items].reverse().find(item=>item.type==='agentMessage'),text=assistant?.text??'';return{id:threadId,status:status(r.thread?.status),turnId:turn?.id??null,turnStatus:turn?status(turn.status):null,text,phase:assistant?.phase??null,cursor:r.page?.nextCursor??null,textTruncated:!!(assistant?.truncated||assistant?.textTruncated||text.length>=2000)}}
 async primary(writing=false){const pipes=await this.discover(writing&&this.clock()-this.lastDiscovery>=DISCOVERY_REFRESH_MS);if(!pipes.length)throw new BridgeError('DESKTOP_OFFLINE','请先打开 Codex 桌面程序');return pipes[0]}
 async supportsActivation(pipe=this.pipes[0]){
  if(!pipe)return false;this.activationSupport??=new Map();const key=pipeKey(pipe);
  if(this.activationSupport.has(key))return this.activationSupport.get(key);
  try{const result=await this.trackedRpc(pipe,{jsonrpc:'2.0',id:crypto.randomUUID(),method:'tools/list',params:{threadStartKind:'all'}},5000);
   if(!Array.isArray(result.result?.tools))return false;
   const supported=result.result.tools.some(tool=>tool?.name==='navigate_to_codex_page');this.remember(this.activationSupport,key,supported);return supported;
  }catch{return false;}
 }
 async nativeCatalog(){const now=Date.now();if(this.modelCatalogCache&&now-this.modelCatalogCacheAt<60000)return this.modelCatalogCache;const pipe=await this.primary(),response=await this.trackedRpc(pipe,{jsonrpc:'2.0',id:crypto.randomUUID(),method:'tools/list',params:{threadStartKind:'all'}});const {parseToolCatalog}=require('./catalog.cjs');this.modelCatalogCache=parseToolCatalog(response,{fetchedAt:now});this.modelCatalogCacheAt=now;return this.modelCatalogCache}
 async registerThread(pipe,threadId,projectId=null){
  if(!UUID.test(threadId??''))throw new BridgeError('BAD_INPUT','会话ID无效');
  if(projectId!==null&&(typeof projectId!=='string'||!projectId))throw new BridgeError('BAD_INPUT','项目ID无效');
  const args={threadId,source:'codex',hostId:'local',projectId};
  for(let attempt=0;attempt<2;attempt++)try{await this.tool(pipe,'move_thread_to_project',args);return{desktopRegistration:'ready'}}catch{}
  return{desktopRegistration:'pending',desktopRegistrationWarning:'会话已创建，但桌面归属登记未确认；可用同一会话ID稍后重试。'}
 }
 async route(threadId,writing=false,allowCached=!writing){
  // 写前沿用原先十秒发现新鲜度；后台刷新失败时不能使用一分钟的读快照放行写入。
  const pipes=await this.discover((writing||!allowCached)&&this.clock()-this.lastDiscovery>=DISCOVERY_REFRESH_MS);if(!pipes.length)throw new BridgeError('DESKTOP_OFFLINE','请先打开 Codex 桌面程序');
  const owner=this.ownerCache.get(threadId),cached=owner&&this.clock()-owner.at<OWNER_TTL_MS?pipes.find(pipe=>pipeKey(pipe)===owner.key):null;
  if(allowCached&&cached)return cached;
  this.ownerCache.delete(threadId);
  const candidates=[];let failure;
  for(const pipe of pipes){try{const data=await this.tool(pipe,'read_thread',{threadId,turnLimit:1,includeOutputs:false,maxOutputCharsPerItem:0});if(data.thread?.kind!=='codex'||data.thread?.hostId!=='local')throw new BridgeError('NOT_FOUND','仅支持本机 Codex 会话');candidates.push({pipe,state:status(data.thread.status),turnId:data.turns?.[0]?.id??null})}catch(e){failure=e}}
  const active=candidates.find(c=>c.state==='active');if(writing&&active)throw new BridgeError('BUSY','此会话正在运行，请等待完成后发送');
  const chosen=active??candidates.find(c=>c.state==='idle')??candidates[0];if(!chosen)throw failure??new BridgeError('NOT_FOUND','会话不可用');this.lastTurns.set(threadId,chosen.turnId);
  if(!writing)this.remember(this.ownerCache,threadId,{key:pipeKey(chosen.pipe),at:this.clock()});
  return chosen.pipe;
 }
 async historyPage(pipe,args){
  const requested=Math.max(1,Math.min(Number.isInteger(args.turnLimit)?args.turnLimit:10,10)),identity=pipeKey(pipe),key=JSON.stringify([identity,args.threadId]);
  let hint=this.historyLimitCache.get(key);
  if(hint&&this.clock()-hint.at>=HISTORY_LIMIT_TTL_MS){this.historyLimitCache.delete(key);hint=null;}
  const first=Math.min(requested,hint?.limit??requested),limits=[first,...[10,5,2,1].filter(n=>n<first)],readArgs=turnLimit=>({threadId:args.threadId,turnLimit,includeOutputs:true,maxOutputCharsPerItem:2000,...(args.cursor?{cursor:args.cursor}:{})});
  let raw,lastError,successfulLimit=first,oversized=false;
  for(const turnLimit of limits){try{raw=await this.tool(pipe,'read_thread',readArgs(turnLimit));successfulLimit=turnLimit;break}catch(error){if(error.code!=='RESPONSE_TOO_LARGE')throw error;oversized=true;lastError=error}}
  let omittedOutputs=false;
  if(!raw){try{raw=await this.tool(pipe,'read_thread',{...readArgs(1),includeOutputs:false});successfulLimit=1;omittedOutputs=true}catch(error){if(error.code!=='RESPONSE_TOO_LARGE')throw error;throw lastError??error}}
  const history=normalizeHistory(raw,{registerImage:(threadId,imagePath)=>registerHistoryImage(this.mediaMap,threadId,imagePath),registerVisualization:(threadId,file)=>registerHistoryVisualization(this.visualizationMap,threadId,file),registerAttachment:(threadId,file)=>registerAttachment(this.attachmentMap,threadId,file)});
  // 只记住原生超大响应确认的页容量；用户主动请求一回合不应缩小后续默认页。
  if(oversized)this.remember(this.historyLimitCache,key,{limit:successfulLimit,at:this.clock(),pipeKey:identity});
  if(omittedOutputs)history.notice='为显示超大记录，本页省略了工具输出。';
  return history;
 }
 async progressPage(pipe,args){
  if(Date.now()<this.waitThreadsBackoffUntil)return this.progressSnapshot(pipe,args.threadId);
  try{
   const r=await this.tool(pipe,'wait_threads',{targets:[{threadId:args.threadId,hostId:'local',...(args.cursor?{afterCursor:args.cursor}:{})}],timeoutMs:0},1500),p=r.polls?.[0];
   if(p?.thread)return{id:args.threadId,status:status(p.thread?.status),turnId:p.latestTurn?.id??null,turnStatus:p.latestTurn?.status??null,text:p.latestAssistantMessage?.text??'',phase:p.latestAssistantMessage?.phase??null,cursor:p.cursor??null,textTruncated:false};
   this.waitThreadsBackoffUntil=Date.now()+60*60*1000;
  }catch(error){if(recoverableReadError(error))throw error;this.waitThreadsBackoffUntil=Date.now()+(error.code==='TIMEOUT'?60000:60*60*1000)}
  return this.progressSnapshot(pipe,args.threadId);
 }
 async execute(operation,args={}){
  try{
   if(['read','send','progress','reconcile','media','visualization','attachment','activateThread'].includes(operation)&&!UUID.test(args.threadId??''))throw new BridgeError('BAD_INPUT','会话ID无效');
   if(operation==='activateThread'){
    const pipe=await this.route(args.threadId,false,false);
    if(!await this.supportsActivation(pipe))throw new BridgeError('UNSUPPORTED_CAPABILITY','当前桌面不提供打开会话入口，请更新 Codex。');
    await this.tool(pipe,'navigate_to_codex_page',{threadId:args.threadId});
    return {threadId:args.threadId,activated:true};
   }
   if(operation==='ping')return{pong:true,fetchedAt:Date.now()};
   if(operation==='threads')return await this.threadPage(args);
   if(operation==='statuses')return await this.statusPage(args);
   if(operation==='usage')return await this.usage();
   if(operation==='models')return await this.modelCatalog.get();
    if(operation==='projects'){const raw=await this.tool(await this.primary(),'list_projects',{});const rows=Array.isArray(raw)?raw:raw.projects??raw.localProjects??[];return{projects:rows.filter(p=>p.kind!=='remote'&&p.type!=='chatgpt'&&p.source!=='chatgpt').map(p=>{const id=p.id??p.projectId,projectPath=p.path??p.rootPaths?.[0]??null;return{id,name:projectDisplayName(p,id,projectPath),path:projectPath}}).filter(p=>p.id)}}
   if(operation==='reconcile'){const projectId=args.projectId??null;if(projectId!==null&&(typeof projectId!=='string'||!projectId))throw new BridgeError('BAD_INPUT','项目ID无效');const pipe=await this.route(args.threadId,false,false);return{threadId:args.threadId,...await this.registerThread(pipe,args.threadId,projectId)}}
   if(operation==='read'){
    if(args.questionIndex!==undefined&&typeof args.questionIndex!=='boolean')throw new BridgeError('BAD_INPUT','questionIndex必须是布尔值');
    if(args.questionIndex){
     if(args.cursor)throw new BridgeError('BAD_INPUT','完整提问索引不能指定分页游标');
     return await this.withReadRoute(args.threadId,pipe=>bridgeQuestionIndex(read=>this.tool(pipe,'read_thread',read),args.threadId,normalizeHistory));
    }
    return await this.withReadRoute(args.threadId,pipe=>this.historyPage(pipe,args));
   }
   if(operation==='media'){try{return await readHistoryImage(this.mediaMap,args.threadId,args.imageId)}catch(error){if(error instanceof MediaError)throw new BridgeError(error.code,error.message);throw error}}
   if(operation==='visualization'){try{return readHistoryVisualization(this.visualizationMap,args.threadId,args.visualizationId)}catch(error){if(error instanceof VisualizationError)throw new BridgeError(error.code,error.message);throw error}}
   if(operation==='attachment'){try{return readAttachmentChunk(this.attachmentMap,args.threadId,args.fileId,args.offset,args.length)}catch(error){if(error instanceof AttachmentError)throw new BridgeError(error.code,error.message);throw error}}
   if(operation==='progress')return await this.withReadRoute(args.threadId,pipe=>this.progressPage(pipe,args));
   if(['create','send'].includes(operation)){
    if(typeof args.prompt!=='string'||!args.prompt.trim()||args.prompt.length>16000)throw new BridgeError('BAD_INPUT','请输入1至16000字的消息');
    let override={};if(args.thinking!==undefined&&args.model===undefined)throw new BridgeError('INVALID_THINKING','自定义推理配置需要同时选择模型');if(args.model!==undefined||args.thinking!==undefined){const catalog=await this.modelCatalog.get(),model=catalog.models.find(m=>m.id===args.model);if(!model)throw new BridgeError('INVALID_MODEL','所选模型不可用');if(args.thinking!==undefined&&!model.reasoningEfforts.some(e=>e.value===args.thinking))throw new BridgeError('INVALID_THINKING','所选推理配置不适用于该模型');override={model:args.model,...(args.thinking!==undefined?{thinking:args.thinking}:{})}}
    if(operation==='create'){if(args.projectId!==undefined&&args.projectId!==null&&(typeof args.projectId!=='string'||!args.projectId))throw new BridgeError('BAD_INPUT','项目ID无效');const projectId=args.projectId??null,pipe=await this.primary(true),target=projectId?{type:'project',projectId,environment:{type:'local'}}:{type:'projectless'};const r=await this.tool(pipe,'create_thread',{target,prompt:args.prompt,...override,...(args.title?{title:args.title.slice(0,120)}:{})});if(!UUID.test(r.threadId??''))throw new BridgeError('UNCERTAIN','桌面可能已创建会话，请检查列表，勿重复提交');let turnId=null;try{turnId=(await this.tool(pipe,'read_thread',{threadId:r.threadId,turnLimit:1,includeOutputs:false,maxOutputCharsPerItem:0})).turns?.[0]?.id??null}catch{}const registration=await this.registerThread(pipe,r.threadId,projectId);return{threadId:r.threadId,...registration,_submission:{prompt:args.prompt,turnId,beforeTurnId:null}}}
    const pipe=await this.route(args.threadId,true),beforeTurnId=this.lastTurns.get(args.threadId)??null;
    const r=await this.tool(pipe,'send_message_to_thread',{threadId:args.threadId,hostId:'local',prompt:args.prompt,...override});let turnId=null;try{const latest=(await this.tool(pipe,'read_thread',{threadId:args.threadId,turnLimit:1,includeOutputs:false,maxOutputCharsPerItem:0})).turns?.[0]?.id;if(latest&&latest!==beforeTurnId)turnId=latest}catch{}return{threadId:r.threadId??args.threadId,_submission:{prompt:args.prompt,turnId,beforeTurnId}};
   }
   throw new BridgeError('BAD_INPUT','不支持的操作');
  }catch(e){this.lastError=e.message;if(['DISCONNECTED','DISCOVERY_FAILED'].includes(e.code))this.invalidateDiscovery();throw e;}
 }
 async getStatus({maxDiscoveryAgeMs=0}={}){try{const age=this.clock()-this.lastDiscovery;const cached=!this.closed&&this.pipes.length>0&&age>=0&&age<Math.min(Math.max(0,maxDiscoveryAgeMs),DISCOVERY_MAX_AGE_MS);if(!cached)await this.discover();if(this.pipes.length)this.context();return{connected:this.pipes.length>0,pid:this.pipes[0]?.pid??null,error:this.pipes.length?null:'Codex 桌面尚未打开'}}catch(e){return{connected:false,pid:this.pipes[0]?.pid??null,error:e.message}}}
}
module.exports={Desktop,BridgeError,rpc,parseToolResponse,normalizeThreads,normalizeHistory,parseResponseAnnotations,usageResult,cursorKey,encodeCursor,decodeCursor,orderPipes};

