'use strict';
const fs=require('node:fs');
const path=require('node:path');
const os=require('node:os');
const crypto=require('node:crypto');
const MAX_VISUALIZATION_BYTES=200_000;
const MAX_VISUALIZATION_ENTRIES=200;
const VISUALIZATION_TTL_MS=2*60*60*1000;
class VisualizationError extends Error{constructor(code,message){super(message);this.code=code}}

function isInside(root,file){const relative=path.relative(root,file);return relative!==''&&!relative.startsWith(`..${path.sep}`)&&relative!=='..'&&!path.isAbsolute(relative)}

function readVisualizationFragment(file,root=path.join(os.homedir(),'.codex','visualizations')){
 if(typeof file!=='string'||file.length>32768||path.extname(file).toLowerCase()!=='.html')return null;
 let rootReal,fileReal,fd;
 try{
  rootReal=fs.realpathSync(root);fileReal=fs.realpathSync(file);
  if(!isInside(rootReal,fileReal)||path.extname(fileReal).toLowerCase()!=='.html')return null;
  fd=fs.openSync(fileReal,'r');
  const before=fs.fstatSync(fd,{bigint:true});
  if(!before.isFile()||before.size>BigInt(MAX_VISUALIZATION_BYTES))return null;
  const checkedRoot=fs.realpathSync(root),checkedFile=fs.realpathSync(fileReal);
  if(checkedRoot!==rootReal||checkedFile!==fileReal||!isInside(checkedRoot,checkedFile))return null;
  const pathStat=fs.statSync(checkedFile,{bigint:true});
  if(!pathStat.isFile()||pathStat.dev!==before.dev||pathStat.ino!==before.ino
      ||pathStat.size!==before.size||pathStat.mtimeNs!==before.mtimeNs)return null;
  const buffer=Buffer.alloc(MAX_VISUALIZATION_BYTES+1);let length=0;
  while(length<buffer.length){const bytesRead=fs.readSync(fd,buffer,length,buffer.length-length,length);if(!bytesRead)break;length+=bytesRead}
  if(length>MAX_VISUALIZATION_BYTES)return null;
  const after=fs.fstatSync(fd,{bigint:true}),pathAfter=fs.realpathSync(fileReal),rootAfter=fs.realpathSync(root);
  if(rootAfter!==rootReal||pathAfter!==fileReal||!isInside(rootAfter,pathAfter)
      ||after.dev!==before.dev||after.ino!==before.ino||after.size!==before.size||after.mtimeNs!==before.mtimeNs
      ||length!==Number(before.size))return null;
  const bytes=buffer.subarray(0,length);
  const source=new TextDecoder('utf-8',{fatal:true}).decode(bytes);
  if(source.length>MAX_VISUALIZATION_BYTES)return null;
  return{title:path.basename(fileReal),source,size:length};
 }catch{return null}
 finally{if(fd!==undefined)try{fs.closeSync(fd)}catch{}}
}

function visualizationUuid(threadId,file,stat){const value=crypto.createHash('sha256').update(`${threadId}\0${file}\0${stat.dev}\0${stat.ino}\0${stat.size}\0${stat.mtimeNs}`).digest('hex');return`${value.slice(0,8)}-${value.slice(8,12)}-4${value.slice(13,16)}-${((parseInt(value[16],16)&3)|8).toString(16)}${value.slice(17,20)}-${value.slice(20,32)}`}
function registerHistoryVisualization(cache,threadId,file,now=Date.now(),root=path.join(os.homedir(),'.codex','visualizations')){
 const fragment=readVisualizationFragment(file,root);if(!fragment)return{unavailable:true,title:'可视化内容不可用',mime:'text/html',size:null};
 try{const canonical=fs.realpathSync(file),stat=fs.statSync(canonical,{bigint:true}),id=visualizationUuid(threadId,canonical,stat);cache.delete(id);cache.set(id,{threadId,path:canonical,root,dev:stat.dev.toString(),ino:stat.ino.toString(),size:stat.size.toString(),mtimeNs:stat.mtimeNs.toString(),createdAt:now});while(cache.size>MAX_VISUALIZATION_ENTRIES)cache.delete(cache.keys().next().value);return{visualizationId:id,title:fragment.title,mime:'text/html',size:fragment.size}}
 catch{return{unavailable:true,title:'可视化内容不可用',mime:'text/html',size:null}}
}
function readHistoryVisualization(cache,threadId,visualizationId,now=Date.now()){
 if(typeof visualizationId!=='string'||visualizationId.length>64)throw new VisualizationError('NOT_FOUND','可视化内容不可用');
 const entry=cache.get(visualizationId);
 if(!entry||entry.threadId!==threadId||now-entry.createdAt>VISUALIZATION_TTL_MS){if(entry&&now-entry.createdAt>VISUALIZATION_TTL_MS)cache.delete(visualizationId);throw new VisualizationError('NOT_FOUND','可视化内容不可用')}
 try{const before=fs.statSync(entry.path,{bigint:true});if(!before.isFile()||before.dev.toString()!==entry.dev||before.ino.toString()!==entry.ino||before.size.toString()!==entry.size||before.mtimeNs.toString()!==entry.mtimeNs)throw new VisualizationError('NOT_FOUND','可视化内容不可用');const fragment=readVisualizationFragment(entry.path,entry.root);const after=fs.statSync(entry.path,{bigint:true});if(!fragment||after.dev.toString()!==entry.dev||after.ino.toString()!==entry.ino||after.size.toString()!==entry.size||after.mtimeNs.toString()!==entry.mtimeNs)throw new VisualizationError('NOT_FOUND','可视化内容不可用');return{mime:'text/html',source:fragment.source}}
 catch(error){if(error instanceof VisualizationError)throw error;throw new VisualizationError('NOT_FOUND','可视化内容不可用')}
}

module.exports={MAX_VISUALIZATION_BYTES,MAX_VISUALIZATION_ENTRIES,VISUALIZATION_TTL_MS,VisualizationError,readVisualizationFragment,registerHistoryVisualization,readHistoryVisualization};
