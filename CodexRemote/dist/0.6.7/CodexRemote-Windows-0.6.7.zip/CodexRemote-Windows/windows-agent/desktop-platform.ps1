﻿#requires -Version 5.1
param(
    [Parameter(Mandatory=$true)][ValidateSet('detect','import','resolve','secure','secureSocket','environment')][string]$Action,
    [string]$Value,
    [string]$LauncherHint
)
$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
[Console]::OutputEncoding=New-Object Text.UTF8Encoding($false)

function Get-OfficialDesktop {
    $package=Get-AppxPackage -Name 'OpenAI.Codex' | Sort-Object Version -Descending | Select-Object -First 1
    if(-not $package){return $null}
    $target=Join-Path $package.InstallLocation 'app\ChatGPT.exe'
    if(-not (Test-Path -LiteralPath $target -PathType Leaf)){return $null}
    $settings=New-Object Xml.XmlReaderSettings
    $settings.DtdProcessing=[Xml.DtdProcessing]::Prohibit;$settings.XmlResolver=$null
    $reader=[Xml.XmlReader]::Create((Join-Path $package.InstallLocation 'AppxManifest.xml'),$settings)
    try{$manifest=New-Object Xml.XmlDocument;$manifest.XmlResolver=$null;$manifest.Load($reader)}finally{$reader.Dispose()}
    if([string]$manifest.DocumentElement.Identity.Name -ne 'OpenAI.Codex'){throw 'DESKTOP_PACKAGE_INVALID'}
    $matches=@($manifest.DocumentElement.Applications.Application | Where-Object {
        $_.Executable -and [IO.Path]::GetFullPath((Join-Path $package.InstallLocation ([string]$_.Executable))) -eq [IO.Path]::GetFullPath($target)
    })
    if($matches.Count -ne 1){throw 'DESKTOP_PACKAGE_INVALID'}
    $binary=Join-Path (Split-Path -Parent $target) 'resources\codex.exe'
    $pwsh=Join-Path $env:ProgramFiles 'PowerShell\7\pwsh.exe'
    if(-not (Test-Path -LiteralPath $pwsh -PathType Leaf)){
        $candidate=Get-Command pwsh.exe -ErrorAction SilentlyContinue
        $pwsh=if($candidate){$candidate.Source}else{''}
    }
    return [pscustomobject]@{kind='official';name='官方 Codex';sourcePath=[IO.Path]::GetFullPath($target);desktopExecutable=[IO.Path]::GetFullPath($target);binary=$binary;powerShellExecutable=$pwsh;sharedSupported=([bool]$pwsh -and (Test-Path -LiteralPath $binary -PathType Leaf))}
}

function Read-EnhancedShortcut([string]$ShortcutPath,$Official){
    if(-not $Official){throw 'DESKTOP_NOT_INSTALLED'}
    if(-not [IO.Path]::IsPathRooted($ShortcutPath) -or [IO.Path]::GetExtension($ShortcutPath) -ine '.lnk' -or -not (Test-Path -LiteralPath $ShortcutPath -PathType Leaf)){throw 'DESKTOP_SHORTCUT_INVALID'}
    $shortcutPath=(Resolve-Path -LiteralPath $ShortcutPath).Path
    $shell=New-Object -ComObject WScript.Shell
    try{$shortcut=$shell.CreateShortcut($shortcutPath);$target=[string]$shortcut.TargetPath;$arguments=[string]$shortcut.Arguments}finally{[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($shell)}
    $isolated=Read-IsolatedDesktopShortcut $target $arguments $Official $shortcutPath
    if($isolated){return $isolated}
    $launcher=$null
    if([IO.Path]::GetFileName($target) -ieq 'LaunchCodex.vbs' -and -not $arguments.Trim()){$launcher=$target}
    elseif([IO.Path]::GetFullPath($target) -ieq (Join-Path $env:SystemRoot 'System32\wscript.exe') -and $arguments -match '^\s*"([^"\r\n]+\\LaunchCodex\.vbs)"\s*$'){$launcher=$matches[1]}
    if(-not $launcher -or -not (Test-Path -LiteralPath $launcher -PathType Leaf)){throw 'DESKTOP_SHORTCUT_UNSUPPORTED'}
    return Read-EnhancedLauncher $launcher $Official $shortcutPath
}

function Read-EnhancedLauncher([string]$LauncherPath,$Official,[string]$SourcePath){
    if(-not $Official){throw 'DESKTOP_NOT_INSTALLED'}
    if(-not [IO.Path]::IsPathRooted($LauncherPath) -or [IO.Path]::GetFileName($LauncherPath) -ine 'LaunchCodex.vbs' -or -not (Test-Path -LiteralPath $LauncherPath -PathType Leaf)){throw 'DESKTOP_ENHANCER_UNSUPPORTED'}
    $launcher=(Resolve-Path -LiteralPath $LauncherPath).Path
    if(-not $SourcePath){$SourcePath=$launcher}
    $root=Split-Path -Parent $launcher
    $script=Join-Path $root 'CodexSidebarLite.ps1'
    if(-not (Test-Path -LiteralPath $script -PathType Leaf) -or (Get-Item -LiteralPath $script).Length -gt 1048576 -or (Get-Item -LiteralPath $launcher).Length -gt 16384){throw 'DESKTOP_ENHANCER_UNSUPPORTED'}
    $vbs=[IO.File]::ReadAllText($launcher)
    $source=[IO.File]::ReadAllText($script)
    # 仅接受已核对的默认启动链；快捷方式附加参数和独立实例配置不被执行。
    if($vbs -notmatch 'CodexSidebarLite\.ps1' -or $vbs -notmatch '" launch"' -or $vbs -match '(?i)InstanceConfigPath' -or
        $source -notmatch 'function Start-ManagedCodex' -or $source -notmatch 'function Start-PackagedCodex' -or $source -notmatch 'function Get-FreeLoopbackPort' -or
        $source -notmatch '\$RuntimeRoot\s*=\s*Join-Path \$ScriptRoot ''\.runtime''' -or $source -notmatch '\$ProfileRoot\s*=\s*Join-Path \$RuntimeRoot ''codex-profile''') {throw 'DESKTOP_ENHANCER_UNSUPPORTED'}
    return [pscustomobject]@{kind='sidebar-lite';name='Codex 增强版';sourcePath=$SourcePath;desktopExecutable=$Official.desktopExecutable;binary=$Official.binary;powerShellExecutable=$Official.powerShellExecutable;sharedSupported=$Official.sharedSupported;enhancedLauncher=$script;enhancedProfileDirectory=(Join-Path $root '.runtime\codex-profile');launcherPath=$launcher;launcherFingerprint=(Get-FileHash -LiteralPath $launcher -Algorithm SHA256).Hash;scriptFingerprint=(Get-FileHash -LiteralPath $script -Algorithm SHA256).Hash}
}

function Resolve-EnhancedInstance([string]$SourcePath,$Official,[string]$LauncherHint=''){
    if([IO.Path]::GetExtension($SourcePath) -ieq '.lnk'){return Read-EnhancedShortcut $SourcePath $Official}
    if([IO.Path]::GetExtension($SourcePath) -ieq '.json'){
        if($LauncherHint){
            # 仅由管理器已验证私有配置提供线索；重新核对能力和指纹，不执行外部脚本。
            $launcher=Read-IsolatedDesktopLauncher $LauncherHint $Official
            return Read-IsolatedDesktopInstance $SourcePath $launcher $Official
        }
        $launchers=@(Get-KnownEnhancedLaunchers $Official @())
        $matches=@(foreach($launcher in $launchers){try{Read-IsolatedDesktopInstance $SourcePath $launcher $Official}catch{}})
        if($matches.Count -ne 1){
            $parentMatches=@();$seen=@{}
            $scan=Get-RunningDesktopProcesses $Official
            foreach($process in @($scan.processes)){
                if(-not $process.profileValid -or -not $process.hasCustomProfile){continue}
                foreach($launcher in @(Get-ParentEnhancedLaunchers $process $Official)){
                    try{
                        $instance=Read-IsolatedDesktopInstance $SourcePath $launcher $Official
                        if($instance.enhancedProfileDirectory -ieq $process.profileDirectory -and -not $seen.ContainsKey($instance.enhancedLauncher)){
                            $seen[$instance.enhancedLauncher]=$true;$parentMatches+=$instance
                        }
                    }catch{}
                }
            }
            $matches=$parentMatches
        }
        if($matches.Count -ne 1){throw 'DESKTOP_INSTANCE_CONFIG_UNSUPPORTED'}
        return $matches[0]
    }
    return Read-EnhancedLauncher $SourcePath $Official ''
}

function Assert-DesktopPathWithoutReparse([string]$Path,[bool]$MustBeDirectory=$false){
    $current=Get-CanonicalDesktopPath $Path
    $isTarget=$true
    while($current){
        $item=$null
        try{$item=Get-Item -LiteralPath $current -Force -ErrorAction Stop}catch [Management.Automation.ItemNotFoundException]{}catch{throw 'DESKTOP_INSTANCE_CONFIG_INVALID'}
        if($item -and ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'DESKTOP_INSTANCE_CONFIG_INVALID'}
        if($item -and (-not $isTarget -or $MustBeDirectory) -and -not $item.PSIsContainer){throw 'DESKTOP_INSTANCE_CONFIG_INVALID'}
        $parent=Split-Path -Parent $current
        if(-not $parent -or $parent -eq $current){break};$current=$parent;$isTarget=$false
    }
}

function Read-DesktopBoundedText([string]$Path,[int]$MaximumBytes){
    Assert-DesktopPathWithoutReparse $Path
    $item=Get-Item -LiteralPath $Path -Force
    if($item.PSIsContainer -or $item.Length -gt $MaximumBytes){throw 'DESKTOP_INSTANCE_CONFIG_INVALID'}
    $bytes=[IO.File]::ReadAllBytes($Path)
    if($bytes.Length -gt $MaximumBytes){throw 'DESKTOP_INSTANCE_CONFIG_INVALID'}
    $encoding=New-Object Text.UTF8Encoding($false,$true)
    $body=$encoding.GetString($bytes)
    if($body.Length -gt 0 -and $body[0] -eq [char]0xFEFF){$body=$body.Substring(1)}
    if($body.Length -gt 0 -and $body[0] -eq [char]0xFEFF){throw 'DESKTOP_INSTANCE_CONFIG_INVALID'}
    $sha=[Security.Cryptography.SHA256]::Create()
    try{$fingerprint=([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-','')}finally{$sha.Dispose()}
    return [pscustomobject]@{body=$body;fingerprint=$fingerprint}
}

function Read-IsolatedDesktopConfig([string]$ConfigPath,[string]$ToolRoot){
    try{
        $config=Get-CanonicalDesktopPath $ConfigPath
        if([IO.Path]::GetExtension($config) -ine '.json'){throw 'INVALID'}
        $text=Read-DesktopBoundedText $config 32768
        # 支持格式只有字符串/空值；逐项解码并检查重复键，避免 ConvertFrom-Json 静默覆盖。
        $token='"(?:[^"\\\x00-\x1f]|\\(?:["\\/bfnrt]|u[0-9A-Fa-f]{4}))*"'
        $pair='(?<key>'+ $token +')\s*:\s*(?<value>'+ $token +'|null)'
        $object=[regex]::Match($text.body,('\A\s*\{\s*(?:'+$pair+'(?:\s*,\s*'+$pair+')*)?\s*\}\s*\z'))
        if(-not $object.Success){throw 'INVALID'}
        $values=@{}
        for($index=0;$index -lt $object.Groups['key'].Captures.Count;$index++){
            $key=([string]('{"v":'+$object.Groups['key'].Captures[$index].Value+'}') | ConvertFrom-Json).v
            if(@('runtimeRoot','profileRoot','codexHome','apiKeyEnvironmentVariable','usageProvider') -cnotcontains $key -or $values.ContainsKey($key)){throw 'INVALID'}
            $values[$key]=([string]('{"v":'+$object.Groups['value'].Captures[$index].Value+'}') | ConvertFrom-Json).v
        }
        $root=Split-Path -Parent $config;$paths=@{}
        foreach($key in @('runtimeRoot','profileRoot','codexHome')){
            $value=$values[$key]
            if(-not ($value -is [string]) -or [string]::IsNullOrWhiteSpace($value) -or [IO.Path]::IsPathRooted($value) -or
                $value -match '[\x00-\x1f\x7f:*?"<>|]' -or $value -match '(?:^|[\\/])\.{1,2}(?:[\\/]|$)' -or $value -match '(?:^|[\\/])[^\\/]*[ .](?:[\\/]|$)' -or
                $value -match '(?i)(?:^|[\\/])(?:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.[^\\/]*)?(?:[\\/]|$)'){throw 'INVALID'}
            $path=Get-CanonicalDesktopPath (Join-Path $root $value)
            if(-not $path.StartsWith($root.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'INVALID'}
            Assert-DesktopPathWithoutReparse $path $true
            foreach($protected in @((Join-Path $ToolRoot '.runtime'),(Join-Path $env:USERPROFILE '.codex'))){
                $protected=Get-CanonicalDesktopPath $protected
                if($path -ieq $protected -or $path.StartsWith($protected+'\',[StringComparison]::OrdinalIgnoreCase) -or $protected.StartsWith($path+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'INVALID'}
            }
            foreach($other in $paths.Values){
                if($path -ieq $other -or $path.StartsWith($other+'\',[StringComparison]::OrdinalIgnoreCase) -or $other.StartsWith($path+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'INVALID'}
            }
            $paths[$key]=$path
        }
        $envKey=$values['apiKeyEnvironmentVariable']
        if(-not ($envKey -is [string]) -or $envKey.Length -gt 128 -or $envKey -cnotmatch '^CODEX_[A-Z0-9_]+_API_KEY$'){throw 'INVALID'}
        if($null -ne $values['usageProvider'] -and (-not ($values['usageProvider'] -is [string]) -or @('litellm-user-budget','bailian-local-usage') -cnotcontains $values['usageProvider'])){throw 'INVALID'}
        return [pscustomobject]@{configPath=$config;configFingerprint=$text.fingerprint;runtimeRoot=$paths.runtimeRoot;profileRoot=$paths.profileRoot;codexHome=$paths.codexHome;apiKeyEnvironmentVariable=$envKey}
    }catch{throw 'DESKTOP_INSTANCE_CONFIG_INVALID'}
}

function Read-IsolatedDesktopLauncher([string]$ScriptPath,$Official){
    try{
        if(-not $Official){throw 'INVALID'}
        $script=Get-CanonicalDesktopPath $ScriptPath
        if([IO.Path]::GetFileName($script) -ine 'CodexSidebarLite.ps1'){throw 'INVALID'}
        $source=Read-DesktopBoundedText $script 1048576
        $module=Join-Path (Split-Path -Parent $script) 'src\instance-config.ps1'
        $moduleSource=Read-DesktopBoundedText $module 262144
        foreach($pattern in @('function Start-ManagedCodex','function Start-PackagedCodex','function Get-FreeLoopbackPort',
            '\[string\]\s*\$InstanceConfigPath','Read-IsolatedInstanceConfig\s+\$InstanceConfigPath\s+\$ScriptRoot',
            '\$RuntimeRoot\s*=\s*\$InstanceConfig\.runtimeRoot','\$ProfileRoot\s*=\s*\$InstanceConfig\.profileRoot',
            'src\\instance-config\.ps1')){if($source.body -notmatch $pattern){throw 'INVALID'}}
        foreach($pattern in @('function Read-IsolatedInstanceConfig','function Start-IsolatedPackagedCodex','apiKeyEnvironmentVariable','runtimeRoot','profileRoot','codexHome')){
            if($moduleSource.body -notmatch $pattern){throw 'INVALID'}
        }
        $parseTokens=$null;$parseErrors=$null
        [void][Management.Automation.Language.Parser]::ParseInput($source.body,[ref]$parseTokens,[ref]$parseErrors)
        if($parseErrors){throw 'INVALID'}
        [void][Management.Automation.Language.Parser]::ParseInput($moduleSource.body,[ref]$parseTokens,[ref]$parseErrors)
        if($parseErrors){throw 'INVALID'}
        return [pscustomobject]@{enhancedLauncher=$script;scriptFingerprint=$source.fingerprint;instanceConfigModulePath=$module;instanceConfigModuleFingerprint=$moduleSource.fingerprint}
    }catch{throw 'DESKTOP_INSTANCE_CONFIG_UNSUPPORTED'}
}

function Read-IsolatedDesktopInstance([string]$ConfigPath,$Launcher,$Official,[string]$SourcePath=''){
    $capability=Read-IsolatedDesktopLauncher $Launcher.enhancedLauncher $Official
    $config=Read-IsolatedDesktopConfig $ConfigPath (Split-Path -Parent $capability.enhancedLauncher)
    if(-not $SourcePath){$SourcePath=$config.configPath}
    return [pscustomobject]@{kind='sidebar-lite';name='Codex 独立实例';sourcePath=$SourcePath;desktopExecutable=$Official.desktopExecutable;binary=$Official.binary;powerShellExecutable=$Official.powerShellExecutable;sharedSupported=$Official.sharedSupported;
        enhancedLauncher=$capability.enhancedLauncher;enhancedProfileDirectory=$config.profileRoot;launcherPath=$capability.enhancedLauncher;launcherFingerprint=$capability.scriptFingerprint;scriptFingerprint=$capability.scriptFingerprint;
        instanceConfigPath=$config.configPath;instanceConfigFingerprint=$config.configFingerprint;instanceConfigModulePath=$capability.instanceConfigModulePath;instanceConfigModuleFingerprint=$capability.instanceConfigModuleFingerprint;
        isolatedCodexHome=$config.codexHome;apiKeyEnvironmentVariable=$config.apiKeyEnvironmentVariable;enhancedRuntimeDirectory=$config.runtimeRoot}
}

function Read-IsolatedDesktopShortcut([string]$Target,[string]$Arguments,$Official,[string]$SourcePath){
    $tokens=@(ConvertFrom-DesktopCommandLine ('"'+$Target+'" '+$Arguments))
    $scriptPath=$null;$configPath=$null
    if([IO.Path]::GetFileName($Target) -ieq 'CodexSidebarLite.ps1'){
        if($tokens.Count -eq 4 -and $tokens[1] -ieq 'launch' -and $tokens[2] -ieq '-InstanceConfigPath'){$scriptPath=$Target;$configPath=$tokens[3]}
    }else{
        $trusted=@((Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'),$Official.powerShellExecutable)
        if($trusted -icontains $Target){
            # 仅接受参数列表；不支持 -Command、脚本块、命令拼接或额外自定义参数。
            $index=1
            foreach($switch in @('-NoLogo','-NoProfile','-NonInteractive')){if($index -lt $tokens.Count -and $tokens[$index] -ieq $switch){$index++}}
            if($index+1 -lt $tokens.Count -and $tokens[$index] -ieq '-ExecutionPolicy' -and $tokens[$index+1] -ieq 'Bypass'){$index+=2}
            if($index+4 -eq $tokens.Count-1 -and $tokens[$index] -ieq '-File' -and $tokens[$index+2] -ieq 'launch' -and $tokens[$index+3] -ieq '-InstanceConfigPath'){$scriptPath=$tokens[$index+1];$configPath=$tokens[$index+4]}
        }
    }
    if(-not $scriptPath){return $null}
    return Read-IsolatedDesktopInstance $configPath ([pscustomobject]@{enhancedLauncher=$scriptPath}) $Official $SourcePath
}

function Get-DesktopParentProcess([int]$ProcessId){Get-CimInstance Win32_Process -Filter ("ProcessId = {0}" -f $ProcessId) -ErrorAction Stop}
function Get-ParentEnhancedLaunchers($Process,$Official){
    $parentId=[int]$Process.parentProcessId
    for($depth=0;$depth -lt 3 -and $parentId -gt 0;$depth++){
        try{
            $parent=Get-DesktopParentProcess $parentId
            if(-not $parent -or [int]$parent.SessionId -ne (Get-CurrentDesktopSessionId) -or (Get-DesktopProcessOwnerSid $parent) -ne (Get-CurrentDesktopUserSid)){break}
            $tokens=@(ConvertFrom-DesktopCommandLine ([string]$parent.CommandLine))
            for($index=1;$index -lt $tokens.Count-1;$index++){
                if($tokens[$index] -ieq '-File' -and [IO.Path]::GetFileName($tokens[$index+1]) -ieq 'CodexSidebarLite.ps1'){
                    try{Read-IsolatedDesktopLauncher $tokens[$index+1] $Official}catch{}
                }
            }
            $parentId=[int]$parent.ParentProcessId
        }catch{break}
    }
}

function Get-KnownEnhancedLaunchers($Official,[array]$Instances){
    $seen=@{}
    foreach($instance in $Instances){
        if($instance.kind -eq 'sidebar-lite' -and $instance.enhancedLauncher){
            try{$launcher=Read-IsolatedDesktopLauncher $instance.enhancedLauncher $Official;if(-not $seen.ContainsKey($launcher.enhancedLauncher)){$seen[$launcher.enhancedLauncher]=$true;$launcher}}catch{}
        }
    }
    foreach($candidate in @(Get-DesktopShortcutCandidates)){
        try{
            $instance=Read-EnhancedShortcut $candidate $Official
            $launcher=Read-IsolatedDesktopLauncher $instance.enhancedLauncher $Official
            if(-not $seen.ContainsKey($launcher.enhancedLauncher)){$seen[$launcher.enhancedLauncher]=$true;$launcher}
        }catch{}
    }
}

function Get-IsolatedDesktopConfigCandidates([string]$ProfileDirectory,[string]$ConfigDirectory=''){
    $directory=Split-Path -Parent (Get-CanonicalDesktopPath $ProfileDirectory);$count=0;$maximumDepth=3
    if($ConfigDirectory){$directory=Get-CanonicalDesktopPath $ConfigDirectory;$maximumDepth=1}
    for($depth=0;$depth -lt $maximumDepth -and $directory;$depth++){
        try{
            Assert-DesktopPathWithoutReparse $directory
            $files=@(Get-ChildItem -LiteralPath $directory -Filter '*.json' -File -Force -ErrorAction Stop | Select-Object -First 33)
            if($files.Count -gt 32){throw 'DESKTOP_INSTANCE_CONFIG_AMBIGUOUS'}
            foreach($file in $files){
                if($file.BaseName -match '(?i)(?:^|[-_.])(auth|models?|catalog)(?:[-_.]|$)' -or $file.Length -gt 32768){continue}
                $count++;if($count -gt 64){throw 'DESKTOP_INSTANCE_CONFIG_AMBIGUOUS'}
                $file.FullName
            }
        }catch{if($_.Exception.Message -eq 'DESKTOP_INSTANCE_CONFIG_AMBIGUOUS'){throw}}
        $parent=Split-Path -Parent $directory;if($parent -eq $directory){break};$directory=$parent
    }
}

function Test-IsolatedDesktopManagedState($Instance,[int]$ProcessId,$Official){
    if($ProcessId -le 0 -or -not $Official){return $false}
    try{
        $path=Join-Path $Instance.enhancedRuntimeDirectory 'managed-instance.json'
        $text=Read-DesktopBoundedText $path 32768
        # 状态仅作当前进程关联证据，允许未知标量字段，拒绝重复键和复杂/歧义结构。
        $token='"(?:[^"\\\x00-\x1f]|\\(?:["\\/bfnrt]|u[0-9A-Fa-f]{4}))*"'
        $scalar=$token+'|null|true|false|-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?'
        $pair='(?<key>'+$token+')\s*:\s*(?<value>'+$scalar+')'
        $object=[regex]::Match($text.body,('\A\s*\{\s*(?:'+$pair+'(?:\s*,\s*'+$pair+')*)?\s*\}\s*\z'))
        if(-not $object.Success){return $false}
        $values=@{}
        for($index=0;$index -lt $object.Groups['key'].Captures.Count;$index++){
            $key=([string]('{"v":'+$object.Groups['key'].Captures[$index].Value+'}') | ConvertFrom-Json).v
            if($values.ContainsKey($key)){return $false}
            $values[$key]=([string]('{"v":'+$object.Groups['value'].Captures[$index].Value+'}') | ConvertFrom-Json).v
        }
        if(($values.rootPid -isnot [int] -and $values.rootPid -isnot [long]) -or $values.rootPid -ne $ProcessId){return $false}
        foreach($field in @('profileDir','executable','instanceConfigPath','codexHome')){if($values[$field] -isnot [string]){return $false}}
        if((Get-CanonicalDesktopPath $values.profileDir) -ine (Get-CanonicalDesktopPath $Instance.enhancedProfileDirectory) -or
            (Get-CanonicalDesktopPath $values.executable) -ine (Get-CanonicalDesktopPath $Official.desktopExecutable) -or
            (Get-CanonicalDesktopPath $values.instanceConfigPath) -ine (Get-CanonicalDesktopPath $Instance.instanceConfigPath) -or
            (Get-CanonicalDesktopPath $values.codexHome) -ine (Get-CanonicalDesktopPath $Instance.isolatedCodexHome)){return $false}
        return $true
    }catch{return $false}
}

function Get-IsolatedDesktopInstanceFromProfile([string]$ProfileDirectory,$Official,[array]$Launchers,[array]$KnownInstances=@(),[int]$ProcessId=0){
    $profile=Get-CanonicalDesktopPath $ProfileDirectory
    $known=@{};$configDirectory=''
    foreach($instance in $KnownInstances){
        if($instance.kind -eq 'sidebar-lite' -and [IO.Path]::GetExtension($instance.sourcePath) -ieq '.lnk' -and $instance.instanceConfigPath -and (Get-CanonicalDesktopPath $instance.enhancedProfileDirectory) -ieq $profile){
            $key=(Get-CanonicalDesktopPath $instance.instanceConfigPath)+'|'+(Get-CanonicalDesktopPath $instance.enhancedLauncher)
            if(-not $known.ContainsKey($key)){$known[$key]=$instance}
        }
    }
    # 已验证lnk明确指向配置时，profile可以位于任意合法深度；仍检查配置同目录歧义。
    if($known.Count){$Launchers=@($known.Values | ForEach-Object {Read-IsolatedDesktopLauncher $_.enhancedLauncher $Official} | Sort-Object enhancedLauncher -Unique)}
    $matches=@();$paths=@{}
    if($known.Count){
        $candidates=@($known.Values | ForEach-Object {$_.instanceConfigPath})
        foreach($directory in @($known.Values | ForEach-Object {Split-Path -Parent $_.instanceConfigPath} | Sort-Object -Unique)){
            $candidates+=@(Get-IsolatedDesktopConfigCandidates $profile $directory)
        }
        $candidates=@($candidates | Sort-Object -Unique)
    }else{$candidates=@(Get-IsolatedDesktopConfigCandidates $profile)}
    foreach($candidate in $candidates){
        $declared=@($known.Values | Where-Object {$_.instanceConfigPath -ieq $candidate})
        $candidateLaunchers=if($declared.Count){@($declared | ForEach-Object {Read-IsolatedDesktopLauncher $_.enhancedLauncher $Official} | Sort-Object enhancedLauncher -Unique)}else{$Launchers}
        foreach($launcher in $candidateLaunchers){
            try{
                # 先检查小型配置是否指向目标profile，再解析/指纹校验较大的外部脚本。
                $config=Read-IsolatedDesktopConfig $candidate (Split-Path -Parent $launcher.enhancedLauncher)
                if($config.profileRoot -ine $profile){continue}
                $instance=Read-IsolatedDesktopInstance $candidate $launcher $Official
                if($instance.enhancedProfileDirectory -ieq $profile){
                    $declaredSource=$declared | Where-Object {$_.enhancedLauncher -ieq $instance.enhancedLauncher} | Select-Object -First 1
                    if($declaredSource){$instance.sourcePath=$declaredSource.sourcePath}
                    $key=$instance.instanceConfigPath+'|'+$instance.enhancedLauncher
                    if(-not $paths.ContainsKey($key)){$paths[$key]=$true;$matches+=$instance}
                }
            }catch{}
        }
    }
    if($matches.Count -gt 1){$matches=@($matches | Where-Object {Test-IsolatedDesktopManagedState $_ $ProcessId $Official})}
    if($matches.Count -ne 1){return $null}
    return $matches[0]
}

function ConvertFrom-DesktopCommandLine([string]$CommandLine){
    if([string]::IsNullOrWhiteSpace($CommandLine)){throw 'DESKTOP_PROCESS_COMMAND_LINE_INVALID'}
    # 使用 Windows 自身的参数拆分规则，保留引号、空参数和反斜杠语义；绝不执行参数。
    if(-not ('CodexRemote.DesktopCommandLine' -as [type])){
        Add-Type -TypeDefinition @'
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
namespace CodexRemote {
    public static class DesktopCommandLine {
        [DllImport("shell32.dll", SetLastError=true, CharSet=CharSet.Unicode)]
        private static extern IntPtr CommandLineToArgvW(string commandLine, out int count);
        [DllImport("kernel32.dll")]
        private static extern IntPtr LocalFree(IntPtr pointer);
        public static string[] Split(string commandLine) {
            int count;
            IntPtr pointer = CommandLineToArgvW(commandLine, out count);
            if (pointer == IntPtr.Zero) throw new Win32Exception();
            try {
                string[] arguments = new string[count];
                for (int index = 0; index < count; index++)
                    arguments[index] = Marshal.PtrToStringUni(Marshal.ReadIntPtr(pointer, index * IntPtr.Size));
                return arguments;
            } finally { LocalFree(pointer); }
        }
    }
}
'@ | Out-Null
    }
    [CodexRemote.DesktopCommandLine]::Split($CommandLine)
}

function Get-CanonicalDesktopPath([string]$Path){
    # 相对目录、设备路径、控制字符和通配符不能用来关联一个配置目录。
    if(-not $Path -or $Path -match '[\x00-\x1f\x7f*?]' -or $Path -match '^\\\\[?.]\\' -or
        $Path -notmatch '^(?:[A-Za-z]:\\|\\\\[^\\]+\\[^\\]+(?:\\|$))'){throw 'DESKTOP_PROCESS_PATH_INVALID'}
    $full=[IO.Path]::GetFullPath($Path)
    $root=[IO.Path]::GetPathRoot($full)
    if($full.Length -gt $root.Length){$full=$full.TrimEnd('\')}
    return $full
}

function Get-DesktopProcessArguments([string]$CommandLine){
    $arguments=@(ConvertFrom-DesktopCommandLine $CommandLine)
    if($arguments.Count -eq 0 -or -not $arguments[0]){throw 'DESKTOP_PROCESS_COMMAND_LINE_INVALID'}
    $profiles=@();$invalidProfile=$false
    for($index=1;$index -lt $arguments.Count;$index++){
        $argument=$arguments[$index]
        if($argument -ieq '--type' -or $argument -imatch '^--type='){return [pscustomobject]@{isChild=$true;hasCustomProfile=$false;profileValid=$false;profileDirectory=''}}
        if($argument -ieq '--user-data-dir'){
            if($index+1 -ge $arguments.Count -or $arguments[$index+1] -match '^--'){$invalidProfile=$true;$profiles+=''}
            else{$index++;$profiles+=$arguments[$index]}
        }elseif($argument -imatch '^--user-data-dir=(.*)$'){$profiles+=$matches[1]}
    }
    $profile=''
    if($profiles.Count -eq 1 -and -not $invalidProfile){try{$profile=Get-CanonicalDesktopPath $profiles[0]}catch{$invalidProfile=$true}}
    elseif($profiles.Count -gt 1){$invalidProfile=$true}
    return [pscustomobject]@{isChild=$false;hasCustomProfile=($profiles.Count -gt 0);profileValid=(-not $invalidProfile);profileDirectory=$profile}
}

function Get-CurrentDesktopSessionId {return [Diagnostics.Process]::GetCurrentProcess().SessionId}
function Get-CurrentDesktopUserSid {return [Security.Principal.WindowsIdentity]::GetCurrent().User.Value}
function Get-DesktopProcessOwnerSid($Process){
    $owner=Invoke-CimMethod -InputObject $Process -MethodName GetOwnerSid -ErrorAction Stop
    if($owner.ReturnValue -ne 0 -or -not $owner.Sid){throw 'DESKTOP_PROCESS_OWNER_UNKNOWN'}
    return [string]$owner.Sid
}
function Get-DesktopProcessSnapshot([int]$SessionId,[string]$ExecutableName){
    # 文件名来自已验证的官方包；仍在下游严格核对完整路径。
    Get-CimInstance Win32_Process -Filter ("SessionId = {0} AND Name = '{1}'" -f $SessionId,$ExecutableName.Replace("'","''")) -ErrorAction Stop
}

function Get-RunningDesktopProcesses($Official){
    $rows=@();$failed=$false
    if(-not $Official){return [pscustomobject]@{processes=@();failed=$false}}
    try{
        $sessionId=Get-CurrentDesktopSessionId;$userSid=Get-CurrentDesktopUserSid
        $officialPath=Get-CanonicalDesktopPath $Official.desktopExecutable
        $snapshot=@(Get-DesktopProcessSnapshot $sessionId ([IO.Path]::GetFileName($officialPath)))
    }catch{return [pscustomobject]@{processes=@();failed=$true}}
    foreach($process in $snapshot){
        try{
            if([int]$process.SessionId -ne $sessionId){continue}
            if(-not $process.ExecutablePath){$failed=$true;continue}
            if((Get-CanonicalDesktopPath ([string]$process.ExecutablePath)) -ine $officialPath){continue}
            $parsed=Get-DesktopProcessArguments ([string]$process.CommandLine)
            if($parsed.isChild){continue}
            if((Get-DesktopProcessOwnerSid $process) -ne $userSid){continue}
            $processId=[long]$process.ProcessId
            if($processId -le 0 -or $processId -gt [int]::MaxValue){$failed=$true;continue}
            if(-not $parsed.isChild){$rows+=[pscustomobject]@{pid=[int]$processId;parentProcessId=[int]$process.ParentProcessId;hasCustomProfile=$parsed.hasCustomProfile;profileValid=$parsed.profileValid;profileDirectory=$parsed.profileDirectory}}
        }catch{$failed=$true}
    }
    return [pscustomobject]@{processes=@($rows | Sort-Object pid);failed=$failed}
}

function Get-DesktopShortcutCandidates {
    $programs=[Environment]::GetFolderPath('Programs')
    $desktop=[Environment]::GetFolderPath('DesktopDirectory')
    $seen=@{}
    # 保留已有两个入口的优先级和 sourcePath；只扫描用户目录的顶层与 Codex 子目录。
    foreach($name in @('Codex.lnk','Codex 增强版.lnk')){
        if($programs){$candidate=Join-Path $programs $name;if(Test-Path -LiteralPath $candidate -PathType Leaf){$seen[$candidate]=$true;$candidate}}
    }
    $directories=@($programs,$desktop)
    if($programs){$directories+=Join-Path $programs 'Codex'}
    foreach($directory in $directories){
        if($directory -and (Test-Path -LiteralPath $directory -PathType Container)){
            foreach($candidate in @(Get-ChildItem -LiteralPath $directory -Filter '*Codex*.lnk' -File -ErrorAction SilentlyContinue | Sort-Object FullName)){
                if(-not $seen.ContainsKey($candidate.FullName)){$seen[$candidate.FullName]=$true;$candidate.FullName}
            }
        }
    }
}

function Get-EnhancedInstanceFromProfile([string]$ProfileDirectory,$Official){
    $profile=Get-CanonicalDesktopPath $ProfileDirectory
    if([IO.Path]::GetFileName($profile) -ine 'codex-profile'){return $null}
    $runtime=Split-Path -Parent $profile
    if([IO.Path]::GetFileName($runtime) -ine '.runtime'){return $null}
    $launcher=Join-Path (Split-Path -Parent $runtime) 'LaunchCodex.vbs'
    $instance=Read-EnhancedLauncher $launcher $Official ''
    if((Get-CanonicalDesktopPath $instance.enhancedProfileDirectory) -ine $profile){return $null}
    return $instance
}

function Get-DesktopDetection {
    $rows=@();$running=@();$profileIdentities=@{};$ambiguousProfiles=@{};$official=Get-OfficialDesktop
    if($official){$rows+=$official}
    foreach($candidate in @(Get-DesktopShortcutCandidates)){
        try{$instance=Read-EnhancedShortcut $candidate $official;if(-not @($rows | Where-Object {$_.sourcePath -ieq $instance.sourcePath}).Count){$rows+=$instance}}catch{}
    }
    $scan=Get-RunningDesktopProcesses $official
    $knownLaunchers=@(Get-KnownEnhancedLaunchers $official $rows)
    foreach($process in @($scan.processes)){
        $instance=$null
        if($process.profileValid){
            if(-not $process.hasCustomProfile){$instance=$official}
            else{
                $instance=$rows | Where-Object {$_.kind -eq 'sidebar-lite' -and -not $_.instanceConfigPath -and (Get-CanonicalDesktopPath $_.enhancedProfileDirectory) -ieq $process.profileDirectory} | Select-Object -First 1
                if(-not $instance){
                    try{$instance=Get-EnhancedInstanceFromProfile $process.profileDirectory $official;if($instance){$rows+=$instance}}catch{}
                }
                if(-not $instance){
                    try{
                        $parentLaunchers=@(Get-ParentEnhancedLaunchers $process $official | Sort-Object enhancedLauncher -Unique)
                        $launchers=if($parentLaunchers.Count){$parentLaunchers}else{$knownLaunchers}
                        $instance=Get-IsolatedDesktopInstanceFromProfile $process.profileDirectory $official @($launchers) $rows $process.pid
                        if($instance){
                            $existing=$rows | Where-Object {$_.sourcePath -ieq $instance.sourcePath} | Select-Object -First 1
                            if($existing){$rows=@($rows | Where-Object {$_.sourcePath -ine $instance.sourcePath})+@($instance)}else{$rows+=$instance}
                        }
                    }catch{}
                }
            }
        }
        if($instance -and $instance.instanceConfigPath){
            $key=$instance.instanceConfigPath+'|'+$instance.enhancedLauncher
            if($profileIdentities.ContainsKey($process.profileDirectory) -and $profileIdentities[$process.profileDirectory] -ine $key){$ambiguousProfiles[$process.profileDirectory]=$true}
            else{$profileIdentities[$process.profileDirectory]=$key}
        }
        if($ambiguousProfiles.ContainsKey($process.profileDirectory)){
            $instance=$null
            foreach($previous in $running){if($previous.profileDirectory -ieq $process.profileDirectory){$previous.instanceSourcePath=$null;$previous.reason='shortcut_required'}}
            $rows=@($rows | Where-Object {-not ($_.instanceConfigPath -and [IO.Path]::GetExtension($_.sourcePath) -ine '.lnk' -and $_.enhancedProfileDirectory -ieq $process.profileDirectory)})
        }
        $running+=[pscustomobject]@{pid=$process.pid;instanceSourcePath=$(if($instance){$instance.sourcePath}else{$null});profileDirectory=$process.profileDirectory;reason=$(if($instance){'matched'}else{'shortcut_required'})}
    }
    $matched=@{};foreach($process in $running){if($process.instanceSourcePath){$matched[$process.instanceSourcePath]=$true}}
    # 稳定分组，保持已安装候选，不根据排序替用户选择实例。
    $ordered=@($rows | Where-Object {$matched.ContainsKey($_.sourcePath)})+@($rows | Where-Object {-not $matched.ContainsKey($_.sourcePath)})
    return [pscustomobject]@{instances=@($ordered);running=@($running);processScanFailed=[bool]$scan.failed}
}

try{
    switch($Action){
        'detect'{
            Get-DesktopDetection | ConvertTo-Json -Depth 5 -Compress
        }
        'import'{@{instance=(Read-EnhancedShortcut $Value (Get-OfficialDesktop))}|ConvertTo-Json -Depth 5 -Compress}
        'resolve'{@{instance=(Resolve-EnhancedInstance $Value (Get-OfficialDesktop) $LauncherHint)}|ConvertTo-Json -Depth 5 -Compress}
        {$_ -in @('secure','secureSocket')}{
            if(-not [IO.Path]::IsPathRooted($Value) -or -not (Test-Path -LiteralPath $Value -PathType Container)){throw 'DESKTOP_PRIVATE_DIRECTORY_INVALID'}
            $item=Get-Item -LiteralPath $Value
            if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'DESKTOP_PRIVATE_DIRECTORY_INVALID'}
            # 从实际目录读取描述符，仅更新DACL；新建描述符在重复写入时可能要求SeSecurityPrivilege。
            $acl=Get-Acl -LiteralPath $Value
            $acl.SetAccessRuleProtection($true,$false)
            foreach($existingRule in @($acl.Access)){$acl.RemoveAccessRuleSpecific($existingRule)}
            $privateSids=@([Security.Principal.WindowsIdentity]::GetCurrent().User.Value)
            if($Action -eq 'secureSocket' -and $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value -ne $privateSids[0]){throw 'DESKTOP_PRIVATE_DIRECTORY_INVALID'}
            if($Action -eq 'secure'){$privateSids+=@('S-1-5-18','S-1-5-32-544')}
            foreach($sid in $privateSids){
                $identity=New-Object Security.Principal.SecurityIdentifier($sid)
                $rule=New-Object Security.AccessControl.FileSystemAccessRule($identity,'FullControl','ContainerInherit,ObjectInherit','None','Allow')
                $acl.AddAccessRule($rule)
            }
            # Set-Acl会要求写入审计节；.NET方法仅持久化上面修改的访问控制节。
            ([IO.DirectoryInfo]$Value).SetAccessControl($acl)
            @{ok=$true}|ConvertTo-Json -Compress
        }
        'environment'{@{ws=[Environment]::GetEnvironmentVariable('CODEX_APP_SERVER_WS_URL','Process');forceCli=[Environment]::GetEnvironmentVariable('CODEX_APP_SERVER_FORCE_CLI','Process')}|ConvertTo-Json -Compress}
    }
}catch{
    # 不回传异常原文、命令行或可能含凭据的环境。
    $known=@('DESKTOP_PACKAGE_INVALID','DESKTOP_NOT_INSTALLED','DESKTOP_SHORTCUT_INVALID','DESKTOP_SHORTCUT_UNSUPPORTED','DESKTOP_ENHANCER_UNSUPPORTED','DESKTOP_PRIVATE_DIRECTORY_INVALID','DESKTOP_INSTANCE_CONFIG_INVALID','DESKTOP_INSTANCE_CONFIG_UNSUPPORTED','DESKTOP_INSTANCE_CONFIG_AMBIGUOUS')
    $code=if($_.Exception.Message -in $known){$_.Exception.Message}else{'DESKTOP_PLATFORM_FAILED'}
    @{error=$code}|ConvertTo-Json -Compress
    exit 1
}
