'use strict';
const {performance} = require('node:perf_hooks');
const {BridgeError} = require('./errors.cjs');

const MAX_PAYLOAD_BYTES = 48 * 1024;
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
function validUiTestReplayArgs(args) {
  if (!args || typeof args !== 'object' || Array.isArray(args) ||
      Object.keys(args).some(key => !['runId', 'messages'].includes(key)) ||
      typeof args.runId !== 'string' || !UUID.test(args.runId) ||
      !Array.isArray(args.messages) || args.messages.length > 200) return false;
  let total = 0;
  const ids = new Set();
  for (const message of args.messages) {
    if (!message || typeof message !== 'object' || Array.isArray(message) ||
        Object.keys(message).some(key => !['id', 'role', 'text', 'kind', 'command', 'toolState', 'toolCategory'].includes(key)) ||
        typeof message.id !== 'string' || !/^[A-Za-z0-9._:-]{1,128}$/.test(message.id) || ids.has(message.id) ||
        !['user', 'assistant'].includes(message.role) || typeof message.text !== 'string' || message.text.length > 32768) return false;
    const kind = Object.hasOwn(message, 'kind') ? message.kind : 'message';
    if (!['message', 'commentary', 'tool'].includes(kind) ||
        (kind !== 'message' && message.role !== 'assistant')) return false;
    if (kind === 'tool') {
      if (typeof message.command !== 'string' || !message.command.trim() || message.command.length > 2048 ||
          (Object.hasOwn(message, 'toolState') && !['completed', 'failed'].includes(message.toolState)) ||
          (Object.hasOwn(message, 'toolCategory') && !['command', 'file'].includes(message.toolCategory))) return false;
    } else if (Object.hasOwn(message, 'command') || Object.hasOwn(message, 'toolState') || Object.hasOwn(message, 'toolCategory')) return false;
    ids.add(message.id);
    total += message.text.length;
  }
  return total <= 262144 && Buffer.byteLength(JSON.stringify(args), 'utf8') <= MAX_PAYLOAD_BYTES;
}

/** 仅回传合成消息；不访问 Codex、会话目录、执行器或磁盘。 */
function replayUiTest(args) {
  const started = performance.now();
  if (!validUiTestReplayArgs(args)) throw new BridgeError('BAD_INPUT', '界面测试数据无效或超过 48 KiB 传输上限');
  const messages = args.messages.map(message => ({...message}));
  return {runId:args.runId, messages, desktopProcessingMs:Math.max(0, performance.now() - started)};
}

module.exports = {replayUiTest, validUiTestReplayArgs, MAX_PAYLOAD_BYTES};
