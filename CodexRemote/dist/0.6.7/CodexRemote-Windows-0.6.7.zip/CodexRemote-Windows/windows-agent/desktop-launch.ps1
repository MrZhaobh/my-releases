﻿#requires -Version 7.0
param([Parameter(Mandatory)][string]$RequestPath,[switch]$PreflightOnly)
$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$request=$null
$brokerStarted=$false
$ownedBroker=$null
function Write-LaunchState([string]$Phase,[string]$Stage,[string]$Code='',[hashtable]$Extra=@{}){
    $record=@{launchId=$request.launchId;phase=$Phase;stage=$Stage;error=$(if($Code){$Code}else{$null});instanceId=$request.instanceId;runtimeMode=$request.runtimeMode;brokerReady=$false;transportConfirmed=$false;updatedAt=[DateTimeOffset]::UtcNow.ToString('o')}
    foreach($key in $Extra.Keys){$record[$key]=$Extra[$key]}
    $temporary=$request.statusFile+'.tmp'
    [IO.File]::WriteAllText($temporary,($record|ConvertTo-Json -Depth 5),[Text.UTF8Encoding]::new($false))
    Move-Item -LiteralPath $temporary -Destination $request.statusFile -Force
}
function Read-Json([string]$Path){Get-Content -Raw -LiteralPath $Path | ConvertFrom-Json}
function Confirm-BrokerStatusFresh($Timestamp,[DateTimeOffset]$Now=[DateTimeOffset]::UtcNow){
    try{
        # ConvertFrom-Json在新版PowerShell中将ISO时间解析为DateTime；转字符串会丢失Kind和UTC时区。
        if($Timestamp -is [DateTimeOffset]){$instant=$Timestamp}
        elseif($Timestamp -is [DateTime] -and $Timestamp.Kind -ne [DateTimeKind]::Unspecified){$instant=[DateTimeOffset]::new($Timestamp)}
        elseif($Timestamp -is [string] -and $Timestamp -match '^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:\d{2})$'){
            $instant=[DateTimeOffset]::Parse($Timestamp,[Globalization.CultureInfo]::InvariantCulture)
        }else{throw 'INVALID_TIMESTAMP'}
        if($Now-$instant -gt [TimeSpan]::FromSeconds(5)){throw 'STALE_TIMESTAMP'}
    }catch{throw 'DESKTOP_BROKER_STATUS_STALE'}
}
function Test-ProcessAlive($ProcessId){
    if(($ProcessId -isnot [long] -and $ProcessId -isnot [int]) -or $ProcessId -le 0){throw 'DESKTOP_PREVIOUS_ENGINE_UNKNOWN'}
    return @(Get-Process -ErrorAction Stop | Where-Object Id -eq $ProcessId).Count -gt 0
}
function Test-PortListening([int]$Port){
    # 启动器清理PSModulePath后，PowerShell 7未必能自动发现Windows NetTCPIP模块。
    # 直接查询系统TCP监听端点，不依赖PowerShell模块，也不主动绑定或连接端口。
    try{return @([Net.NetworkInformation.IPGlobalProperties]::GetIPGlobalProperties().GetActiveTcpListeners() | Where-Object Port -eq $Port).Count -gt 0}
    catch{throw 'DESKTOP_ENGINE_INSPECTION_FAILED'}
}
function Confirm-OldEnginesStopped([string]$SelectedConfig){
    $managerRoot=Split-Path -Parent $RequestPath
    $runsRoot=Join-Path $managerRoot 'runs'
    $files=@()
    if(Test-Path -LiteralPath $runsRoot -PathType Container){$files+=@(Get-ChildItem -LiteralPath $runsRoot -Directory | ForEach-Object {Join-Path $_.FullName 'config.json'})}
    if($request.previousSharedConfigFile){$files+=[string]$request.previousSharedConfigFile}
    foreach($file in @($files|Select-Object -Unique)){
        if($SelectedConfig -and [IO.Path]::GetFullPath($file) -eq [IO.Path]::GetFullPath($SelectedConfig)){continue}
        if(-not (Test-Path -LiteralPath $file -PathType Leaf)){continue}
        $directory=Split-Path -Parent $file
        $stateFile=Join-Path $directory 'broker-status.json'
        if(-not (Test-Path -LiteralPath $stateFile -PathType Leaf)){
            $unknown=Read-Json $file
            if($unknown.socketPath -and (Test-Path -LiteralPath $unknown.socketPath)){throw 'DESKTOP_PREVIOUS_ENGINE_UNKNOWN'}
            if($unknown.url -and (Test-PortListening ([uri]$unknown.url).Port)){throw 'DESKTOP_PREVIOUS_ENGINE_UNKNOWN'}
            continue
        }
        $state=Read-Json $stateFile
        if($state.backend -ne 'owned'){throw 'DESKTOP_PREVIOUS_ENGINE_UNKNOWN'}
        # 完整清理回执已确认代理和引擎结束，记录中的PID随后可能被其他进程复用。
        # 与双PID均不存在时一致，仍检查原端口，绝不向复用PID的进程发退出请求。
        if($state.stopped -eq $true -and $state.cleanup.ok -eq $true -and $state.engineCleanup.ok -eq $true -and $state.engine.running -eq $false -and $state.engineCleanup.running -eq $false){
            $oldConfig=Read-Json $file
            if(Test-PortListening ([uri]$oldConfig.url).Port){throw 'DESKTOP_PREVIOUS_ENGINE_UNKNOWN'}
            continue
        }
        $brokerAlive=Test-ProcessAlive $state.pid
        # 创建引擎进程前失败的broker没有engine PID；仅在退出/清理均确认时接受此状态。
        $neverStarted=$null -eq $state.engine.pid -and $state.stopped -eq $true -and $state.cleanup.ok -eq $true -and $state.engineCleanup.ok -eq $true -and $state.engine.started -eq $false -and $state.engine.startedByUs -eq $false -and $state.engine.running -eq $false
        $engineAlive=if($neverStarted){$false}else{Test-ProcessAlive $state.engine.pid}
        if(-not $brokerAlive -and -not $engineAlive){$oldConfig=Read-Json $file;if(Test-PortListening ([uri]$oldConfig.url).Port){throw 'DESKTOP_PREVIOUS_ENGINE_UNKNOWN'};continue}
        # 只向由本管理器创建的run请求优雅退出；外部已导入的服务只报告阻塞。
        $prefix=[IO.Path]::GetFullPath($runsRoot).TrimEnd('\')+'\'
        if(-not [IO.Path]::GetFullPath($file).StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)) {throw 'DESKTOP_PREVIOUS_ENGINE_RUNNING'}
        $config=Read-Json $file
        $broker=Get-CimInstance Win32_Process -Filter "ProcessId = $($state.pid)" -ErrorAction SilentlyContinue
        if(-not $broker -or -not $broker.ExecutablePath -or [IO.Path]::GetFullPath([string]$broker.ExecutablePath) -ne [IO.Path]::GetFullPath([string]$request.nodeExecutable) -or
            -not ([string]$broker.CommandLine).Contains([string]$file) -or -not ([string]$broker.CommandLine).Contains((Join-Path $request.runtimeRoot 'run-broker.cjs'))) {throw 'DESKTOP_PREVIOUS_ENGINE_UNKNOWN'}
        New-Item -ItemType File -Path (Join-Path $directory 'stop-broker.request') -Force|Out-Null
        $deadline=[DateTimeOffset]::UtcNow.AddSeconds(18)
        while((Test-ProcessAlive $state.pid) -or (-not $neverStarted -and (Test-ProcessAlive $state.engine.pid)) -or (Test-PortListening ([uri]$config.url).Port)){
            if([DateTimeOffset]::UtcNow -gt $deadline){throw 'DESKTOP_PREVIOUS_ENGINE_RUNNING'}
            Start-Sleep -Milliseconds 200
        }
    }
}
function Assert-DesktopLaunchSelection($SelectedRequest,$SelectedConfig){
    if($SelectedRequest.runtimeMode -notin @('desktop-bridge','shared-engine') -or $SelectedRequest.instance.kind -notin @('official','sidebar-lite')){throw 'DESKTOP_REQUEST_INVALID'}
    $selectedIsolation=Read-IsolatedDesktopSelection $SelectedRequest.instance
    $SelectedConfigSelection=Read-IsolatedDesktopSelection $SelectedConfig
    if([bool]$SelectedConfigSelection -ne [bool]$selectedIsolation){throw 'DESKTOP_SELECTION_CHANGED'}
    if($selectedIsolation){foreach($field in @('instanceConfigPath','instanceConfigFingerprint','instanceConfigModulePath','instanceConfigModuleFingerprint','isolatedCodexHome','apiKeyEnvironmentVariable','enhancedRuntimeDirectory')){if([string]$SelectedConfig.$field -cne [string]$SelectedRequest.instance.$field){throw 'DESKTOP_SELECTION_CHANGED'}}}
    if($SelectedRequest.runtimeMode -eq 'desktop-bridge' -and $SelectedConfig.originalDesktopEnvironment.ws){throw 'DESKTOP_BRIDGE_ENVIRONMENT_CONFLICT'}
    if([string]$SelectedConfig.desktopExecutable -ine [string]$SelectedRequest.instance.desktopExecutable){throw 'DESKTOP_SELECTION_CHANGED'}
    if($SelectedRequest.instance.kind -eq 'sidebar-lite'){
        if([string]$SelectedConfig.enhancedLauncher -ine [string]$SelectedRequest.instance.enhancedLauncher -or [string]$SelectedConfig.enhancedProfileDirectory -ine [string]$SelectedRequest.instance.enhancedProfileDirectory){throw 'DESKTOP_SELECTION_CHANGED'}
        if((Get-FileHash -LiteralPath $SelectedRequest.instance.enhancedLauncher -Algorithm SHA256).Hash -ne $SelectedRequest.instance.scriptFingerprint -or
           (Get-FileHash -LiteralPath $SelectedRequest.instance.launcherPath -Algorithm SHA256).Hash -ne $SelectedRequest.instance.launcherFingerprint){throw 'DESKTOP_SELECTION_CHANGED'}
    }elseif($SelectedConfig.enhancedLauncher -or $SelectedConfig.enhancedProfileDirectory){throw 'DESKTOP_SELECTION_CHANGED'}
    $endpoint=[uri]$SelectedConfig.url
    if($endpoint.Scheme -ne 'ws' -or $endpoint.Host -ne '127.0.0.1' -or $endpoint.Port -lt 1 -or $endpoint.AbsolutePath -ne '/rpc' -or $endpoint.Query -or $endpoint.Fragment -or $endpoint.UserInfo -or [string]$SelectedConfig.token -notmatch '^[A-Za-z0-9_-]{43}$'){throw 'DESKTOP_SHARED_CONFIG_INVALID'}
    if($SelectedRequest.runtimeMode -eq 'shared-engine'){
        if($SelectedConfig.engineMode -ne 'owned' -or [string]$SelectedConfig.binary -ine [string]$SelectedRequest.instance.binary -or -not [IO.Path]::IsPathRooted([string]$SelectedConfig.binary) -or -not [IO.Path]::IsPathRooted([string]$SelectedConfig.socketPath)){throw 'DESKTOP_SHARED_CONFIG_INVALID'}
    }else{
        $original=$SelectedConfig.originalDesktopEnvironment
        if($null -eq $original -or $null -eq $original.PSObject.Properties['ws'] -or $null -eq $original.PSObject.Properties['forceCli']){throw 'DESKTOP_BRIDGE_ENVIRONMENT_CONFLICT'}
        foreach($value in @($original.ws,$original.forceCli)){if($null -ne $value -and ($value -isnot [string] -or $value.Length -gt 8192 -or $value -match '[\x00\r\n]')){throw 'DESKTOP_BRIDGE_ENVIRONMENT_CONFLICT'}}
    }
    if($SelectedRequest.instance.kind -eq 'sidebar-lite'){
        if(-not [IO.Path]::IsPathFullyQualified([string]$SelectedConfig.enhancedProfileDirectory) -or [string]$SelectedConfig.enhancedProfileDirectory -match '["\x00-\x1f\x7f]' -or ($SelectedConfig.enhancedPort -isnot [int] -and $SelectedConfig.enhancedPort -isnot [long]) -or $SelectedConfig.enhancedPort -lt 1 -or $SelectedConfig.enhancedPort -gt 65535){throw 'DESKTOP_SELECTION_CHANGED'}
    }elseif($null -ne $SelectedConfig.PSObject.Properties['enhancedPort']){throw 'DESKTOP_SELECTION_CHANGED'}
}
function Confirm-SelectedDesktopAndOldEngines($SelectedRequest,$SelectedConfig,[string]$SelectedFile){
    # 身份/模式/环境校验全部先于任何旧引擎stop请求。
    Assert-DesktopLaunchSelection $SelectedRequest $SelectedConfig
    try{Confirm-OldEnginesStopped $(if($SelectedRequest.runtimeMode -eq 'shared-engine'){$SelectedFile}else{''})}
    catch{if($_.Exception.Message -match '^DESKTOP_PREVIOUS_ENGINE_(RUNNING|UNKNOWN)$'){throw};throw 'DESKTOP_ENGINE_INSPECTION_FAILED'}
}
try{
    $RequestPath=(Resolve-Path -LiteralPath $RequestPath).Path
    $request=Read-Json $RequestPath
    $managerRoot=Split-Path -Parent $RequestPath
    if($request.schema -ne 1 -or [string]$request.launchId -notmatch '^[a-f0-9-]{36}$' -or [string]$request.instanceId -notmatch '^[a-f0-9]{24}$' -or
       $request.runtimeMode -notin @('desktop-bridge','shared-engine') -or [IO.Path]::GetDirectoryName([IO.Path]::GetFullPath([string]$request.statusFile)) -ne $managerRoot -or
       [IO.Path]::GetFileName([string]$request.statusFile) -ne ('launch-'+$request.launchId+'.json')){throw 'DESKTOP_REQUEST_INVALID'}
    . (Join-Path $request.runtimeRoot 'packaged-desktop-launch.ps1')
    . (Join-Path $request.runtimeRoot 'enhanced-desktop-launch.ps1')
    . (Join-Path $request.runtimeRoot 'isolated-desktop-config.ps1')
    . (Join-Path $request.runtimeRoot 'broker-identity.ps1')
    $isolatedSelection=Read-IsolatedDesktopSelection $request.instance
    Assert-PackagedDesktopPrivatePath $RequestPath
    Assert-PackagedDesktopPrivatePath $managerRoot
    try{$launchLock=[IO.File]::Open((Join-Path $managerRoot 'launch.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)}catch{throw 'DESKTOP_LAUNCH_BUSY'}
    Write-LaunchState 'starting' 'checking_desktop'
    if(Get-Process -Name ChatGPT -ErrorAction SilentlyContinue){Write-LaunchState 'needs_exit' 'needs_desktop_exit' 'DESKTOP_EXISTING_PROCESS';exit 0}
    if($PreflightOnly){Write-LaunchState 'idle' 'checking_desktop' '' @{preflightOnly=$true};exit 0}
    $configPath=[string]$request.sharedEngineConfigFile
    $temporaryBridge=-not $configPath
    if($temporaryBridge){
        if($request.runtimeMode -ne 'desktop-bridge'){throw 'DESKTOP_SHARED_CONFIG_INVALID'}
        $configPath=Join-Path $managerRoot ('bridge-'+$request.launchId+'.json')
        $config=[pscustomobject]@{url='ws://127.0.0.1:1/rpc';token=('x'*43);desktopExecutable=$request.instance.desktopExecutable;originalDesktopEnvironment=[pscustomobject]@{ws=$null;forceCli=$null}}
        if($request.instance.kind -eq 'sidebar-lite'){
            $config|Add-Member -NotePropertyMembers @{enhancedLauncher=$request.instance.enhancedLauncher;enhancedProfileDirectory=$request.instance.enhancedProfileDirectory;enhancedPort=1}
            foreach($field in @('instanceConfigPath','instanceConfigFingerprint','instanceConfigModulePath','instanceConfigModuleFingerprint','isolatedCodexHome','apiKeyEnvironmentVariable','enhancedRuntimeDirectory')){if($null -ne $request.instance.PSObject.Properties[$field]){$config|Add-Member -NotePropertyName $field -NotePropertyValue $request.instance.$field}}
        }
    }else{$config=Read-Json $configPath}
    Write-LaunchState 'starting' 'checking_previous_engine'
    try{Confirm-SelectedDesktopAndOldEngines $request $config $(if($temporaryBridge){''}else{$configPath})}
    catch{if($_.Exception.Message -like 'DESKTOP_PREVIOUS_ENGINE_*'){Write-LaunchState 'needs_exit' 'needs_engine_exit' $_.Exception.Message;exit 0};throw}
    if($request.instance.kind -eq 'sidebar-lite'){
        New-Item -ItemType Directory -Path $config.enhancedProfileDirectory -Force|Out-Null
        if($temporaryBridge){$listener=[Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,0);$listener.Start();try{$config.enhancedPort=$listener.LocalEndpoint.Port}finally{$listener.Stop()}}
    }
    if($temporaryBridge){[IO.File]::WriteAllText($configPath,($config|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))}
    if($request.runtimeMode -eq 'shared-engine'){
        if($config.engineMode -ne 'owned'){throw 'DESKTOP_SHARED_CONFIG_INVALID'}
        $directory=Split-Path -Parent $configPath;$brokerFile=Join-Path $directory 'broker-status.json'
        $state=if(Test-Path -LiteralPath $brokerFile){Read-Json $brokerFile}else{$null}
        $endpoint=[uri]$config.url
        if($state -and ((Test-ProcessAlive $state.pid) -or (Test-ProcessAlive $state.engine.pid))){
            # 复用既有broker必须仍是同一条精确配置的受管进程，旧状态不能代替身份核验。
            $broker=Get-CimInstance Win32_Process -Filter "ProcessId = $($state.pid)" -ErrorAction SilentlyContinue
            if(-not (Test-SelectedManagedBroker $broker $configPath $request $RequestPath) -or
                $state.backend -ne 'owned' -or -not $state.ready -or -not $state.engine.running){throw 'DESKTOP_PREVIOUS_ENGINE_UNKNOWN'}
        }else{
            if((Test-PortListening $endpoint.Port) -or (Test-Path -LiteralPath (Join-Path $directory 'stop-broker.request')) -or (Test-Path -LiteralPath $config.socketPath)){throw 'DESKTOP_SHARED_RUN_STALE'}
            Write-LaunchState 'starting' 'starting_broker'
            $ownedBroker=Start-Process -FilePath $request.nodeExecutable -ArgumentList @('"'+(Join-Path $request.runtimeRoot 'run-broker.cjs')+'"','"'+$configPath+'"') -WindowStyle Hidden -PassThru
            $brokerStarted=$true
            Write-LaunchState 'starting' 'waiting_broker'
            $deadline=[DateTimeOffset]::UtcNow.AddSeconds(45)
            do{
                Start-Sleep -Milliseconds 200;$ownedBroker.Refresh()
                if($ownedBroker.HasExited){throw 'DESKTOP_BROKER_EXITED'}
                $state=if(Test-Path -LiteralPath $brokerFile){Read-Json $brokerFile}else{$null}
            }until(($state.ready -and $state.pid -eq $ownedBroker.Id) -or [DateTimeOffset]::UtcNow -gt $deadline)
            if(-not $state.ready -or $state.pid -ne $ownedBroker.Id -or $state.backend -ne 'owned' -or -not $state.engine.running){throw 'DESKTOP_BROKER_NOT_READY'}
        }
        # run-broker的ready已包含native proxy initialize/thread/loaded/list门禁。
        Confirm-BrokerStatusFresh $state.at
        $health=Invoke-RestMethod -Uri ('http://127.0.0.1:'+$endpoint.Port+'/health') -TimeoutSec 3
        if($health.ok -ne $true -or $health.service -ne 'codex-shared-engine-broker'){throw 'DESKTOP_BROKER_NOT_READY'}
    }
    Write-LaunchState 'starting' 'starting_desktop' '' @{brokerReady=($request.runtimeMode -eq 'shared-engine')}
    if(Get-Process -Name ChatGPT -ErrorAction SilentlyContinue){Write-LaunchState 'needs_exit' 'needs_desktop_exit' 'DESKTOP_EXISTING_PROCESS';exit 0}
    $mode=if($request.runtimeMode -eq 'shared-engine'){'Shared'}else{'Original'}
    $receipt=if($request.instance.kind -eq 'sidebar-lite'){Start-EnhancedDesktop -ConfigPath $configPath -Mode $mode}else{Start-PackagedDesktop -ConfigPath $configPath -Mode $mode}
    if(-not $receipt.ok -or $receipt.pid -le 0){throw 'DESKTOP_START_NOT_CONFIRMED'}
    if($request.runtimeMode -eq 'shared-engine'){
        Write-LaunchState 'awaiting_connection' 'awaiting_connection' '' @{brokerReady=$true;desktopPid=$receipt.pid}
    }else{Write-LaunchState 'started' 'desktop_started' '' @{desktopPid=$receipt.pid}}
}catch{
    if($request){
        $known=@('DESKTOP_REQUEST_INVALID','DESKTOP_LAUNCH_BUSY','DESKTOP_SELECTION_CHANGED','DESKTOP_SHARED_CONFIG_INVALID','DESKTOP_PREVIOUS_ENGINE_UNKNOWN','DESKTOP_ENGINE_INSPECTION_FAILED','DESKTOP_SHARED_RUN_STALE','DESKTOP_BROKER_EXITED','DESKTOP_BROKER_NOT_READY','DESKTOP_BROKER_STATUS_STALE','DESKTOP_START_NOT_CONFIRMED','DESKTOP_BRIDGE_ENVIRONMENT_CONFLICT')
        $code=if($_.Exception.Message -in $known){$_.Exception.Message}else{'DESKTOP_LAUNCH_FAILED'}
        try{Write-LaunchState 'failed' 'failed' $code}catch{}
        # 失败时仅请求本次spawn的broker优雅退出，不结束任何桌面或daemon。
        if($brokerStarted -and $ownedBroker){try{New-Item -ItemType File -Path (Join-Path (Split-Path -Parent $request.sharedEngineConfigFile) 'stop-broker.request') -Force|Out-Null}catch{}}
    }
    exit 1
}finally{if($launchLock){$launchLock.Dispose()}}
