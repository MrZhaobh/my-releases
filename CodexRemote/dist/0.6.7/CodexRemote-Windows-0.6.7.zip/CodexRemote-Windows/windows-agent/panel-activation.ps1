﻿function Open-ControlPanelInstance([string]$Name='Local\CodexRemote-WindowsTray-v060') {
    $mutex=New-Object Threading.Mutex($false,$Name)
    $owned=$false
    try {$owned=$mutex.WaitOne(0)} catch [Threading.AbandonedMutexException] {$owned=$true}
    if($owned){
        try {$signal=New-Object Threading.EventWaitHandle($false,[Threading.EventResetMode]::AutoReset,($Name+'-Open'))}
        catch {$mutex.ReleaseMutex();$mutex.Dispose();throw}
        return [pscustomobject]@{owned=$true;mutex=$mutex;signal=$signal}
    }
    try {
        # 首个窗口可能仍在初始化；事件保留到其消息循环就绪后再处理。
        for($attempt=0;$attempt -lt 30;$attempt++){
            $signal=$null
            try {$signal=[Threading.EventWaitHandle]::OpenExisting($Name+'-Open')}
            catch [Threading.WaitHandleCannotBeOpenedException] {Start-Sleep -Milliseconds 100;continue}
            try {[void]$signal.Set();return [pscustomobject]@{owned=$false;mutex=$null;signal=$null}}
            finally {$signal.Dispose()}
        }
        throw '已有连接中心仍在初始化，或来自旧版本。可从系统托盘打开；稍后再试。'
    } finally {$mutex.Dispose()}
}

function Show-ControlPanelOnRequest($Window,[Threading.EventWaitHandle]$Signal) {
    if($Signal -and $Signal.WaitOne(0)){
        $Window.Show()
        $Window.WindowState='Normal'
        [void]$Window.Activate()
        return $true
    }
    return $false
}
