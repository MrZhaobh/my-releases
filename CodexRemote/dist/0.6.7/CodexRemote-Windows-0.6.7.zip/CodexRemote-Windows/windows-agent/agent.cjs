'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{execFileSync}=require('node:child_process');
const {BridgeError}=require('./errors.cjs');
const {RegistrationQueue}=require('./registration.cjs');
const {BridgeSocket}=require('./bridge-socket.cjs');
const {ReadCache}=require('./read-cache.cjs');
const {replayUiTest}=require('./ui-test-replay.cjs');
const {MAX_INDEX_BYTES}=require('./question-index.cjs');
const {parseReply}=require('./async-question-reply.cjs');
const {normalizeRelayUrl,timeouts,journalPath}=require('./connection-config.cjs');
const gzip=require('node:util').promisify(require('node:zlib').gzip);
const RESULT_GZIP_THRESHOLD=64*1024,RESULT_BODY_LIMIT=8*1024*1024+64*1024;
const SUPPORTED_OPERATIONS=new Set(['threads','statuses','projects','read','media','visualization','attachment','ping','progress','models','usage','create','send','reconcile','interrupt','importCandidates','importThread','respondApproval','activateThread','queryResult','uiTestReplay']);
const BACKGROUND_OPERATIONS=new Set(['media','visualization','attachment','usage','models']);
const OPERATION_ERROR_NAMES=new Set(['Error','TypeError','RangeError','SyntaxError','ReferenceError','URIError','EvalError','AggregateError','BridgeError']);
const OPERATION_FAILURE_STAGES=new Set(['dispatch','runtime','journal','journal-read-overlay','result-preparation']);
const OPERATION_ERROR_CODES=new Set([
 'DESKTOP_ERROR','RPC_ERROR','RPC_TIMEOUT','RPC_DISCONNECTED','ERR_SQLITE_ERROR','SQLITE_ERROR','SQLITE_BUSY','SQLITE_LOCKED',
 'BAD_INPUT','NOT_FOUND','BUSY','CONFLICT','UNCERTAIN','DISPATCH_MISMATCH','BACKEND_CHANGED','CACHE_MISS','OFFLINE',
 'DESKTOP_OFFLINE','CONTEXT_REQUIRED','DISCOVERY_FAILED','BINARY_NOT_FOUND','PROCESS_LIMIT','RUNTIME_EXITED',
 'INVALID_HISTORY','RECOVERY_FAILED','RESPONSE_TOO_LARGE','IMAGE_TOO_LARGE','UNSUPPORTED_IMAGE','IMAGE_MISMATCH',
 'MODELS_UNAVAILABLE','USAGE_UNAVAILABLE','MODEL_UNAVAILABLE','MODEL_MISMATCH','INVALID_MODEL','INVALID_THINKING',
 'CURSOR_EXPIRED','TURN_MISMATCH','TURN_NOT_ACTIVE','TURN_STEER_REJECTED','TURN_START_REJECTED','STEER_UNSUPPORTED',
 'UNSUPPORTED','UNSUPPORTED_CAPABILITY','APPROVAL_EXPIRED','APPROVAL_STALE','APPROVAL_NOT_FOUND','APPROVAL_CONFLICT',
 'APPROVAL_UNSUPPORTED','INVALID_APPROVAL','APPROVAL_SEND_FAILED','SHARED_CONNECT_FAILED','SHARED_CONFIG_INVALID',
 'DELIVERY_UNKNOWN','CONNECTION_LIMIT','CLOSED','REQUEST_CONFLICT','LEGACY_JOURNAL_INVALID','INVALID_ANSWERS','QUESTION_EXPIRED','QUESTION_ALREADY_ANSWERED',
]);
// 诊断只记录阶段与受限标识，原生错误正文、调用参数及凭据不进入日志。
function operationFailureFields(job,stage,error){
 const fields={operation:SUPPORTED_OPERATIONS.has(job.operation)?job.operation:'unknown',stage:OPERATION_FAILURE_STAGES.has(stage)?stage:'dispatch',
  code:OPERATION_ERROR_CODES.has(error?.code)?error.code:'DESKTOP_ERROR',
  errorName:OPERATION_ERROR_NAMES.has(error?.name)?error.name:'Error'};
 if(Number.isInteger(error?.rpcCode)&&error.rpcCode>=-2147483648&&error.rpcCode<=2147483647)fields.rpcCode=error.rpcCode;
 const threadId=job.arguments?.threadId;
 if(typeof threadId==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(threadId))fields.threadId=threadId;
 return fields;
}
const backgroundJob=job=>BACKGROUND_OPERATIONS.has(job.operation)||(job.operation==='read'&&job.arguments?.questionIndex===true);
const URGENT_EVENT_STATES=new Set(['completed','cancelled','interrupted','failed','error','waiting','declined']);
const urgentEvent=frame=>frame.type==='approval.upsert'||frame.error!=null||URGENT_EVENT_STATES.has(frame.turnStatus)||URGENT_EVENT_STATES.has(typeof frame.status==='object'?frame.status?.type:frame.status)||['waiting','failed','cancelled'].includes(frame.activity?.kind)||frame.item?.error!=null||['failed','error','waiting','cancelled','interrupted','declined'].includes(frame.item?.status);
function atomic(file,data){fs.mkdirSync(path.dirname(file),{recursive:true});const tmp=file+'.'+process.pid+'.tmp';fs.writeFileSync(tmp,JSON.stringify(data,null,2));fs.renameSync(tmp,file);}
function configFrom(file){const config=JSON.parse(fs.readFileSync(file,'utf8').replace(/^\uFEFF/,''));if(config.bridgeKeyFile){const raw=execFileSync('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',path.join(__dirname,'read-secret.ps1'),'-Path',config.bridgeKeyFile],{windowsHide:true,encoding:'utf8',timeout:10000});config.bridgeKey=JSON.parse(raw).bridgeKey;}if(config.bridgeTokenFile){const encrypted=fs.readFileSync(config.bridgeTokenFile,'utf8');const raw=execFileSync('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',path.join(__dirname,'dpapi.ps1'),'-Action','unprotect'],{windowsHide:true,encoding:'utf8',timeout:10000,input:encrypted});config.bridgeToken=JSON.parse(raw).bridgeToken;}config.bridgeKey??=config.bridgeToken;
 config.relayUrl=normalizeRelayUrl(config.baseUrl??config.relayUrl);Object.assign(config,timeouts(config));
 if(typeof config.bridgeKey!=='string'||config.bridgeKey.length<32)throw Error('Bridge key is missing');config.relayUrl=config.relayUrl.replace(/\/+$/,'');config.deviceId??='windows-main';return config;}
class Journal{
 constructor(file,{registerDesktop=true,runtimeKey='legacy'}={}){this.registerDesktop=registerDesktop;this.runtimeKey=runtimeKey;this.activeMutations=new Set();fs.mkdirSync(path.dirname(file),{recursive:true});const{DatabaseSync}=require('node:sqlite');this.db=new DatabaseSync(file);this.db.exec('PRAGMA synchronous=FULL; PRAGMA busy_timeout=1000; CREATE TABLE IF NOT EXISTS mutations(id TEXT PRIMARY KEY,hash TEXT NOT NULL,state TEXT NOT NULL,at INTEGER NOT NULL,result TEXT,code TEXT); CREATE TABLE IF NOT EXISTS submissions(id TEXT PRIMARY KEY,thread_id TEXT NOT NULL,prompt TEXT NOT NULL,turn_id TEXT,before_turn_id TEXT,at INTEGER NOT NULL); CREATE INDEX IF NOT EXISTS submissions_thread ON submissions(thread_id); CREATE TABLE IF NOT EXISTS metadata(key TEXT PRIMARY KEY,value TEXT)');
  this.registrations=new RegistrationQueue(this.db);
  if(!this.db.prepare('PRAGMA table_info(mutations)').all().some(column=>column.name==='runtime_key'))this.db.exec('ALTER TABLE mutations ADD COLUMN runtime_key TEXT');
  if(!this.db.prepare('PRAGMA table_info(mutations)').all().some(column=>column.name==='requester_id'))this.db.exec('ALTER TABLE mutations ADD COLUMN requester_id TEXT');
  if(!this.db.prepare('PRAGMA table_info(submissions)').all().some(column=>column.name==='client_message_id'))this.db.exec('ALTER TABLE submissions ADD COLUMN client_message_id TEXT');
  this.db.exec('CREATE TABLE IF NOT EXISTS async_question_claims(thread_id TEXT NOT NULL,call_id TEXT NOT NULL,question_index INTEGER NOT NULL,request_id TEXT NOT NULL,PRIMARY KEY(thread_id,call_id,question_index))');
  const legacy=file.replace(/\.sqlite$/,'.json');if(legacy!==file&&fs.existsSync(legacy)&&!this.db.prepare('SELECT value FROM metadata WHERE key=?').get('legacy-json-imported')){
   if(fs.statSync(legacy).size>8*1024*1024)throw new BridgeError('LEGACY_JOURNAL_INVALID','旧防重记录过大，已停止启动以保留保护');
   const entries=Object.entries(JSON.parse(fs.readFileSync(legacy,'utf8')));
   for(const[id,row]of entries)if(id.length>100||!/^[a-f0-9]{64}$/.test(row.hash??'')||!['pending','done'].includes(row.state)||row.state==='done'&&typeof row.result!=='object')throw new BridgeError('LEGACY_JOURNAL_INVALID','旧防重记录无效，已停止启动以保留保护');
   this.db.exec('BEGIN');try{const insert=this.db.prepare('INSERT OR IGNORE INTO mutations(id,hash,state,at,result,code) VALUES(?,?,?,?,?,?)');for(const[id,row]of entries)insert.run(id,row.hash,row.state,row.at??Date.now(),row.state==='done'?JSON.stringify(row.result):null,row.code??null);this.db.prepare('INSERT INTO metadata(key,value) VALUES(?,?)').run('legacy-json-imported','true');this.db.exec('COMMIT')}catch(e){this.db.exec('ROLLBACK');throw e;}
  }
 }
 async execute(job,fn){
  const writing=['create','send','reconcile','interrupt','importThread','respondApproval','activateThread'].includes(job.operation);if(!writing)return fn();
  if(typeof job.id!=='string'||job.id.length>100)throw new BridgeError('BAD_INPUT','请求标识无效');
  const hash=crypto.createHash('sha256').update(JSON.stringify({operation:job.operation,arguments:job.arguments})).digest('hex');
  const prior=this.db.prepare('SELECT hash,state,result,runtime_key,requester_id FROM mutations WHERE id=?').get(job.id);if(prior){if(prior.requester_id==null&&job.requesterId!=null)throw new BridgeError('UNCERTAIN','旧请求没有手机归属，不能返回旧结果或重新执行；请核对原会话');if(prior.requester_id!=null&&prior.requester_id!==(job.requesterId??null))throw new BridgeError('UNCERTAIN','原请求结果不能由当前手机确认；请核对原会话，不要重新提交');if((prior.runtime_key??'legacy')!==this.runtimeKey)throw new BridgeError('BACKEND_CHANGED','此请求属于原运行实例，请核对原会话；不会转交新模式执行');if(prior.hash!==hash)throw new BridgeError('CONFLICT','请求标识对应的内容不同');if(prior.state==='done')return JSON.parse(prior.result);throw new BridgeError('UNCERTAIN','上次请求结果不确定，请检查会话列表和历史，勿自动重发');}
  const reply=job.operation==='send'?parseReply(job.arguments?.prompt):null;
  const insertMutation=()=>this.db.prepare('INSERT INTO mutations(id,hash,state,at,runtime_key,requester_id) VALUES(?,?,?,?,?,?)').run(job.id,hash,'pending',Date.now(),this.runtimeKey,job.requesterId??null);
  if(reply){
   this.db.exec('BEGIN IMMEDIATE');
   try{
    for(const entry of reply.entries){const index=JSON.parse(entry.questionItemId)[2];if(this.db.prepare('SELECT request_id FROM async_question_claims WHERE thread_id=? AND call_id=? AND question_index=?').get(job.arguments.threadId,reply.callId,index))throw new BridgeError('QUESTION_ALREADY_ANSWERED','该问题已有提交记录，请核对原会话，不要重复提交。');}
    insertMutation();for(const entry of reply.entries)this.db.prepare('INSERT INTO async_question_claims(thread_id,call_id,question_index,request_id) VALUES(?,?,?,?)').run(job.arguments.threadId,reply.callId,JSON.parse(entry.questionItemId)[2],job.id);
    this.db.exec('COMMIT');
   }catch(error){this.db.exec('ROLLBACK');throw error;}
  }else insertMutation();
  this.activeMutations.add(job.id);
  try{const raw=await fn();const{_submission,...result}=raw;
   if(this.registerDesktop&&job.operation==='create'&&/^[a-f0-9-]{36}$/i.test(result.threadId??''))try{this.registrations.schedule(result.threadId,job.arguments.projectId??null)}catch{result.desktopRegistration='pending';result.desktopRegistrationWarning='会话已创建，桌面同步待核对；可在会话中重试。'}
   if(this.registerDesktop&&job.operation==='reconcile'&&result.desktopRegistration==='ready')this.db.prepare("UPDATE registrations SET state='done',next_at=NULL,last_code=NULL WHERE thread_id=? AND state='pending'").run(result.threadId);
   if(_submission)this.db.prepare('INSERT OR REPLACE INTO submissions(id,thread_id,prompt,turn_id,before_turn_id,at,client_message_id) VALUES(?,?,?,?,?,?,?)').run(job.id,result.threadId,_submission.prompt,_submission.turnId,_submission.beforeTurnId,Date.now(),_submission.clientUserMessageId??null);
   this.db.prepare('UPDATE mutations SET state=?,at=?,result=? WHERE id=?').run('done',Date.now(),JSON.stringify(result),job.id);return result}catch(error){
   if(['BUSY','BAD_INPUT','DESKTOP_OFFLINE','CONTEXT_REQUIRED','NOT_FOUND','DISCOVERY_FAILED','INVALID_MODEL','INVALID_THINKING','MODELS_UNAVAILABLE','MODEL_UNAVAILABLE','MODEL_MISMATCH','BINARY_NOT_FOUND','PROCESS_LIMIT','TURN_NOT_ACTIVE','INVALID_ANSWERS','QUESTION_EXPIRED','QUESTION_ALREADY_ANSWERED',...(reply?['IPC_METHOD_UNSUPPORTED','IPC_VERSION_UNSUPPORTED','UNSUPPORTED_CAPABILITY']:[]),...(job.operation==='activateThread'?['UNSUPPORTED_CAPABILITY']:[])].includes(error.code)){this.db.prepare('DELETE FROM async_question_claims WHERE request_id=?').run(job.id);this.db.prepare('DELETE FROM mutations WHERE id=?').run(job.id);}
   else this.db.prepare('UPDATE mutations SET code=? WHERE id=?').run(error.code??'DESKTOP_ERROR',job.id);
   throw error;
  }finally{this.activeMutations.delete(job.id);}
 }
 queryResult(requestId,requesterId){
  if(typeof requestId!=='string'||!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(requestId)||typeof requesterId!=='string'||!requesterId)throw new BridgeError('BAD_INPUT','结果查询参数无效');
  const row=this.db.prepare('SELECT state,result,code,runtime_key,requester_id FROM mutations WHERE id=?').get(requestId);
  if(!row||row.requester_id==null||row.requester_id!==requesterId)return{requestId,state:'unknown'};
  if((row.runtime_key??'legacy')!==this.runtimeKey)return{requestId,state:'uncertain',code:'BACKEND_CHANGED'};
  if(row.state==='done'){const result=JSON.parse(row.result);return{requestId,state:'done',result:result?.threadId?this.submissionReceipt(result,requestId):result};}
  return{requestId,state:this.activeMutations.has(requestId)?'pending':'uncertain'};
 }
 submissionReceipt(result,requestId){
  const row=this.db.prepare('SELECT turn_id FROM submissions WHERE id=? AND thread_id=?').get(requestId,result.threadId);
  return{...result,clientRequestId:requestId,turnId:row?.turn_id??null};
 }
 addRegistration(result,threadId){
  if(!this.registerDesktop)return result;
  const registration=this.db.prepare('SELECT state FROM registrations WHERE thread_id=?').get(threadId);
  if(registration&&registration.state!=='cancelled')result.desktopRegistration=registration.state==='done'?'ready':'pending';
  return result;
 }
 addSubmissions(history){
  this.addRegistration(history,history.id);
  const rows=this.db.prepare('SELECT id,prompt,turn_id,before_turn_id,client_message_id FROM submissions WHERE thread_id=? ORDER BY at').all(history.id);
  for(const row of rows){const turn=row.turn_id?history.turns.find(t=>t.id===row.turn_id):null;
   if(turn){
    // 同回合steer只使用原生clientId逐项确认，不能按相同文字猜测。
    if(row.client_message_id){if(this.registerDesktop&&row.before_turn_id!==row.turn_id)turn.clientRequestId=row.id;const item=turn.items.find(item=>item.role==='user'&&item.clientRequestId===row.client_message_id);if(item)item.clientRequestId=row.id;continue;}
    turn.clientRequestId=row.id;
    if(history.source!=='desktop-bridge-ipc'&&!turn.items.some(i=>i.role==='user'))turn.items.unshift({type:'userMessage',role:'user',text:row.prompt,phase:null,source:'client-submission'});
   }
  }return history;
 }
 close(){this.db.close()}
}
class Agent{
 constructor(config,{runtime,fetchImpl=fetch,clock=()=>Date.now(),statusCheckIntervalMs=10000}={}){this.config={...config,...timeouts(config)};this.runtime=runtime??require('./runtime-factory.cjs').createRuntime(config);if(config.readCache===true&&typeof this.runtime.execute==='function')this.runtime=new ReadCache(this.runtime,{deviceId:config.deviceId});this.fetch=fetchImpl;this.clock=clock;this.statusCheckIntervalMs=statusCheckIntervalMs;this.stopping=false;this.journal=new Journal(journalPath(config),{registerDesktop:(config.runtimeMode??'desktop-bridge')==='desktop-bridge',runtimeKey:this.runtime.instanceId?`${config.runtimeMode??'desktop-bridge'}:${this.runtime.instanceId}`:'legacy'});this.abort=null;this.controllers=new Set();this.eventQueue=[];this.eventBytes=0;this.eventTask=null;this.eventTimer=null;this.lastLogKey=null;this.lockFile=path.join(config.dataDirectory,'agent.lock');this.desktopStatus={connected:false,pid:null,error:'尚未检查 Codex 引擎状态'};this.desktopCheckedAt=null;this.lastPollAt=null;this.statusCheckTask=null;this.statusCheckCancel=null;this.statusCheckTimer=null;this.relayConnected=false;this.runtime.setEventListener?.(event=>this.enqueueEvent(event));}
 log(event,fields={}){try{const file=path.join(this.config.dataDirectory,'events.log'),line=JSON.stringify({at:new Date().toISOString(),event,...fields})+'\n';if(fs.existsSync(file)&&fs.statSync(file).size+Buffer.byteLength(line)>1024*1024){if(fs.existsSync(file+'.previous'))fs.unlinkSync(file+'.previous');fs.renameSync(file,file+'.previous')}fs.appendFileSync(file,line)}catch{}}
 lock(){fs.mkdirSync(this.config.dataDirectory,{recursive:true});try{const old=JSON.parse(fs.readFileSync(this.lockFile,'utf8'));if(old.pid&&old.pid!==process.pid){try{process.kill(old.pid,0);throw new BridgeError('ALREADY_RUNNING','后台服务已经运行')}catch(e){if(e.code==='ALREADY_RUNNING')throw e}}}catch(e){if(e.code==='ALREADY_RUNNING')throw e}atomic(this.lockFile,{pid:process.pid});}
 enqueueEvent(frame){
  if(this.stopping||!frame||!Number.isSafeInteger(frame.seq)||frame.seq<1)return;
  const bytes=Buffer.byteLength(JSON.stringify(frame));
  if(bytes>256*1024){this.log('event_dropped',{code:'EVENT_TOO_LARGE'});return;}
  this.eventQueue.push({frame,bytes,urgent:urgentEvent(frame)});this.eventBytes+=bytes;
  while(this.eventQueue.length>1024||this.eventBytes>4*1024*1024){const old=this.eventQueue.shift();this.eventBytes-=old.bytes;}
  this.scheduleEvents();
 }
 scheduleEvents(delay=100){
  if(this.stopping||this.eventTask||!this.eventQueue.length)return;
  const now=this.clock(),urgent=this.eventQueue.some(entry=>entry.urgent),wait=Math.max(0,(this.eventRetryAt??0)-now,urgent?0:delay),due=now+wait;
  if(this.eventTimer&&this.eventTimerAt<=due)return;
  clearTimeout(this.eventTimer);this.eventTimerAt=due;
  this.eventTimer=setTimeout(()=>{this.eventTimer=null;this.eventTimerAt=0;void this.flushEvents()},wait);this.eventTimer.unref?.();
 }
 flushEvents(){
  if(this.stopping)return Promise.resolve();if(this.eventTask)return this.eventTask;
  if(this.clock()<(this.eventRetryAt??0)){this.scheduleEvents(0);return Promise.resolve();}
  clearTimeout(this.eventTimer);this.eventTimer=null;this.eventTimerAt=0;
  const batch=[];let bytes=0;
  for(const entry of this.eventQueue){if(batch.length>=64||bytes+entry.bytes>512*1024)break;batch.push(entry);bytes+=entry.bytes;}
  if(!batch.length)return Promise.resolve();
  let retry=false;
  const task=this.post('/bridge/events',{deviceId:this.config.deviceId,...(this.desktopStatus.instanceId?{instanceId:this.desktopStatus.instanceId}:{}),events:batch.map(entry=>entry.frame)}).then(()=>{
   this.eventRetryAt=0;
   const acknowledged=new Set(batch);this.eventQueue=this.eventQueue.filter(entry=>!acknowledged.has(entry));this.eventBytes=this.eventQueue.reduce((total,entry)=>total+entry.bytes,0);
  },()=>{retry=true;this.eventRetryAt=this.clock()+1000;if(!this.stopping)this.log('event_delivery_wait',{code:'EVENT_TRANSPORT_FAILED'});}).finally(()=>{if(this.eventTask===task)this.eventTask=null;this.scheduleEvents(retry?1000:100);});
  this.eventTask=task;return task;
 }
 desktopStatusSnapshot(){
  if(this.desktopCheckedAt!==null&&this.clock()-this.desktopCheckedAt>30000)return{...this.desktopStatus,connected:false,error:'Codex 引擎状态已过期，请等待重新检查'};
  return{...this.desktopStatus};
 }
 writeStatus(relayConnected=this.relayConnected){
  if(this.stopping)return;this.relayConnected=relayConnected;
  try{atomic(path.join(this.config.dataDirectory,'status.json'),{pid:process.pid,updatedAt:this.clock(),lastPollAt:this.lastPollAt,desktopCheckedAt:this.desktopCheckedAt,relayConnected,backend:this.desktopStatus.backend??this.config.runtimeMode??'desktop-bridge',engine:this.desktopStatusSnapshot(),desktop:this.desktopStatusSnapshot(),lastSuccessfulTransport:this.lastSuccessfulTransport??null,transportResponses:this.transportResponses??{http:0,websocket:0}})}catch{this.log('status_write_failed',{code:'STATUS_WRITE_FAILED'})}
 }
 refreshDesktopStatus(){
  if(this.stopping)return Promise.resolve();if(this.statusCheckTask)return this.statusCheckTask;
  let cancel;const cancelled=new Promise(resolve=>{cancel=resolve});this.statusCheckCancel=cancel;
  // A stop releases our waiter; Desktop discovery retains its own existing timeout.
  const check=Promise.resolve().then(()=>this.stopping?null:this.runtime.getStatus()).then(status=>{
   if(this.stopping)return;this.desktopCheckedAt=this.clock();
   this.desktopStatus={connected:status?.connected===true,pid:status?.pid??null,error:status?.connected===true?null:'Codex 引擎尚未就绪，请检查 CLI 登录和进程状态',...(['app-server','desktop-bridge','shared-engine'].includes(status?.backend)?{backend:status.backend,...(typeof status.instanceId==='string'?{instanceId:status.instanceId}:{}),capabilities:{streaming:status.capabilities?.streaming===true,interrupt:status.capabilities?.interrupt===true,approvals:status.capabilities?.approvals===true,asyncQuestionAnswers:status.capabilities?.asyncQuestionAnswers===true,desktopActivation:status.capabilities?.desktopActivation===true,steer:status.capabilities?.steer===true,createPermissionMode:status.capabilities?.createPermissionMode===true,...(this.runtime instanceof ReadCache?{cacheReads:true}:{})}}:{})};
   this.writeStatus();
  },()=>{
   if(this.stopping)return;this.desktopCheckedAt=this.clock();this.desktopStatus={...this.desktopStatus,connected:false,error:'Codex 引擎状态检查失败，请检查后重试'};this.writeStatus();
  });
  const task=Promise.race([check,cancelled]).finally(()=>{if(this.statusCheckTask===task){this.statusCheckTask=null;this.statusCheckCancel=null}});
  this.statusCheckTask=task;return task;
 }
 startDesktopStatusChecks(){
  if(this.stopping||this.statusCheckTimer)return;
  this.statusCheckTimer=setInterval(()=>{if(this.stopping)return;this.writeStatus();void this.refreshDesktopStatus()},this.statusCheckIntervalMs);this.statusCheckTimer.unref();
 }
 stopDesktopStatusChecks(){if(this.statusCheckTimer){clearInterval(this.statusCheckTimer);this.statusCheckTimer=null}this.statusCheckCancel?.();}
 preparePostBody(endpoint,body){
  const text=JSON.stringify(body),bytes=Buffer.byteLength(text);
  // 旧 Relay 不认识压缩体；只有本次 poll 明确声明能力后才启用。
  if(endpoint==='/bridge/result'&&this.gzipResults===true&&bytes>=RESULT_GZIP_THRESHOLD&&bytes<=RESULT_BODY_LIMIT){
   return gzip(text,{level:3}).then(compressed=>compressed.length<=bytes*.9?{body:compressed,encoding:'gzip'}:{body:text},()=>({body:text}));
  }
  return{body:text};
 }
 async post(endpoint,body,timeout=endpoint==='/bridge/poll'?this.config.pollTimeoutMs:this.config.requestTimeoutMs,prepared=null){const controller=new AbortController();this.abort=controller;this.controllers.add(controller);const timer=setTimeout(()=>controller.abort(),timeout);try{
  if(this.socketAdvertised===true&&this.config.bridgeSocket!==false){
   this.bridgeSocket??=new BridgeSocket({relayUrl:this.config.relayUrl,bridgeKey:this.config.bridgeKey,clock:this.clock});
   try{const reply=await this.bridgeSocket.request(endpoint,body,{signal:controller.signal,timeout});
    if(reply.status<200||reply.status>=300)throw new BridgeError('RELAY_'+reply.status,'中继连接失败');
    this.recordTransport('websocket');return this.observeTransport(endpoint,reply.body);
   }catch(error){if(!error.beforeSend)throw error;controller.signal.throwIfAborted();}
  }
  const pending=prepared??this.preparePostBody(endpoint,body),payload=typeof pending?.then==='function'?await pending:pending;controller.signal.throwIfAborted();
  const response=await this.fetch(this.config.relayUrl+endpoint,{method:'POST',headers:{Authorization:'Bearer '+this.config.bridgeKey,'Content-Type':'application/json','X-Bridge-Query-Results':'1',...(payload.encoding?{'Content-Encoding':payload.encoding}:{})},body:payload.body,signal:controller.signal,redirect:'error'});
  if(!response.ok)throw new BridgeError('RELAY_'+response.status,'中继连接失败');const size=Number(response.headers.get('content-length')??0);if(size>8*1024*1024)throw Error('Relay response too large');
  const reader=response.body.getReader();let bytes=0;const chunks=[];while(true){const{done,value}=await reader.read();if(done)break;bytes+=value.length;if(bytes>8*1024*1024){await reader.cancel();throw Error('Relay response too large')}chunks.push(value)}this.recordTransport('http');return this.observeTransport(endpoint,JSON.parse(Buffer.concat(chunks).toString('utf8')));
 }finally{clearTimeout(timer);this.controllers.delete(controller);if(this.abort===controller)this.abort=null}}
 recordTransport(mode){this.transportResponses??={http:0,websocket:0};this.transportResponses[mode]++;if(this.lastSuccessfulTransport!==mode){this.lastSuccessfulTransport=mode;this.writeStatus();}}
 observeTransport(endpoint,result){if(endpoint==='/bridge/poll'){this.gzipResults=result.transport?.gzipResults===true;this.readLanes=result.transport?.readLanes===true;this.socketAdvertised=result.transport?.bridgeSocketV1===true;}return result;}
 wait(ms){if(this.stopping)return Promise.resolve();this.stopWaiters??=new Set();return new Promise(resolve=>{const done=()=>{clearTimeout(timer);this.stopWaiters.delete(done);resolve();};const timer=setTimeout(done,ms);this.stopWaiters.add(done);});}
 useReadLanes(){return this.config.runtimeMode==='shared-engine'&&this.readLanes===true}
 workSnapshot(excludeId=null){
  const lanes=[...(this.activeOperations??new Map())].filter(([id])=>id!==excludeId).map(([,lane])=>lane);
  return{foreground:lanes.filter(lane=>lane!=='background').length,background:lanes.filter(lane=>lane==='background').length,eventFrames:this.eventQueue.length,eventBytes:this.eventBytes,eventDelivery:!!this.eventTask,statusChecking:!!this.statusCheckTask};
 }
 async executeJob(job,lane){
   this.activeOperations??=new Map();this.activeOperations.set(job.id,lane??'foreground');
   try{
   const started=performance.now();let outcome,stage='dispatch';
   try{
    if(lane==='background'&&!backgroundJob(job))throw new BridgeError('DISPATCH_MISMATCH','后台读取通道收到不匹配任务；未执行或转交写入');
    if(lane==='foreground'&&backgroundJob(job))throw new BridgeError('DISPATCH_MISMATCH','前景通道收到后台任务；未占用保留读取槽');
    if(!SUPPORTED_OPERATIONS.has(job.operation))throw new BridgeError('BAD_INPUT','操作不受支持');
    let result;
    if(job.operation==='uiTestReplay'){stage='runtime';result=replayUiTest(job.arguments);}
    else if(job.operation==='queryResult'){stage='journal';result=this.journal.queryResult(job.arguments.requestId,job.arguments.requesterId);}
    else {stage='journal';result=await this.journal.execute(job,async()=>{stage='runtime';const value=await this.runtime.execute(job.operation,{...job.arguments,requestId:job.id});stage='journal';return value;});}
    stage='journal-read-overlay';
    if(job.operation==='read')result=this.journal.addSubmissions(result);
    stage='result-preparation';
    if(result.questionIndexOnly===true)result.turns=result.turns.filter(turn=>turn.items.some(item=>item.role==='user'));
    if(result.questionIndexOnly===true&&Buffer.byteLength(JSON.stringify(result))>MAX_INDEX_BYTES)
     throw new BridgeError('RESPONSE_TOO_LARGE','完整提问索引补充身份后超过2 MiB上限，不能返回部分总数。');
    if(job.operation==='progress'){stage='journal-read-overlay';result=this.journal.addRegistration(result,job.arguments.threadId);stage='result-preparation';}
    if(['create','send','importThread'].includes(job.operation)){stage='journal-read-overlay';result=this.journal.submissionReceipt(result,job.id);try{this.runtime.registerSubmissionReceipt?.(result);}catch{this.log('receipt_metadata_failed',{code:'RECEIPT_METADATA_FAILED'});}stage='result-preparation';}
    if(job.operation==='ping'&&job.diagnostics)result={...result,bridgeWork:this.workSnapshot(job.id)};
    outcome={deviceId:this.config.deviceId,jobId:job.id,ok:true,result};
   }catch(e){try{this.log('operation_failed',operationFailureFields(job,stage,e));}catch{}outcome={deviceId:this.config.deviceId,jobId:job.id,ok:false,error:{code:e.code??'DESKTOP_ERROR',message:e instanceof BridgeError?e.message:'Codex 操作未完成，请检查后再重试'}}}
   outcome.timings={executeMs:Math.min(120000,Math.max(0,Math.round((performance.now()-started)*1000)/1000))};
   const prepared=this.socketAdvertised===true&&this.config.bridgeSocket!==false?null:await this.preparePostBody('/bridge/result',outcome);
   let delivered=false;for(let retry=0;retry<3&&!this.stopping;retry++){try{await this.post('/bridge/result',outcome,undefined,prepared);delivered=true;break}catch{await this.wait(500*(retry+1)*(.5+Math.random()))}}
   if(!delivered&&!this.stopping)this.log('result_delivery_failed',{operation:job.operation});
   }finally{this.activeOperations.delete(job.id);}
 }
 async pollLane(lane){
  let backoff=1000,lastError=null;
  while(!this.stopping&&(lane!=='background'||this.useReadLanes())){try{
   const status=this.desktopStatusSnapshot();
   const requestedLane=this.useReadLanes()?lane:null;
   const{job}=await this.post('/bridge/poll',{deviceId:this.config.deviceId,status,...(requestedLane?{readLane:requestedLane}:{})});
   if(this.stopping)break;this.lastPollAt=this.clock();backoff=1000;lastError=null;this.writeStatus(true);
   if(lane!=='background'&&!this.useReadLanes()&&this.backgroundTask)await this.backgroundTask;
   if(job)await this.executeJob(job,requestedLane);
   if(lane!=='background'&&this.useReadLanes()&&!this.backgroundTask){
    const task=this.pollLane('background');this.backgroundTask=task;
    task.finally(()=>{if(this.backgroundTask===task)this.backgroundTask=null}).catch(()=>{});
   }
  }catch(e){if(this.stopping)break;const key=e.code??'CONNECTIVITY';if(lastError!==key){this.log('connection_wait',{code:key,lane});lastError=key}if(lane!=='background')this.writeStatus(false);await this.wait(backoff*(.5+Math.random()));backoff=Math.min(backoff*2,15000);}}
 }
 async run(){this.lock();this.log('started',{deviceId:this.config.deviceId});const managerWatch=this.config.controllerHeartbeatFile?setInterval(()=>{try{const ageMs=Date.now()-fs.statSync(this.config.controllerHeartbeatFile).mtimeMs;if(ageMs>12000){this.log('controller_heartbeat_expired',{ageMs:Math.floor(ageMs)});this.stop()}}catch{this.log('controller_heartbeat_missing');this.stop()}},2000):null;managerWatch?.unref();try{
   await this.refreshDesktopStatus();this.startDesktopStatusChecks();await this.pollLane('foreground');
  }finally{this.stop();if(managerWatch)clearInterval(managerWatch);await this.runtimeCloseTask;await Promise.allSettled([this.backgroundTask,this.eventTask].filter(Boolean));await this.journal.registrations.drain();try{const lock=JSON.parse(fs.readFileSync(this.lockFile,'utf8'));if(lock.pid===process.pid)fs.unlinkSync(this.lockFile)}catch{}this.journal.close();this.log('stopped');}}
 stop(){this.stopping=true;this.stopDesktopStatusChecks();clearTimeout(this.eventTimer);this.eventTimer=null;for(const controller of this.controllers)controller.abort();this.abort?.abort();this.bridgeSocket?.stop();for(const done of this.stopWaiters??[])done();if(!this.runtimeCloseTask){this.runtimeCloseTask=Promise.resolve().then(()=>this.runtime.close?.());this.runtimeCloseTask.catch(()=>{});}}
}
if(require.main===module){const file=process.argv[2];if(!file){console.error('Usage: node agent.cjs <config.json>');process.exit(1)}let agent;try{const config=configFrom(file);agent=new Agent(config);process.on('SIGINT',()=>agent.stop());process.on('SIGTERM',()=>agent.stop());agent.run().catch(e=>{console.error(JSON.stringify({event:'fatal',code:e.code??'START_FAILED'}));process.exitCode=1})}catch{console.error('Bridge configuration could not be loaded');process.exitCode=1}}
module.exports={Agent,Journal,configFrom,SUPPORTED_OPERATIONS};



