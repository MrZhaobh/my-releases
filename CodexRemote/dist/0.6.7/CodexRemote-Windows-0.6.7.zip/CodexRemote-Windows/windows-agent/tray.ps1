﻿param([string]$NodePath=(Get-Command node.exe -ErrorAction SilentlyContinue).Source,[switch]$Preview,[switch]$SmokeTest,[string]$EvidenceDirectory,[ValidateRange(1,2)][double]$PreviewScale=1,[string]$StartupNotice='')
$ErrorActionPreference='Stop'
& (Join-Path $PSScriptRoot 'tray-native.ps1') @PSBoundParameters
