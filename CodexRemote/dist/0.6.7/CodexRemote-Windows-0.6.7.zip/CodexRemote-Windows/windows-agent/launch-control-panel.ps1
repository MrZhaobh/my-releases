﻿$ErrorActionPreference='Stop'
try{
 $root=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
 $node=Join-Path $root 'node.exe'
 if(-not (Test-Path -LiteralPath $node -PathType Leaf)){
  $node=Join-Path $root '.local/node-v24.19.0-release/node.exe'
  if(-not (Test-Path -LiteralPath $node -PathType Leaf)){
   $command=Get-Command node.exe -CommandType Application -ErrorAction SilentlyContinue|Select-Object -First 1
   if(-not $command){throw '未找到 Node 运行时，请使用完整 Windows 发布包。'}
   $node=$command.Source
  }
 }
 $startupNotice=''
 try{& (Join-Path $PSScriptRoot 'install-shortcuts.ps1') -LauncherPath (Join-Path $root 'CodexRemote.exe')}
 catch{$startupNotice='部分快捷方式未能创建，可继续使用控制面板或直接打开 CodexRemote.exe。'}
 & (Join-Path $PSScriptRoot 'tray.ps1') -NodePath $node -StartupNotice $startupNotice
}catch{
 Add-Type -AssemblyName System.Windows.Forms
 [void][Windows.Forms.MessageBox]::Show(('无法打开 Codex Remote 控制面板。'+[Environment]::NewLine+[Environment]::NewLine+$_.Exception.Message),'Codex Remote',[Windows.Forms.MessageBoxButtons]::OK,[Windows.Forms.MessageBoxIcon]::Error)
 exit 1
}
