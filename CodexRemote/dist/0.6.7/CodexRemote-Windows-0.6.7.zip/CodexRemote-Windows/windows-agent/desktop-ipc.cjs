'use strict';
const net = require('node:net');
const {randomUUID} = require('node:crypto');
const {EventEmitter} = require('node:events');
const {UUID, reduce, viewOf, collectTurns, active, approvalInfo} = require('./desktop-ipc-state.cjs');
const {parseReply,validateReply}=require('./async-question-reply.cjs');
// 桌面 TurnStart 使用 text_elements；不能替换为 app-server 的简化文本结构。
const desktopTextInput = text => ({type: 'text', text, text_elements: []});
const ENDPOINT = '\\\\.\\pipe\\codex-ipc';
const MAX_FRAME = 32 * 1024 * 1024;
const METHODS = new Set(['initialize', 'thread-owner-discovery', 'thread-follower-load-complete-history']);
const WRITE_METHODS = new Set(['thread-follower-start-turn', 'thread-follower-interrupt-turn', 'thread-follower-command-approval-decision', 'thread-follower-submit-mcp-server-elicitation-response', 'thread-follower-submit-user-input', 'thread-follower-steer-turn']);
const CONTROLLED = Symbol('validated-local-ui-action');
const fault = code => Object.assign(Error(code), {code});
const nativeRequestId = value => typeof value === 'string' || Number.isSafeInteger(value);
const definiteWriteFailure = error => ['IPC_METHOD_UNSUPPORTED', 'IPC_VERSION_UNSUPPORTED', 'IPC_REJECTED'].includes(error?.code);
function responseFailure(response, fallback) {
  const reason = typeof response?.error === 'string' ? response.error : response?.error?.code ?? response?.error?.message ?? '';
  if (/version|incompatible/i.test(reason)) return fault('IPC_VERSION_UNSUPPORTED');
  if (/no-handler|unsupported|unknown-method|not-implemented/i.test(reason)) return fault('IPC_METHOD_UNSUPPORTED');
  return fault(fallback);
}
function encode(value) {
  const data = Buffer.from(JSON.stringify(value)); if (!data.length || data.length > MAX_FRAME) throw fault('FRAME_LIMIT');
  const prefix = Buffer.alloc(4); prefix.writeUInt32LE(data.length); return Buffer.concat([prefix, data]);
}
class Decoder {
  constructor() { this.buffer = Buffer.alloc(0); }
  push(data, receive) {
    if (this.buffer.length + data.length > MAX_FRAME + 65536) throw fault('FRAME_LIMIT');
    this.buffer = Buffer.concat([this.buffer, data]);
    while (this.buffer.length >= 4) {
      const length = this.buffer.readUInt32LE(); if (!length || length > MAX_FRAME) throw fault('FRAME_LIMIT');
      if (this.buffer.length < length + 4) return;
      const raw = this.buffer.subarray(4, length + 4); this.buffer = this.buffer.subarray(length + 4);
      let value; try { value = JSON.parse(new TextDecoder('utf-8', {fatal: true}).decode(raw)); } catch { throw fault('INVALID_FRAME'); }
      if (!value || typeof value !== 'object' || Array.isArray(value)) throw fault('INVALID_FRAME');
      receive(value);
    }
  }
}
class IpcReader extends EventEmitter {
  constructor({connect = () => net.createConnection(ENDPOINT), requestTimeoutMs = 5000, snapshotTimeoutMs = 7000, ownerRefreshMs = 10000, ownerVerificationMs = 60000, clock = () => Date.now(), maxSessions = 8} = {}) {
    super(); this.connect = connect; this.requestTimeoutMs = requestTimeoutMs; this.snapshotTimeoutMs = snapshotTimeoutMs;
    this.sessions = new Map(); this.pending = new Map(); this.connected = false; this.closed = false; this.retryDelay = 1000;
    this.ownerRefreshMs = Math.max(20, ownerRefreshMs); this.ownerVerificationMs = Math.max(this.ownerRefreshMs, ownerVerificationMs); this.clock = clock; this.maxSessions = Math.max(1, maxSessions);
  }
  send(frame) { if (this.closed || !this.socket || this.socket.destroyed) throw fault('IPC_DISCONNECTED'); this.socket.write(encode(frame)); }
  request(method, params, version = 0, owner, permit) {
    if (this.closed) return Promise.reject(fault('CLOSED'));
    if (!METHODS.has(method) && !(permit === CONTROLLED && WRITE_METHODS.has(method))) return Promise.reject(fault('READ_ONLY_METHOD')); // 无任意 IPC 方法代理。
    const requestId = randomUUID();
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => { this.pending.delete(requestId); reject(fault('IPC_TIMEOUT')); }, this.requestTimeoutMs);
      this.pending.set(requestId, {resolve, reject, timer});
      try { this.send({type: 'request', requestId, sourceClientId: this.clientId ?? 'initializing-client', method, params, version, ...(owner ? {targetClientId: owner} : {})}); }
      catch (error) { clearTimeout(timer); this.pending.delete(requestId); reject(error); }
    });
  }
  following(session, enabled) {
    this.send({type: 'broadcast', method: 'thread-stream-following-changed', version: 1, sourceClientId: this.clientId, targetClientIds: [session.owner], params: {hostId: 'local', conversationId: session.id, following: enabled}});
  }
  async ensureConnected() {
    if (this.closed) throw fault('CLOSED'); if (this.connected) return; if (this.connecting) return this.connecting;
    this.connecting = new Promise((resolve, reject) => {
      this.rejectConnecting = reject;
      const decoder = new Decoder(); const socket = this.connect(); this.socket = socket;
      const timer = setTimeout(() => { reject(fault('IPC_TIMEOUT')); socket.destroy(); }, this.requestTimeoutMs); this.connectTimer = timer;
      socket.once('connect', async () => {
        try {
          if (this.closed || socket !== this.socket) throw fault('CLOSED');
          const result = await this.request('initialize', {clientType: 'codex-remote-bridge'});
          if (result.resultType !== 'success') throw responseFailure(result, 'INITIALIZE_FAILED');
          if (typeof result.result?.clientId !== 'string' || !result.result.clientId.trim()) throw fault('INITIALIZE_FAILED');
          if (this.closed || socket !== this.socket) throw fault('CLOSED');
          this.blockedConnectCode = null; this.clientId = result.result.clientId; this.connected = true; this.retryDelay = 1000; clearTimeout(timer);
          this.emit('connection', {connected: true}); resolve();
        } catch (error) {
          if (['IPC_METHOD_UNSUPPORTED', 'IPC_VERSION_UNSUPPORTED', 'INITIALIZE_FAILED'].includes(error.code)) this.blockedConnectCode = error.code;
          clearTimeout(timer); reject(error); socket.destroy();
        }
      });
      socket.on('data', bytes => { if (socket !== this.socket || this.closed) return; try { decoder.push(bytes, frame => this.receive(frame)); } catch { socket.destroy(); } });
      socket.once('error', () => { clearTimeout(timer); reject(fault('IPC_UNAVAILABLE')); });
      socket.once('close', () => {
        clearTimeout(timer); reject(fault('IPC_DISCONNECTED'));
        if (socket !== this.socket || this.closed) return;
        this.connected = false; this.clientId = null;
        for (const p of this.pending.values()) { clearTimeout(p.timer); p.reject(fault('IPC_DISCONNECTED')); } this.pending.clear();
        for (const s of this.sessions.values()) { s.connected = false; s.awaitingSnapshot = true; s.notice = '桌面连接已断开，保留已读取内容；正在等待重新连接。'; this.emit('view', viewOf(s)); }
        this.emit('connection', {connected: false, error: 'IPC_DISCONNECTED'}); this.scheduleReconnect();
      });
    });
    try { await this.connecting; } finally { this.connecting = null; this.rejectConnecting = null; clearTimeout(this.connectTimer); this.connectTimer = null; }
  }
  scheduleReconnect() {
    if (this.closed || this.blockedConnectCode || this.retryTimer || !this.sessions.size) return;
    this.retryTimer = setTimeout(async () => {
      this.retryTimer = null;
      try { await this.ensureConnected(); for (const s of this.sessions.values()) await this.refresh(s).catch(error => this.sessionFault(s, error)); }
      catch { this.scheduleReconnect(); }
    }, this.retryDelay); this.retryTimer.unref(); this.retryDelay = Math.min(this.retryDelay * 2, 10000);
  }
  sessionFault(session, error) {
    if (this.closed || session.retired) return;
    session.connected = false; session.awaitingSnapshot = true; session.error = error.code ?? 'IPC_FAILED';
    if (session.error === 'OWNER_NOT_FOUND') session.owner = null;
    session.notice = session.error === 'OWNER_NOT_FOUND' ? '桌面尚未加载此对话。请在使用普通本地引擎的 Codex 窗口打开它。' : ['IPC_METHOD_UNSUPPORTED', 'IPC_VERSION_UNSUPPORTED', 'INITIALIZE_FAILED'].includes(session.error) ? '当前桌面 IPC 接口版本不受支持，请更新连接后重试。' : '读取暂时失败，正在等待恢复连接。';
    this.emit('view', viewOf(session)); this.emit('fault', {id: session.id, code: error.code ?? 'IPC_FAILED', message: session.notice});
  }
  receive(frame) {
    if (this.closed) return;
    if (frame.type === 'client-discovery-request') { this.send({type: 'client-discovery-response', requestId: frame.requestId, response: {canHandle: false}}); return; }
    if (frame.type === 'request') { this.send({type: 'response', requestId: frame.requestId, resultType: 'error', error: 'no-handler-for-request'}); return; }
    if (frame.type === 'response') { const p = this.pending.get(frame.requestId); if (p) { this.pending.delete(frame.requestId); clearTimeout(p.timer); p.resolve(frame); } return; }
    if (frame.type !== 'broadcast' || frame.method !== 'thread-stream-state-changed' || frame.params?.hostId !== 'local') return;
    const s = this.sessions.get(frame.params.conversationId); if (!s || s.owner !== frame.sourceClientId) return;
    if (frame.version !== 11) { this.sessionFault(s, fault('IPC_VERSION_UNSUPPORTED')); return; }
    if (s.awaitingSnapshot && frame.params.change?.type !== 'snapshot') return;
    try {
      const next = reduce(s.current, frame.params.change);
      if (next.value.id !== s.id && next.value.sessionId !== s.id) throw fault('THREAD_MISMATCH');
      s.current = next; s.lastEventAt = this.clock(); s.connected = true; s.notice = ''; s.error = null;
      if (s.pendingSend && collectTurns(next.value).some(t => t.params?.clientUserMessageId === s.pendingSend || t.items.some(i => i.clientId === s.pendingSend))) s.pendingSend = null;
      if (frame.params.change.type === 'snapshot') { s.snapshotCount++; s.awaitingSnapshot = false; clearTimeout(s.resyncTimer); s.resyncTimer = null; }
      else s.patchCount++;
      this.emit('view', viewOf(s));
    } catch {
      s.connected = false; s.awaitingSnapshot = true; s.notice = '增量版本不连续，正在重新读取桌面快照。'; this.emit('view', viewOf(s));
      if (!s.resyncTimer) s.resyncTimer = setTimeout(() => { s.resyncTimer = null; this.refresh(s).catch(error => this.sessionFault(s, error)); }, 150);
    }
  }
  async refresh(s) {
    if (s.refreshing) return s.refreshing;
    s.ownerRevision = (s.ownerRevision ?? 0) + 1;
    s.refreshing = (async () => {
      await this.ensureConnected();
      if (s.owner) { try { this.following(s, false); } catch {} }
      const response = await this.request('thread-owner-discovery', {hostId: 'local', conversationId: s.id}, 1);
      if (response.resultType !== 'success' || !response.handledByClientId) throw responseFailure(response, 'OWNER_NOT_FOUND');
      s.error = null; s.owner = response.handledByClientId; s.ownerCheckedAt = this.clock(); s.awaitingSnapshot = true; const before = s.snapshotCount;
      this.following(s, true);
      const deadline = Date.now() + this.snapshotTimeoutMs;
      while (s.snapshotCount === before) { if (this.closed) throw fault('CLOSED'); if (s.retired) throw fault('SESSION_EVICTED'); if (s.error === 'IPC_VERSION_UNSUPPORTED') throw fault(s.error); if (!this.connected) throw fault('IPC_DISCONNECTED'); if (Date.now() > deadline) throw fault('SNAPSHOT_TIMEOUT'); await new Promise(resolve => setTimeout(resolve, 30)); }
      return viewOf(s);
    })();
    try { return await s.refreshing; } finally { s.refreshing = null; }
  }
  async attach(id) {
    if (!UUID.test(id ?? '')) throw fault('INVALID_THREAD_ID');
    if (this.closed) throw fault('CLOSED'); this.blockedConnectCode = null;
    let s = this.sessions.get(id);
    if (!s) {
      if (this.sessions.size >= this.maxSessions) {
        const oldest = [...this.sessions.values()].sort((a, b) => a.lastAccess - b.lastAccess)[0];
        if (oldest.owner && this.connected) this.following(oldest, false); clearTimeout(oldest.resyncTimer); oldest.retired = true; this.sessions.delete(oldest.id);
        this.emit('fault', {id: oldest.id, code: 'SESSION_EVICTED', message: '已达到同时订阅会话上限，最久未访问会话的订阅已释放。'});
      }
      s = {id, owner: null, current: null, snapshotCount: 0, patchCount: 0, lastEventAt: null, lastAccess: this.clock(), connected: false}; this.sessions.set(id, s);
    }
    s.lastAccess = this.clock(); this.startOwnerMonitor();
    try { return await this.refresh(s); } catch (error) { this.sessionFault(s, error); throw error; }
  }
  async history(id) {
    if (!UUID.test(id ?? '')) throw fault('INVALID_THREAD_ID');
    const s = this.sessions.get(id); if (!s?.connected || !s.owner) return this.attach(id);
    const result = await this.request('thread-follower-load-complete-history', {conversationId: id}, 1, s.owner);
    if (result.resultType !== 'success') throw responseFailure(result, 'HISTORY_UNAVAILABLE');
    return this.refresh(s);
  }
  live(id) {
    if (!UUID.test(id ?? '')) throw fault('INVALID_THREAD_ID');
    const s = this.sessions.get(id); if (!s?.current) throw fault('NOT_ATTACHED');
    if (!this.connected || !s.connected || s.awaitingSnapshot || !s.owner) throw fault('IPC_NOT_READY'); return s;
  }
  async commit(s, method, params, version) {
    try {
      const result = await this.request(method, params, version, s.owner, CONTROLLED);
      if (result.resultType === 'error') throw responseFailure(result, 'IPC_REJECTED');
      if (result.resultType !== 'success') throw fault('DELIVERY_UNKNOWN');
      return result;
    } catch (error) { if (definiteWriteFailure(error)) throw error; throw fault('DELIVERY_UNKNOWN'); }
  }
  async message(id, {requestId, prompt}) {
    const s = this.live(id); const last = collectTurns(s.current.value).at(-1);
    if (s.pendingSend || active(last?.status)) throw fault('BUSY');
    if (!UUID.test(requestId ?? '') || typeof prompt !== 'string' || !prompt.trim() || prompt.length > 16000) throw fault('BAD_INPUT');
    s.pendingSend = requestId;
    try {
      await this.commit(s, 'thread-follower-start-turn', {conversationId: id, turnStart: {request: {threadId: id, clientUserMessageId: requestId, input: [desktopTextInput(prompt)]}, context: {inheritThreadSettings: true}}}, 2);
    } catch (error) { if (definiteWriteFailure(error)) s.pendingSend = null; throw error; }
    const turn = collectTurns(s.current.value).find(t => t.params?.clientUserMessageId === requestId || t.items.some(i => i.clientId === requestId));
    if (turn) s.pendingSend = null;
    return {accepted: true, clientUserMessageId: requestId, turnId: turn?.turnId ?? null, delivery: 'accepted'};
  }
  async answerAsync(id,{requestId,prompt}) {
    if(!UUID.test(requestId??''))throw fault('BAD_INPUT');
    const reply=parseReply(prompt);if(!reply)throw fault('INVALID_ANSWERS');
    const s=this.live(id),raw=s.current.value,{turnId,callId}=validateReply(raw,reply);
    const keys=reply.entries.map(entry=>JSON.stringify(['async-question',s.owner,turnId,callId,JSON.parse(entry.questionItemId)[2]]));s.actions??=new Set();
    if(keys.some(key=>s.actions.has(key)))throw fault('QUESTION_ALREADY_ANSWERED');for(const key of keys)s.actions.add(key);
    const context={prompt,turnTrigger:'send_user_message_async_question',addedFiles:[],fileAttachments:[],imageAttachments:[],ideContext:null,workspaceRoots:typeof raw.cwd==='string'?[raw.cwd]:[]};
    const restoreMessage={id:requestId,text:prompt,context,cwd:raw.cwd??null,createdAt:Date.now(),responsesapiClientMetadata:{source:'codex'}};
    try{
      let result;
      try{result=await this.request('thread-follower-steer-turn',{conversationId:id,input:[desktopTextInput(prompt)],restoreMessage,attachments:[],clientUserMessageId:requestId},1,s.owner,CONTROLLED);}catch{throw fault('DELIVERY_UNKNOWN');}
      // 只有路由层的精确拒绝标记能证明handler未执行；owner任意错误正文不作预写证明。
      if(result.resultType==='error'){
        if(result.error==='request-version-mismatch')throw fault('IPC_VERSION_UNSUPPORTED');
        if(result.error==='no-handler-for-request')throw fault('IPC_METHOD_UNSUPPORTED');
        throw fault('DELIVERY_UNKNOWN');
      }
      if(result.resultType!=='success')throw fault('DELIVERY_UNKNOWN');
      // owning接口会挑选活动轮，不能假称其支持客户端expectedTurnId；确认回包仍属原问题轮。
      if(result.result?.result?.turnId!==turnId)throw fault('DELIVERY_UNKNOWN');
      return {accepted:true,turnId,clientUserMessageId:requestId};
    }catch(error){if(error.code==='IPC_REJECTED')throw fault('DELIVERY_UNKNOWN');if(definiteWriteFailure(error))for(const key of keys)s.actions.delete(key);throw error;}
  }
  async approve(id, {approvalId, decision, expectedTurnId}) {
    const s = this.live(id); if (!['approve', 'reject'].includes(decision) || !nativeRequestId(approvalId)) throw fault('BAD_INPUT');
    const item = (s.current.value.requests ?? []).find(r => r.completed !== true && r.id === approvalId && (/\/requestApproval$/.test(r.method) || r.method === 'mcpServer/elicitation/request'));
    if (!item || (item.params?.threadId != null && item.params.threadId !== id)) throw fault('APPROVAL_EXPIRED');
    const turnId = item.params?.turnId;
    const currentTurn = collectTurns(s.current.value).at(-1);
    if (!expectedTurnId || turnId !== expectedTurnId || currentTurn?.turnId !== expectedTurnId || !active(currentTurn.status)) throw fault('APPROVAL_EXPIRED');
    const info = approvalInfo(item); if (!(decision === 'approve' ? info.canApprove : info.canReject)) throw fault('UNSUPPORTED_APPROVAL');
    const key = JSON.stringify(['approval', s.owner, expectedTurnId, approvalId]); s.actions ??= new Set(); if (s.actions.has(key)) throw fault('APPROVAL_EXPIRED'); s.actions.add(key);
    const params = {conversationId: id, requestId: item.id};
    try {
    if (info.kind === 'command') await this.commit(s, 'thread-follower-command-approval-decision', {...params, decision: decision === 'approve' ? 'accept' : 'decline'}, 1);
    else await this.commit(s, 'thread-follower-submit-mcp-server-elicitation-response', {...params, response: {action: decision === 'approve' ? 'accept' : 'decline', content: decision === 'approve' ? {} : null, _meta: null}}, 1);
    } catch (error) { if (definiteWriteFailure(error)) s.actions.delete(key); throw error; }
    return {accepted: true}; // 仅确认提交，执行完成仍以原生后续事件为准。
  }
  async answer(id, {questionId, expectedTurnId, answers}) {
    if (!nativeRequestId(questionId)) throw fault('BAD_INPUT');
    const s = this.live(id); const item = (s.current.value.requests ?? []).find(r => r.completed !== true && r.method === 'item/tool/requestUserInput' && r.id === questionId);
    if (!item || item.params?.turnId !== expectedTurnId || (item.params?.threadId != null && item.params.threadId !== id)) throw fault('QUESTION_EXPIRED');
    const questions = item.params?.questions;
    const turn = collectTurns(s.current.value).at(-1); if (turn?.turnId !== expectedTurnId || !active(turn.status)) throw fault('QUESTION_EXPIRED');
    if (!Array.isArray(questions) || questions.some(q => q.isSecret) || !answers || typeof answers !== 'object' || Array.isArray(answers)) throw fault('INVALID_ANSWERS');
    const allowed = new Set(questions.map(q => q.id));
    for (const [key, value] of Object.entries(answers)) if (!allowed.has(key) || !Array.isArray(value?.answers) || value.answers.length > 10 || value.answers.some(a => typeof a !== 'string' || a.length > 4000)) throw fault('INVALID_ANSWERS');
    const key = JSON.stringify(['question', s.owner, expectedTurnId, questionId]); s.actions ??= new Set(); if (s.actions.has(key)) throw fault('QUESTION_EXPIRED'); s.actions.add(key);
    try { await this.commit(s, 'thread-follower-submit-user-input', {conversationId: id, requestId: item.id, response: {answers}}, 1); }
    catch (error) { if (definiteWriteFailure(error)) s.actions.delete(key); throw error; }
    return {accepted: true};
  }
  async interrupt(id, {expectedTurnId}) {
    const s = this.live(id), turn = collectTurns(s.current.value).at(-1);
    if (!expectedTurnId || turn?.turnId !== expectedTurnId || !active(turn.status)) throw fault('TURN_NOT_ACTIVE');
    await this.commit(s, 'thread-follower-interrupt-turn', {conversationId: id, expectedTurnId, mode: 'user-stop'}, 4); return {accepted: true};
  }
  async resolveUnknown(id, {clientUserMessageId}) {
    if (!UUID.test(clientUserMessageId ?? '')) throw fault('BAD_INPUT');
    const s = this.live(id);
    if (s.pendingSend && s.pendingSend !== clientUserMessageId) throw fault('BAD_INPUT');
    await this.refresh(s); // 用户明确核对后，先取得新快照；绝不重发原提示词。
    if (active(collectTurns(s.current.value).at(-1)?.status)) throw fault('BUSY');
    s.pendingSend = null; return {accepted: true};
  }
  raw(id) { const s = this.sessions.get(id); return s?.current ? structuredClone(s.current.value) : null; }
  hasLiveSession() {
    return this.connected && [...this.sessions.values()].some(s => !s.retired && s.owner && s.connected && !s.awaitingSnapshot);
  }
  session(id) {
    const s = this.sessions.get(id); if (!s) return null;
    return structuredClone({id: s.id, owner: s.owner, current: s.current, connected: !!s.connected, awaitingSnapshot: !!s.awaitingSnapshot, pendingSend: s.pendingSend ?? null, error: s.error ?? null, snapshotCount: s.snapshotCount, patchCount: s.patchCount, lastEventAt: s.lastEventAt, ownerCheckedAt: s.ownerCheckedAt});
  }
  startOwnerMonitor() {
    if (this.closed || this.ownerTimer) return;
    this.ownerTimer = setInterval(() => { this.probeOwners().catch(() => {}); }, this.ownerRefreshMs); this.ownerTimer.unref();
  }
  async probeOwners() {
    if (this.closed || !this.connected || this.ownerProbing) return;
    this.ownerProbing = true;
    try {
      const due = [...this.sessions.values()].filter(s => {
        if (s.retired || s.refreshing) return false;
        // 正常会话由增量驱动；归属仍须独立、有界校准，不能被别的会话事件永久续期。
        const healthy = s.owner && s.connected && !s.awaitingSnapshot;
        const age = this.clock() - s.ownerCheckedAt;
        return !(healthy && Number.isFinite(age) && age >= 0 && age < this.ownerVerificationMs);
      });
      let index = 0;
      const probe = async () => { for (;;) {
        if (this.closed || !this.connected) return;
        const s = due[index++]; if (!s) return;
        if (s.retired || s.refreshing || this.sessions.get(s.id) !== s) continue;
        const revision = s.ownerRevision ?? 0, owner = s.owner;
        const currentRevision = value => !this.closed && this.connected && !s.retired && this.sessions.get(s.id) === s && (s.ownerRevision ?? 0) === value;
        const current = () => currentRevision(revision) && s.owner === owner;
        try {
          const response = await this.request('thread-owner-discovery', {hostId: 'local', conversationId: s.id}, 1);
          if (!current()) continue;
          if (response.resultType !== 'success' || !response.handledByClientId) throw responseFailure(response, 'OWNER_NOT_FOUND');
          s.ownerCheckedAt = this.clock();
          if (s.owner !== response.handledByClientId || (!s.connected || s.awaitingSnapshot) && !['IPC_METHOD_UNSUPPORTED', 'IPC_VERSION_UNSUPPORTED'].includes(s.error)) {
            // 仅重新订阅已有 owner；不打开、恢复或激活桌面对话。
            s.error = null;
            const refreshing = this.refresh(s), refreshingRevision = s.ownerRevision;
            try { await refreshing; } catch (error) { if (currentRevision(refreshingRevision)) this.sessionFault(s, error); }
          }
        } catch (error) { if (current()) this.sessionFault(s, error); }
      }};
      // 小批并发避免一个静默 owner 的超时堵住其他会话恢复。
      await Promise.all(Array.from({length: Math.min(2, due.length)}, probe));
    } finally { this.ownerProbing = false; }
  }
  status() { return {connected: this.connected, transport: 'desktop-ipc-only', capabilities: {catalog: false, readOnly: false, send: true, approvals: true, questions: true, interrupt: true}, attached: [...this.sessions.values()].map(s => ({id: s.id, title: s.current?.value?.title || '未命名对话', status: viewOf(s).status}))}; }
  close() {
    if (this.closed) return;
    for (const s of this.sessions.values()) if (this.connected && s.owner) { try { this.following(s, false); } catch {} }
    this.closed = true; clearTimeout(this.retryTimer); clearTimeout(this.connectTimer); clearInterval(this.ownerTimer); this.ownerTimer = null;
    this.rejectConnecting?.(fault('CLOSED'));
    for (const p of this.pending.values()) { clearTimeout(p.timer); p.reject(fault('CLOSED')); } this.pending.clear();
    for (const s of this.sessions.values()) clearTimeout(s.resyncTimer);
    this.connected = false; this.clientId = null;
    for (const s of this.sessions.values()) { s.connected = false; s.awaitingSnapshot = true; }
    this.socket?.destroy();
  }
}
module.exports = {IpcReader, Decoder, encode};
