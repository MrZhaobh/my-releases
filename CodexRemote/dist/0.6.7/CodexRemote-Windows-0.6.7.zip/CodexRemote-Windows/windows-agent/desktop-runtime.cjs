'use strict';
const {randomUUID,createHmac,timingSafeEqual}=require('node:crypto');
const {BridgeError}=require('./errors.cjs');
const {IpcReader}=require('./desktop-ipc.cjs');
const {UUID,collectTurns,active,approvalInfo,viewOf}=require('./desktop-ipc-state.cjs');
const {normalizeConversation}=require('./desktop-ipc-mapping.cjs');
const {approvalSpec,review}=require('./shared-approvals.cjs');
const {registerHistoryImage}=require('./media.cjs');
const {registerHistoryVisualization}=require('./visualizations.cjs');
const {registerAttachment}=require('./attachments.cjs');
const {parseReply}=require('./async-question-reply.cjs');
const fail=(code,message)=>new BridgeError(code,message);
const copy=value=>structuredClone(value);

// Bridge 是唯一的新建/发送入口；IPC 只附着已有 owner，不以隐式发送激活会话。
class DesktopRuntime {
 constructor(config={}, {desktop,ipc}={}) {
  this.desktop=desktop??new(require('./desktop.cjs').Desktop)(config,{backgroundDiscovery:false});
  this.ipc=ipc??new IpcReader();this.instanceId=randomUUID();this.streamId=randomUUID();
  this.sessions=new Map();this.secret=randomUUID();this.listener=null;this.closed=false;
  this.ipc.on('view',view=>this.changed(view.id));
  this.ipc.on('fault',event=>{this.disconnected(event.id,event.message);if(event.code==='SESSION_EVICTED'){clearTimeout(this.sessions.get(event.id)?.timer);this.sessions.delete(event.id);}});
  this.ipc.on('connection',event=>{if(!event.connected){this.desktop.invalidateDiscovery?.();for(const id of this.sessions.keys())this.disconnected(id,'桌面实时连接断开，正在只读重连；不会重发输入。');}});
 }
 setEventListener(listener){this.listener=listener;}
 session(id){let s=this.sessions.get(id);if(!s){s={id,streamId:randomUUID(),seq:0,turns:new Map(),items:new Map(),approvals:new Map(),receipts:new Map()};this.sessions.set(id,s);}return s;}
 emit(s,data){
  if(this.closed)return;
  if(Buffer.byteLength(JSON.stringify(data))>240*1024){
   if(data.type==='item.upsert'){
    const {text='',...metadata}=data.item;let base={...metadata,text:''};
    if(Buffer.byteLength(JSON.stringify(base))>220*1024)base={id:data.item.id,type:data.item.type,role:data.item.role,phase:data.item.phase??null,text:'',streamMetadataDeferred:true};
    if(metadata.segments)base.streamMetadataDeferred=true;this.emit(s,{...data,item:base});
    for(let offset=0;offset<text.length;){let end=Math.min(text.length,offset+16000);if(end<text.length&&/[\uD800-\uDBFF]/.test(text[end-1]))end--;this.emit(s,{type:'item.delta',turnId:data.turnId,itemId:data.item.id,delta:text.slice(offset,end)});offset=end;}
    return;
   }
   this.emit(s,{type:'status',status:'unknown',notice:'结构化内容超过实时单帧上限，请刷新原会话查看。'});return;
  }
  const event={streamId:s.streamId,seq:++s.seq,threadId:s.id,at:Date.now(),...copy(data)};try{this.listener?.(event);}catch{}
 }
 cursor(s){return `${s.streamId}:${s.seq}`;}
 changed(id){const s=this.sessions.get(id);if(!s||s.timer||this.closed)return;if(this.ipc.session(id)?.awaitingSnapshot)this.disconnected(id,'桌面增量正在重新同步，审批暂时失效。');s.timer=setTimeout(()=>{s.timer=null;try{this.publish(id);}catch{this.disconnected(id,'桌面内容转换失败，请刷新原会话确认。');}},40);s.timer.unref?.();}
 disconnected(id,notice){const s=this.sessions.get(id);if(!s)return;for(const a of s.approvals.values())if(a.state==='pending'){a.state='expired';a.expiredByConnection=true;this.emit(s,{type:'approval.upsert',approval:this.publicApproval(a)});}s.status=null;this.emit(s,{type:'status',status:'unknown',activity:{kind:'syncing',title:'正在重新连接',updatedAt:Date.now()},notice});}
 normalize(id){const raw=this.ipc.raw(id);if(!raw)return null;const page=normalizeConversation(raw,{threadId:id,
  registerImage:(threadId,file)=>registerHistoryImage(this.desktop.mediaMap,threadId,file),
  registerVisualization:(threadId,file)=>registerHistoryVisualization(this.desktop.visualizationMap,threadId,file),
  registerAttachment:(threadId,file)=>registerAttachment(this.desktop.attachmentMap,threadId,file)});
  for(const turn of page.turns){const requestId=this.sessions.get(id)?.receipts.get(turn.id);if(requestId)turn.clientRequestId=requestId;}return page;
 }
 // 必须由持久发送账本在完成真实回执后调用；不按正文或“最后一轮”推断归属。
 registerSubmissionReceipt({threadId,turnId,clientRequestId,submissionScope}){
  if(submissionScope==='item')return;
  if(!UUID.test(threadId??'')||!UUID.test(clientRequestId??'')||typeof turnId!=='string'||!turnId)return;
  const s=this.session(threadId);s.receipts.set(turnId,clientRequestId);
  while(s.receipts.size>256)s.receipts.delete(s.receipts.keys().next().value);
  try{this.publish(threadId);}catch{this.disconnected(threadId,'发送已确认，实时请求标识待回读同步。');}
 }
 interactions(s,raw){
  const owner=this.ipc.session(s.id)?.owner,last=collectTurns(raw).at(-1),seen=new Set();
  for(const request of raw.requests??[]){
   if(!request||request.completed===true)continue;const p=request.params??{},question=request.method==='item/tool/requestUserInput';
   if(!question&&!/\/requestApproval$/.test(request.method??'')&&request.method!=='mcpServer/elicitation/request')continue;
   if(p.threadId!=null&&p.threadId!==s.id)continue;
   const key=JSON.stringify([owner,p.turnId,request.id]);seen.add(key);let a=[...s.approvals.values()].reverse().find(a=>a.key===key);
   if(a&&!(a.state==='expired'&&a.expiredByConnection&&this.ipc.session(s.id)?.snapshotCount!==a.snapshotCount)){
    if(a.state==='pending'&&(!active(last?.status)||p.turnId!==last?.turnId)){a.state='expired';this.emit(s,{type:'approval.upsert',approval:this.publicApproval(a)});}continue;
   }
   if(!p.turnId||typeof p.turnId!=='string')continue;
   const spec=approvalSpec(request.method,p,null),support=approvalInfo(request);
   if(support.kind==='mcp'&&support.canApprove){
    const scope=p._meta?.persist==='always'?'桌面请求持续授权此站点':'桌面请求授权访问此站点';
    const browserReview=review([['站点',support.origin],['授权范围',scope],['说明',p.message],['工具',p._meta?.tool_name],['参数',p._meta?.tool_params]]);
    spec.kind='browserOrigin';spec.title='浏览器站点授权';spec.reason=scope;spec.summary=support.origin;spec.details=browserReview.details;spec.approve=browserReview.complete?{}:null;spec.reject={};
   }
   const validTurn=!!p.turnId&&p.turnId===last?.turnId&&active(last.status);
   const questions=question&&Array.isArray(p.questions)?p.questions:[];
   const questionsFit=JSON.stringify(questions).length<=16000;
   const canAnswer=question&&validTurn&&questionsFit&&questions.length>0&&questions.length<=8&&!questions.some(q=>q.isSecret||typeof q.id!=='string'||typeof q.question!=='string');
   a={id:randomUUID(),key,nativeId:request.id,owner,snapshotCount:this.ipc.session(s.id)?.snapshotCount,threadId:s.id,turnId:p.turnId??last?.turnId,
    kind:question?'userInput':spec.kind,title:question?'需要你回答以下问题':spec.title,
    details:question?'回答将直接交回当前桌面回合。':spec.details,
    ...(spec.command?{command:spec.command}:{}),...(spec.reason?{reason:spec.reason}:{}),...(spec.summary?{summary:spec.summary}:{}),...(spec.cwd?{cwd:spec.cwd}:{}),
    ...(question?{questions:questionsFit?copy(questions):[],canAnswer}:{}),canApprove:question?canAnswer:validTurn&&support.canApprove&&!!spec.approve,
    canReject:!question&&validTurn&&support.canReject&&!!spec.reject,state:'pending',expiresAt:Date.now()+600000};
   s.approvals.set(a.id,a);this.emit(s,{type:'approval.upsert',approval:this.publicApproval(a)});
  }
  for(const a of s.approvals.values())if(a.state==='pending'&&(!seen.has(a.key)||Date.now()>=a.expiresAt)){a.state='expired';this.emit(s,{type:'approval.upsert',approval:this.publicApproval(a)});}
  while(s.approvals.size>32)s.approvals.delete(s.approvals.keys().next().value);
 }
 publicApproval(a){const {key,nativeId,owner,snapshotCount,expiredByConnection,...view}=a;return copy(view);}
 publish(id){
  const s=this.session(id),info=this.ipc.session(id);if(!info?.connected||info.awaitingSnapshot)return;
  const page=this.normalize(id);if(!page)return;const raw=this.ipc.raw(id);
  for(const turn of page.turns){
   const signature=JSON.stringify([turn.status,turn.clientRequestId]);if(s.turns.get(turn.id)!==signature){s.turns.set(turn.id,signature);this.emit(s,{type:'turn.upsert',turnId:turn.id,turnStatus:turn.status,...(turn.clientRequestId?{clientRequestId:turn.clientRequestId}:{})});}
   for(const item of turn.items){const key=JSON.stringify([turn.id,item.id]),value=JSON.stringify(item);if(s.items.get(key)!==value){s.items.set(key,value);this.emit(s,{type:'item.upsert',turnId:turn.id,item});}}
  }
  this.interactions(s,raw);s.page=page;
  const status=JSON.stringify([page.status,page.activity?.kind,page.activity?.itemId,page.title,page.model,page.reasoningEffort]);
  if(s.status!==status){s.status=status;this.emit(s,{type:'status',status:page.status,activity:page.activity,title:page.title,realtimeState:'connected',desktopConnectionRequired:false,notice:'',settings:{model:page.model,reasoningEffort:page.reasoningEffort}});}
 }
 async attach(id){const s=this.session(id);try{const view=await this.ipc.attach(id);s.attachError=null;this.publish(id);return view;}catch(error){if(['OWNER_NOT_FOUND','IPC_UNAVAILABLE','IPC_TIMEOUT','SNAPSHOT_TIMEOUT','IPC_DISCONNECTED','IPC_METHOD_UNSUPPORTED','IPC_VERSION_UNSUPPORTED','INITIALIZE_FAILED'].includes(error.code)){s.attachError=error.code;s.status=null;return null;}throw error;}}
 encode(id,before){const body=Buffer.from(JSON.stringify({id,before})).toString('base64url');return 'ipc.'+body+'.'+createHmac('sha256',this.secret).update(body).digest('base64url');}
 decode(cursor,id){try{const [prefix,body,sig,...rest]=cursor.split('.'),expected=createHmac('sha256',this.secret).update(body).digest('base64url');if(prefix!=='ipc'||rest.length||sig.length!==expected.length||!timingSafeEqual(Buffer.from(sig),Buffer.from(expected)))throw Error();const value=JSON.parse(Buffer.from(body,'base64url'));if(value.id!==id||typeof value.before!=='string')throw Error();return value.before;}catch{throw fail('CURSOR_EXPIRED','历史分页已失效，请刷新同一会话。');}}
 historyFallback(page,id){const code=this.session(id).attachError;
  const reason=code==='OWNER_NOT_FOUND'?'此对话尚未接入实时同步，可在桌面打开此对话。':['IPC_METHOD_UNSUPPORTED','IPC_VERSION_UNSUPPORTED','INITIALIZE_FAILED'].includes(code)?'当前桌面实时接口暂不兼容，请更新连接后重试。':['IPC_TIMEOUT','SNAPSHOT_TIMEOUT'].includes(code)?'实时连接暂时超时，正在自动重试。':'实时连接暂不可用，正在自动重连。';
  return {...page,realtimeState:'unavailable',desktopConnectionRequired:code==='OWNER_NOT_FOUND',notice:'已读取历史；'+reason};
 }
 async read(args){
  if(args.questionIndex)return this.desktop.execute('read',args);
  if(args.cursor&&!args.cursor.startsWith('ipc.')){
   await this.attach(args.threadId);const page=await this.desktop.execute('read',args),s=this.session(args.threadId),info=this.ipc.session(args.threadId);
   if(s.status!=null&&info?.connected&&!info.awaitingSnapshot&&s.page)return {...page,realtimeState:'connected',desktopConnectionRequired:false,notice:'',status:s.page.status,activity:s.page.activity,model:s.page.model,reasoningEffort:s.page.reasoningEffort,eventCursor:this.cursor(s)};
   return this.historyFallback(page,args.threadId);
  }
  let view=await this.attach(args.threadId);if(!view){if(args.cursor)throw fail('CURSOR_EXPIRED','桌面历史连接已变化，请刷新。');const page=await this.desktop.execute('read',args),session=this.session(args.threadId),info=this.ipc.session(args.threadId);
   // Bridge回读期间恢复的原生快照优先，避免迟到历史把实时状态降级。
   if(session.status!=null&&info?.connected&&!info.awaitingSnapshot&&session.page){view=viewOf(info);}else{
   return this.historyFallback(page,args.threadId);}}
  const s=this.session(args.threadId);if(args.cursor&&s.page.turns.findIndex(t=>t.id===this.decode(args.cursor,args.threadId))<10&&view.hasMoreHistory){await this.ipc.history(args.threadId);this.publish(args.threadId);}
  const page=s.page,limit=Math.max(1,Math.min(Number.isInteger(args.turnLimit)?args.turnLimit:10,10));let end=page.turns.length;
  if(args.cursor){end=page.turns.findIndex(t=>t.id===this.decode(args.cursor,args.threadId));if(end<0)throw fail('CURSOR_EXPIRED','历史边界已变化，请刷新。');}
  const start=Math.max(0,end-limit),turns=page.turns.slice(start,end),hasNativeMore=viewOf({current:{value:this.ipc.raw(args.threadId)}}).hasMoreHistory,more=start>0||hasNativeMore;
  if(!turns.length&&more)throw fail('INVALID_HISTORY','桌面尚未返回更早历史，请稍后刷新；不会发送消息激活。');
  const result={...page,turns,source:'desktop-bridge-ipc',realtimeState:'connected',desktopConnectionRequired:false,notice:'',hasMore:more,nextCursor:more&&turns.length?this.encode(args.threadId,turns[0].id):null,eventCursor:this.cursor(s),approvals:[...s.approvals.values()].map(a=>this.publicApproval(a))};
  if(Buffer.byteLength(JSON.stringify(result))>2*1024*1024)throw fail('RESPONSE_TOO_LARGE','本页超过移动端 2 MiB 上限，请减少回合数或在桌面查看。');return result;
 }
 async respond(args){
  const s=this.sessions.get(args.threadId),a=s?.approvals.get(args.approvalId);
  if(!a||a.state!=='pending'||Date.now()>=a.expiresAt)throw fail('APPROVAL_EXPIRED','审批已失效，请重新读取。');
  const info=this.ipc.session(args.threadId);if(!info?.connected||info.awaitingSnapshot||info.owner!==a.owner)throw fail('APPROVAL_EXPIRED','审批所属连接已变化，请重新读取。');
  if(!UUID.test(args.requestId??''))throw fail('BAD_INPUT','请求标识无效。');
  if(args.decision==='answer'?a.kind!=='userInput'||!a.canAnswer:a.kind==='userInput'||!['approve','reject'].includes(args.decision)||!a[args.decision==='approve'?'canApprove':'canReject'])throw fail('APPROVAL_UNSUPPORTED','请在原客户端处理此请求。');
  a.state='submitting';this.emit(s,{type:'approval.upsert',approval:this.publicApproval(a)});
  try{
   if(args.decision==='answer')await this.ipc.answer(args.threadId,{questionId:a.nativeId,expectedTurnId:a.turnId,answers:args.answers});
   else await this.ipc.approve(args.threadId,{approvalId:a.nativeId,expectedTurnId:a.turnId,decision:args.decision});
   a.state=args.decision==='reject'?'rejected':'submitted';return {accepted:true,approvalId:a.id,state:a.state,notice:'响应已送出，等待桌面回合继续执行。'};
  }catch(error){a.state=error.code==='DELIVERY_UNKNOWN'?'error':'expired';throw error;}finally{this.emit(s,{type:'approval.upsert',approval:this.publicApproval(a)});}
 }
 execute(operation,args={}){
  if(operation==='create'&&args.permissionMode!==undefined)throw fail('UNSUPPORTED_CAPABILITY','桌面 Bridge 模式不支持指定创建权限。');
  if(['importCandidates','importThread'].includes(operation))throw fail('UNSUPPORTED_CAPABILITY','桌面 Bridge 模式不提供导入。');
  if(['read','progress','send','interrupt','respondApproval','activateThread'].includes(operation)&&!UUID.test(args.threadId??''))throw fail('BAD_INPUT','会话ID无效。');
  return this.run(operation,args);
 }
 async run(operation,args){
  if(operation==='activateThread'){
   const result=await this.desktop.execute(operation,args);if(result?.activated!==true)throw fail('DELIVERY_UNKNOWN','桌面打开结果未确认，请核对桌面。');
   let connected=false;const deadline=Date.now()+4000;
   while(!this.closed&&Date.now()<deadline){
    let timer;try{const view=await Promise.race([this.attach(args.threadId).catch(()=>null),new Promise(resolve=>{timer=setTimeout(()=>resolve(null),Math.max(0,deadline-Date.now()));})]);if(view){connected=true;break;}}finally{clearTimeout(timer);}
    const remaining=deadline-Date.now();if(remaining<=0)break;await new Promise(resolve=>setTimeout(resolve,Math.min(200,remaining)));
   }
   return {threadId:args.threadId,activated:true,connected,notice:connected?'已连接桌面会话。':'已在桌面打开此会话，正在等待实时连接。'};
  }
  if(operation==='read')return this.read(args);
  if(operation==='respondApproval')return this.respond(args);
  if(operation==='interrupt'){await this.attach(args.threadId);await this.ipc.interrupt(args.threadId,{expectedTurnId:args.turnId});return {threadId:args.threadId,turnId:args.turnId,accepted:true,notice:'停止请求已送出，等待回合终态。'};}
  if(operation==='progress'){
   if(await this.attach(args.threadId)){const s=this.session(args.threadId),page=s.page,turn=page.turns.at(-1),assistant=[...(turn?.items??[])].reverse().find(i=>i.role==='assistant');return {id:args.threadId,status:page.status,turnId:turn?.id??null,turnStatus:turn?.status??null,text:assistant?.text??'',phase:assistant?.phase??null,textTruncated:false,cursor:this.cursor(s),eventCursor:this.cursor(s),activity:page.activity};}
  }
  if(operation==='send'){
   if(parseReply(args.prompt)){
    if(args.model!==undefined||args.thinking!==undefined||args.expectedTurnId!==undefined)throw fail('BAD_INPUT','异步问题答复不能夹带模型覆盖或任意补充消息。');
    if(!await this.attach(args.threadId))throw fail('QUESTION_EXPIRED','原问题实时连接不可用，请重新读取后核对。');
    let result;try{result=await this.ipc.answerAsync(args.threadId,{requestId:args.requestId,prompt:args.prompt});}catch(error){if(['IPC_METHOD_UNSUPPORTED','IPC_VERSION_UNSUPPORTED'].includes(error.code))throw fail('UNSUPPORTED_CAPABILITY','当前桌面不支持运行中问题答复，请更新连接。');throw error;}
    return {threadId:args.threadId,turnId:result.turnId,accepted:true,submissionScope:'item',_submission:{prompt:args.prompt,turnId:result.turnId,beforeTurnId:result.turnId,clientUserMessageId:result.clientUserMessageId}};
   }
   if(args.expectedTurnId!==undefined)throw fail('STEER_UNSUPPORTED','当前桌面组合不提供运行中补充，请等待本轮结束。');
   const s=this.ipc.session(args.threadId),last=s?.current?.value&&collectTurns(s.current.value).at(-1);if(s?.connected&&active(last?.status))throw fail('BUSY','当前回合仍在运行。');
  }
  const result=await this.desktop.execute(operation,args);
  if(['create','send'].includes(operation)&&result.threadId){
   try{if(!await this.attach(result.threadId))result.notice='桌面已接收消息，实时快照暂未就绪；请回读确认，不要重复发送。';}
   catch{result.notice='桌面已接收消息，实时快照暂未就绪；请回读确认，不要重复发送。';}
   const turnId=result._submission?.turnId;
   if(turnId){const turn=collectTurns(this.ipc.raw(result.threadId)).find(turn=>turn.turnId===turnId);
    if(UUID.test(turn?.params?.clientUserMessageId??''))result._submission.clientUserMessageId=turn.params.clientUserMessageId;
   }
  }
  return result;
 }
 async getStatus(){const status=await this.desktop.getStatus({maxDiscoveryAgeMs:this.ipc.hasLiveSession?.()===true?60000:0});let connected=false,desktopActivation=false;try{await this.ipc.ensureConnected();connected=true;}catch{}if(status.connected)try{desktopActivation=await this.desktop.supportsActivation?.()===true;}catch{}return {...status,backend:'desktop-bridge',instanceId:this.instanceId,capabilities:{streaming:connected,interrupt:connected,approvals:connected,asyncQuestionAnswers:connected,desktopActivation},nativeIpc:{connected}};}
 async close(){this.closed=true;for(const s of this.sessions.values())clearTimeout(s.timer);this.ipc.close();await this.desktop.close?.();}
}
module.exports={DesktopRuntime};
