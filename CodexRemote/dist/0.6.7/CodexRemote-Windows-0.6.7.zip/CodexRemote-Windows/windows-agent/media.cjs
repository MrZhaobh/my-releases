'use strict';
const fs=require('node:fs/promises');
const fsSync=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const MAX_IMAGE_BYTES=3*1024*1024;
const MAX_MEDIA_ENTRIES=500;
const MEDIA_TTL_MS=2*60*60*1000;
const EXTENSION_MIME={'.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp','.gif':'image/gif'};
class MediaError extends Error{constructor(code,message){super(message);this.code=code}}
function sniffImage(buffer){
 if(buffer.length>=8&&buffer.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))return'image/png';
 if(buffer.length>=3&&buffer[0]===0xff&&buffer[1]===0xd8&&buffer[2]===0xff)return'image/jpeg';
 if(buffer.length>=12&&buffer.toString('ascii',0,4)==='RIFF'&&buffer.toString('ascii',8,12)==='WEBP')return'image/webp';
 if(buffer.length>=6&&['GIF87a','GIF89a'].includes(buffer.toString('ascii',0,6)))return'image/gif';
 return null;
}
function imageUuid(threadId,source,stat=null){
 const metadata=stat?`${stat.size}:${stat.mtimeNs??BigInt(Math.trunc(Number(stat.mtimeMs)*1e6))}`:'unavailable';
 const hash=crypto.createHash('sha256').update(`${threadId}\0${source}\0${metadata}`).digest('hex').slice(0,32);
 return`${hash.slice(0,8)}-${hash.slice(8,12)}-4${hash.slice(13,16)}-${((parseInt(hash[16],16)&3)|8).toString(16)}${hash.slice(17,20)}-${hash.slice(20)}`;
}
function safeImageName(value){return(path.basename(value).replace(/[\x00-\x1f\x7f]/g,'').slice(0,255)||'image')}
function registerHistoryImage(cache,threadId,imagePath,now=Date.now()){
 if(typeof imagePath!=='string')return null;
 try{
  const canonical=fsSync.realpathSync(imagePath),details=fsSync.statSync(canonical,{bigint:true});
  if(!details.isFile())throw new Error('not-file');
  const imageId=imageUuid(threadId,canonical,details),name=safeImageName(canonical);
  const mime=EXTENSION_MIME[path.extname(canonical).toLowerCase()]??'application/octet-stream';
  for(const[key,entry]of cache)if(entry.threadId===threadId&&entry.path===canonical&&key!==imageId)cache.delete(key);
  cache.delete(imageId);
  cache.set(imageId,{threadId,path:canonical,name,mime,size:details.size.toString(),mtimeNs:details.mtimeNs.toString(),createdAt:now});
  while(cache.size>MAX_MEDIA_ENTRIES)cache.delete(cache.keys().next().value);
  return{id:imageId,name,mime,size:Number(details.size)};
 }catch{
  const source=imagePath.slice(0,32768),name=safeImageName(source),mime=EXTENSION_MIME[path.extname(source).toLowerCase()]??'application/octet-stream';
  return{id:imageUuid(threadId,source),name,mime,size:null,unavailable:true};
 }
}
async function readHistoryImage(cache,threadId,imageId,now=Date.now()){
 if(typeof imageId!=='string'||imageId.length>64)throw new MediaError('NOT_FOUND','图片不可用');
 const entry=cache.get(imageId);
 if(!entry||entry.threadId!==threadId||now-entry.createdAt>MEDIA_TTL_MS){if(entry&&now-entry.createdAt>MEDIA_TTL_MS)cache.delete(imageId);throw new MediaError('NOT_FOUND','图片不可用')}
 try{
  const handle=await fs.open(entry.path,'r');
  let bytes;
  try{
   const stat=await handle.stat({bigint:true});
   if(!stat.isFile()||stat.size.toString()!==entry.size||stat.mtimeNs.toString()!==entry.mtimeNs)throw new MediaError('NOT_FOUND','图片不可用');
   if(stat.size>BigInt(MAX_IMAGE_BYTES))throw new MediaError('IMAGE_TOO_LARGE','图片超过 3 MiB 上限');
   const buffer=Buffer.alloc(Number(stat.size));let offset=0;
   while(offset<buffer.length){const{bytesRead}=await handle.read(buffer,offset,buffer.length-offset,offset);if(!bytesRead)throw new MediaError('NOT_FOUND','图片不可用');offset+=bytesRead}
   const after=await handle.stat({bigint:true});
   if(after.size.toString()!==entry.size||after.mtimeNs.toString()!==entry.mtimeNs)throw new MediaError('NOT_FOUND','图片不可用');
   bytes=buffer;
  }finally{await handle.close()}
  const mime=sniffImage(bytes);
  if(!mime)throw new MediaError('UNSUPPORTED_IMAGE','图片格式不受支持');
  // 文件名只用于展示；以实际内容的允许格式决定响应 MIME。
  return{mime,base64:bytes.toString('base64')};
 }catch(error){if(error instanceof MediaError)throw error;throw new MediaError('NOT_FOUND','图片不可用')}
}
module.exports={MAX_IMAGE_BYTES,MediaError,sniffImage,registerHistoryImage,readHistoryImage};
