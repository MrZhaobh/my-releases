'use strict';

const path = require('node:path');
const {normalizeHistory} = require('./desktop.cjs');
const {collectTurns, active, UUID} = require('./desktop-ipc-state.cjs');

// 验收：纯状态映射；时间正序去重、稳定标识、正文完整、工具预览有界、媒体只传描述符。
const TOOL_PREVIEW_BYTES = 8 * 1024;
const TOOL_PREVIEW_NOTICE = '\n[工具输出仅显示有界预览；完整日志请在桌面查看。]';
const TITLES = {
  thinking: '正在思考', compacting: '正在压缩上下文', command: '正在运行命令',
  editing: '正在修改文件', tool: '正在使用工具', responding: '正在回复',
  waiting: '等待审批', processing: '正在处理', idle: '已完成',
  failed: '运行失败', cancelled: '已停止', syncing: '正在同步',
};
const byteLength = value => Buffer.byteLength(typeof value === 'string' ? value : JSON.stringify(value), 'utf8');
const statusOf = value => {
  const status = typeof value === 'string' ? value : value?.type;
  return ({inProgress: 'running', in_progress: 'running', pending: 'running', interrupted: 'cancelled'})[status] ?? status ?? 'unknown';
};
const terminalItem = value => ['completed', 'failed', 'declined', 'cancelled', 'interrupted'].includes(value);
function utf8Prefix(value, maximum) {
  const buffer = Buffer.from(String(value), 'utf8');
  let end = Math.max(0, Math.min(Math.floor(maximum), buffer.length));
  while (end > 0 && end < buffer.length && (buffer[end] & 0xc0) === 0x80) end--;
  return buffer.subarray(0, end).toString('utf8');
}
function itemStatus(item, turn) {
  if (terminalItem(item.status)) return item.status;
  if (Number.isFinite(item.completedAtMs) || turn.completedItemIds?.[item.id] === true) return 'completed';
  if (item.status) return item.status;
  if (turn.completedItemIds?.[item.id] === false || Number.isFinite(item.startedAtMs) && item.completedAtMs === null) return 'inProgress';
  return undefined;
}
function toolPreview(item) {
  const source = item.text ?? '', result = {
    id: item.id, type: item.type, role: 'tool', phase: item.phase ?? null,
    originalBytes: byteLength(source),
  };
  let metadataTruncated = false;
  for (const key of ['status', 'exitCode', 'command', 'tool', 'server', 'title', 'cwd',
    'toolName', 'arguments', 'success', 'error', 'contentItems', 'commandActions',
    'actionSummary', 'fileCount', 'paths', 'pathsTruncated', 'path', 'kind',
    'agentPath', 'agentThreadId', 'model', 'reasoningEffort', 'source', 'durationMs', 'action']) {
    if (item[key] === undefined) continue;
    const value = item[key];
    if (byteLength(value) > 1024) {
      result[key] = utf8Prefix(typeof value === 'string' ? value : JSON.stringify(value), 1024);
      metadataTruncated = true;
    } else result[key] = value;
  }
  if (item.changes !== undefined) {
    if (byteLength(item.changes) <= 1024) result.changes = item.changes;
    else {
      result.changesPreview = utf8Prefix(JSON.stringify(item.changes), 1024);
      metadataTruncated = true;
    }
  }
  for (const key of ['toolFiles', 'toolImages']) if (item[key]?.length) result[key] = item[key].slice(0, 4);
  const truncated = result.originalBytes > TOOL_PREVIEW_BYTES || metadataTruncated;
  result.text = truncated
    ? utf8Prefix(source, TOOL_PREVIEW_BYTES - byteLength(TOOL_PREVIEW_NOTICE)) + TOOL_PREVIEW_NOTICE
    : source;
  if (truncated) result.outputTruncated = true;
  if (metadataTruncated) result.metadataTruncated = true;
  return result;
}
function toolDescriptor(file, item, raw, threadId, register) {
  if (typeof file !== 'string' || !file || file.length > 32768) return null;
  // 同时识别 Windows 与 POSIX 绝对路径；相对路径只能使用桌面明确提供的 cwd。
  const api = path.win32.isAbsolute(file) && !path.posix.isAbsolute(file) ? path.win32 : path;
  if (!api.isAbsolute(file)) {
    const cwd = item.cwd ?? raw.cwd ?? raw.latestThreadSettings?.cwd;
    if (typeof cwd !== 'string') return null;
    const cwdApi = path.win32.isAbsolute(cwd) && !path.posix.isAbsolute(cwd) ? path.win32 : path;
    if (!cwdApi.isAbsolute(cwd)) return null;
    file = cwdApi.resolve(cwd, file);
  }
  const descriptor = register?.(threadId, file);
  if (!descriptor || typeof descriptor !== 'object') return null;
  return {
    ...Object.fromEntries(['id', 'mime', 'size', 'unavailable'].filter(key => descriptor[key] !== undefined).map(key => [key, descriptor[key]])),
    name: utf8Prefix(descriptor.name ?? 'file', 255),
  };
}

function asyncQuestions(item) {
  if (item.type !== 'agentMessage' || item.delivery !== 'async' || !Array.isArray(item.questions) || !item.questions.length) return null;
  if (!item.questions.every(question => question && typeof question === 'object'
    && typeof (question.title ?? question.question) === 'string'
    && (question.options == null || Array.isArray(question.options)
      && question.options.every(option => typeof option === 'string' || option && typeof option.label === 'string')))) return null;
  return item.questions.map(question => ({...question, title: question.title ?? question.question, options: question.options ?? []}));
}

function questionReplies(turns) {
  const replies = new Map();
  for (const turn of turns) for (const item of turn.items) {
    if (item?.type !== 'steeringUserMessage' || item.status !== 'accepted'
      || item.targetTurnId != null && ![turn.turnId, turn.rootTurnId, turn._id].includes(item.targetTurnId)
      || !Array.isArray(item.input)) continue;
    const text = item.input.filter(part => part?.type === 'text' && typeof part.text === 'string').map(part => part.text).join('\n');
    const match = /^\s*<send_user_message_question_reply>\s*([\s\S]*)\s*<\/send_user_message_question_reply>\s*$/.exec(text);
    if (!match || byteLength(match[1]) > 64 * 1024) continue;
    let entries;
    try { entries = JSON.parse(match[1]); } catch { continue; }
    if (!Array.isArray(entries) || !entries.length || entries.length > 64) continue;
    const parsed = [];
    for (const entry of entries) {
      let identity;
      try { identity = JSON.parse(entry?.questionItemId); } catch { break; }
      if (!Array.isArray(identity) || identity.length !== 3 || identity[0] !== 'request_user_input_async'
        || typeof identity[1] !== 'string' || !identity[1] || !Number.isSafeInteger(identity[2]) || identity[2] < 0
        || typeof entry.question !== 'string' || typeof entry.answer !== 'string'
        || entry.skipped !== undefined && typeof entry.skipped !== 'boolean') break;
      parsed.push({callId: identity[1], index: identity[2], question: entry.question, answer: entry.answer, skipped: entry.skipped === true});
    }
    if (parsed.length !== entries.length) continue;
    for (const reply of parsed) {
      if (!replies.has(reply.callId)) replies.set(reply.callId, new Map());
      replies.get(reply.callId).set(reply.index, reply);
    }
  }
  return replies;
}

function normalizeItem(item, turn, index, raw, context) {
  if (!item || typeof item !== 'object') return null;
  if (item.type === 'steered') return null;
  if (item.type === 'steeringUserMessage') {
    if (!Array.isArray(item.input)) return null;
    const normalized = normalizeItem({...item, type: 'userMessage', content: item.input,
      clientId: item.clientUserMessageId ?? item.serverClientUserMessageId}, turn, index, raw, context);
    return normalized ? {...normalized, ...(item.status !== undefined ? {status: item.status} : {})} : null;
  }
  if (/reasoning/i.test(item.type ?? '') || /^(reasoning|analysis)$/i.test(item.phase ?? '')) return null;
  if (['functionCallOutput', 'function_call_output'].includes(item.type) && ['create_thread', 'send_message_to_thread'].includes(item.name)) return null;
  const id = typeof item.id === 'string' && item.id ? item.id : `${turn._id}:item:${index}`;
  const questions = asyncQuestions(item);
  if (questions) {
    const replies = [...(context.questionReplies?.get(id)?.values() ?? [])].filter(reply => reply.index < questions.length);
    const answered = replies.length === questions.length;
    return {id, type: 'request_user_input_async', role: 'assistant', phase: 'question',
      text: item.text ?? '', callId: id, delivery: 'async', questions,
      ...(replies.length ? {_questionReplyAnswers: replies.map(({callId, ...reply}) => reply)} : {}),
      ...(answered ? {_questionReplyState: 'answered'} : {})};
  }
  if (['agentMessage', 'userMessage'].includes(item.type)) {
    // IPC 的交互请求单独映射；不要把助手的正文列表改写成合成问卷。
    const native = item.type === 'agentMessage' ? {...item, phase: null} : {
      ...item, content: Array.isArray(item.content) ? item.content : [{type: 'text', text: typeof item.text === 'string' ? item.text : typeof item.content === 'string' ? item.content : ''}],
    };
    const normalized = normalizeHistory({thread: {id: context.threadId}, turns: [{id: turn._id, items: [native]}]}, context).turns[0].items[0];
    if (!normalized) return null;
    // 合成输入与随后到达的原生回显共享标识；steer 使用自己的 clientId，不能继承首条请求。
    const clientRequestId = item.type === 'userMessage' && UUID.test(item.clientId ?? '') ? item.clientId : null;
    return {...normalized, id: clientRequestId ? `user:${clientRequestId}` : id, phase: item.phase ?? normalized.phase ?? null,
      ...(clientRequestId ? {clientRequestId} : {})};
  }
  const fields = Object.fromEntries(['command', 'exitCode', 'tool', 'server', 'changes',
    'title', 'cwd', 'arguments', 'success', 'error', 'contentItems', 'commandActions',
    'path', 'kind', 'agentPath', 'agentThreadId', 'model', 'reasoningEffort', 'source',
    'durationMs', 'action'].filter(key => item[key] !== undefined).map(key => [key, item[key]]));
  const status = itemStatus(item, turn);
  if (status !== undefined) fields.status = status;
  if (item.name) fields.toolName = item.name;
  if (Array.isArray(item.commandActions)) {
    fields.actionSummary = {read: 0, list: 0, search: 0, run: 0};
    for (const action of item.commandActions) fields.actionSummary[({read: 'read', listFiles: 'list', search: 'search'})[action?.type] ?? 'run']++;
  }
  if (item.type === 'fileChange' && Array.isArray(item.changes) && item.changes.every(change => typeof change?.path === 'string' && change.path)) {
    const paths = [...new Set(item.changes.map(change => change.path))];
    fields.fileCount = paths.length;
    fields.paths = paths.slice(0, 4).map(file => utf8Prefix(file, 200));
    fields.pathsTruncated = paths.length > 4 || paths.some(file => byteLength(file) > 200);
    fields.toolFiles = paths.slice(0, 4).map(file => toolDescriptor(file, item, raw, context.threadId, context.registerAttachment)).filter(Boolean);
  }
  if (item.type === 'imageView') {
    const image = toolDescriptor(item.path, item, raw, context.threadId, context.registerImage);
    if (image) fields.toolImages = [image];
    delete fields.path;
  }
  const output = item.aggregatedOutput ?? item.text ?? item.output ?? item.result;
  return toolPreview({id, type: item.type ?? 'unknown', role: 'tool', phase: item.phase ?? null,
    text: output == null ? '' : typeof output === 'string' ? output : JSON.stringify(output), ...fields});
}
function kindOf(item) {
  if (/reasoning/i.test(item.type ?? '') || /^(reasoning|analysis)$/i.test(item.phase ?? '')) return 'thinking';
  if (['steeringUserMessage', 'steered'].includes(item.type)) return null;
  return ({contextCompaction: 'compacting', commandExecution: 'command', fileChange: 'editing', agentMessage: 'responding', userMessage: null})[item.type] ?? (item.type === 'userMessage' ? null : 'tool');
}
function activityOf(raw, turns, threadId) {
  const turn = turns.at(-1);
  let kind, selected;
  const status = statusOf(turn?.status ?? raw.status);
  if (status === 'waiting') kind = 'waiting';
  else if (!active(status)) kind = ['failed', 'cancelled'].includes(status) ? status : status === 'unknown' ? 'syncing' : 'idle';
  else {
    const waiting = (Array.isArray(raw.requests) ? raw.requests : []).some(request => request && request.completed !== true
      && (request.params?.threadId == null || request.params.threadId === threadId)
      && (request.params?.turnId == null || request.params.turnId === (turn.turnId ?? turn._id))
      && (/\/requestApproval$/.test(request.method ?? '') || ['mcpServer/elicitation/request', 'item/tool/requestUserInput'].includes(request.method)));
    if (waiting) kind = 'waiting';
    else {
      const pending = turn.items.map((item, index) => ({item, index, kind: item && typeof item === 'object' ? kindOf(item) : null}))
        .filter(({item, kind}) => kind && !terminalItem(itemStatus(item, turn))
          && (active(itemStatus(item, turn)) || turn.completedItemIds?.[item.id] === false));
      selected = [...pending].reverse().find(item => ['compacting', 'command', 'editing', 'tool'].includes(item.kind))
        ?? [...pending].reverse().find(item => item.kind === 'responding') ?? pending.find(item => item.kind === 'thinking');
      kind = selected?.kind ?? 'processing';
    }
  }
  return {kind, title: TITLES[kind],
    ...(selected ? {itemId: selected.item.id || `${turn._id}:item:${selected.index}`} : {}),
    updatedAt: selected?.item.startedAtMs ?? turn?.turnStartedAtMs ?? raw.updatedAtMs ?? 0};
}

function fallbackInput(turn) {
  const params = turn.params ?? {};
  if (Array.isArray(params.input) && params.input.length) return params.input;
  const output = params.toolOutput;
  if (output?.namespace !== 'codex_app' || !['send_message_to_thread', 'create_thread'].includes(output.name) || typeof output.output !== 'string') return null;
  // 只解析明确的委派封套，正文始终是用户文本。贪婪捕获保留正文中出现的同名标签。
  const match = /^\s*<codex_delegation>\s*<source_thread_id>([^<>\r\n]+)<\/source_thread_id>\s*<input>([\s\S]*)<\/input>\s*<\/codex_delegation>\s*$/.exec(output.output);
  if (!match || !UUID.test(match[1].trim()) || !match[2].length) return null;
  return [{type: 'text', text: match[2]}];
}

function assignedTurnId(turn) {
  for (const id of [turn.turnId, turn.rootTurnId])
    if (typeof id === 'string' && id.trim() && !/^(tail:|live:)/.test(id)) return id;
  // 已落入历史索引的 UUID key 可独立标识正式历史；tail/local 与 live 下标不能当 turn ID。
  if (UUID.test(turn._id ?? '')) return turn._id;
  const keyId = typeof turn._id === 'string' && turn._id.startsWith('turn:') ? turn._id.slice(5) : '';
  return UUID.test(keyId) ? keyId : null;
}

function assignedTurns(collected) {
  const turns = new Map();
  for (const turn of collected) {
    const id = assignedTurnId(turn);
    if (id) turns.set(id, {...turn, _id: id});
  }
  return [...turns.values()].sort((a, b) => (a.turnStartedAtMs ?? 0) - (b.turnStartedAtMs ?? 0));
}

/** 将桌面 conversationState 转成现有 Android 会话协议；回调与 normalizeHistory 保持相同签名。 */
function normalizeConversation(raw = {}, {threadId = raw.threadId ?? raw.id, registerImage, registerVisualization, registerAttachment} = {}) {
  const context = {threadId, registerImage, registerVisualization, registerAttachment};
  // 尚未分配正式 turn ID 的瞬时状态不能发布；Android 只有 upsert，无法删除旧临时 turn。
  const rawTurns = collectTurns(raw), collected = assignedTurns(rawTurns);
  context.questionReplies = questionReplies(collected);
  const turns = collected.map(turn => {
    const items = new Map();
    for (const [index, item] of turn.items.entries()) {
      const normalized = normalizeItem(item, turn, index, raw, context);
      if (normalized) items.set(normalized.id, normalized);
    }
    // steer 是后续用户消息，不能因此丢掉本轮最初仅存在于 params 的输入。
    const input = !turn.items.some(item => item?.type === 'userMessage') ? fallbackInput(turn) : null;
    if (input) {
      const item = normalizeItem({type: 'userMessage', id: `${turn._id}:input`, clientId: turn.params?.clientUserMessageId, content: input}, turn, -1, raw, context);
      if (item && !items.has(item.id)) return {id: turn._id, status: statusOf(turn.status), items: [item, ...items.values()]};
    }
    return {id: turn._id, status: statusOf(turn.status), items: [...items.values()]};
  });
  const latest = rawTurns.at(-1);
  const awaitingTurnId = latest && !assignedTurnId(latest) && active(statusOf(latest.status));
  // 保留新轮正在开始的状态，但不把上一正式轮改为 running，也不暴露临时标识。
  const activity = awaitingTurnId
    ? {kind: 'processing', title: '正在等待桌面同步', updatedAt: latest.turnStartedAtMs ?? raw.updatedAtMs ?? 0}
    : activityOf(raw, collected, threadId);
  return {id: threadId, title: raw.title ?? raw.name ?? '未命名会话',
    status: awaitingTurnId ? 'running' : activity.kind === 'waiting' ? 'waiting' : statusOf(collected.at(-1)?.status ?? raw.status),
    model: raw.latestModel ?? raw.latestThreadSettings?.model ?? null,
    reasoningEffort: [raw.latestReasoningEffort, raw.latestThreadSettings?.effort, raw.latestThreadSettings?.reasoningEffort]
      .find(value => typeof value === 'string' && value.trim())?.trim() ?? null,
    turns, activity};
}

module.exports = {normalizeConversation,questionReplies};
