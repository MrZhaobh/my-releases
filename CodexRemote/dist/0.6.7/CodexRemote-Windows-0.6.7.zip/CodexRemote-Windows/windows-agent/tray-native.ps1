﻿param([string]$NodePath=(Get-Command node.exe -ErrorAction SilentlyContinue).Source,[switch]$Preview,[switch]$SmokeTest,[string]$EvidenceDirectory,[ValidateRange(1,2)][double]$PreviewScale=1,[string]$StartupNotice='')
$ErrorActionPreference='Stop'
if($SmokeTest -and -not $Preview){throw 'SmokeTest 必须使用隔离 Preview 模式。'}
if(-not $Preview -and (-not $NodePath -or -not(Test-Path -LiteralPath $NodePath))){throw '未找到 Node 运行时，请使用完整 Windows 发布包启动。'}
if(-not $Preview){
 & $NodePath --no-warnings -e "try{require('node:sqlite')}catch{process.exit(1)}" 2>$null
 if($LASTEXITCODE -ne 0){throw '当前 Node 运行时不支持 node:sqlite。请使用完整 Windows 发布包，或通过 -NodePath 指定 Node 24 的 node.exe。'}
}
Add-Type -AssemblyName PresentationFramework,PresentationCore,WindowsBase,System.Windows.Forms,System.Drawing
$script:mutex=$null
$script:activationSignal=$null
. (Join-Path $PSScriptRoot 'panel-activation.ps1')
if(-not $Preview){$instance=Open-ControlPanelInstance;if(-not $instance.owned){return};$script:mutex=$instance.mutex;$script:activationSignal=$instance.signal}
$controller=Join-Path $PSScriptRoot 'tray-controller.cjs'
$script:exiting=$false;$script:backendReady=[bool]$Preview;$script:startupAttempted=$false;$script:statusPending=$false;$script:pendingBusy=$false;$script:pendingForceRequired=$false;$script:pendingContext='';$script:phonesBusy=$false;$script:operationBusy=$false;$script:desktopBusy=$false;$script:confirmBusy=$false;$script:detectionBusy=$false
$script:selection=$null;$script:settings=$null;$script:lastStatus=$null;$script:invite=$null;$script:requestId='';$script:requestExpires=0L;$script:pendingRows=@();$script:phoneRows=@();$script:asyncRequests=New-Object Collections.ArrayList
$script:previewCalls=New-Object Collections.ArrayList;$script:previewState=@{runtimeMode='desktop-bridge';name='我的工作电脑';autoStart=$false;paused=$false;paired=$true;desktopInstance=$null};$script:previewLaunch=@{phase='idle';stage='idle'}
$script:previewQueue=New-Object Collections.ArrayList;$script:deferPreview=$false
$script:previewState.relayUrl='https://relay.example.com'
$reader=New-Object Xml.XmlTextReader((Join-Path $PSScriptRoot 'tray-window.xaml'));try{$script:window=[Windows.Markup.XamlReader]::Load($reader)}finally{$reader.Close()}
$script:ui=@{}
foreach($name in @('HomeTab','PhonesTab','SettingsTab','HomePanel','SettingsPanel','PhonesPanel','HomeTitle','OverviewPanel','HomeInstanceName','HomeInstanceSource','RelayStatus','EngineStatus','PhoneCount','LaunchProgress','LaunchButton','PairButton','PauseButton','RetryRelayButton','PairPanel','QrImage','QrPlaceholder','InviteCode','CopyCodeButton','InviteCountdown','RefreshInviteButton','BackFromPairButton','RequestsPanel','RequestCount','PendingRequests','VerificationCode','RequestExpiry','AgreeCode','ApproveButton','RejectButton','InstanceDrop','InstanceName','InstanceSource','InstanceDetectionStatus','InstanceDetectionProgress','InstanceDetectionText','ChooseInstanceButton','DetectButton','ImportButton','ModeCombo','ModeHint','ComputerName','AutoStart','SaveButton','SaveLaunchButton','PhonesEmpty','PhonesList','AddPhoneButton','RefreshPhonesButton','Notice','FooterStatus')){$script:ui[$name]=$script:window.FindName($name)}
$script:ui.RelayAddress=$script:window.FindName('RelayAddress')
if($Preview){$script:window.Title='Codex Remote · 隔离预览'}
try{$script:window.Icon=New-Object Windows.Media.Imaging.BitmapImage([Uri](Join-Path $PSScriptRoot 'app.ico'))}catch{}
$script:lightPalette=@{}
foreach($resourceKey in $script:window.Resources.Keys){if($script:window.Resources[$resourceKey] -is [Windows.Media.SolidColorBrush]){$script:lightPalette[$resourceKey]=$script:window.Resources[$resourceKey].Color.ToString()}}
function Set-NativeTheme([ValidateSet('System','Light','Dark','HighContrast')][string]$Theme='System'){
 $dark=$false;try{$dark=(Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' -Name AppsUseLightTheme).AppsUseLightTheme -eq 0}catch{}
 if($Theme -ne 'System'){$dark=$Theme -eq 'Dark'}
 $highContrast=$Theme -eq 'HighContrast' -or ($Theme -eq 'System' -and [Windows.SystemParameters]::HighContrast)
 if($highContrast){$map=@{PageBrush=[Windows.SystemColors]::WindowColor;SurfaceBrush=[Windows.SystemColors]::WindowColor;TextBrush=[Windows.SystemColors]::WindowTextColor;MutedBrush=[Windows.SystemColors]::WindowTextColor;LineBrush=[Windows.SystemColors]::WindowTextColor;AccentBrush=[Windows.SystemColors]::HighlightColor;AccentTextBrush=[Windows.SystemColors]::HighlightTextColor;SuccessBrush=[Windows.SystemColors]::WindowTextColor;WarningBrush=[Windows.SystemColors]::WindowTextColor}}
 elseif($dark){$map=@{PageBrush='#202020';SurfaceBrush='#2D2D2D';TextBrush='#F5F5F5';MutedBrush='#B6B6B6';LineBrush='#454545';AccentBrush='#7DC5FF';AccentTextBrush='#003052';HoverBrush='#383838';SuccessBrush='#87D6A1';WarningBrush='#EDC484'}}else{$map=$script:lightPalette}
 foreach($key in $map.Keys){$script:window.Resources[$key]=[Windows.Media.SolidColorBrush]::new([Windows.Media.ColorConverter]::ConvertFromString([string]$map[$key]))}
 $scrollColors=if($highContrast){@{ScrollTrackBrush=[Windows.SystemColors]::WindowColor;ScrollThumbBrush=[Windows.SystemColors]::WindowTextColor;ScrollThumbHoverBrush=[Windows.SystemColors]::HighlightColor;ScrollThumbPressedBrush=[Windows.SystemColors]::HighlightColor}}elseif($dark){@{ScrollTrackBrush='#242424';ScrollThumbBrush='#858589';ScrollThumbHoverBrush='#B0B0B4';ScrollThumbPressedBrush='#D0D0D4'}}else{@{ScrollTrackBrush='#F1F1F3';ScrollThumbBrush='#858589';ScrollThumbHoverBrush='#626268';ScrollThumbPressedBrush='#45454B'}}
 foreach($key in $scrollColors.Keys){$script:window.Resources[$key]=[Windows.Media.SolidColorBrush]::new([Windows.Media.ColorConverter]::ConvertFromString([string]$scrollColors[$key]))}
 $script:window.Resources[[Windows.SystemParameters]::VerticalScrollBarWidthKey]=[double]$(if($highContrast){18}else{12})
 $script:window.Resources[[Windows.SystemParameters]::HorizontalScrollBarHeightKey]=[double]$(if($highContrast){18}else{12})
}
Set-NativeTheme
function Set-Notice([string]$Text,[bool]$Failure=$false){$script:ui.Notice.Text=$Text;$script:ui.Notice.Foreground=$script:window.Resources[$(if($Failure){'WarningBrush'}else{'MutedBrush'})]}
function Get-SelectionDraftPath{
 if($Preview){if($SmokeTest -and $EvidenceDirectory){return Join-Path ([IO.Path]::GetFullPath($EvidenceDirectory)) 'desktop-selection-draft.json'};return $null}
 $directory=if($env:CODEX_REMOTE_DATA_DIR){$env:CODEX_REMOTE_DATA_DIR}else{Join-Path $env:LOCALAPPDATA 'CodexRemote\windows-agent-v0.6\data'}
 return Join-Path $directory 'desktop-selection-draft.json'
}
function Save-SelectionDraft{
 if(-not $script:selection){return}
 $record=@{version=1;baseSelectionId=[string]$script:settings.desktopInstance.id;selection=$script:selection}
 $path=Get-SelectionDraftPath
 if(-not $path){$script:previewSelectionDraft=$record;return}
 [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($path))|Out-Null
 $temporary=$path+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
 try{[IO.File]::WriteAllText($temporary,($record|ConvertTo-Json -Depth 6),[Text.UTF8Encoding]::new($false));if([IO.File]::Exists($path)){[IO.File]::Replace($temporary,$path,[System.Management.Automation.Language.NullString]::Value)}else{[IO.File]::Move($temporary,$path)}}finally{if([IO.File]::Exists($temporary)){[IO.File]::Delete($temporary)}}
}
function Clear-SelectionDraft{
 $path=Get-SelectionDraftPath;if($path -and [IO.File]::Exists($path)){[IO.File]::Delete($path)};$script:previewSelectionDraft=$null
}
function Restore-SelectionDraft($Settings){
 $script:selectionDraftRestored=$false;$path=Get-SelectionDraftPath;$draft=$null
 try{if($path -and [IO.File]::Exists($path)){if((Get-Item -LiteralPath $path).Length -gt 32768){return $Settings.desktopInstance};$draft=[IO.File]::ReadAllText($path)|ConvertFrom-Json}elseif(-not $path){$draft=$script:previewSelectionDraft}}catch{return $Settings.desktopInstance}
 if(-not $draft -or $draft.version -ne 1 -or [string]$draft.baseSelectionId -ne [string]$Settings.desktopInstance.id){return $Settings.desktopInstance}
 $fields=@('id','kind','name','sourcePath','desktopExecutable','sharedSupported');$selection=$draft.selection
 if(-not $selection -or -not $selection.id -or -not $selection.sourcePath -or @($selection.PSObject.Properties|Where-Object {$_.Name -notin $fields}).Count){return $Settings.desktopInstance}
 if($selection.id -isnot [string] -or $selection.kind -isnot [string] -or $selection.name -isnot [string] -or $selection.sourcePath -isnot [string] -or $selection.desktopExecutable -isnot [string] -or $selection.sharedSupported -isnot [bool]){return $Settings.desktopInstance}
 try{if($selection.sourcePath.IndexOfAny([IO.Path]::GetInvalidPathChars()) -ge 0){return $Settings.desktopInstance};[void][IO.Path]::GetFileName($selection.sourcePath)}catch{return $Settings.desktopInstance}
 $script:selectionDraftRestored=$true;return $selection
}
function Remember-Selection($Selection){
 $previous=$script:selection;$script:selection=$Selection
 try{Save-SelectionDraft;Update-SelectionView;Set-Notice '已记住实例选择，保存后应用。'}catch{$script:selection=$previous;Update-SelectionView;Set-Notice '未能记住实例选择，请重试。' $true}
}
function Get-ErrorText([string]$Text){
 if($Text -match 'DESKTOP_CLI_PREPARE_FAILED'){return '无法准备与当前 Codex 匹配的共享引擎程序。请检查本机私有目录权限及磁盘空间。'}
 if($Text -match 'DESKTOP_ENGINE_INSPECTION_FAILED'){return '无法检查旧共享引擎的进程或端口状态，启动已暂停。请查看本机诊断；此错误不代表旧引擎仍在运行。'}
 if($Text -match 'DESKTOP_SHARED_SELECTION_MISMATCH'){return '共享启动配置与当前 Codex 入口不一致。请重新检测实例并保存；若仍失败，请检查独立实例配置或启动器是否已变更。'}
 if($Text -match 'DESKTOP_PREVIOUS_ENGINE_RUNNING|DESKTOP_PREVIOUS_ENGINE_UNKNOWN'){return '旧共享引擎仍在运行或身份无法确认。请检查本机诊断，不要重复启动或强制结束 Codex。'}
 if($Text -match 'DESKTOP_SHARED_RUN_STALE'){return '检测到旧共享端点残留，未重复启动。请检查旧引擎退出状态后重新配置共享启动。'}
 if($Text -match 'DESKTOP_BROKER_EXITED|DESKTOP_BROKER_NOT_READY|DESKTOP_BROKER_STATUS_STALE'){return '共享引擎未能就绪。请查看本机 broker 状态和引擎日志，确认当前 Codex CLI 可用。'}
 if($Text -match 'DESKTOP_EXISTING_PROCESS'){return 'Codex 正在运行。请保存工作并手动退出，再重新启动共享模式。'}
 if($Text -match 'DESKTOP_DETECTION_TIMEOUT'){return '检测超时，请重试；也可直接导入快捷方式。'}
 if($Text -match 'DESKTOP_LEGACY_CONNECTION_ONLY'){return '当前旧版共享连接尚未配置一键启动，实例选择和现有连接已保留。'}
 if($Text -match 'DESKTOP_SHARED_CONFIG_INVALID'){return '共享配置无效或不兼容，未应用更改。请保留现有连接并检查本机配置。'}
 if($Text -match 'DESKTOP_SELECTION_CHANGED'){return '启动入口已经变化，请重新检测或导入快捷方式后保存。'}
 if($Text -match 'DESKTOP_POWERSHELL_REQUIRED'){return '请先安装 PowerShell 7，再重试启动。'}
 if($Text -match 'DESKTOP_LAUNCH_BUSY'){return 'Codex 正在启动，请等待当前操作结束。'}
 if($Text -match 'DESKTOP_BRIDGE_ENVIRONMENT_CONFLICT'){return '当前启动环境仍指向共享引擎，请从普通 Windows 环境重新打开本工具。'}
 if($Text -match 'ALREADY_RUNNING|NEEDS_EXIT|needs_exit'){return 'Codex 正在运行。请保存工作并手动退出，再重新检查。'}
 if($Text -match 'UNSUPPORTED|NOT_SUPPORTED'){return '此入口尚未适配共享模式，请选择官方应用或受支持的增强实例。'}
 if($Text -match '配置文件|PRIVATE|ACL'){return '共享配置无法读取或权限不符合要求，请重新选择实例。'}
 if($Text -match 'Unsupported controller action'){return '后台版本较旧，请退出 Codex Remote 后重新打开；无需退出 Codex。'}
 if($Text -match 'timeout|timed out|Timeout'){return '操作超时，结果未确认。请先刷新状态，勿连续重复操作。'}
 if($Text -match 'relay|Relay|RELAY|fetch|connect'){return '无法连接中继，请检查网络后重试。'}
 return '操作未完成，请刷新状态后重试或查看本机诊断。'
}
function Get-PreviewInstance([string]$Kind='enhanced'){
 return [pscustomobject]@{id='preview-'+$Kind;kind=$Kind;name=$(if($Kind -eq 'official'){'Codex 官方应用'}else{'Codex 增强实例'});sourcePath='Codex.lnk';desktopExecutable='';sharedSupported=$true}
}
function Invoke-PreviewAction([string]$Action,[hashtable]$Body){
 [void]$script:previewCalls.Add($Action)
 switch($Action){
  'settings'{return [pscustomobject]$script:previewState}
  'status'{return @{paired=$script:previewState.paired;settings=$script:previewState;relay=@{connected=$true};desktop=@{connected=$false};bridge=@{running=$true};desktopLaunch=$script:previewLaunch}}
  'detectDesktop'{if($script:previewDetection){return $script:previewDetection};return @{instances=@((Get-PreviewInstance),(Get-PreviewInstance 'official'));running=@();processScanFailed=$false}}
  'importDesktop'{return @{instance=(Get-PreviewInstance)}}
  'saveSettings'{if($script:previewSaveFailure){throw $script:previewSaveFailure};foreach($key in $Body.Keys){$script:previewState[$key]=$Body[$key]};return @{saved=$true}}
  'launchDesktop'{$script:previewLaunch=@{phase='awaiting_connection';stage='awaiting_connection'};return @{accepted=$true}}
  'connectAndInvite'{$script:previewState.paired=$true;$modules=@();for($y=0;$y -lt 21;$y++){$row=@();for($x=0;$x -lt 21;$x++){$row+=($x%3 -eq 0 -or $y%4 -eq 0)};$modules+=,@($row)};return @{code='48271639';expiresAt=[DateTimeOffset]::UtcNow.AddMinutes(2).ToUnixTimeMilliseconds();qrModules=$modules}}
  'refreshPending'{return @{requests=$script:pendingRows}}
  'pending'{return @{requests=$script:pendingRows}}
  'phones'{return @{phones=$script:phoneRows}}
  'confirm'{$script:pendingRows=@();if($Body.approve){$script:phoneRows=@([pscustomobject]@{phoneId='preview-phone';name='测试 Android 手机';createdAt=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()})};return @{ok=$true}}
  'revoke'{$script:phoneRows=@();return @{ok=$true}}
  'pause'{$script:previewState.paused=$true;return @{stopped=$true}}
  'resume'{$script:previewState.paused=$false;return @{started=$true}}
  'refreshRelay'{return @{ok=$true}}
  'exit'{return @{exit=$true}}
 };throw '隔离预览不支持此操作。'
}
function Invoke-ControllerAsync([string]$Action,[hashtable]$Body,[scriptblock]$Done){
 if($Preview){if($script:deferPreview){[void]$script:previewQueue.Add(@{action=$Action;body=$Body;done=$Done});return};try{$value=Invoke-PreviewAction $Action $Body;& $Done $value $null}catch{& $Done $null $_.Exception.Message};return}
 try{
  $p=New-Object Diagnostics.Process;$p.StartInfo.FileName=$NodePath;$p.StartInfo.Arguments='"'+$controller+'" call '+$Action;$p.StartInfo.UseShellExecute=$false;$p.StartInfo.CreateNoWindow=$true;$p.StartInfo.RedirectStandardInput=$true;$p.StartInfo.RedirectStandardOutput=$true;$p.StartInfo.RedirectStandardError=$true
  $p.StartInfo.StandardOutputEncoding=[Text.UTF8Encoding]::new($false);$p.StartInfo.StandardErrorEncoding=[Text.UTF8Encoding]::new($false)
  if(-not $p.Start()){throw 'CONTROLLER_START_FAILED'}
  $out=$p.StandardOutput.ReadToEndAsync();$err=$p.StandardError.ReadToEndAsync();$bytes=[Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $Body -Compress -Depth 15));$p.StandardInput.BaseStream.Write($bytes,0,$bytes.Length);$p.StandardInput.Close()
  [void]$script:asyncRequests.Add([pscustomobject]@{process=$p;outTask=$out;errTask=$err;done=$Done;deadline=[DateTime]::UtcNow.AddSeconds(130)})
 }catch{& $Done $null $_.Exception.Message}
}
function Complete-ControllerRequests{
 for($i=$script:asyncRequests.Count-1;$i -ge 0;$i--){$request=$script:asyncRequests[$i];$p=$request.process
  if(-not $p.HasExited){if([DateTime]::UtcNow -lt $request.deadline){continue};try{$p.Kill()}catch{};$failure='Controller timed out.';$value=$null}
  else{$p.WaitForExit();$out=$request.outTask.GetAwaiter().GetResult();$err=$request.errTask.GetAwaiter().GetResult();$value=$null;$failure=$null;if($p.ExitCode -ne 0){$failure=$err}else{try{$value=$out|ConvertFrom-Json}catch{$failure='INVALID_CONTROLLER_RESPONSE'}}}
  $p.Dispose();$script:asyncRequests.RemoveAt($i);& $request.done $value $failure
 }
}
function Set-OperationBusy([bool]$Busy){
 $script:operationBusy=$Busy
 foreach($name in @('PairButton','AddPhoneButton','RefreshInviteButton','SaveButton','SaveLaunchButton','DetectButton','ImportButton','ChooseInstanceButton','ModeCombo','RelayAddress','ComputerName','AutoStart','PauseButton','LaunchButton')){$script:ui[$name].IsEnabled=(-not ($Busy -or $script:desktopBusy) -and $script:backendReady)}
 if($script:detectionBusy){foreach($name in @('ChooseInstanceButton','DetectButton','ImportButton','SaveButton','SaveLaunchButton')){$script:ui[$name].IsEnabled=$false}}
}
function Set-DetectionBusy([bool]$Busy){
 $script:detectionBusy=$Busy;$script:ui.InstanceDetectionStatus.Visibility=if($Busy){'Visible'}else{'Collapsed'};$script:ui.InstanceDetectionProgress.Visibility=if($Busy){'Visible'}else{'Collapsed'};$script:ui.InstanceDetectionProgress.IsIndeterminate=$Busy;$script:ui.InstanceDetectionText.Text='正在检测 Codex…';$script:ui.InstanceDetectionText.Foreground=$script:window.Resources.MutedBrush
 $script:ui.ChooseInstanceButton.Content=if($Busy){'检测中…'}else{'更换'};$script:ui.DetectButton.Content=if($Busy){'检测中…'}else{'自动检测'};Set-OperationBusy $script:operationBusy
}
function Test-PanelVisible{return $script:window.IsVisible -and $script:window.WindowState -ne 'Minimized'}
function Show-Page([string]$Name){foreach($page in @('Home','Settings','Phones')){$script:ui[$page+'Panel'].Visibility=if($page -eq $Name){'Visible'}else{'Collapsed'}};if($Name -eq 'Phones' -and (Test-PanelVisible)){Refresh-Phones}}
function Update-ModeHint{$script:ui.ModeHint.Text=if($script:ui.ModeCombo.SelectedIndex -eq 1){if($script:selection -and -not $script:selection.sharedSupported){'此入口尚未适配共享模式。'}else{'启动时准备共享引擎，保留原实例配置。'}}else{'沿用所选实例的启动方式。'}}
function Update-SelectionView{if($script:selection){$script:ui.InstanceName.Text=$script:selection.name;$script:ui.InstanceSource.Text=[IO.Path]::GetFileName([string]$script:selection.sourcePath)}else{$script:ui.InstanceName.Text='尚未选择 Codex';$script:ui.InstanceSource.Text='可将快捷方式拖到这里'};Update-ModeHint}
function Update-HomeInstance{
 if($script:settings -and $script:settings.desktopInstance){$script:ui.HomeInstanceName.Text=$script:settings.desktopInstance.name;$script:ui.HomeInstanceSource.Text=[IO.Path]::GetFileName([string]$script:settings.desktopInstance.sourcePath)}else{$script:ui.HomeInstanceName.Text='尚未选择 Codex';$script:ui.HomeInstanceSource.Text='在设置中自动检测或导入快捷方式'}
}
function Apply-Status($s){
 $script:lastStatus=$s;$script:backendReady=$true
 if($script:ui.PairPanel.Visibility -ne 'Visible'){$script:ui.HomeTitle.Text=$s.settings.name}
 $script:ui.RelayStatus.Text=if($s.relay.connected){'已连接'}elseif(-not $s.paired){'尚未注册'}else{'离线'};$script:ui.RelayStatus.Foreground=$script:window.Resources[$(if($s.relay.connected){'SuccessBrush'}else{'MutedBrush'})]
 $script:ui.FooterStatus.Text='Codex Remote · '+$(if($s.settings.paused){'后台已暂停'}elseif($s.bridge.running){'后台运行中'}else{'后台待连接'});$script:ui.PauseButton.Content=if($s.settings.paused){'恢复连接'}else{'暂停连接'}
 $launch=$s.desktopLaunch;$phase=[string]$launch.phase;$stage=[string]$launch.stage;$busy=$phase -in @('starting','preparing','launching','checking','initializing')
 $script:ui.EngineStatus.Text=switch($phase){'needs_exit'{if($stage -eq 'needs_engine_exit'){'旧共享引擎待检查'}else{'请先退出 Codex'}} 'failed'{'启动未完成'} 'awaiting_connection'{'桌面已启动，连接待确认'} 'connected'{'已连接'} 'started'{if($s.desktop.connected){'已连接'}else{'桌面已启动，等待连接'}} default{if($busy){'启动中…'}elseif($s.desktop.connected){if($s.settings.runtimeMode -eq 'shared-engine'){'共享引擎可用'}else{'已连接'}}else{'未就绪'}}}
 $script:ui.EngineStatus.Foreground=$script:window.Resources[$(if($s.desktop.connected -and -not $busy -and $phase -ne 'awaiting_connection'){'SuccessBrush'}else{'MutedBrush'})]
 $script:ui.LaunchProgress.Visibility=if($busy -or $phase -in @('awaiting_connection','needs_exit','failed')){'Visible'}else{'Collapsed'}
 $script:ui.LaunchProgress.Text=switch($stage){'checking_desktop'{'检查桌面状态…'} 'checking_previous_engine'{'检查旧共享引擎…'} 'starting_broker'{'启动共享引擎…'} 'waiting_broker'{'等待共享引擎就绪…'} 'starting_desktop'{'正在启动所选 Codex…'} 'needs_engine_exit'{Get-ErrorText ([string]$launch.error)} 'checking'{'检查启动配置…'} 'preparing'{'准备共享引擎…'} 'broker_ready'{'共享引擎已就绪，正在启动桌面…'} 'launching'{'正在启动所选 Codex…'} 'awaiting_connection'{'等待桌面共享连接确认。'} default{if($phase -eq 'needs_exit'){'请保存工作并手动退出 Codex，再重试。'}elseif($phase -eq 'failed'){Get-ErrorText ([string]$launch.error)}elseif($busy){'正在检查启动状态…'}else{''}}}
 $script:ui.LaunchButton.Content=if($busy){'启动中…'}elseif($phase -eq 'needs_exit'){'重新检查并启动'}elseif($s.settings.runtimeMode -eq 'shared-engine'){'以共享模式启动 Codex'}else{'启动 Codex'}
 Update-HomeInstance
 $script:desktopBusy=$busy;Set-OperationBusy $script:operationBusy;if($script:trayIcon){$script:trayIcon.Text='Codex Remote · '+$(if($s.relay.connected){'中继已连接'}else{'中继待连接'})};if($script:trayContext){$script:trayContext.Items[1].Text=[string]$script:ui.PauseButton.Content}
}
function Start-ControllerIfNeeded{if($script:startupAttempted){return};$script:startupAttempted=$true;try{Start-Process -FilePath $NodePath -ArgumentList @('"'+$controller+'"','daemon') -WindowStyle Hidden|Out-Null;Set-Notice '正在启动本机后台…'}catch{Set-Notice '本机后台启动失败，请重新打开 Codex Remote。' $true}}
function Refresh-Status{if($script:statusPending){return};$script:statusPending=$true;Invoke-ControllerAsync 'status' @{} {param($s,$errorText)$script:statusPending=$false;if($errorText){$script:ui.EngineStatus.Text='状态不可用';$script:ui.RelayStatus.Text='状态不可用';if(-not $script:backendReady){Start-ControllerIfNeeded};return};$first=-not $script:backendReady;Apply-Status $s;if($first){Set-Notice $StartupNotice ([bool]$StartupNotice);Load-Settings}}}
function Load-Settings([bool]$ThenLaunch=$false){$script:launchAfterSettingsRead=$ThenLaunch;Invoke-ControllerAsync 'settings' @{} {param($s,$errorText)if($errorText){$script:launchAfterSettingsRead=$false;Set-Notice (Get-ErrorText $errorText) $true;return};$script:settings=$s;Update-HomeInstance;$script:selection=Restore-SelectionDraft $s;$script:ui.ComputerName.Text=$s.name;$script:ui.RelayAddress.Text=[string]$s.relayUrl;$script:ui.AutoStart.IsChecked=[bool]$s.autoStart;$script:ui.ModeCombo.SelectedIndex=if($s.runtimeMode -eq 'shared-engine'){1}else{0};Update-SelectionView;if($script:selectionDraftRestored){$script:ui.SettingsTab.IsChecked=$true;Set-Notice '已恢复实例选择，保存后应用。'};if(-not $script:selection){$script:ui.SettingsTab.IsChecked=$true;Find-Instances $false};if($script:launchAfterSettingsRead){$script:launchAfterSettingsRead=$false;Launch-Codex}}}
function Copy-InstanceRecord($Instance){
 if(-not $Instance -or -not $Instance.id){return $null}
 # 运行态的 PID、profile 和匹配依据只属于展示信息，不进入草稿或启动配置。
 return [pscustomobject]@{id=[string]$Instance.id;kind=[string]$Instance.kind;name=[string]$Instance.name;sourcePath=[string]$Instance.sourcePath;desktopExecutable=[string]$Instance.desktopExecutable;sharedSupported=[bool]$Instance.sharedSupported}
}
function Get-InstanceChoices($Detection){
 $instances=@($Detection.instances);$matchedIds=@{}
 foreach($process in @($Detection.running)){
  if(-not $process){continue}
  $instance=$null;if($process.reason -eq 'matched' -and $process.instanceId){$instance=$instances|Where-Object {$_.id -eq $process.instanceId}|Select-Object -First 1}
  $record=Copy-InstanceRecord $instance
  $profile=if($process.profileDirectory){[string]$process.profileDirectory}else{'默认配置目录'}
  if($record){$matchedIds[$record.id]=$true;[pscustomobject]@{instance=$record;name=$record.name;status='正在运行 · PID '+$process.pid;detail='配置目录：'+$profile}}
  else{
   $label='自定义 Codex';try{if($process.profileDirectory){$directory=[string]$process.profileDirectory;$leaf=[IO.Path]::GetFileName($directory.TrimEnd('\'));if($leaf -in @('desktop-profile','codex-profile','profile','user-data')){$directory=[IO.Path]::GetDirectoryName($directory);if([IO.Path]::GetFileName($directory) -eq '.runtime'){$directory=[IO.Path]::GetDirectoryName($directory)};$leaf=[IO.Path]::GetFileName($directory)};if($leaf){$label+=' · '+$leaf}}}catch{}
   [pscustomobject]@{instance=$null;name=$label+'（尚未适配）';status='正在运行 · PID '+$process.pid;detail='配置目录：'+$profile+"`n"+'已识别运行进程，当前启动方式尚未适配。'}
  }
 }
 foreach($instance in $instances){if($instance -and -not $matchedIds.ContainsKey([string]$instance.id)){$record=Copy-InstanceRecord $instance;[pscustomobject]@{instance=$record;name=$record.name;status='其他候选 · 已验证入口';detail=[string]$record.sourcePath}}}
}
function New-InstancePicker($Detection){
 $picker=New-Object Windows.Window;$picker.Title='选择 Codex';$picker.Owner=$script:window;$picker.Resources.MergedDictionaries.Add($script:window.Resources);$picker.Width=500;$picker.Height=440;$picker.MinWidth=380;$picker.MinHeight=300;$picker.WindowStartupLocation='CenterOwner';$picker.Background=$script:window.Resources.PageBrush;$picker.Foreground=$script:window.Resources.TextBrush;$picker.FontFamily=$script:window.FontFamily
 $grid=New-Object Windows.Controls.Grid;$grid.Background=$script:window.Resources.PageBrush;$grid.Margin='18';foreach($height in @('Auto','*','Auto')){[void]$grid.RowDefinitions.Add((New-Object Windows.Controls.RowDefinition -Property @{Height=$height}))};$picker.Content=$grid
 $hint=New-Object Windows.Controls.TextBlock;$hint.Text=if($Detection.processScanFailed){'运行状态扫描失败。可手动选择已验证入口，现有选择保持不变。'}else{'选择要使用的启动配置。运行中的 Codex 优先列出。'};$hint.TextWrapping='Wrap';$hint.Margin='0,0,0,12';$hint.Foreground=$script:window.Resources.MutedBrush;[void]$grid.Children.Add($hint)
 $list=New-Object Windows.Controls.ListBox;$list.Background=$script:window.Resources.SurfaceBrush;$list.Foreground=$script:window.Resources.TextBrush;$list.BorderBrush=$script:window.Resources.LineBrush;[Windows.Controls.Grid]::SetRow($list,1);[Windows.Controls.ScrollViewer]::SetHorizontalScrollBarVisibility($list,'Disabled')
 foreach($choice in @(Get-InstanceChoices $Detection)){
  $item=New-Object Windows.Controls.ListBoxItem;$item.Tag=$choice.instance;$item.Padding='10';$item.HorizontalContentAlignment='Stretch';$item.IsEnabled=$null -ne $choice.instance
  $content=New-Object Windows.Controls.StackPanel
  $name=New-Object Windows.Controls.TextBlock;$name.Text=$choice.name;$name.FontWeight='SemiBold';$name.TextWrapping='Wrap';[void]$content.Children.Add($name)
  $status=New-Object Windows.Controls.TextBlock;$status.Text=$choice.status;$status.Foreground=$script:window.Resources.MutedBrush;$status.Margin='0,4,0,0';$status.FontSize=12;$status.TextWrapping='Wrap';[void]$content.Children.Add($status)
  $detail=New-Object Windows.Controls.TextBlock;$detail.Text=$choice.detail;$detail.Foreground=$script:window.Resources.MutedBrush;$detail.Margin='0,4,0,0';$detail.FontSize=12;$detail.TextWrapping='Wrap';[void]$content.Children.Add($detail)
  $item.Content=$content;[void]$list.Items.Add($item)
 };[void]$grid.Children.Add($list)
 $actions=New-Object Windows.Controls.StackPanel;$actions.Orientation='Horizontal';$actions.Margin='0,14,0,0';[Windows.Controls.Grid]::SetRow($actions,2);[void]$grid.Children.Add($actions)
 $accept=New-Object Windows.Controls.Button;$accept.Content='使用所选实例';$accept.Style=$script:window.Resources.Primary;$accept.IsEnabled=$false;$cancel=New-Object Windows.Controls.Button;$cancel.Content='取消';$cancel.Style=$script:window.Resources[[Windows.Controls.Button]];[void]$actions.Children.Add($accept);[void]$actions.Children.Add($cancel)
 $list.Add_SelectionChanged({$accept.IsEnabled=$null -ne $list.SelectedItem -and $list.SelectedItem.IsEnabled -and $null -ne $list.SelectedItem.Tag}.GetNewClosure());$accept.Add_Click({if($list.SelectedItem -and $list.SelectedItem.IsEnabled -and $list.SelectedItem.Tag){$picker.Tag=$list.SelectedItem.Tag;$picker.DialogResult=$true}}.GetNewClosure());$cancel.Add_Click({$picker.DialogResult=$false}.GetNewClosure())
 return [pscustomobject]@{window=$picker;list=$list;accept=$accept}
}
function Show-InstancePicker($Detection){if($SmokeTest){$script:previewPickerDetection=$Detection;return};$view=New-InstancePicker $Detection;if($view.window.ShowDialog()){Remember-Selection $view.window.Tag}}
function Apply-InstanceDetection($Result,[bool]$ShowPicker,[bool]$ForcePicker=$false){
 $items=@($Result.instances);$running=@($Result.running|Where-Object {$null -ne $_});$scanFailed=[bool]$Result.processScanFailed
 if(-not $scanFailed -and -not $ForcePicker){
  if($running.Count -eq 1 -and $running[0].reason -eq 'matched'){$match=@($items|Where-Object {$_.id -eq $running[0].instanceId});if($match.Count -eq 1){Remember-Selection (Copy-InstanceRecord $match[0]);return}}
  if(-not $running.Count -and $items.Count -eq 1){Remember-Selection (Copy-InstanceRecord $items[0]);return}
 }
 if($scanFailed){Set-Notice '无法扫描正在运行的 Codex，已保留当前选择。可点“更换”或“自动检测”手动选择已验证入口。' $true}
 elseif($running.Count -gt 1){Set-Notice ('找到 '+$running.Count+' 个正在运行的 Codex。请点“更换”或“自动检测”选择要使用的实例。')}
 elseif($running.Count -eq 1 -and $running[0].reason -eq 'matched'){Set-Notice '请选择要使用的 Codex 启动配置。'}
 elseif($running.Count){Set-Notice '发现自定义配置实例，当前启动方式尚未适配。可点“更换”选择已验证入口。'}
 elseif($items.Count){Set-Notice '找到多个 Codex，请点“更换”或“自动检测”选择要使用的实例。'}
 else{Set-Notice '未找到 Codex，可导入开始菜单或桌面的快捷方式。'}
 if($ShowPicker -and ($items.Count -or $running.Count)){Show-InstancePicker $Result}
}
function Find-Instances([bool]$ShowPicker=$true,[bool]$ForcePicker=$false){if($script:operationBusy -or $script:detectionBusy){return};Set-DetectionBusy $true;Set-Notice ''; $script:showDetectedPicker=$ShowPicker;$script:forceDetectedPicker=$ForcePicker;Invoke-ControllerAsync 'detectDesktop' @{} {param($result,$errorText)Set-DetectionBusy $false;if($errorText){$message='检测未完成：'+(Get-ErrorText $errorText);$script:ui.InstanceDetectionStatus.Visibility='Visible';$script:ui.InstanceDetectionText.Text=$message;$script:ui.InstanceDetectionText.Foreground=$script:window.Resources.WarningBrush;Set-Notice $message $true;return};Apply-InstanceDetection $result $script:showDetectedPicker $script:forceDetectedPicker}}
function Import-Shortcut([string]$Path){if($script:operationBusy -or $script:detectionBusy){return};if([IO.Path]::GetExtension($Path) -ne '.lnk'){Set-Notice '请选择 .lnk 快捷方式。' $true;return};Set-OperationBusy $true;Set-Notice '正在识别快捷方式…';Invoke-ControllerAsync 'importDesktop' @{shortcutPath=$Path} {param($result,$errorText)Set-OperationBusy $false;if($errorText){Set-Notice (Get-ErrorText $errorText) $true;return};Remember-Selection $result.instance}}
function Save-Settings([bool]$Launch=$false){
 $relay=$script:ui.RelayAddress.Text.Trim();$relayUri=$null
 if(-not [Uri]::TryCreate($relay,[UriKind]::Absolute,[ref]$relayUri) -or ($relayUri.Scheme -ne 'https' -and -not($relayUri.Scheme -eq 'http' -and $relayUri.IsLoopback)) -or $relayUri.UserInfo -or $relayUri.Query -or $relayUri.Fragment){Set-Notice '请填写有效的 HTTPS 中继地址。' $true;$script:ui.RelayAddress.Focus()|Out-Null;return}
 if($script:settings.relayUrl -and $relay -ne $script:settings.relayUrl -and -not $Preview){if([Windows.MessageBox]::Show($script:window,'更换中继会清除本机配对，需要重新绑定手机。旧服务器上的授权须另行撤销。','更换中继',[Windows.MessageBoxButton]::OKCancel,[Windows.MessageBoxImage]::Warning) -ne [Windows.MessageBoxResult]::OK){return}}
 if($script:operationBusy){return};$name=$script:ui.ComputerName.Text.Trim();if(-not $name){Set-Notice '请填写电脑名称。' $true;$script:ui.ComputerName.Focus()|Out-Null;return};if(-not $script:selection){Set-Notice '请先选择 Codex 实例。' $true;return}
 $mode=if($script:ui.ModeCombo.SelectedIndex -eq 1){'shared-engine'}else{'desktop-bridge'};if($mode -eq 'shared-engine' -and -not $script:selection.sharedSupported){Set-Notice '此入口尚未适配共享模式，请更换实例或选择桌面 Bridge。' $true;return}
 $script:launchAfterSave=$Launch;Set-OperationBusy $true;Invoke-ControllerAsync 'saveSettings' @{relayUrl=$relay;name=$name;autoStart=[bool]$script:ui.AutoStart.IsChecked;runtimeMode=$mode;desktopInstance=$script:selection} {param($result,$errorText)Set-OperationBusy $false;if($errorText){$script:ui.SettingsTab.IsChecked=$true;Set-Notice ('保存失败：'+(Get-ErrorText $errorText)) $true;return};try{Clear-SelectionDraft}catch{};$script:ui.HomeTab.IsChecked=$true;Load-Settings $script:launchAfterSave;Refresh-Status;if(-not $script:launchAfterSave){Set-Notice $(if($result.launchPending){'启动配置已保存，当前连接未切换。'}else{'设置已保存。Codex 不会自动重启。'})}}
}
function Launch-Codex{if($script:operationBusy){return};if(-not $script:settings -or -not $script:settings.desktopInstance){$script:ui.SettingsTab.IsChecked=$true;Set-Notice '请先选择并保存 Codex 实例。';return};Set-OperationBusy $true;Set-Notice '正在检查启动条件…';Invoke-ControllerAsync 'launchDesktop' @{} {param($result,$errorText)Set-OperationBusy $false;if($errorText){Set-Notice (Get-ErrorText $errorText) $true;return};Set-Notice '启动请求已受理，连接状态确认后更新。';Refresh-Status}}
function Set-QrImage([object]$Modules){
 $script:ui.QrImage.Source=$null;if(-not $Modules){return};$n=$Modules.Count;if($n -lt 1 -or $n -gt 177){throw '二维码尺寸无效。'};$scale=4;$side=($n+8)*$scale;$pixels=New-Object byte[] ($side*$side*4)
 for($i=0;$i -lt $pixels.Length;$i++){$pixels[$i]=255}
 for($y=0;$y -lt $n;$y++){for($x=0;$x -lt $n;$x++){if($Modules[$y][$x]){for($dy=0;$dy -lt $scale;$dy++){for($dx=0;$dx -lt $scale;$dx++){$at=((($y+4)*$scale+$dy)*$side+($x+4)*$scale+$dx)*4;$pixels[$at]=20;$pixels[$at+1]=20;$pixels[$at+2]=20}}}}}
 $bitmap=[Windows.Media.Imaging.BitmapSource]::Create($side,$side,96,96,[Windows.Media.PixelFormats]::Bgra32,$null,$pixels,$side*4);$bitmap.Freeze();$script:ui.QrImage.Source=$bitmap
}
function Update-Invitation{if(-not $script:invite){return};$left=[long]$script:invite.expiresAt-[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds();if($left -le 0){$script:ui.QrImage.Source=$null;$script:ui.QrPlaceholder.Text='邀请已过期';$script:ui.QrPlaceholder.Visibility='Visible';$script:ui.InviteCode.Text='—';$script:ui.CopyCodeButton.IsEnabled=$false;$script:ui.InviteCountdown.Text='请重新生成邀请';$script:invite=$null;return};$seconds=[int][Math]::Ceiling($left/1000);$script:ui.InviteCountdown.Text='剩余 '+[int][Math]::Floor($seconds/60)+':'+($seconds%60).ToString('00')}
function Begin-Pairing{if($script:operationBusy){return};if(-not $script:settings.relayUrl){$script:ui.SettingsTab.IsChecked=$true;Set-Notice '请先在设置中填写并保存中继地址。' $true;return};$script:ui.HomeTab.IsChecked=$true;$script:ui.OverviewPanel.Visibility='Collapsed';$script:ui.PairPanel.Visibility='Visible';$script:ui.HomeTitle.Text='配对手机';$script:invite=$null;$script:ui.CopyCodeButton.IsEnabled=$false;$script:ui.QrImage.Source=$null;$script:ui.QrPlaceholder.Visibility='Visible';$script:ui.QrPlaceholder.Text='正在创建邀请…';$script:ui.InviteCode.Text='—';Set-OperationBusy $true;Invoke-ControllerAsync 'connectAndInvite' @{} {param($result,$errorText)Set-OperationBusy $false;if($errorText){$script:ui.QrPlaceholder.Text='邀请未能创建';Set-Notice (Get-ErrorText $errorText) $true;return};$script:invite=$result;$script:ui.InviteCode.Text=([string]$result.code).Insert(4,' ');Set-QrImage $result.qrModules;$script:ui.QrPlaceholder.Visibility='Collapsed';$script:ui.CopyCodeButton.IsEnabled=$true;Update-Invitation;Set-Notice '';Refresh-Pending $true}}
function Apply-Pending([object[]]$Rows){
 $now=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds();$items=@($Rows|Where-Object {$_.expiresAt -gt $now});$old=$script:requestId;$same=$items.Count -eq $script:pendingRows.Count
 if($same){for($i=0;$i -lt $items.Count;$i++){if($items[$i].requestId -ne $script:pendingRows[$i].requestId -or $items[$i].verificationCode -ne $script:pendingRows[$i].verificationCode -or $items[$i].phoneName -ne $script:pendingRows[$i].phoneName -or $items[$i].expiresAt -ne $script:pendingRows[$i].expiresAt){$same=$false;break}}}
 $script:ui.RequestCount.Text=if($items.Count -gt 1){'等待连接 · '+$items.Count+' 台手机，可切换选择'}else{'等待连接'}
 $script:pendingRows=$items;$script:ui.RequestsPanel.Visibility=if($items.Count){'Visible'}else{'Collapsed'}
 if($items.Count){$script:ui.PairPanel.Visibility='Collapsed';$script:ui.OverviewPanel.Visibility='Collapsed';$script:ui.HomeTitle.Text='确认手机'}elseif($script:ui.PairPanel.Visibility -ne 'Visible'){$script:ui.OverviewPanel.Visibility='Visible'}
 if(-not $same -or -not $script:ui.PendingRequests.SelectedItem){$script:ui.PendingRequests.ItemsSource=$items;$index=0;for($i=0;$i -lt $items.Count;$i++){if($items[$i].requestId -eq $old){$index=$i}};if($items.Count){$script:ui.PendingRequests.SelectedIndex=$index}else{$script:requestId='';$script:ui.AgreeCode.IsChecked=$false}}
}
function Update-SelectedRequest{$request=$script:ui.PendingRequests.SelectedItem;$id=if($request){[string]$request.requestId}else{''};if($id -ne $script:requestId){$script:ui.AgreeCode.IsChecked=$false};$script:requestId=$id;$script:requestExpires=if($request){[long]$request.expiresAt}else{0L};$script:ui.VerificationCode.Text=if($request){[string]$request.verificationCode}else{''};$script:ui.RequestExpiry.Text='请与手机上的数字核对';$script:ui.ApproveButton.IsEnabled=(-not $script:confirmBusy) -and [bool]$script:ui.AgreeCode.IsChecked -and $script:requestExpires -gt [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()}
function Get-PendingContext{return [string](ConvertTo-Json -InputObject @($script:lastStatus.paired,$script:lastStatus.settings.relayUrl,$script:lastStatus.settings.runtimeMode,$script:lastStatus.bridge.pid) -Compress)}
function Refresh-Pending([bool]$Force=$false){
 if($script:pendingBusy){if($Force){$script:pendingForceRequired=$true};return}
 if($script:exiting -or -not $script:backendReady -or (-not $Preview -and -not $script:lastStatus.paired)){return};$script:pendingBusy=$true;$script:pendingContext=Get-PendingContext
 $action=if($Force){'refreshPending'}else{'pending'}
 $active=(Test-PanelVisible) -and $script:ui.HomePanel.Visibility -eq 'Visible' -and (($script:invite -and [long]$script:invite.expiresAt -gt [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()) -or $script:pendingRows.Count -gt 0)
 Invoke-ControllerAsync $action @{pairingActive=[bool]$active} {param($data,$errorText)
  $script:pendingBusy=$false
  $force=$script:pendingForceRequired;$script:pendingForceRequired=$false
  if($script:exiting){return}
  if($script:pendingContext -ne (Get-PendingContext)){return}
  if($force -and (Test-PanelVisible)){Refresh-Pending $true;return}
  if($script:confirmRefreshRequired){$script:confirmRefreshRequired=$false;Refresh-Pending;return}
  if($script:confirmBusy -and -not $script:confirmDone){return}
  if($errorText -or $data.error){$script:ui.ApproveButton.IsEnabled=$false;$script:ui.AgreeCode.IsChecked=$false;Set-Notice '暂时无法读取手机请求，请检查中继连接。' $true;return}
  Apply-Pending @($data.requests);$script:confirmBusy=$false;$script:confirmDone=$false;$script:ui.PendingRequests.IsEnabled=$true;$script:ui.AgreeCode.IsEnabled=$true;$script:ui.RejectButton.IsEnabled=$true;Update-SelectedRequest
 }
}
function Confirm-Phone([bool]$Approve){
 if($script:confirmBusy -or -not $script:requestId -or ($Approve -and -not $script:ui.AgreeCode.IsChecked)){return}
 if($script:requestExpires -le [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()){Set-Notice '请求已过期，请让手机重新申请。' $true;Refresh-Pending $true;return}
 $script:confirmBusy=$true;$script:confirmDone=$false;$script:ui.ApproveButton.IsEnabled=$false;$script:ui.RejectButton.IsEnabled=$false;$script:ui.PendingRequests.IsEnabled=$false;$script:ui.AgreeCode.IsEnabled=$false;$script:confirmApproved=$Approve
 Invoke-ControllerAsync 'confirm' @{requestId=$script:requestId;approve=$Approve} {param($result,$errorText)
  $script:ui.AgreeCode.IsChecked=$false;$script:confirmDone=$true
  if($errorText){Set-Notice '授权结果未确认，请刷新请求及手机列表后核对。' $true}else{Set-Notice $(if($script:confirmApproved){'手机已授权。'}else{'已拒绝这次申请。'})}
  if($script:pendingBusy){$script:confirmRefreshRequired=$true}else{Refresh-Pending};Refresh-Phones
 }
}
function Apply-Phones([object[]]$Rows){
 $script:phoneRows=@($Rows);$script:ui.PhoneCount.Text=[string]$script:phoneRows.Count+' 部';$script:ui.PhonesEmpty.Visibility=if($script:phoneRows.Count){'Collapsed'}else{'Visible'};$script:ui.PhonesList.Children.Clear()
 foreach($phone in $script:phoneRows){$row=New-Object Windows.Controls.Grid;$row.Margin='0,0,0,12';[void]$row.ColumnDefinitions.Add((New-Object Windows.Controls.ColumnDefinition));[void]$row.ColumnDefinitions.Add((New-Object Windows.Controls.ColumnDefinition -Property @{Width='Auto'}));$label=New-Object Windows.Controls.TextBlock;$label.Text=[string]$phone.name;$label.VerticalAlignment='Center';$label.Foreground=$script:window.Resources.TextBrush;[void]$row.Children.Add($label);$revoke=New-Object Windows.Controls.Button;$revoke.Content='解除配对';$revoke.Tag=[string]$phone.phoneId;$revoke.Style=$script:window.Resources[[Windows.Controls.Button]];[Windows.Controls.Grid]::SetColumn($revoke,1)
  $revoke.Add_Click({$target=$this;if([Windows.MessageBox]::Show($script:window,'解除后，此手机不能继续访问这台电脑。其他手机不受影响。','解除配对',[Windows.MessageBoxButton]::YesNo,[Windows.MessageBoxImage]::Question) -ne [Windows.MessageBoxResult]::Yes){return};$target.IsEnabled=$false;Invoke-ControllerAsync 'revoke' @{phoneId=[string]$target.Tag} {param($result,$errorText)if($errorText){Set-Notice '解除结果未确认，请刷新手机列表后核对。' $true};Refresh-Phones}});[void]$row.Children.Add($revoke);[void]$script:ui.PhonesList.Children.Add($row)
 }
}
function Refresh-Phones{if($script:phonesBusy -or -not $script:backendReady){return};$script:phonesBusy=$true;Invoke-ControllerAsync 'phones' @{} {param($data,$errorText)$script:phonesBusy=$false;if($errorText){Set-Notice '无法读取手机列表，请稍后刷新。' $true;return};Apply-Phones @($data.phones)}}
function Toggle-Connection{if($script:operationBusy){return};$action=if($script:lastStatus.settings.paused){'resume'}else{'pause'};Invoke-ControllerAsync $action @{} {param($result,$errorText)if($errorText){Set-Notice (Get-ErrorText $errorText) $true};Refresh-Status}}
function Exit-Tray{if($script:exiting){return};$script:exiting=$true;Invoke-ControllerAsync 'exit' @{} {param($result,$errorText)if($errorText){$script:exiting=$false;Set-Notice '后台退出未确认，请稍后重试。' $true}else{$script:window.Close()}}}
$script:ui.HomeTab.Add_Checked({Show-Page 'Home'});$script:ui.SettingsTab.Add_Checked({Show-Page 'Settings'});$script:ui.PhonesTab.Add_Checked({Show-Page 'Phones'});$script:ui.ModeCombo.Add_SelectionChanged({Update-ModeHint})
$script:ui.DetectButton.Add_Click({Find-Instances});$script:ui.ChooseInstanceButton.Add_Click({Find-Instances $true $true})
$script:ui.ImportButton.Add_Click({$picker=New-Object Microsoft.Win32.OpenFileDialog;$picker.Filter='Windows 快捷方式 (*.lnk)|*.lnk';$picker.Title='选择 Codex 快捷方式';$picker.DereferenceLinks=$false;if($picker.ShowDialog($script:window)){Import-Shortcut $picker.FileName}})
$script:ui.InstanceDrop.Add_DragOver({if($_.Data.GetDataPresent([Windows.DataFormats]::FileDrop)){$_.Effects=[Windows.DragDropEffects]::Copy}else{$_.Effects=[Windows.DragDropEffects]::None};$_.Handled=$true})
$script:ui.InstanceDrop.Add_Drop({$paths=@($_.Data.GetData([Windows.DataFormats]::FileDrop));if($paths.Count -eq 1){Import-Shortcut ([string]$paths[0])}else{Set-Notice '请一次拖入一个 Codex 快捷方式。' $true};$_.Handled=$true})
$script:ui.SaveButton.Add_Click({Save-Settings});$script:ui.SaveLaunchButton.Add_Click({Save-Settings $true});$script:ui.LaunchButton.Add_Click({Launch-Codex})
$script:ui.PairButton.Add_Click({Begin-Pairing});$script:ui.AddPhoneButton.Add_Click({Begin-Pairing});$script:ui.RefreshInviteButton.Add_Click({Begin-Pairing})
$script:ui.BackFromPairButton.Add_Click({$script:ui.PairPanel.Visibility='Collapsed';$script:ui.OverviewPanel.Visibility='Visible';Set-Notice '邀请仍会按有效期失效。';Refresh-Status})
$script:ui.CopyCodeButton.Add_Click({if($script:invite -and [long]$script:invite.expiresAt -gt [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()){try{[Windows.Clipboard]::SetText([string]$script:invite.code);Set-Notice '配对码已复制。'}catch{Set-Notice '剪贴板暂不可用，请手动输入配对码。' $true}}else{Update-Invitation}})
$script:ui.PendingRequests.Add_SelectionChanged({Update-SelectedRequest});$script:ui.AgreeCode.Add_Checked({Update-SelectedRequest});$script:ui.AgreeCode.Add_Unchecked({$script:ui.ApproveButton.IsEnabled=$false})
$script:ui.ApproveButton.Add_Click({Confirm-Phone $true});$script:ui.RejectButton.Add_Click({Confirm-Phone $false});$script:ui.RefreshPhonesButton.Add_Click({Refresh-Phones});$script:ui.PauseButton.Add_Click({Toggle-Connection})
$script:ui.RetryRelayButton.Add_Click({Invoke-ControllerAsync 'refreshRelay' @{} {param($result,$errorText)if($errorText){Set-Notice (Get-ErrorText $errorText) $true};Refresh-Status}})
$script:trayIcon=$null;$script:trayContext=$null
if(-not $Preview){
 $script:trayContext=New-Object System.Windows.Forms.ContextMenuStrip;$open=$script:trayContext.Items.Add('打开 Codex Remote');$pause=$script:trayContext.Items.Add('暂停连接');[void]$script:trayContext.Items.Add('-');$exit=$script:trayContext.Items.Add('退出 Codex Remote')
 $open.Add_Click({$script:window.Show();$script:window.WindowState='Normal';$script:window.Activate()|Out-Null;Refresh-Status});$pause.Add_Click({Toggle-Connection});$exit.Add_Click({Exit-Tray})
 $script:trayIcon=New-Object System.Windows.Forms.NotifyIcon;$script:trayIcon.Icon=New-Object Drawing.Icon((Join-Path $PSScriptRoot 'app.ico'));$script:trayIcon.ContextMenuStrip=$script:trayContext;$script:trayIcon.Text='Codex Remote';$script:trayIcon.Visible=$true;$script:trayIcon.Add_DoubleClick({$script:window.Show();$script:window.WindowState='Normal';$script:window.Activate()|Out-Null})
}
function Register-TrayWindowLifetime([Windows.Window]$Window,[scriptblock]$ShouldExit,[bool]$KeepAlive){
 $Window.Add_Closing({param($sender,$eventArgs)if($KeepAlive -and -not (& $ShouldExit)){$eventArgs.Cancel=$true;$sender.Hide()}}.GetNewClosure())
 $Window.Add_Closed({if($KeepAlive){$Window.Dispatcher.BeginInvokeShutdown([Windows.Threading.DispatcherPriority]::Normal)}}.GetNewClosure())
}
function Start-TrayWindowLoop([Windows.Window]$Window){
 # Hide 会结束 ShowDialog 的模态循环；托盘生命周期必须独立于主窗可见性。
 $Window.Show();[Windows.Threading.Dispatcher]::Run()
}
Register-TrayWindowLifetime $script:window {$script:exiting} (-not [bool]$Preview)
$script:asyncTimer=New-Object Windows.Threading.DispatcherTimer;$script:asyncTimer.Interval=[TimeSpan]::FromMilliseconds(100);$script:asyncTimer.Add_Tick({Complete-ControllerRequests;if(Show-ControlPanelOnRequest $script:window $script:activationSignal){Refresh-Status}})
$script:seconds=0;$script:timer=New-Object Windows.Threading.DispatcherTimer;$script:timer.Interval=[TimeSpan]::FromSeconds(1)
function Refresh-VisiblePanel{
 if(-not (Test-PanelVisible)){return};Update-Invitation;Refresh-Status;Refresh-Pending $true
 if($script:ui.PhonesPanel.Visibility -eq 'Visible'){Refresh-Phones}
}
function Update-PanelTick{
 $script:seconds++
 if(-not (Test-PanelVisible)){return}
 Update-Invitation
 if($script:requestExpires -and $script:requestExpires -le [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()){$script:ui.ApproveButton.IsEnabled=$false;$script:ui.AgreeCode.IsChecked=$false;$script:ui.RequestExpiry.Text='请求已过期'}
 if($script:seconds%3 -eq 0){Refresh-Status;Refresh-Pending}
 if($script:seconds%15 -eq 0 -and $script:ui.PhonesPanel.Visibility -eq 'Visible'){Refresh-Phones}
}
$script:timer.Add_Tick({Update-PanelTick})
$script:window.Add_IsVisibleChanged({if(-not $SmokeTest){Refresh-VisiblePanel}})
$script:window.Add_StateChanged({if(-not $SmokeTest){Refresh-VisiblePanel}})
function Save-PreviewImage([string]$Name,[Windows.Window]$Window=$script:window){
 $Window.UpdateLayout();if(-not $EvidenceDirectory){return};$visual=$Window.Content;$width=[int][Math]::Ceiling($visual.ActualWidth*$PreviewScale);$height=[int][Math]::Ceiling($visual.ActualHeight*$PreviewScale)
 $image=New-Object Windows.Media.Imaging.RenderTargetBitmap($width,$height,(96*$PreviewScale),(96*$PreviewScale),[Windows.Media.PixelFormats]::Pbgra32);$drawing=New-Object Windows.Media.DrawingVisual;$context=$drawing.RenderOpen();try{$brush=New-Object Windows.Media.VisualBrush($visual);$context.DrawRectangle($brush,$null,(New-Object Windows.Rect(0,0,$visual.ActualWidth,$visual.ActualHeight)))}finally{$context.Close()};$image.Render($drawing);$encoder=New-Object Windows.Media.Imaging.PngBitmapEncoder;$encoder.Frames.Add([Windows.Media.Imaging.BitmapFrame]::Create($image));$stream=[IO.File]::Create((Join-Path $EvidenceDirectory ($Name+'.png')));try{$encoder.Save($stream)}finally{$stream.Dispose()}
}
function Invoke-NativeSmokeTest{
 $script:checks=0
 function Assert-Ui([bool]$Value,[string]$Label){if(-not $Value){throw ('原生 UI 验收失败：'+$Label)};$script:checks++}
 function Get-RenderedText($Root){if($Root -is [Windows.Controls.TextBlock]){$Root.Text};for($j=0;$j -lt [Windows.Media.VisualTreeHelper]::GetChildrenCount($Root);$j++){Get-RenderedText ([Windows.Media.VisualTreeHelper]::GetChild($Root,$j))}}
 if($EvidenceDirectory){New-Item -ItemType Directory -Force -Path $EvidenceDirectory|Out-Null}
 $script:selection=Get-PreviewInstance;$script:previewState.desktopInstance=$script:selection;Load-Settings;Apply-Status (Invoke-PreviewAction 'status' @{});$script:ui.SettingsTab.IsChecked=$true;Save-PreviewImage 'settings';Assert-Ui ($script:ui.ModeCombo.Visibility -eq 'Visible') '运行模式直接可见'
 $savedRelay=$script:ui.RelayAddress.Text;$script:ui.RelayAddress.Text='';$saveCalls=@($script:previewCalls|Where-Object {$_ -eq 'saveSettings'}).Count;Save-Settings;Assert-Ui (@($script:previewCalls|Where-Object {$_ -eq 'saveSettings'}).Count -eq $saveCalls) '默认空地址不发保存请求'
 $script:settings.relayUrl='';$inviteCalls=@($script:previewCalls|Where-Object {$_ -eq 'connectAndInvite'}).Count;Begin-Pairing;Assert-Ui (@($script:previewCalls|Where-Object {$_ -eq 'connectAndInvite'}).Count -eq $inviteCalls -and $script:ui.SettingsPanel.Visibility -eq 'Visible') '未设置中继引导设置'
 $script:ui.RelayAddress.Text='https://new-relay.example.com/team';$script:settings.relayUrl=$savedRelay;Save-Settings;Assert-Ui ($script:previewState.relayUrl -eq 'https://new-relay.example.com/team') '新中继地址实际写入保存请求'
 $script:ui.ComputerName.Text='原生界面测试电脑';$script:ui.ModeCombo.SelectedIndex=1;Save-Settings
 Assert-Ui ($script:previewState.name -eq '原生界面测试电脑') '保存电脑名称';Assert-Ui ($script:previewState.runtimeMode -eq 'shared-engine') '保存共享模式'
 Launch-Codex;Assert-Ui ($script:ui.EngineStatus.Text -eq '桌面已启动，连接待确认') '不把启动当连接';Save-PreviewImage 'home'
 Begin-Pairing;Assert-Ui ($script:ui.CopyCodeButton.IsEnabled -and $script:ui.QrImage.Source) '创建邀请和二维码';Save-PreviewImage 'pairing'
 $request=[pscustomobject]@{requestId='preview-request';phoneName='Google Pixel 4';verificationCode='729416';expiresAt=[DateTimeOffset]::UtcNow.AddMinutes(2).ToUnixTimeMilliseconds()};Apply-Pending @($request);Assert-Ui (-not $script:ui.ApproveButton.IsEnabled) '未核对不能批准';$script:ui.AgreeCode.IsChecked=$true;Assert-Ui $script:ui.ApproveButton.IsEnabled '核对后可批准';Save-PreviewImage 'request'
 $selectedText=@(Get-RenderedText $script:ui.PendingRequests);Assert-Ui ($selectedText -contains 'Google Pixel 4') '选中设备实际渲染名称';Assert-Ui (-not ($selectedText -match 'requestId|verificationCode|@\{')) '选择区不呈现原始对象和核对码'
 Confirm-Phone $true;Assert-Ui ($script:phoneRows.Count -eq 1) '授权后更新设备列表';$script:ui.PhonesTab.IsChecked=$true;Save-PreviewImage 'phones';Assert-Ui ($script:ui.PhonesList.Children.Count -eq 1) '设备按行管理'
 $script:invite=@{expiresAt=1L};Update-Invitation;Assert-Ui (-not $script:ui.CopyCodeButton.IsEnabled -and -not $script:ui.QrImage.Source) '邀请过期清除二维码并禁止复制'
 $a=[pscustomobject]@{requestId='a';phoneName='手机 A';verificationCode='123456';expiresAt=[DateTimeOffset]::UtcNow.AddMinutes(2).ToUnixTimeMilliseconds()};$b=[pscustomobject]@{requestId='b';phoneName='手机 B';verificationCode='654321';expiresAt=$a.expiresAt};Apply-Pending @($a,$b);$script:ui.AgreeCode.IsChecked=$true;$script:ui.PendingRequests.SelectedIndex=1;Assert-Ui (-not $script:ui.ApproveButton.IsEnabled) '切换申请撤销旧核对'
 $script:ui.HomeTab.IsChecked=$true;$script:window.UpdateLayout();$script:ui.PendingRequests.IsDropDownOpen=$true;$script:window.Dispatcher.Invoke([Action]{},[Windows.Threading.DispatcherPriority]::Background);$script:window.UpdateLayout();$popup=$script:ui.PendingRequests.Template.FindName('PART_Popup',$script:ui.PendingRequests);$popup.Child.UpdateLayout();$dropdownText=@(Get-RenderedText $popup.Child)
 Assert-Ui ($dropdownText -contains '手机 A' -and $dropdownText -contains '手机 B') '下拉项实际渲染各设备名称';Assert-Ui (-not ($dropdownText -match 'requestId|verificationCode|@\{')) '下拉项不呈现原始对象和核对码';$script:ui.PendingRequests.IsDropDownOpen=$false
 Assert-Ui ($script:ui.VerificationCode.Text -eq '654321' -and $script:requestId -eq 'b') '切换选择同步核对码与请求标识';Save-PreviewImage 'request-multiple'
 $renamed=[pscustomobject]@{requestId='b';phoneName='Google Pixel 4（工作手机）';verificationCode='654321';expiresAt=$b.expiresAt+60000};Apply-Pending @($a,$renamed);$script:window.UpdateLayout();Assert-Ui (@(Get-RenderedText $script:ui.PendingRequests) -contains $renamed.phoneName) '同一申请刷新设备名';Assert-Ui ($script:requestExpires -eq $renamed.expiresAt) '同一申请刷新到期时间'
 $script:window.Width=420;Save-PreviewImage 'request-narrow';$script:window.Height=480;$script:window.UpdateLayout();$requestScroller=$script:window.FindName('ContentScrollViewer');$requestScroller.ScrollToEnd();Save-PreviewImage 'request-short';Assert-Ui ($script:ui.ApproveButton.ActualWidth -gt 0 -and $requestScroller.ScrollableHeight -gt 0) '最小窗口可滚动访问授权操作';$script:window.Height=660;$requestScroller.ScrollToHome();Set-NativeTheme 'Light';Save-PreviewImage 'request-light';Set-NativeTheme 'Dark';Save-PreviewImage 'request-dark';Set-NativeTheme
 $expired=[pscustomobject]@{requestId='expired';phoneName='已过期手机';verificationCode='000000';expiresAt=1L};Apply-Pending @($expired);Assert-Ui ($script:ui.RequestsPanel.Visibility -eq 'Collapsed' -and -not $script:ui.ApproveButton.IsEnabled) '过期申请不可授权且隐藏'
 $script:window.Width=520

 $script:ui.SettingsTab.IsChecked=$true;$script:window.Width=420;Save-PreviewImage 'settings-narrow';Assert-Ui ($script:ui.SaveLaunchButton.ActualWidth -gt 0) '窄窗口保留操作'
 # 延迟回调覆盖真实controller异步顺序，避免同步预览掩盖竞态。
 $script:previewLaunch=@{phase='needs_exit';stage='needs_engine_exit';error='DESKTOP_PREVIOUS_ENGINE_RUNNING'};Apply-Status (Invoke-PreviewAction 'status' @{});Assert-Ui ($script:ui.EngineStatus.Text -eq '旧共享引擎待检查' -and $script:ui.LaunchProgress.Text -like '旧共享引擎仍在运行*') '旧引擎阻塞不误报退出桌面'
 $script:previewLaunch=@{phase='failed';stage='failed';error='DESKTOP_SHARED_SELECTION_MISMATCH'};Apply-Status (Invoke-PreviewAction 'status' @{});Assert-Ui ($script:ui.LaunchProgress.Text -like '共享启动配置与当前 Codex 入口不一致*') '启动配置失配展示具体恢复提示'
 $script:previewLaunch=@{phase='starting';stage='starting_broker'};Apply-Status (Invoke-PreviewAction 'status' @{});Assert-Ui (-not $script:ui.SaveButton.IsEnabled) '启动中禁用设置'
 $script:previewLaunch=@{phase='awaiting_connection';stage='awaiting_connection'};Apply-Status (Invoke-PreviewAction 'status' @{});Assert-Ui $script:ui.SaveButton.IsEnabled '启动终态恢复操作'
 $script:previewLaunch=@{phase='started';stage='desktop_started'};Apply-Status (Invoke-PreviewAction 'status' @{});Assert-Ui ($script:ui.EngineStatus.Text -eq '桌面已启动，等待连接') 'Bridge进程启动回执仍等待连接'
 function Drain-PreviewQueue([int]$Limit=100){$n=0;while($script:previewQueue.Count -and $n -lt $Limit){$entry=$script:previewQueue[0];$script:previewQueue.RemoveAt(0);$value=Invoke-PreviewAction $entry.action $entry.body;& $entry.done $value $null;$n++};if($n -eq 100){throw '预览异步队列未收敛'}}
 $script:settings=[pscustomobject]@{desktopInstance=$null};$script:deferPreview=$true;$launches=@($script:previewCalls|Where-Object {$_ -eq 'launchDesktop'}).Count;Save-Settings $true
 Drain-PreviewQueue 1;Assert-Ui (@($script:previewCalls|Where-Object {$_ -eq 'launchDesktop'}).Count -eq $launches) '保存回执后等待settings读取'
 Drain-PreviewQueue;Assert-Ui (@($script:previewCalls|Where-Object {$_ -eq 'launchDesktop'}).Count -eq $launches+1) 'settings刷新后只启动一次'
 $script:pendingRows=@();Apply-Pending @($a);$script:ui.AgreeCode.IsChecked=$true;Confirm-Phone $true;$script:ui.AgreeCode.IsChecked=$false;$script:ui.AgreeCode.IsChecked=$true;Confirm-Phone $true
 Assert-Ui (@($script:previewQueue|Where-Object {$_.action -eq 'confirm'}).Count -eq 1) '确认期间不能重复提交';Assert-Ui (-not $script:ui.PendingRequests.IsEnabled) '确认期间冻结申请选择';Drain-PreviewQueue;$script:deferPreview=$false
 Assert-Ui ($script:ui.PendingRequests.IsEnabled -and -not $script:confirmBusy) '确认并刷新后恢复申请选择'
 $script:ui.SettingsTab.IsChecked=$true;$script:window.Height=480;$script:window.UpdateLayout();$scroller=$script:window.FindName('ContentScrollViewer');$scroller.ApplyTemplate()|Out-Null;$bar=$scroller.Template.FindName('PART_VerticalScrollBar',$scroller);$bar.ApplyTemplate()|Out-Null
 Assert-Ui ($bar.ActualWidth -eq 12) '普通主题滚动条12 DIP'
 $scroller.ScrollToHome();$script:window.UpdateLayout();[Windows.Controls.Primitives.ScrollBar]::PageDownCommand.Execute($null,$bar);$script:window.UpdateLayout();Assert-Ui ($scroller.VerticalOffset -gt 0) '轨道翻页保持有效'
 $scroller.ScrollToHome();$script:window.UpdateLayout();$track=$bar.Template.FindName('PART_Track',$bar);$delta=New-Object Windows.Controls.Primitives.DragDeltaEventArgs(0,20);$delta.RoutedEvent=[Windows.Controls.Primitives.Thumb]::DragDeltaEvent;$track.Thumb.RaiseEvent($delta);$script:window.UpdateLayout();Assert-Ui ($scroller.VerticalOffset -gt 0) '拖动滑块保持有效'
 Set-NativeTheme 'Dark';Save-PreviewImage 'scrollbar-dark';Assert-Ui ($script:window.Resources['ScrollTrackBrush'].Color.ToString() -eq '#FF242424') '深色轨道'
 Set-NativeTheme 'Light';Save-PreviewImage 'scrollbar-light';Assert-Ui ($script:window.Resources['ScrollTrackBrush'].Color.ToString() -eq '#FFF1F1F3') '浅色轨道'
 Set-NativeTheme 'HighContrast';$script:window.UpdateLayout();Assert-Ui ($bar.ActualWidth -eq 18) '高对比度增大滚动条';Assert-Ui ($script:window.Resources['ScrollThumbBrush'].Color -eq [Windows.SystemColors]::WindowTextColor) '高对比度使用系统画刷';Set-NativeTheme
 $script:previewState.desktopInstance=$null;Load-Settings;Clear-SelectionDraft;$saveBefore=@($script:previewCalls|Where-Object {$_ -eq 'saveSettings'}).Count;Import-Shortcut 'C:\Samples\Codex.lnk'
 Assert-Ui ($script:selection.id -eq 'preview-enhanced') '导入选择被记住';Assert-Ui (-not $script:previewState.desktopInstance) '记住草稿不应用后台配置'
 $script:selection=$null;Load-Settings;Assert-Ui ($script:selection.id -eq 'preview-enhanced' -and $script:selectionDraftRestored) '重新加载恢复未保存实例'
 Assert-Ui (@($script:previewCalls|Where-Object {$_ -eq 'saveSettings'}).Count -eq $saveBefore) '恢复草稿不触发后台保存'
 Save-Settings;Assert-Ui (-not $script:selectionDraftRestored) '正式保存后清理实例草稿'
 # 运行实例只用于选择器呈现，持久化仍使用纯六字段实例记录。
 $enhanced=Get-PreviewInstance;$official=Get-PreviewInstance 'official';$enhanced|Add-Member -NotePropertyName pid -NotePropertyValue 9999
 $multi=[pscustomobject]@{instances=@($enhanced,$official);running=@([pscustomobject]@{pid=4101;instanceId=$enhanced.id;profileDirectory='C:\Profiles\Work';reason='matched'},[pscustomobject]@{pid=4102;instanceId=$enhanced.id;profileDirectory='C:\Profiles\Work';reason='matched'},[pscustomobject]@{pid=4103;instanceId=$null;profileDirectory='C:\Profiles\Unknown';reason='shortcut_required'});processScanFailed=$false}
 $view=New-InstancePicker $multi;$view.window.ShowInTaskbar=$false;$view.window.Show();$view.window.Dispatcher.Invoke([Action]{},[Windows.Threading.DispatcherPriority]::Background);$view.window.UpdateLayout()
 try{
  Assert-Ui ($view.list.Items.Count -eq 4) '同实例多PID分别显示且保留其他候选'
  $pickerText=@(Get-RenderedText $view.list);Assert-Ui ($pickerText -contains '正在运行 · PID 4101' -and $pickerText -contains '正在运行 · PID 4102' -and $pickerText -contains '配置目录：C:\Profiles\Work') '选择器实际显示PID和profile'
  Assert-Ui ($pickerText -contains '自定义 Codex · Unknown（尚未适配）' -and $pickerText -contains '其他候选 · 已验证入口') '未知实例和静态候选分别说明'
  Assert-Ui (-not ($pickerText -match '需导入快捷方式|请取消后导入')) '未适配启动链不误导用户导入即可使用'
  Assert-Ui (-not $view.list.Items[2].IsEnabled -and $null -eq $view.list.Items[2].Tag) '未知profile不可选且无持久化Tag'
  $tag=$view.list.Items[0].Tag;Assert-Ui (@($tag.PSObject.Properties).Count -eq 6 -and @($tag.PSObject.Properties|Where-Object {$_.Name -in @('pid','profileDirectory','reason','instanceId')}).Count -eq 0) '候选Tag严格保留六字段'
  Assert-Ui (-not $view.accept.IsEnabled -and $view.list.SelectedIndex -eq -1) '多进程选择器不预选'
  $view.list.SelectedIndex=1;Assert-Ui ($view.accept.IsEnabled -and $view.list.SelectedItem.Tag.id -eq $enhanced.id) '第二个同实例进程可手动选择'
  Save-PreviewImage 'running-instance-picker' $view.window
 }finally{$view.window.Close()}
 $script:selection=$official;Clear-SelectionDraft;$script:previewPickerDetection=$null;$script:previewDetection=$multi;Find-Instances $false
 Assert-Ui ($script:selection.id -eq $official.id -and $script:ui.Notice.Text -match '3 个正在运行' -and $null -eq $script:previewPickerDetection) '多运行进程检测保留选择且提示手选'
 $failed=[pscustomobject]@{instances=@($enhanced);running=@();processScanFailed=$true};$script:previewDetection=$failed;Find-Instances $false
 Assert-Ui ($script:selection.id -eq $official.id -and $script:ui.Notice.Text -match '无法扫描') '扫描失败不自动换选'
 $single=[pscustomobject]@{instances=@($enhanced,$official);running=@($multi.running[0]);processScanFailed=$false};$script:previewDetection=$single;Find-Instances $false
 Assert-Ui ($script:selection.id -eq $enhanced.id) '唯一匹配运行实例优先记草稿'
 $script:previewPickerDetection=$null;Find-Instances $true $true;Assert-Ui ($script:selection.id -eq $enhanced.id -and $null -ne $script:previewPickerDetection -and $script:ui.Notice.Text -notmatch '未识别' -and $script:ui.Notice.Text -match '启动配置') '更换强制展示唯一运行实例及其他候选且不自动覆盖'
 $switchView=New-InstancePicker $script:previewPickerDetection;$switchView.window.ShowInTaskbar=$false;$switchView.window.Show();$switchView.window.UpdateLayout();try{$switchView.list.SelectedIndex=1;Assert-Ui ($switchView.list.SelectedItem.Tag.id -eq $official.id -and $switchView.accept.IsEnabled) '唯一增强运行时更换仍可选择官方入口';Save-PreviewImage 'running-instance-switch' $switchView.window}finally{$switchView.window.Close()}

 $draftPath=Get-SelectionDraftPath;$draft=if($draftPath){Get-Content -LiteralPath $draftPath -Raw|ConvertFrom-Json}else{$script:previewSelectionDraft};Assert-Ui (@($draft.selection.PSObject.Properties).Count -eq 6) '运行实例草稿保持纯六字段schema'
 $unknown=[pscustomobject]@{instances=@($official);running=@($multi.running[2]);processScanFailed=$false};$script:previewDetection=$unknown;Find-Instances $false
 Assert-Ui ($script:selection.id -eq $enhanced.id -and $script:ui.Notice.Text -match '尚未适配') '未知运行实例不自动冒充官方入口'
 $script:previewDetection=[pscustomobject]@{instances=@($official);running=@();processScanFailed=$false};Find-Instances $false;Assert-Ui ($script:selection.id -eq $official.id) '无运行实例时唯一静态入口可记草稿'
 $script:previewDetection=$null;Clear-SelectionDraft
 $script:previewState.desktopInstance=$null;Load-Settings;Remember-Selection $enhanced;$script:previewSaveFailure='DESKTOP_SHARED_CONFIG_INVALID';$script:ui.HomeTab.IsChecked=$true;Save-Settings
 Assert-Ui (-not $script:previewState.desktopInstance -and $script:selection.id -eq $enhanced.id) '保存失败不应用实例且保留选择'
 Assert-Ui ($script:ui.SettingsTab.IsChecked -and $script:ui.Notice.Text -match '保存失败.*共享配置') '保存失败留在设置并提示具体原因'
 $failureDraftPath=Get-SelectionDraftPath;Assert-Ui ($(if($failureDraftPath){Test-Path -LiteralPath $failureDraftPath}else{$null -ne $script:previewSelectionDraft})) '保存失败保留选择草稿'
 $script:previewSaveFailure=$null;Save-Settings;Assert-Ui ($script:previewState.desktopInstance.id -eq $enhanced.id -and $script:ui.HomeInstanceName.Text -eq $enhanced.name) '保存成功首页立即显示已保存实例'
 $script:ui.HomeInstanceName.Text='旧显示';Load-Settings;Assert-Ui ($script:ui.HomeInstanceName.Text -eq $enhanced.name) '读取设置独立刷新首页无需等待状态轮询'
 # 延迟检测回调覆盖卡片邻近反馈、状态轮询及成功/失败恢复。
 $script:ui.SettingsTab.IsChecked=$true;$script:selection=$enhanced;$script:previewDetection=[pscustomobject]@{instances=@($official);running=@();processScanFailed=$false};$script:deferPreview=$true;Find-Instances $false
 Assert-Ui ($script:detectionBusy -and -not $script:operationBusy -and $script:ui.InstanceDetectionStatus.Visibility -eq 'Visible') '检测使用独立状态且立即在实例卡片显示反馈'
 Save-PreviewImage 'detection-loading';Assert-Ui ($script:ui.InstanceDetectionProgress.IsIndeterminate -and $script:ui.InstanceDetectionProgress.ActualWidth -gt 0 -and @(Get-RenderedText $script:ui.InstanceDrop) -contains '正在检测 Codex…') '卡片真实呈现不定进度和检测文字'
 Assert-Ui ($script:ui.ChooseInstanceButton.Content -eq '检测中…' -and $script:ui.DetectButton.Content -eq '检测中…' -and -not $script:ui.ChooseInstanceButton.IsEnabled -and -not $script:ui.SaveButton.IsEnabled) '检测中按钮文案明确并冻结冲突操作'
 Apply-Status (Invoke-PreviewAction 'status' @{});Assert-Ui ($script:ui.ChooseInstanceButton.Content -eq '检测中…' -and -not $script:ui.ChooseInstanceButton.IsEnabled -and $script:ui.InstanceDetectionStatus.Visibility -eq 'Visible') '状态轮询不覆盖检测文案和禁用状态'
 $script:ui.HomeTab.IsChecked=$true;Assert-Ui ($script:ui.HomePanel.Visibility -eq 'Visible' -and $script:ui.SettingsTab.IsEnabled) '检测期间可正常切换页面';$script:ui.SettingsTab.IsChecked=$true
 $queuedDetections=@($script:previewQueue|Where-Object {$_.action -eq 'detectDesktop'}).Count;Find-Instances $false;Assert-Ui (@($script:previewQueue|Where-Object {$_.action -eq 'detectDesktop'}).Count -eq $queuedDetections) '重复检测不会重入'
 Drain-PreviewQueue;Assert-Ui (-not $script:detectionBusy -and $script:ui.InstanceDetectionStatus.Visibility -eq 'Collapsed' -and $script:ui.ChooseInstanceButton.Content -eq '更换' -and $script:ui.ChooseInstanceButton.IsEnabled -and $script:selection.id -eq $official.id) '延迟检测成功后恢复操作并更新候选'
 Find-Instances $false;$pendingDetection=$script:previewQueue|Where-Object {$_.action -eq 'detectDesktop'}|Select-Object -First 1;[void]$script:previewQueue.Remove($pendingDetection);& $pendingDetection.done $null 'Controller timed out.'
 Assert-Ui (-not $script:detectionBusy -and -not $script:ui.InstanceDetectionProgress.IsIndeterminate -and $script:ui.InstanceDetectionProgress.Visibility -eq 'Collapsed' -and $script:ui.ChooseInstanceButton.IsEnabled -and $script:ui.DetectButton.Content -eq '自动检测') '延迟检测失败后恢复按钮并停止进度'
 Save-PreviewImage 'detection-failure';Assert-Ui ($script:selection.id -eq $official.id -and $script:ui.InstanceDetectionStatus.Visibility -eq 'Visible' -and $script:ui.InstanceDetectionText.Text -match '检测未完成') '检测失败保留选择并在卡片邻近显示原因'
 $script:deferPreview=$false;$script:previewDetection=$null;Clear-SelectionDraft
 Write-Output ('NATIVE_UI_OK checks='+$script:checks+' scale='+$PreviewScale+' previewOnly=true')
}
try{
 $script:window.Add_Loaded({if($SmokeTest){return};if($Preview){Load-Settings;Apply-Status (Invoke-PreviewAction 'status' @{});Set-Notice '隔离预览，不连接后台或真实设备。'}else{Set-OperationBusy $false;Refresh-Status};$script:asyncTimer.Start();$script:timer.Start()})
 if($SmokeTest){$script:window.ShowInTaskbar=$false;$script:window.Show();Invoke-NativeSmokeTest;$script:exiting=$true;$script:window.Close()}elseif($Preview){[void]$script:window.ShowDialog()}else{Start-TrayWindowLoop $script:window}
}finally{
 $script:timer.Stop();$script:asyncTimer.Stop();foreach($request in $script:asyncRequests){try{if(-not $request.process.HasExited){$request.process.Kill()};$request.process.Dispose()}catch{}}
 if($script:trayIcon){$script:trayIcon.Visible=$false;$script:trayIcon.Dispose()};if($script:trayContext){$script:trayContext.Dispose()};if($script:activationSignal){$script:activationSignal.Dispose()};if($script:mutex){try{$script:mutex.ReleaseMutex()}catch{};$script:mutex.Dispose()}
}
