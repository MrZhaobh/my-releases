﻿$ErrorActionPreference='Stop'
Add-Type -TypeDefinition @'
using System;using System.Runtime.InteropServices;using Microsoft.Win32.SafeHandles;
public static class CodexPipeOwner{[DllImport("kernel32.dll",SetLastError=true)]public static extern bool GetNamedPipeServerProcessId(SafePipeHandle h,out uint pid);}
'@
$names=([Console]::In.ReadToEnd()|ConvertFrom-Json)
$sessionId=[System.Diagnostics.Process]::GetCurrentProcess().SessionId
$owners=@()
foreach($name in $names){
 if($name -notmatch '^codex-app-tools-[a-f0-9-]+$'){continue}
 $pipe=New-Object System.IO.Pipes.NamedPipeClientStream('.', $name, [System.IO.Pipes.PipeDirection]::InOut)
 try{$pipe.Connect(300);[uint32]$ownerId=0;if([CodexPipeOwner]::GetNamedPipeServerProcessId($pipe.SafePipeHandle,[ref]$ownerId)){$owners+=@{name=$name;pid=$ownerId}}}catch{}finally{$pipe.Dispose()}
}
$result=@()
if($owners.Count -gt 0){
 $filter=($owners.pid|ForEach-Object{"ProcessId = $_"}) -join ' OR '
 $processes=@(Get-CimInstance Win32_Process -Filter $filter)
 foreach($owner in $owners){
  $p=$processes|Where-Object ProcessId -eq $owner.pid
  if($p.Name -ne 'ChatGPT.exe' -or $p.ExecutablePath -notlike '*\WindowsApps\OpenAI.Codex_*\app\ChatGPT.exe' -or $p.SessionId -ne $sessionId){continue}
  $profile=$null
  if($p.CommandLine -match '--user-data-dir=(?:"([^"]+)"|(\S+))'){$profile=if($matches[1]){$matches[1]}else{$matches[2]}}
  $hasVisibleWindow=$false
  try{$windowProcess=[System.Diagnostics.Process]::GetProcessById([int]$owner.pid);$hasVisibleWindow=($windowProcess.MainWindowHandle -ne [IntPtr]::Zero)}catch{}
  $result+=@{name=$owner.name;pid=$owner.pid;profile=$profile;isDefault=($null -eq $profile);hasVisibleWindow=$hasVisibleWindow}
 }
}
ConvertTo-Json -InputObject @($result) -Compress
