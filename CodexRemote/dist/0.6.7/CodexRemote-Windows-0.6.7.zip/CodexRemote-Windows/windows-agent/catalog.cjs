'use strict';
class CatalogError extends Error{constructor(code,message){super(message);this.code=code;}}
function parseModelSet(schema){
 const description=schema?.properties?.model?.description;
 if(typeof description!=='string')return null;
 const rows=new Map();
 for(const match of description.matchAll(/([a-zA-Z0-9][a-zA-Z0-9._-]+)\s*\(([^)]*?)supported reasoning efforts:\s*([a-z, ]+)[^)]*\)/gi)){
  const id=match[1],efforts=[...new Set(match[3].split(/,\s*/).filter(Boolean))];
  rows.set(id,{id,displayName:id,reasoningEfforts:efforts});
 }
 return rows.size?rows:null;
}
function parseToolCatalog(result,{fetchedAt=Date.now()}={}){
 const tools=result?.result?.tools??result?.tools;
 if(!Array.isArray(tools))throw new CatalogError('MODELS_UNAVAILABLE','模型目录暂不可用');
 const create=tools.find(t=>t.name==='create_thread'),send=tools.find(t=>t.name==='send_message_to_thread');
 if(!create||!send)throw new CatalogError('MODELS_UNAVAILABLE','模型目录暂不可用');
 const createModels=parseModelSet(create.inputSchema),sendModels=parseModelSet(send.inputSchema);
 const createThinking=create.inputSchema?.properties?.thinking?.enum,sendThinking=send.inputSchema?.properties?.thinking?.enum;
 if(!createModels||!sendModels||!Array.isArray(createThinking)||!Array.isArray(sendThinking))throw new CatalogError('MODELS_UNAVAILABLE','模型目录暂不可用');
 const thinkingSet=new Set(createThinking.filter(x=>typeof x==='string'&&sendThinking.includes(x)));
 const models=[];
 for(const [id,createModel]of createModels){const sendModel=sendModels.get(id);if(!sendModel)continue;
  const allowed=new Set(sendModel.reasoningEfforts),reasoningEfforts=createModel.reasoningEfforts.filter(value=>allowed.has(value)&&thinkingSet.has(value)).map(value=>({value,label:value}));
  models.push({id,displayName:createModel.displayName,reasoningEfforts,defaultReasoningEffort:null,isDefault:false});
 }
 if(!models.length)throw new CatalogError('MODELS_UNAVAILABLE','模型目录暂不可用');
 return{models,source:'desktop-tools-schema',fetchedAt,stale:false,capabilities:{canOverrideModel:true,canOverrideThinking:models.some(m=>m.reasoningEfforts.length>0),canSetSpeed:false}};
}
function normalizeCatalog(raw,{source='desktop-tools-schema',fetchedAt=Date.now(),stale=false}={}){
 if(!Array.isArray(raw?.models)||!raw.models.length)throw new CatalogError('MODELS_UNAVAILABLE','模型目录暂不可用');
 const models=raw.models.filter(m=>typeof m?.id==='string'&&typeof m?.displayName==='string').map(m=>({id:m.id,displayName:m.displayName,...(typeof m.description==='string'?{description:m.description}:{}),reasoningEfforts:(m.reasoningEfforts??[]).filter(e=>typeof e?.value==='string').map(e=>({value:e.value,label:typeof e.label==='string'?e.label:e.value})),defaultReasoningEffort:null,isDefault:false}));
 if(!models.length)throw new CatalogError('MODELS_UNAVAILABLE','模型目录暂不可用');
 return{models,source,fetchedAt,stale,capabilities:{canOverrideModel:true,canOverrideThinking:models.some(m=>m.reasoningEfforts.length>0),canSetSpeed:false}};
}
function createModelCatalog({provider}={}){
 return{async get(){try{const result=await provider?.();if(!result)throw new Error('unavailable');return normalizeCatalog(result,{source:result.source??'desktop-tools-schema',fetchedAt:Number.isFinite(result.fetchedAt)?result.fetchedAt:Date.now(),stale:!!result.stale})}catch(e){if(e?.code==='MODELS_UNAVAILABLE')throw e;throw new CatalogError('MODELS_UNAVAILABLE','模型目录暂不可用')}}};
}
module.exports={CatalogError,parseToolCatalog,normalizeCatalog,createModelCatalog};
