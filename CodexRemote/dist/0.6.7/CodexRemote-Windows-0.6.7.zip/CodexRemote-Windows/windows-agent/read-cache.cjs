'use strict';

const {BridgeError}=require('./errors.cjs');
const RESULT_BYTES=8*1024*1024;
const DEFAULT_LIMITS=Object.freeze({ttlMs:30000,listBytes:2*1024*1024,pageBytes:32*1024*1024,itemBytes:8*1024*1024,pages:10,inFlight:64});
const POLICIES=new Set(['fresh','prefer','only']);
const WRITES=new Set(['create','send','reconcile','interrupt','importThread','respondApproval','activateThread']);
const copy=value=>structuredClone(value);
const error=(code,message)=>new BridgeError(code,message);

function normalizeRead(operation,args){
 const known=new Set(operation==='threads'?['limit','cursor','requestId']:['threadId','turnLimit','cursor','requestId']);
 const eligibleKeys=Object.keys(args).every(key=>known.has(key));
 const cursor=args.cursor;
 if(cursor!=null&&(typeof cursor!=='string'||cursor.length>4096))throw error('BAD_INPUT','读取游标无效');
 const normalized={...args};
 if(cursor)normalized.cursor=cursor;else delete normalized.cursor;
 const keyArgs={};
 if(operation==='threads'){
  normalized.limit=Math.max(1,Math.min(Number.isInteger(args.limit)?args.limit:30,50));keyArgs.limit=normalized.limit;
 }else{
  if(typeof args.threadId!=='string'||!args.threadId||args.threadId.length>512)throw error('BAD_INPUT','会话ID无效');
  normalized.turnLimit=Math.max(1,Math.min(Number.isInteger(args.turnLimit)?args.turnLimit:10,10));
  keyArgs.threadId=args.threadId;keyArgs.turnLimit=normalized.turnLimit;
 }
 // Agent 的 requestId 是读取任务的关联标识，不改变这两个只读操作的内容。
 return{args:normalized,key:JSON.stringify([operation,keyArgs]),threadId:operation==='read'?args.threadId:null,eligible:eligibleKeys&&!cursor};
}

/**
 * 仅保存最近前台请求得到的首列表和十个会话最新页，不主动寻找或预取活跃会话。
 * fresh 始终通过原运行时校验；prefer/only 的命中明确是旧快照，不能解释为同步完成。
 * TTL 惰性清理，不创建定时器。结果和参数均完整拷贝，不裁剪正文、工具或附件描述。
 */
class ReadCache{
 constructor(runtime,{deviceId='local',identity,clock=Date.now,limits={}}={}){
  if(!runtime||typeof runtime.execute!=='function')throw error('BAD_INPUT','读取缓存缺少运行时');
  this.runtime=runtime;this.clock=clock;
  this.identityProvider=identity??(()=>({deviceId,runtimeId:runtime.instanceId??'legacy'}));
  if(typeof this.identityProvider!=='function')throw error('BAD_INPUT','运行时身份提供器无效');
  this.limits={...DEFAULT_LIMITS,...limits};
  for(const [key,value]of Object.entries(this.limits))if(!Object.hasOwn(DEFAULT_LIMITS,key)||!Number.isSafeInteger(value)||value<1||value>DEFAULT_LIMITS[key])throw error('BAD_INPUT','读取缓存容量配置无效');
  this.identity=null;this.revision=0;this.sequence=0;this.list=null;this.pages=new Map();this.pageBytes=0;this.flights=new Map();this.waiters=new Set();this.closed=false;this.closeTask=null;
 }
 get instanceId(){return this.runtime.instanceId;}
 getStatus(...args){return this.runtime.getStatus(...args);}
 registerSubmissionReceipt(...args){return this.runtime.registerSubmissionReceipt?.(...args);}
 setEventListener(listener){
  this.runtime.setEventListener?.(event=>{this.onEvent(event);listener?.(event);});
 }
 _identity(){
  const value=this.identityProvider();
  let key;
  if(typeof value==='string'&&value&&value.length<=2048)key=value;
  else if(value&&typeof value==='object'&&!Array.isArray(value)){
   const entries=Object.entries(value).sort(([a],[b])=>a.localeCompare(b));
   if(!entries.length||entries.length>8||entries.some(([key,value])=>key.length>64||!['string','number','boolean'].includes(typeof value)||typeof value==='string'&&value.length>512||typeof value==='number'&&!Number.isFinite(value)))throw error('BAD_INPUT','运行时身份无效');
   key=JSON.stringify(entries);
  }else throw error('BAD_INPUT','运行时身份无效');
  if(key!==this.identity){this.identity=key;this.invalidate();}
  return key;
 }
 _dropPage(threadId){const entry=this.pages.get(threadId);if(entry){this.pages.delete(threadId);this.pageBytes-=entry.bytes;}}
 _prune(){
  const valid=entry=>{const age=this.clock()-entry.savedAt;return age>=0&&age<this.limits.ttlMs;};
  if(this.list&&!valid(this.list))this.list=null;
  for(const [threadId,entry]of this.pages)if(!valid(entry))this._dropPage(threadId);
 }
 invalidate(options){
  if(this.closed)return;
  this.revision++;
  if(!options||typeof options!=='object'||options.all===true){this.list=null;this.pages.clear();this.pageBytes=0;return;}
  if(options.list!==false)this.list=null;
  if(typeof options.threadId==='string')this._dropPage(options.threadId);
 }
 onEvent(event){
  if(this.closed||!event||typeof event!=='object')return false;
  const type=event.data?.type??event.type??event.method;
  if(['ping','pong','heartbeat'].includes(type))return false;
  const threadId=event.threadId??event.data?.threadId??event.params?.threadId;
  if(typeof threadId==='string'&&threadId&&threadId.length<=512)this.invalidate({threadId});
  else this.invalidate();
  return true;
 }
 _entry(spec){
  const entry=spec.threadId===null?this.list:this.pages.get(spec.threadId);
  return entry?.key===spec.key&&entry.identity===this.identity?entry:null;
 }
 _fitsMetadata(value,metadata,bytes=Buffer.byteLength(JSON.stringify(value))){
  // 通常没有根 cache 字段，直接累加 JSON 对象的确切字节，避免反复序列化大正文。
  if(!Object.hasOwn(value,'cache'))return bytes+Buffer.byteLength(JSON.stringify({cache:metadata}))-2+(bytes>2?1:0)<=RESULT_BYTES;
  return Buffer.byteLength(JSON.stringify({...value,cache:metadata}))<=RESULT_BYTES;
 }
 _store(spec,packet,flight,policy){
  const bytes=packet.bytes;
  if(bytes>this.limits.itemBytes||bytes>(spec.threadId===null?this.limits.listBytes:this.limits.pageBytes))return false;
  // 预留真实返回元数据和有效期内最宽的命中元数据。不能因加入缓存字段破坏既有 8 MiB 协议边界。
  if(!this._fitsMetadata(packet.value,{policy,hit:false,ageMs:0,savedAt:packet.validatedAt,stale:false,validated:true,validatedAt:packet.validatedAt},bytes)||
     !this._fitsMetadata(packet.value,{policy:'prefer',hit:true,ageMs:this.limits.ttlMs,savedAt:packet.validatedAt,stale:true,validated:false,validatedAt:null},bytes))return false;
  const existing=spec.threadId===null?this.list:this.pages.get(spec.threadId);
  // 较早启动的 prefer 回读不能覆盖后来 fresh 已完成的结果，参数不同的同一会话也一样。
  if(existing&&existing.fetchOrder>flight.order)return false;
  const entry={key:spec.key,identity:flight.identity,value:packet.value,savedAt:packet.validatedAt,bytes,fetchOrder:flight.order,lastUsed:flight.lastUsed};
  if(spec.threadId===null){this.list=entry;return true;}
  this._dropPage(spec.threadId);this.pages.set(spec.threadId,entry);this.pageBytes+=bytes;
  while(this.pages.size>this.limits.pages||this.pageBytes>this.limits.pageBytes){
   let oldestId,oldest=Infinity;
   for(const [id,value]of this.pages)if(value.lastUsed<oldest){oldest=value.lastUsed;oldestId=id;}
   this._dropPage(oldestId);
  }
  return this.pages.get(spec.threadId)===entry;
 }
 _decorate(value,metadata,bytes){
  // 原始结果接近上限时完整返回；这一回没有 cache 字段也不能被解释为缓存命中。
  return this._fitsMetadata(value,metadata,bytes)?{...copy(value),cache:{...metadata}}:copy(value);
 }
 _wait(task){
  if(this.closed)return Promise.reject(error('CLOSED','读取缓存已关闭'));
  return new Promise((resolve,reject)=>{
   const waiter={reject};this.waiters.add(waiter);
   task.then(value=>{if(this.waiters.delete(waiter))resolve(value);},failure=>{if(this.waiters.delete(waiter))reject(failure);});
  });
 }
 async _read(operation,spec,policy,identity){
  const revision=this.revision,lastUsed=++this.sequence,key=JSON.stringify([identity,revision,policy,spec.key,...(spec.eligible?[]:['uncached',lastUsed])]);
  const cached=this._entry(spec);if(cached)cached.lastUsed=lastUsed;
  let flight=spec.eligible?this.flights.get(key):null;
  if(!flight){
   if(this.flights.size>=this.limits.inFlight)throw error('BUSY','读取校验请求过多，请稍后重试');
   flight={identity,revision,order:lastUsed,lastUsed,task:null};
   const fetch=async()=>{
    if(this.closed)throw error('CLOSED','读取缓存已关闭');
    const result=await this.runtime.execute(operation,copy(spec.args));
    if(this.closed)throw error('CLOSED','读取缓存已关闭');
    if(!result||typeof result!=='object'||Array.isArray(result))throw error('INVALID_RESPONSE','读取结果格式无效');
    const packet={value:copy(result),validatedAt:this.clock(),savedAt:null,stale:true};packet.bytes=Buffer.byteLength(JSON.stringify(packet.value));
    if(!this.closed)this._identity();
    packet.stale=this.closed||flight.identity!==this.identity||flight.revision!==this.revision;
    if(spec.eligible&&!packet.stale&&this._store(spec,packet,flight,policy))packet.savedAt=packet.validatedAt;
    return packet;
   };
   // 设置在途条目后才调用真实运行时，运行时同步事件也能正确推进版本。
   const task=Promise.resolve().then(fetch).finally(()=>{if(this.flights.get(key)===flight)this.flights.delete(key);});
   flight.task=task;this.flights.set(key,flight);
  }else flight.lastUsed=lastUsed;
  const packet=await this._wait(flight.task);
  // 等待者恢复前仍可能已发生新事件；不能把旧 flight 的结果标为当前同步完成。
  const stale=packet.stale||this.closed||identity!==this._identity()||revision!==this.revision;
  return this._decorate(packet.value,{policy,hit:false,ageMs:0,savedAt:packet.savedAt,stale,validated:true,validatedAt:packet.validatedAt},packet.bytes);
 }
 async execute(operation,args={}){
  if(this.closed)throw error('CLOSED','读取缓存已关闭');
  if(!args||typeof args!=='object'||Array.isArray(args))throw error('BAD_INPUT','读取参数无效');
  const {cachePolicy='fresh',...input}=copy(args);
  if(!POLICIES.has(cachePolicy))throw error('BAD_INPUT','缓存策略仅支持 fresh、prefer、only');
  const identity=this._identity();this._prune();
  // 索引与普通历史正文互不复用，不命中或覆盖实验缓存。
  if(operation==='read'&&Object.hasOwn(input,'questionIndex')){
   if(typeof input.questionIndex!=='boolean')throw error('BAD_INPUT','questionIndex必须是布尔值');
   if(input.questionIndex)return this.runtime.execute(operation,copy(input));
   delete input.questionIndex;
  }
  if(operation!=='threads'&&operation!=='read'){
   if(args.cachePolicy!==undefined)throw error('BAD_INPUT','此操作不接受读取缓存策略');
   if(!WRITES.has(operation))return this.runtime.execute(operation,copy(input));
   let result;
   this.invalidate({threadId:input.threadId,list:true});
   try{result=await this.runtime.execute(operation,copy(input));return result;}
   finally{this.invalidate({threadId:result?.threadId??input.threadId,list:true});}
  }
  const spec=normalizeRead(operation,input),entry=spec.eligible?this._entry(spec):null;
  if(cachePolicy!=='fresh'&&entry){
   const metadata={policy:cachePolicy,hit:true,ageMs:this.clock()-entry.savedAt,savedAt:entry.savedAt,stale:true,validated:false,validatedAt:null};
   if(this._fitsMetadata(entry.value,metadata,entry.bytes)){
    entry.lastUsed=++this.sequence;
    return this._decorate(entry.value,metadata,entry.bytes);
   }
   // 即便时钟/元数据长度变化，也不能无标记地把命中快照交给 only/prefer。
   if(spec.threadId===null)this.list=null;else this._dropPage(spec.threadId);
  }
  if(cachePolicy==='only')throw error('CACHE_MISS','没有可用的内存快照，请执行 fresh 读取');
  return this._read(operation,spec,cachePolicy,identity);
 }
 close(){
  if(this.closeTask)return this.closeTask;
  this.invalidate();this.closed=true;
  for(const waiter of this.waiters)waiter.reject(error('CLOSED','读取缓存已关闭'));this.waiters.clear();this.flights.clear();
  this.closeTask=Promise.resolve().then(()=>this.runtime.close?.());return this.closeTask;
 }
}

module.exports={ReadCache,createReadCache:(runtime,options)=>new ReadCache(runtime,options),DEFAULT_LIMITS};
