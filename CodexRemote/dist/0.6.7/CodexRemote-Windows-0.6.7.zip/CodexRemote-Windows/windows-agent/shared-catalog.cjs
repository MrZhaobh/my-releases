'use strict';

const crypto = require('node:crypto');
const {BridgeError} = require('./errors.cjs');
const {usageResult} = require('./usage.cjs');
const UUID = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
const error = (code, message) => new BridgeError(code, message);
const copy = value => structuredClone(value);
const millis = value => Number.isFinite(value) && value >= 0 ? (value < 1e12 ? value * 1000 : value) : null;
const text = value => typeof value === 'string' && value.trim() ? value : null;
const status = value => {
  const kind = typeof value === 'string' ? value : value?.type;
  return kind === 'active' ? 'active' : kind === 'idle' ? 'idle' : 'unknown';
};
const visible = row => row && UUID.test(row.id ?? '') && !row.parentThreadId && row.archived !== true && !['subagent', 'composer_link'].includes(row.threadSource) && !(typeof row.source === 'string' ? /^subagent/i.test(row.source) : row.source && typeof row.source === 'object' && ('subAgent' in row.source || 'subagent' in row.source));
function page(value, limit) {
  if (!value || !Array.isArray(value.data) || value.data.length > limit) throw error('INVALID_RESPONSE', '共享引擎目录返回格式或数量无效。');
  const cursor = value.nextCursor;
  if (cursor != null && (typeof cursor !== 'string' || !cursor || cursor.length > 8192)) throw error('INVALID_RESPONSE', '共享引擎分页游标无效。');
  return {rows:value.data, cursor:cursor ?? null};
}

/** 只通过当前共享引擎的 RPC 读取目录；不发现或调用任何桌面实例。 */
class SharedCatalog {
  constructor({request, instanceId, secret} = {}) {
    if (typeof request !== 'function' || typeof instanceId !== 'string' || !instanceId || instanceId.length > 256 || !(typeof secret === 'string' || Buffer.isBuffer(secret)) || Buffer.byteLength(secret) < 16) throw error('BAD_INPUT', '共享目录缺少有效的请求通道或游标签名配置。');
    this.request = request; this.instanceId = instanceId; this.secret = secret;
    this.cache = new Map(); this.inFlight = new Map();
  }
  _encode(provider, query) {
    const body = Buffer.from(JSON.stringify({v:1, instanceId:this.instanceId, provider, query})).toString('base64url');
    return `${body}.${crypto.createHmac('sha256', this.secret).update(body).digest('base64url')}`;
  }
  _decode(value, query) {
    try {
      if (typeof value !== 'string' || value.length > 16384) throw Error();
      const [body, signature, extra] = value.split('.');
      const expected = crypto.createHmac('sha256', this.secret).update(body ?? '').digest('base64url');
      if (extra !== undefined || !signature || signature.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) throw Error();
      const decoded = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
      if (decoded.v !== 1 || decoded.instanceId !== this.instanceId || JSON.stringify(decoded.query) !== JSON.stringify(query) || typeof decoded.provider !== 'string' || !decoded.provider || decoded.provider.length > 8192) throw Error();
      return decoded.provider;
    } catch { throw error('CURSOR_EXPIRED', '共享目录游标已失效或不属于当前查询，请刷新列表。'); }
  }
  async _cached(key, ttl, load) {
    const cached = this.cache.get(key);
    if (cached && Date.now() - cached.at < ttl) return copy(cached.value);
    if (!this.inFlight.has(key)) {
      const task = Promise.resolve().then(load).then(value => {this.cache.set(key, {at:Date.now(), value:copy(value)}); return value;});
      this.inFlight.set(key, task);
      task.finally(() => {if (this.inFlight.get(key) === task) this.inFlight.delete(key);}).catch(() => {});
    }
    return copy(await this.inFlight.get(key));
  }
  async _all(method, args) {
    const rows = [], seen = new Set(); let cursor;
    for (let index = 0; index < 100; index++) {
      const result = page(await this.request(method, {...args, limit:100, ...(cursor ? {cursor} : {})}), 100);
      rows.push(...result.rows);
      if (!result.cursor) return rows;
      if (seen.has(result.cursor)) throw error('INVALID_RESPONSE', '共享引擎目录分页没有前进。');
      seen.add(result.cursor); cursor = result.cursor;
    }
    throw error('INVALID_RESPONSE', '共享引擎目录超过分页上限。');
  }
  async threads(args = {}) {
    const limit = Math.max(1, Math.min(Number.isInteger(args.limit) ? args.limit : 30, 50));
    if (args.search !== undefined && (typeof args.search !== 'string' || args.search.length > 200)) throw error('BAD_INPUT', '会话搜索条件最多 200 字。');
    if (args.projectId !== undefined && args.projectId !== null && (!text(args.projectId) || args.projectId.length > 256)) throw error('BAD_INPUT', '项目标识无效。');
    const query = {limit, search:args.search ?? '', ...(Object.hasOwn(args, 'projectId') ? {projectId:args.projectId} : {})};
    const cursor = args.cursor ? this._decode(args.cursor, query) : null;
    const result = page(await this.request('thread/list', {
      limit, archived:false, sortKey:'recency_at', sortDirection:'desc', modelProviders:[], useStateDbOnly:true,
      ...(query.search ? {searchTerm:query.search} : {}),
      ...(Object.hasOwn(query, 'projectId') ? {projectId:query.projectId} : {}), ...(cursor ? {cursor} : {}),
    }), limit);
    if (result.cursor && result.cursor === cursor) throw error('INVALID_RESPONSE', '共享会话目录分页没有前进。');
    const ids = new Set(), projects = this.cache.get('projects')?.value.projects ?? [];
    const threads = result.rows.filter(row => visible(row) && !ids.has(row.id) && ids.add(row.id)).map(row => {
      const updatedAt = millis(row.recencyAt) ?? millis(row.updatedAt) ?? millis(row.createdAt);
      return {
        id:row.id, title:text(row.name) ?? text(row.preview)?.slice(0, 200) ?? '未命名会话', preview:typeof row.preview === 'string' ? row.preview : '',
        status:status(row.status), updatedAt, sortAt:updatedAt, lastUpdatedAt:millis(row.updatedAt),
        ...(text(row.cwd) ? {cwd:row.cwd} : {}), projectId:text(row.projectId), projectName:projects.find(project => project.id === row.projectId)?.name ?? null,
      };
    });
    // 原生协议未提供置顶字段，不从分组名称或其他桌面配置推测置顶。
    return {threads, hasMore:!!result.cursor, nextCursor:result.cursor ? this._encode(result.cursor, query) : null, source:'shared-engine:thread/list', fetchedAt:Date.now(), capabilities:{pinned:false}};
  }
  async statuses(args = {}) {
    const ids = args.threadIds;
    if (!Array.isArray(ids) || !ids.length || ids.length > 50 || new Set(ids).size !== ids.length || ids.some(id => !UUID.test(id ?? ''))) throw error('BAD_INPUT', '会话状态查询参数无效。');
    const rows = new Array(ids.length); let next = 0;
    await Promise.all(Array.from({length:Math.min(4, ids.length)}, async () => {
      while (next < ids.length) {
        const index = next++, id = ids[index];
        try {
          const result = await this.request('thread/read', {threadId:id, includeTurns:false});
          if (result?.thread?.id !== id || !visible(result.thread)) throw Error();
          rows[index] = {id, status:status(result.thread.status), turnStatus:null, updatedAt:millis(result.thread.updatedAt)};
        } catch { rows[index] = {id, status:'unknown', turnStatus:null, updatedAt:null}; }
      }
    }));
    return {threads:rows, fetchedAt:Date.now()};
  }
  async projects() {
    return this._cached('projects', 30000, async () => {
      const seen = new Set(), rows = await this._all('project/list', {});
      const projects = rows.filter(row => text(row?.id) && !seen.has(row.id) && seen.add(row.id)).map(row => {
        const roots = Array.isArray(row.roots) ? row.roots.map(root => text(root?.path)).filter(Boolean) : [];
        return {id:row.id, name:text(row.name) ?? '未命名项目', path:roots[0] ?? null, rootPaths:roots};
      });
      return {projects, source:'shared-engine:project/list', fetchedAt:Date.now()};
    });
  }
  async models() {
    return this._cached('models', 60000, async () => {
      const seen = new Set(), rows = await this._all('model/list', {includeHidden:false});
      const models = rows.filter(row => row && row.hidden !== true && text(row.model) && !seen.has(row.model) && seen.add(row.model)).map(row => {
        const efforts = new Set();
        return {id:row.model, displayName:text(row.displayName) ?? row.model, description:typeof row.description === 'string' ? row.description : '',
          reasoningEfforts:(Array.isArray(row.supportedReasoningEfforts) ? row.supportedReasoningEfforts : []).map(value => typeof value === 'string' ? value : value?.reasoningEffort).filter(value => text(value) && !efforts.has(value) && efforts.add(value)).map(value => ({value, label:value})),
          defaultReasoningEffort:text(row.defaultReasoningEffort), isDefault:row.isDefault === true};
      });
      if (!models.length) throw error('MODELS_UNAVAILABLE', '当前共享引擎未返回可用模型。');
      return {models, source:'shared-engine:model/list', fetchedAt:Date.now(), stale:false, capabilities:{canOverrideModel:true, canOverrideThinking:models.some(model => model.reasoningEfforts.length > 0), canSetSpeed:false}};
    });
  }
  async usage() { return this._cached('usage', 10000, async () => usageResult(await this.request('account/rateLimits/read', {}))); }
  execute(operation, args = {}) {
    if (!['threads', 'statuses', 'projects', 'models', 'usage'].includes(operation)) throw error('BAD_INPUT', '不支持的共享目录操作。');
    return this[operation](args);
  }
}
module.exports = {SharedCatalog};
