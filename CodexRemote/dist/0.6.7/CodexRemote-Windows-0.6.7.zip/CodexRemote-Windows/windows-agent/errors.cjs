'use strict';
class BridgeError extends Error {
  constructor(code, message) { super(message); this.code = code; }
}
module.exports = {BridgeError};
