﻿param([Parameter(Mandatory=$true)][int]$ProcessId,[Parameter(Mandatory=$true)][string]$AgentPath)
$ErrorActionPreference='Stop'
$p=Get-CimInstance Win32_Process -Filter "ProcessId = $ProcessId"
if($p -and $p.Name -eq 'node.exe' -and $p.CommandLine -like "*$AgentPath*" -and $p.CommandLine -like '*agent-config.json*'){
 Stop-Process -Id $p.ProcessId -ErrorAction Stop
 'stopped'
}else{'not-owned'}
