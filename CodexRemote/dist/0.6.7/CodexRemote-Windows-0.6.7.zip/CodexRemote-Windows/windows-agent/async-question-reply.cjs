'use strict';
const {collectTurns,active}=require('./desktop-ipc-state.cjs');
const {questionReplies}=require('./desktop-ipc-mapping.cjs');
const fault=code=>Object.assign(Error(code),{code});

// 只接收桌面原生问题封套；普通消息不获得运行中补充能力。
function parseReply(prompt){
 if(typeof prompt!=='string'||!prompt.trimStart().startsWith('<send_user_message_question_reply>'))return null;
 const match=/^\s*<send_user_message_question_reply>\s*([\s\S]*?)\s*<\/send_user_message_question_reply>\s*$/.exec(prompt);
 if(!match||prompt.length>16000)throw fault('INVALID_ANSWERS');
 let entries;try{entries=JSON.parse(match[1]);}catch{throw fault('INVALID_ANSWERS');}
 if(!Array.isArray(entries)||!entries.length||entries.length>8)throw fault('INVALID_ANSWERS');
 const indexes=new Set();let callId;
 for(const entry of entries){
  if(!entry||typeof entry!=='object'||Array.isArray(entry)||Object.keys(entry).some(k=>!['questionItemId','question','answer','skipped'].includes(k))
    ||typeof entry.question!=='string'||typeof entry.answer!=='string'||entry.answer.length>4000
    ||entry.skipped!==undefined&&typeof entry.skipped!=='boolean')throw fault('INVALID_ANSWERS');
  let identity;try{identity=JSON.parse(entry.questionItemId);}catch{throw fault('INVALID_ANSWERS');}
  if(!Array.isArray(identity)||identity.length!==3||identity[0]!=='request_user_input_async'||typeof identity[1]!=='string'
    ||!identity[1]||identity[1].length>512||!Number.isSafeInteger(identity[2])||identity[2]<0||identity[2]>7
    ||indexes.has(identity[2])||callId&&callId!==identity[1]||entry.skipped===true&&entry.answer!=='')throw fault('INVALID_ANSWERS');
  callId=identity[1];indexes.add(identity[2]);
 }
 return {callId,entries};
}

function validateReply(raw,reply){
 const turns=collectTurns(raw),turn=turns.at(-1);
 if(!turn?.turnId||!active(turn.status))throw fault('QUESTION_EXPIRED');
 const item=turn.items.find(i=>i?.id===reply.callId&&i.type==='agentMessage'&&i.delivery==='async');
 const questions=item?.questions;
 if(!Array.isArray(questions)||!questions.length||questions.length>8)throw fault('QUESTION_EXPIRED');
 const previous=questionReplies(turns).get(reply.callId);
 for(const entry of reply.entries){
  const index=JSON.parse(entry.questionItemId)[2],question=questions[index];
  if(previous?.has(index))throw fault('QUESTION_ALREADY_ANSWERED');
  const prompt=typeof question?.question==='string'&&question.question?question.question:question?.title;
  if(!question||question.isSecret===true||question.secret===true||typeof prompt!=='string'
    ||entry.question!==prompt||!entry.answer.trim()||entry.skipped===true)throw fault('INVALID_ANSWERS');
 }
 return {turnId:turn.turnId,callId:reply.callId};
}
module.exports={parseReply,validateReply};
