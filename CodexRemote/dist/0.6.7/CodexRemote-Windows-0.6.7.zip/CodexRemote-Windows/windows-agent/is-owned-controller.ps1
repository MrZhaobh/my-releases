﻿param([Parameter(Mandatory=$true)][int]$ProcessId,[Parameter(Mandatory=$true)][string]$ControllerPath)
$ErrorActionPreference='Stop'
$p=Get-CimInstance Win32_Process -Filter "ProcessId = $ProcessId"
if($p -and $p.Name -eq 'node.exe' -and $p.CommandLine -like "*$ControllerPath*" -and $p.CommandLine -like '* daemon*'){'owned'}else{'not-owned'}
