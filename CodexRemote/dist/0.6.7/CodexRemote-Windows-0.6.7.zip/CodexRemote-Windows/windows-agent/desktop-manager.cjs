'use strict';
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const childProcess = require('node:child_process');
const {promisify} = require('node:util');
const {FIELDS:ISOLATED_FIELDS,readIsolatedInstance}=require('../prototypes/shared-engine-v1/isolated-instance.cjs');
const execute = promisify(childProcess.execFile);
const RECORD_KEYS = new Set(['id','kind','name','sourcePath','desktopExecutable','sharedSupported']);
const PHASES = new Set(['idle','starting','needs_exit','failed','started','awaiting_connection']);
const STAGES = new Set(['queued','checking_desktop','checking_previous_engine','starting_broker','waiting_broker','starting_desktop','desktop_started','broker_ready','awaiting_connection','needs_desktop_exit','needs_engine_exit','failed']);
const fail = code => Object.assign(new Error(code), {code});
const safePath = value => typeof value === 'string' && value.length < 4096 && !/["\x00-\x1f\x7f]/.test(value) && (path.isAbsolute(value) || path.win32.isAbsolute(value));
// 只接受同一官方包目录的版本变化；其他入口变化仍须重新选择。
function packageUpgrade(previous, current) {
  const parse=value=>typeof value==='string'?value.replaceAll('/','\\').match(/^(.*\\WindowsApps\\OpenAI\.Codex_)(\d+\.\d+\.\d+\.\d+)(_x64__2p2nqsd0c76g0\\app\\ChatGPT\.exe)$/i):null;
  const a=parse(previous),b=parse(current);
  if(!a||!b||a[1].toLowerCase()!==b[1].toLowerCase()||a[3].toLowerCase()!==b[3].toLowerCase())return false;
  const before=a[2].split('.').map(Number),after=b[2].split('.').map(Number);
  for(let i=0;i<before.length;i++)if(before[i]!==after[i])return after[i]>before[i];
  return false;
}
function validateInstanceRecord(value) {
  if (!value || Array.isArray(value) || typeof value !== 'object' || Object.keys(value).some(key => !RECORD_KEYS.has(key)) ||
      !['official','sidebar-lite'].includes(value.kind) || typeof value.id !== 'string' || !/^[a-f0-9]{24}$/.test(value.id) || !safePath(value.sourcePath)) throw fail('DESKTOP_SELECTION_INVALID');
  if (value.desktopExecutable !== undefined && !safePath(value.desktopExecutable)) throw fail('DESKTOP_SELECTION_INVALID');
  return Object.fromEntries(Object.entries(value).filter(([key]) => RECORD_KEYS.has(key)));
}
function publicInstance(value) {
  if (!value || !['official','sidebar-lite'].includes(value.kind) || !safePath(value.sourcePath) || !safePath(value.desktopExecutable)) throw fail('DESKTOP_PLATFORM_INVALID');
  if(value.instanceConfigPath!==undefined && (value.kind!=='sidebar-lite'||!ISOLATED_FIELDS.every(key=>typeof value[key]==='string')||!['instanceConfigPath','instanceConfigModulePath','isolatedCodexHome','enhancedRuntimeDirectory','enhancedProfileDirectory','enhancedLauncher'].every(key=>safePath(value[key]))||!['instanceConfigFingerprint','instanceConfigModuleFingerprint'].every(key=>/^[a-f0-9]{64}$/i.test(value[key]))||!/^CODEX_[A-Z0-9_]+_API_KEY$/.test(value.apiKeyEnvironmentVariable)||value.apiKeyEnvironmentVariable.length>128))throw fail('DESKTOP_PLATFORM_INVALID');
  const identity=[value.kind, value.sourcePath.toLowerCase(), value.launcherFingerprint ?? '', value.scriptFingerprint ?? ''];
  if(value.instanceConfigPath)identity.push(value.instanceConfigPath.toLowerCase(),value.enhancedLauncher.toLowerCase(),value.instanceConfigFingerprint??'',value.instanceConfigModuleFingerprint??'');
  const id = crypto.createHash('sha256').update(identity.join('\0')).digest('hex').slice(0,24);
  let name='官方 Codex';
  if(value.kind==='sidebar-lite'){
    const file=path.win32.basename(value.sourcePath),stem=path.win32.basename(file,path.win32.extname(file));
    const generic=/^(?:codex|(?:codex\s*)?增强版|launchcodex)$/i.test(stem);
    const directory=safePath(value.enhancedLauncher)?path.win32.basename(path.win32.dirname(value.enhancedLauncher)):'';
    name=value.instanceConfigPath?'Codex · '+path.win32.basename(path.win32.dirname(value.instanceConfigPath)):(generic?'Codex · '+(directory||id.slice(0,6)):stem);
    name=name.slice(0,100);
  }
  return {id,kind:value.kind,name,sourcePath:value.sourcePath,desktopExecutable:value.desktopExecutable,sharedSupported:value.sharedSupported === true};
}
function inside(root, target) {
  const relative = path.relative(root,target);
  return !!relative && !relative.startsWith('..') && !path.isAbsolute(relative);
}
function atomic(file, value) {
  const tmp = file + '.' + crypto.randomBytes(6).toString('hex') + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(value,null,2), {encoding:'utf8',mode:0o600,flag:'wx'});
  fs.renameSync(tmp,file);
}
function readJson(file) { return JSON.parse(fs.readFileSync(file,'utf8').replace(/^\uFEFF/,'')); }
function safeStatus(value) {
  const result = {phase:PHASES.has(value?.phase)?value.phase:'idle',stage:STAGES.has(value?.stage)?value.stage:'queued',error:null,instanceId:null,runtimeMode:null};
  if (/^DESKTOP_[A-Z_]{1,80}$/.test(value?.error ?? '')) result.error=value.error;
  if (/^[a-f0-9]{24}$/.test(value?.instanceId ?? '')) result.instanceId=value.instanceId;
  if (['desktop-bridge','shared-engine'].includes(value?.runtimeMode)) result.runtimeMode=value.runtimeMode;
  result.brokerReady=value?.brokerReady === true;
  // 启动回执只证明进程启动；没有桌面身份对应的协议证据时永不宣称接入完成。
  result.transportConfirmed=false;
  if (Number.isInteger(value?.desktopPid) && value.desktopPid>0) result.desktopPid=value.desktopPid;
  return result;
}
function createDesktopManager({dataDir,getSettings=()=>({}),platform,spawn=childProcess.spawn,schedule=setImmediate,socketDirectory,materializeBinary}={}) {
  if (!safePath(dataDir)) throw fail('DESKTOP_DATA_DIRECTORY_INVALID');
  const root=path.join(path.resolve(dataDir),'desktop-launch');
  const runtimeRoot=path.resolve(__dirname,'../prototypes/shared-engine-v1');
  const powershell=path.join(process.env.SystemRoot || 'C:\\Windows','System32','WindowsPowerShell','v1.0','powershell.exe');
  let current=safeStatus(null),active=null;
  const instanceHints=new Map();
  const runPlatform=platform ?? (async(action,value,launcherHint)=>{
    const env={...process.env};for(const key of Object.keys(env))if(key.toLowerCase()==='psmodulepath')delete env[key];
    try{
      if(launcherHint&&!safePath(launcherHint))throw fail('DESKTOP_SELECTION_CHANGED');
      const {stdout}=await execute(powershell,['-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',path.join(__dirname,'desktop-platform.ps1'),'-Action',action,...(value?['-Value',value]:[]),...(launcherHint?['-LauncherHint',launcherHint]:[])],{windowsHide:true,encoding:'utf8',timeout:action==='detect'?30000:15000,maxBuffer:128*1024,env});
      const parsedValue=JSON.parse(stdout.replace(/^\uFEFF/,''));if(parsedValue?.error)throw fail(parsedValue.error);return parsedValue;
    }catch(error){
      if(action==='detect'&&error.killed)throw fail('DESKTOP_DETECTION_TIMEOUT');
      if(/^DESKTOP_[A-Z_]+$/.test(error.code??''))throw error;
      try {const parsed=JSON.parse(String(error.stdout??'').replace(/^\uFEFF/,''));if(/^DESKTOP_[A-Z_]+$/.test(parsed.error))throw fail(parsed.error);}catch(parsed){if(parsed.code?.startsWith('DESKTOP_'))throw parsed;}
      throw fail('DESKTOP_PLATFORM_FAILED');
    }
  });
  async function secure(directory,action='secure'){fs.mkdirSync(directory,{recursive:true});await runPlatform(action,directory);}
  async function fileHash(file){
    const hash=crypto.createHash('sha256');
    for await(const bytes of fs.createReadStream(file))hash.update(bytes);
    return hash.digest('hex');
  }
  async function prepareRuntimeBinary(binary){
    // WindowsApps 中的包内CLI可能拒绝外部CreateProcess；仅复制平台已验证的官方文件。
    if(!/[/\\]WindowsApps[/\\]OpenAI\.Codex_[^/\\]+[/\\]app[/\\]resources[/\\]codex\.exe$/i.test(binary))return binary;
    let temporary;
    try{
      const source=path.dirname(binary),names=['codex.exe','codex-code-mode-host.exe','codex-command-runner.exe','codex-windows-sandbox-service.exe','codex-windows-sandbox-setup.exe'];
      const files=[];
      for(const name of names)if(name==='codex.exe'||fs.existsSync(path.join(source,name)))files.push({name,hash:await fileHash(path.join(source,name))});
      const digest=crypto.createHash('sha256').update(JSON.stringify(files)).digest('hex'),directory=path.join(root,'cli',digest);
      await secure(path.join(root,'cli'));
      if(!fs.existsSync(directory)){
        temporary=directory+'.tmp-'+crypto.randomBytes(6).toString('hex');await secure(temporary);
        for(const file of files){const target=path.join(temporary,file.name);await fs.promises.copyFile(path.join(source,file.name),target,fs.constants.COPYFILE_EXCL);if(await fileHash(target)!==file.hash)throw fail('DESKTOP_CLI_PREPARE_FAILED');}
        try{fs.renameSync(temporary,directory);}catch(error){if(!fs.existsSync(directory))throw error;}
      }
      for(const file of files)if(await fileHash(path.join(directory,file.name))!==file.hash)throw fail('DESKTOP_CLI_PREPARE_FAILED');
      return path.join(directory,'codex.exe');
    }catch{throw fail('DESKTOP_CLI_PREPARE_FAILED');}
    finally{
      const cliRoot=path.resolve(root,'cli');
      if(temporary&&path.dirname(path.resolve(temporary))===cliRoot&&/^[a-f0-9]{64}\.tmp-[a-f0-9]{12}$/.test(path.basename(temporary)))await fs.promises.rm(temporary,{recursive:true,force:true});
    }
  }
  async function discover(){
    const result=await runPlatform('detect');
    if(!Array.isArray(result?.instances)||result.instances.length>16)throw fail('DESKTOP_PLATFORM_INVALID');
    const seen=new Set(),instances=result.instances.map(publicInstance).filter(row=>!seen.has(row.id)&&seen.add(row.id));
    for(const details of result.instances)if(details.instanceConfigPath&&safePath(details.enhancedLauncher)){instanceHints.set(publicInstance(details).id,details.enhancedLauncher);while(instanceHints.size>32)instanceHints.delete(instanceHints.keys().next().value);}
    const running=[];
    for(const row of Array.isArray(result.running)?result.running.slice(0,32):[]){
      if(!Number.isSafeInteger(row?.pid)||row.pid<=0||typeof row.profileDirectory!=='string'||row.profileDirectory.length>4096||/[\x00-\x1f\x7f]/.test(row.profileDirectory))continue;
      const instance=typeof row.instanceSourcePath==='string'?instances.find(value=>value.sourcePath.toLowerCase()===row.instanceSourcePath.toLowerCase()):null;
      running.push({pid:row.pid,instanceId:row.reason==='matched'&&instance?instance.id:null,profileDirectory:row.profileDirectory,reason:row.reason==='matched'&&instance?'matched':'shortcut_required'});
    }
    return {instances,running,processScanFailed:result.processScanFailed===true};
  }
  async function importShortcut(shortcutPath){
    if(!safePath(shortcutPath)||path.extname(shortcutPath).toLowerCase()!=='.lnk')throw fail('DESKTOP_SHORTCUT_INVALID');
    const result=await runPlatform('import',shortcutPath);return {instance:publicInstance(result.instance)};
  }
  async function resolveSelection(record,configurationHint,{runtimeMode='shared-engine'}={}){
    const selected=validateInstanceRecord(record);
    let launcherHint=instanceHints.get(selected.id);
    if(configurationHint){
      try{const {config}=privateConfig(configurationHint);if(config.instanceConfigPath?.toLowerCase()===selected.sourcePath.toLowerCase()&&safePath(config.enhancedLauncher)){existingConfig(configurationHint);launcherHint=config.enhancedLauncher;}}
      catch{throw fail('DESKTOP_SHARED_CONFIG_INVALID');}
    }
    let candidate;
    if(selected.kind==='official'){
      const found=await runPlatform('detect');candidate=found.instances?.find(row=>row.kind==='official');
    }else candidate=(await runPlatform(['.vbs','.json'].includes(path.extname(selected.sourcePath).toLowerCase())?'resolve':'import',selected.sourcePath,launcherHint)).instance;
    const instance=publicInstance(candidate);
    const officialUpgrade=selected.kind==='official'&&instance.kind==='official'&&selected.sourcePath===selected.desktopExecutable&&packageUpgrade(selected.desktopExecutable,instance.desktopExecutable)&&publicInstance({...candidate,sourcePath:selected.sourcePath}).id===selected.id;
    if(!officialUpgrade&&(instance.id!==selected.id || instance.kind!==selected.kind || instance.sourcePath.toLowerCase()!==selected.sourcePath.toLowerCase()))throw fail('DESKTOP_SELECTION_CHANGED');
    const binary=candidate.sharedSupported&&runtimeMode==='shared-engine'?await (materializeBinary??prepareRuntimeBinary)(candidate.binary):candidate.binary;
    return {instance,details:{...candidate,binary,packagedBinary:candidate.binary}};
  }
  function privateConfig(filename){
    if(!safePath(filename))throw fail('DESKTOP_SHARED_CONFIG_INVALID');
    const resolved=fs.realpathSync(filename);
    const roots=[path.resolve(dataDir),path.resolve(__dirname,'../.local'),path.join(os.homedir(),'.codex'),path.join(process.env.LOCALAPPDATA??path.join(os.homedir(),'AppData','Local'),'CodexRemote')];
    if(!roots.some(candidate=>{try{return inside(fs.realpathSync(candidate),resolved);}catch{return false;}})||!fs.statSync(resolved).isFile()||fs.statSync(resolved).size>65536)throw fail('DESKTOP_SHARED_CONFIG_INVALID');
    return {resolved,config:readJson(resolved)};
  }
  function legacyConnection(config){
    if(!config||Array.isArray(config)||Object.keys(config).length!==2||typeof config.url!=='string'||typeof config.token!=='string')return false;
    try{const url=new URL(config.url);return url.protocol==='ws:'&&url.hostname==='127.0.0.1'&&url.pathname==='/rpc'&&!!url.port&&!url.username&&!url.password&&!url.search&&!url.hash&&/^[A-Za-z0-9_-]{43}$/.test(config.token);}catch{return false;}
  }
  function existingConfig(filename){
    const {resolved,config}=privateConfig(filename),url=new URL(config.url);
    if(config.engineMode!=='owned'||url.protocol!=='ws:'||url.hostname!=='127.0.0.1'||url.pathname!=='/rpc'||!url.port||url.username||url.password||url.search||url.hash||!/^[A-Za-z0-9_-]{43}$/.test(config.token)||!safePath(config.binary)||!safePath(config.socketPath))throw fail('DESKTOP_SHARED_CONFIG_INVALID');
    if(ISOLATED_FIELDS.some(key=>config[key]!==undefined)){try{readIsolatedInstance(config);}catch{throw fail('DESKTOP_SHARED_CONFIG_INVALID');}}
    return resolved;
  }
  function preparedSelection(instance,filename,details){
    if(instance.kind==='sidebar-lite'&&!safePath(details.enhancedProfileDirectory))throw fail('DESKTOP_PLATFORM_INVALID');
    let isolatedCodexHome;
    if(details.instanceConfigPath){try{isolatedCodexHome=readIsolatedInstance(details).codexHome;}catch{throw fail('DESKTOP_ISOLATED_CONFIG_INVALID');}}
    return {instance,sharedEngineConfigFile:filename,...(instance.kind==='sidebar-lite'?{preferredProfile:details.enhancedProfileDirectory}:{}),...(isolatedCodexHome===undefined?{}:{isolatedCodexHome})};
  }
  async function prepareSelection(record,{existingSharedConfigFile,preserveLegacyConnection=false,runtimeMode='shared-engine'}={}){
    const {instance,details}=await resolveSelection(record,existingSharedConfigFile,{runtimeMode});
    if(existingSharedConfigFile){
      let prior;try{prior=privateConfig(existingSharedConfigFile);}catch{throw fail('DESKTOP_SHARED_CONFIG_INVALID');}
      if(legacyConnection(prior.config)){
        if(preserveLegacyConnection)return preparedSelection(instance,existingSharedConfigFile,details);
        throw fail('DESKTOP_LEGACY_CONNECTION_ONLY');
      }
      try{
        const validated=existingConfig(existingSharedConfigFile),config=readJson(validated);
        const upgraded=packageUpgrade(config.desktopExecutable,instance.desktopExecutable);
        const binaryChanged=runtimeMode==='shared-engine'&&config.binary.toLowerCase()!==details.binary.toLowerCase();
        const packagedCopy=binaryChanged&&config.binary.toLowerCase()===details.packagedBinary?.toLowerCase();
        if((config.desktopExecutable.toLowerCase()!==instance.desktopExecutable.toLowerCase()&&!upgraded) ||
           (binaryChanged&&!upgraded&&!packagedCopy) ||
           (config.instanceConfigPath??'').toLowerCase()!==(details.instanceConfigPath??'').toLowerCase() ||
           (config.instanceConfigFingerprint??'')!==(details.instanceConfigFingerprint??'') ||
           (instance.kind==='sidebar-lite' ? config.enhancedLauncher?.toLowerCase()!==details.enhancedLauncher?.toLowerCase() || config.enhancedProfileDirectory?.toLowerCase()!==details.enhancedProfileDirectory?.toLowerCase() : !!config.enhancedLauncher))throw fail('DESKTOP_SHARED_SELECTION_MISMATCH');
        let retired=false;
        try{const prior=readJson(path.join(path.dirname(validated),'broker-status.json'));retired=prior.stopped===true&&prior.engineCleanup?.ok===true;}catch{}
        // 成功退出的旧run仍完整保留；下一次共享启动准备新token、端口与socket。
        // 重建只准备新run；不改旧token、端口、socket，也不停止既有引擎。
        if(!retired&&!upgraded&&!packagedCopy)return preparedSelection(instance,validated,details);
      }catch(error){if(error.code==='DESKTOP_SHARED_SELECTION_MISMATCH')throw error;throw fail('DESKTOP_SHARED_CONFIG_INVALID');}
    }
    if(!instance.sharedSupported)return preparedSelection(instance,'',details);
    if(!safePath(details.binary)||!safePath(details.powerShellExecutable))throw fail('DESKTOP_SHARED_UNSUPPORTED');
    await secure(root);
    const runDirectory=path.join(root,'runs',crypto.randomUUID());await secure(runDirectory);
    // AF_UNIX 地址有104字节上限；短端点与私有配置分离，绝不删除或复用旧socket。
    const socketRoot=socketDirectory??path.join(process.env.LOCALAPPDATA??os.tmpdir(),'CodexRemote','s');
    if(!safePath(socketRoot))throw fail('DESKTOP_SOCKET_PATH_INVALID');await secure(socketRoot,'secureSocket');
    const socketPath=path.join(socketRoot,crypto.randomBytes(8).toString('hex')+'.sock');
    if(Buffer.byteLength(socketPath,'utf8')>=104)throw fail('DESKTOP_SOCKET_PATH_TOO_LONG');
    const port=await new Promise((resolve,reject)=>{const server=require('node:net').createServer();server.once('error',reject);server.listen(0,'127.0.0.1',()=>{const port=server.address().port;server.close(error=>error?reject(error):resolve(port));});});
    const environment=await runPlatform('environment');
    const config={engineMode:'owned',url:`ws://127.0.0.1:${port}/rpc`,token:crypto.randomBytes(32).toString('base64url'),binary:details.binary,socketPath,desktopExecutable:instance.desktopExecutable,originalDesktopEnvironment:{ws:environment.ws??null,forceCli:environment.forceCli??null},appToolsBridge:{enabled:true,mode:'plugin-pipe',nodePath:process.execPath}};
    if(instance.kind==='sidebar-lite'){
      if(!safePath(details.enhancedLauncher)||!safePath(details.enhancedProfileDirectory))throw fail('DESKTOP_ENHANCER_UNSUPPORTED');
      config.enhancedLauncher=details.enhancedLauncher;config.enhancedProfileDirectory=details.enhancedProfileDirectory;config.enhancedPort=await new Promise((resolve,reject)=>{const server=require('node:net').createServer();server.once('error',reject);server.listen(0,'127.0.0.1',()=>{const value=server.address().port;server.close(error=>error?reject(error):resolve(value));});});
      if(details.instanceConfigPath){
        for(const key of ISOLATED_FIELDS)config[key]=details[key];
        try{readIsolatedInstance(config);}catch{throw fail('DESKTOP_ISOLATED_CONFIG_INVALID');}
      }
    }
    const sharedEngineConfigFile=path.join(runDirectory,'config.json');atomic(sharedEngineConfigFile,config);
    return preparedSelection(instance,sharedEngineConfigFile,details);
  }
  async function launch(selection){
    const {instance,details}=await resolveSelection(selection.instance,selection.sharedEngineConfigFile,{runtimeMode:selection.runtimeMode});
    const mode=selection.runtimeMode;
    if(mode==='shared-engine'&&!instance.sharedSupported)throw fail('DESKTOP_SHARED_UNSUPPORTED');
    const configFile=selection.sharedEngineConfigFile?existingConfig(selection.sharedEngineConfigFile):'';
    if(mode==='shared-engine'&&!configFile)throw fail('DESKTOP_SHARED_CONFIG_REQUIRED');
    if(!safePath(details.powerShellExecutable))throw fail('DESKTOP_POWERSHELL_REQUIRED');
    await secure(root);
    const launchId=crypto.randomUUID(),statusFile=path.join(root,'launch-'+launchId+'.json'),requestFile=path.join(root,'request-'+launchId+'.json');
    const request={schema:1,launchId,instanceId:instance.id,runtimeMode:mode,instance:{...instance,...details},sharedEngineConfigFile:configFile,previousSharedConfigFile:getSettings()?.sharedEngineConfigFile??'',statusFile,nodeExecutable:process.execPath,runtimeRoot};
    atomic(requestFile,request);
    const env={...process.env};for(const key of Object.keys(env))if(key.toLowerCase()==='psmodulepath')delete env[key];
    const child=spawn(details.powerShellExecutable,['-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',path.join(__dirname,'desktop-launch.ps1'),'-RequestPath',requestFile],{windowsHide:true,stdio:'ignore',env});
    active={child,statusFile,launchId};
    child.once('error',()=>{if(active?.launchId===launchId){current={...current,phase:'failed',stage:'failed',error:'DESKTOP_HELPER_START_FAILED'};active=null;}});
    child.once('exit',()=>{
      if(active?.launchId!==launchId)return;
      try{const value=readJson(statusFile);if(value.launchId===launchId)current=safeStatus(value);}catch{}
      if(current.phase==='starting')current={...current,phase:'failed',stage:'failed',error:'DESKTOP_HELPER_EXITED'};
      active=null;
    });
  }
  function status(){
    if(active){try{const value=readJson(active.statusFile);if(value.launchId===active.launchId)current=safeStatus(value);}catch{}}
    return {...current};
  }
  function start(selection={}){
    if(current.phase==='starting'||active)throw fail('DESKTOP_LAUNCH_BUSY');
    if(!['desktop-bridge','shared-engine'].includes(selection.runtimeMode))throw fail('DESKTOP_MODE_INVALID');
    const record=validateInstanceRecord(selection.instance);
    current={phase:'starting',stage:'queued',error:null,instanceId:record.id,runtimeMode:selection.runtimeMode,brokerReady:false,transportConfirmed:false};
    schedule(()=>{launch({...selection,instance:record}).catch(error=>{current={...current,phase:'failed',stage:'failed',error:/^DESKTOP_[A-Z_]+$/.test(error.code??'')?error.code:'DESKTOP_LAUNCH_FAILED'};});});
    return {accepted:true,...status()};
  }
  return {discover,importShortcut,prepareSelection,start,status};
}
module.exports={createDesktopManager,validateInstanceRecord,publicInstance,safeStatus};
