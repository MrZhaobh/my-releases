﻿param(
 [Parameter(Mandatory=$true)][string]$LauncherPath,
 [string]$DesktopDirectory=[Environment]::GetFolderPath('DesktopDirectory'),
 [string]$ProgramsDirectory=[Environment]::GetFolderPath('Programs')
)
$ErrorActionPreference='Stop'
$launcher=[IO.Path]::GetFullPath($LauncherPath)
if(-not (Test-Path -LiteralPath $launcher -PathType Leaf)){throw '找不到 Codex Remote 控制面板入口。'}
$root=[IO.Path]::GetDirectoryName($launcher)
$icon=Join-Path $root 'windows-agent/app.ico'
$shell=$null
$failures=@()
try{
 $shell=New-Object -ComObject WScript.Shell
 foreach($directory in @($DesktopDirectory,$ProgramsDirectory)){
  $shortcut=$null
  try{
   if([string]::IsNullOrWhiteSpace($directory)){throw '快捷方式目标目录不能为空。'}
   [IO.Directory]::CreateDirectory([IO.Path]::GetFullPath($directory))|Out-Null
   $shortcut=$shell.CreateShortcut((Join-Path $directory 'Codex Remote.lnk'))
   $shortcut.TargetPath=$launcher
   $shortcut.Arguments=''
   $shortcut.WorkingDirectory=$root
   $shortcut.IconLocation=$icon+',0'
   $shortcut.Description='打开 Codex Remote 控制面板'
   $shortcut.Save()
  }catch{$failures+=$directory}finally{if($shortcut){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($shortcut)}}
 }
}finally{if($shell){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($shell)}}
if($failures.Count){throw '部分快捷方式目录不可写，未能建立全部入口。'}
