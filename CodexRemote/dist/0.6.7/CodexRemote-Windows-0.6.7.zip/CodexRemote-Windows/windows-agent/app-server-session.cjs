'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const childProcess = require('node:child_process');
const {BridgeError} = require('./errors.cjs');

const MODEL = 'gpt-6-luna';
const MAX_TEXT = 24000, MAX_LINE = 16 * 1024 * 1024, MAX_REQUESTS = 10000;
const failure = (message, code, statusCode = 500) => Object.assign(new BridgeError(code, message), {statusCode});
const bounded = value => String(value ?? '').slice(0, MAX_TEXT);
const statusOf = value => ({completed:'completed', interrupted:'cancelled', failed:'failed', inProgress:'running'})[value] ?? 'unknown';

function resolveBinary() {
  if (process.env.CODEX_BINARY) return process.env.CODEX_BINARY;
  const platform = process.platform === 'win32' ? 'codex-win32-x64' : process.platform === 'darwin' ? `codex-darwin-${process.arch}` : `codex-linux-${process.arch}`;
  const triple = process.platform === 'win32' ? 'x86_64-pc-windows-msvc' : process.platform === 'darwin' ? `${process.arch === 'arm64' ? 'aarch64' : 'x86_64'}-apple-darwin` : `${process.arch === 'arm64' ? 'aarch64' : 'x86_64'}-unknown-linux-musl`;
  for (const directory of (process.env.PATH ?? '').split(path.delimiter).filter(Boolean)) {
    const exe = path.join(directory, process.platform === 'win32' ? 'codex.exe' : 'codex');
    // Windows npm 安装的入口是 cmd；优先其相邻的原生二进制，避免 shell 包装进程。
    const packageRoot = path.join(directory, 'node_modules', '@openai', 'codex');
    const candidates = [path.join(packageRoot, 'node_modules', '@openai', platform, 'vendor', triple, 'bin', process.platform === 'win32' ? 'codex.exe' : 'codex'), path.join(packageRoot, 'vendor', triple, 'codex', process.platform === 'win32' ? 'codex.exe' : 'codex'), exe];
    for (const candidate of candidates) if (fs.existsSync(candidate)) return candidate;
  }
  throw failure('未找到 Codex 原生程序，请设置 CODEX_BINARY。', 'BINARY_NOT_FOUND');
}

class AppServerSession {
  constructor({onSnapshot, stateDir, binary, spawn, model = MODEL, cwd, sandbox = 'read-only', threadId, controlOnly = false} = {}) {
    if (!['read-only', 'workspace-write', 'danger-full-access'].includes(sandbox)) throw failure('运行沙箱配置无效。', 'BAD_INPUT', 400);
    if (!stateDir) throw failure('必须配置自管会话目录。', 'BAD_INPUT', 400);
    this.stateDir = stateDir;
    this.workDir = cwd ?? path.join(this.stateDir, 'workspace');
    this.model = model; this.sandbox = sandbox; this.controlOnly = controlOnly;
    fs.mkdirSync(this.stateDir, {recursive:true});
    fs.mkdirSync(this.workDir, {recursive:true});
    this.onSnapshot = onSnapshot; this.binary = binary; this.spawn = spawn ?? childProcess.spawn;
    this.pending = new Map(); this.requests = new Map(); this.seq = 0; this.child = null; this.initializing = null;
    this.writerThreads = new Set();
    this.activeTurn = null; this.sending = false; this.closed = false; this.closePromise = null;
    this.snapshot = {source:'app-server', model, status:'unknown', connection:'disconnected', turns:[], receivedAt:Date.now(), ...(threadId ? {threadId} : {})};
    try {
      const saved = JSON.parse(fs.readFileSync(path.join(this.stateDir, 'state.json'), 'utf8'));
      if (saved.snapshot && Array.isArray(saved.snapshot.turns)) this.snapshot = {...saved.snapshot, connection:'disconnected'};
      if (typeof saved.threadId === 'string') this.snapshot.threadId = saved.threadId;
      this.threadCreationUnknown = saved.threadCreationUnknown === true;
      for (const id of saved.writerThreads ?? []) if (typeof id === 'string' && id.length > 0 && id.length <= 200) this.writerThreads.add(id);
      if (this.snapshot.status === 'running' || this.snapshot.status === 'waiting') { this.snapshot.status = 'unknown'; for (const turn of this.snapshot.turns) if (turn.status === 'running') turn.status = 'unknown'; }
      for (const entry of (saved.requests ?? [])) {
        if (typeof entry.id === 'string' && (entry.result || entry.unknown)) this.requests.set(entry.id, {hash:entry.hash, result:entry.result, unknown:entry.unknown, baseline:entry.baseline ? new Set(entry.baseline) : undefined, ...(entry.result ? {promise:Promise.resolve(entry.result)} : {})});
      }
      this.deliveryUnknown = [...this.requests.values()].some(entry => entry.unknown && !entry.result);
    } catch (error) { if (error.code !== 'ENOENT') throw failure('自管会话状态不可读，已阻止创建替代会话。', 'STATE_CORRUPT', 503); }
  }

  getSnapshot() { return structuredClone(this.snapshot); }

  async connect() {
    await this._initialize();
    return {connected:true, threadId:this.snapshot.threadId, model:this.model};
  }

  _publish() {
    // 全历史留在所属私有目录，分页由 Runtime 完成；不可截断后伪装完整历史。
    this.snapshot.receivedAt = Date.now();
    try { this.onSnapshot?.(this.getSnapshot()); } catch { /* 订阅者错误不能中断协议读取。 */ }
  }

  _persist() {
    const requests = [...this.requests].filter(([, value]) => value.result || value.unknown).map(([id, value]) => ({id, hash:value.hash, result:value.result, unknown:value.unknown, ...(value.baseline ? {baseline:[...value.baseline]} : {})}));
    const file = path.join(this.stateDir, 'state.json');
    fs.writeFileSync(file + '.tmp', JSON.stringify({threadId:this.snapshot.threadId, snapshot:this.snapshot, threadCreationUnknown:!!this.threadCreationUnknown, writerThreads:[...this.writerThreads], requests}));
    fs.renameSync(file + '.tmp', file);
  }

  _log(event) {
    // 仅记录协议元信息，正文与登录材料不写入日志；单文件最大约 1 MiB。
    try {
      const file = path.join(this.stateDir, 'events.ndjson');
      if (fs.existsSync(file) && fs.statSync(file).size > 1024 * 1024) fs.renameSync(file, file + '.previous');
      fs.appendFileSync(file, JSON.stringify({at:Date.now(), ...event, ...(event.method ? {method:String(event.method).slice(0, 200)} : {})}) + '\n');
    } catch { /* 日志写入失败不影响正文流。 */ }
  }

  _write(message) {
    if (!this.child || this.child.exited || !this.child.proc.stdin.writable) throw failure('独立 Codex 连接已关闭。', 'DISCONNECTED', 503);
    this.child.proc.stdin.write(JSON.stringify(message) + '\n');
  }

  _rpc(method, params = {}, timeout = 45000) {
    return new Promise((resolve, reject) => {
      const id = ++this.seq;
      const timer = setTimeout(() => { this.pending.delete(id); reject(failure(`Codex 请求超时：${method}`, 'RPC_TIMEOUT', 504)); }, timeout);
      this.pending.set(id, {resolve, reject, timer});
      try { this._write({id, method, params}); } catch (error) { clearTimeout(timer); this.pending.delete(id); reject(error); }
    });
  }

  async _initialize() {
    if (this.closed) throw failure('会话管理器已关闭。', 'CLOSED', 503);
    if (this.child && !this.child.exited && this.ready) return;
    if (this.initializing) return this.initializing;
    const operation = this._start();
    this.initializing = operation;
    try { await operation; } finally { if (this.initializing === operation) this.initializing = null; }
  }

  async _start() {
    if (this.threadCreationUnknown && !this.snapshot.threadId) throw failure('上次创建的接受结果未知；为避免重复创建，需核对自管会话记录。', 'DELIVERY_UNKNOWN', 409);
    const proc = this.spawn(this.binary ?? resolveBinary(), ['app-server', '--listen', 'stdio://'], {cwd:this.workDir, windowsHide:true, stdio:['pipe', 'pipe', 'pipe']});
    const child = {proc, exited:false, buffer:''}; this.child = child; this.ready = false;
    child.exitPromise = new Promise(resolve => { child.resolveExit = resolve; });
    const ended = error => {
      if (child.exited) return;
      child.exited = true; child.resolveExit();
      if (this.child !== child) return;
      this.ready = false;
      for (const pending of this.pending.values()) { clearTimeout(pending.timer); pending.reject(failure('独立 Codex 进程已退出。', 'DISCONNECTED', 503)); }
      this.pending.clear();
      if (!this.closed && !this.hibernating) {
        this.snapshot.connection = 'retrying';
        if (this.snapshot.status === 'running' || this.snapshot.status === 'waiting') {
          this.snapshot.status = 'unknown';
          const active = this.snapshot.turns.find(turn => turn.id === this.activeTurn);
          if (active) active.status = 'unknown';
        }
        this.activeTurn = null; this.deliveryUnknown = false;
        this.snapshot.notice = error ? `独立进程启动失败：${error.message}` : '独立进程已退出；回合结果未知，下次发送前尝试恢复。'; this._publish();
        try { this._persist(); } catch { this.snapshot.notice = '进程退出后保存状态失败；请检查私有目录磁盘。'; }
      }
    };
    proc.on('close', () => ended()); proc.on('error', error => { if (!proc.pid) ended(error); else { this.snapshot.notice = error.message; this._publish(); } });
    proc.stdout.setEncoding('utf8');
    proc.stdout.on('data', chunk => {
      if (child !== this.child || child.exited) return;
      child.buffer += chunk;
      if (child.buffer.length > MAX_LINE && !child.buffer.includes('\n')) { this.snapshot.notice = '协议单行超过上限，已停止独立进程。'; this._publish(); proc.kill(); return; }
      let newline;
      while ((newline = child.buffer.indexOf('\n')) !== -1) {
        const line = child.buffer.slice(0, newline); child.buffer = child.buffer.slice(newline + 1);
        if (line.length > MAX_LINE) { proc.kill(); break; }
        let message; try { message = JSON.parse(line); } catch { this._log({event:'invalid-json'}); continue; }
        this._message(message);
      }
    });
    proc.stderr.on('data', () => this._log({event:'stderr-output'}));
    proc.stdin.on('error', () => {
      this._log({event:'stdin-error'});
      if (child.exited || child !== this.child) return;
      this.snapshot.connection = 'retrying'; this.snapshot.notice = '独立 Codex 输入管道已断开，正在停止其子进程。'; this._publish();
      for (const pending of this.pending.values()) { clearTimeout(pending.timer); pending.reject(failure('独立 Codex 输入管道已断开。', 'DISCONNECTED', 503)); }
      this.pending.clear(); proc.kill();
    });
    try {
      await this._rpc('initialize', {clientInfo:{name:'codex_remote', title:'Codex Remote', version:'1.0.0'}, capabilities:{experimentalApi:true}});
      this._write({method:'initialized', params:{}});
      if (this.controlOnly) { this.ready = true; this.snapshot.connection = 'connected'; return; }
      let cursor = null, found = false, pages = 0;
      do {
        const models = await this._rpc('model/list', {includeHidden:true, ...(cursor ? {cursor} : {})});
        found ||= (models.data ?? []).some(model => model.model === this.model || model.id === this.model);
        cursor = models.nextCursor;
      } while (!found && cursor && ++pages < 20);
      if (!found) throw failure(`当前 Codex 模型目录没有 ${this.model}。`, 'MODEL_UNAVAILABLE', 503);
      const parameters = {model:this.model, cwd:this.workDir, sandbox:this.sandbox, approvalPolicy:'never'};
      const existing = this.snapshot.threadId;
      if (!existing) { this.threadCreationUnknown = true; this._persist(); }
      const response = await this._rpc(existing ? 'thread/resume' : 'thread/start', existing ? {...parameters, threadId:existing} : {...parameters, ephemeral:false}, 60000);
      if (typeof response.thread?.id === 'string' && (!existing || response.thread.id === existing)) this.writerThreads.add(response.thread.id);
      if (response.model && response.model !== this.model) throw failure('Codex 返回的模型与请求不一致。', 'MODEL_MISMATCH', 503);
      if (!response.thread?.id || (existing && response.thread.id !== existing)) throw failure('Codex 会话标识不一致。', 'INVALID_THREAD', 502);
      this.snapshot.threadId = response.thread.id;
      this.threadCreationUnknown = false;
      // resume 返回已保存的完整 turns；部分协议响应缺少 turns 时不丢弃缓存。
      if (Array.isArray(response.thread.turns)) this.snapshot.turns = response.thread.turns.map(turn => ({id:turn.id, status:statusOf(turn.status), items:(turn.items ?? []).map(item => this._normalize(item)).filter(Boolean)}));
      const latest = this.snapshot.turns.at(-1);
      this.activeTurn = latest?.status === 'running' ? latest.id : null;
      for (const entry of this.requests.values()) if (entry.unknown && !entry.result && entry.baseline) {
        const novel = this.snapshot.turns.filter(turn => !entry.baseline.has(turn.id));
        if (novel.length === 1) { entry.unknown = false; entry.result = {threadId:this.snapshot.threadId, turnId:novel[0].id, accepted:true}; entry.promise = Promise.resolve(entry.result); }
      }
      this.deliveryUnknown = [...this.requests.values()].some(entry => entry.unknown && !entry.result);
      this.snapshot.status = latest?.status ?? 'unknown'; this.snapshot.connection = 'connected';
      delete this.snapshot.notice; this.ready = true; this._persist(); this._publish();
    } catch (error) {
      this.snapshot.notice = error.message; this.snapshot.connection = 'retrying'; this._publish();
      if (!this.snapshot.threadId && error.code === 'RPC_ERROR') { this.threadCreationUnknown = false; this._persist(); }
      // 保留 child 直到观察到 close；不能因初始化失败丢失进程所有权。
      await this._stopChild(child); throw error;
    }
  }

  _normalize(item) {
    if (!item || typeof item.id !== 'string' || !item.id || /reasoning/i.test(item.type ?? '')) return null;
    const normalized = {id:String(item.id), type:String(item.type ?? 'unknown'), role:'tool', text:''};
    if (item.type === 'agentMessage') Object.assign(normalized, {role:'assistant', text:String(item.text ?? ''), phase:['commentary','partial_answer','final_answer'].includes(item.phase) ? item.phase : null});
    else if (item.type === 'userMessage') Object.assign(normalized, {role:'user', text:(item.content ?? []).filter(part => part.type === 'text').map(part => part.text).join('\n'), phase:null});
    else if (item.type === 'commandExecution') Object.assign(normalized, {text:String(item.aggregatedOutput ?? ''), command:String(item.command ?? ''), exitCode:item.exitCode ?? null, status:item.status, phase:null});
    else Object.assign(normalized, {text:typeof (item.text ?? item.output ?? item.result) === 'string' ? (item.text ?? item.output ?? item.result) : String(item.type ?? '工具执行'), status:item.status, phase:null});
    return normalized;
  }

  _turn(id) {
    let turn = this.snapshot.turns.find(entry => entry.id === id);
    if (!turn) { turn = {id, status:'running', items:[]}; this.snapshot.turns.push(turn); }
    return turn;
  }

  _message(message) {
    if (!message || typeof message !== 'object' || Array.isArray(message)) { this._log({event:'invalid-message'}); return; }
    if (message.id != null && !message.method) {
      const pending = this.pending.get(message.id);
      if (pending) { clearTimeout(pending.timer); this.pending.delete(message.id); message.error ? pending.reject(failure(bounded(message.error.message ?? 'Codex RPC 失败'), 'RPC_ERROR', 502)) : pending.resolve(message.result); }
      return;
    }
    this._log({method:message.method, request:message.id != null});
    const p = message.params ?? {};
    if (message.id != null && message.method) {
      const approval = ['item/commandExecution/requestApproval', 'item/fileChange/requestApproval'].includes(message.method);
      try {
        this._write(approval ? {id:message.id, result:{decision:'decline'}} : {id:message.id, error:{code:-32601, message:'This isolated prototype does not support interactive requests'}});
        this.snapshot.notice = `当前客户端不支持交互请求 ${String(message.method).slice(0, 200)}，已${approval ? '拒绝审批' : '返回协议错误'}。`;
      } catch { this.snapshot.notice = '交互请求未能送出拒绝响应：独立连接已关闭。'; }
      this._publish(); return;
    }
    if (!this.snapshot.threadId || p.threadId !== this.snapshot.threadId) return;
    const turnId = p.turn?.id ?? p.turnId;
    if (!turnId) return;
    const existingTurn = this.snapshot.turns.find(turn => turn.id === turnId);
    if (existingTurn && ['completed', 'cancelled', 'failed'].includes(existingTurn.status) && message.method !== 'turn/completed') return;
    if (this.activeTurn && turnId !== this.activeTurn) return;
    // turn/start 结果未知时，旧回合的迟到通知不能替新请求解除闸门。
    if (!this.activeTurn && this.pendingDeliveryBaseline?.has(turnId) && (this.sending || this.deliveryUnknown)) return;
    if (message.method === 'turn/started') {
      this.activeTurn = turnId; this._turn(turnId).status = 'running'; this.snapshot.status = 'running';
    } else if (message.method === 'turn/completed') {
      if (!['completed','interrupted','failed'].includes(p.turn.status)) { this.snapshot.notice = 'Codex 返回了未识别的回合终态，仍等待明确结果。'; this._publish(); return; }
      const delivery = this.inflightDelivery;
      // 按本次请求开始时的 ID 集合关联新回合，不能用快照的旧 completed 推断投递结果。
      if (delivery && !delivery.baseline.has(turnId)) {
        delivery.observedTurnId = turnId; delivery.terminalStatus = p.turn.status;
        delivery.unknown = false; delivery.result = {threadId:this.snapshot.threadId, turnId, accepted:true};
        this.inflightDelivery = null;
      }
      const turn = this._turn(turnId);
      // turn/completed 是唯一成功、失败或取消判据；item 完成或 RPC 确认均不代表回合终态。
      turn.status = statusOf(p.turn.status); this.snapshot.status = turn.status;
      for (const raw of (p.turn.items ?? [])) { const item = this._normalize(raw); if (item) { const index = turn.items.findIndex(v => v.id === item.id); index < 0 ? turn.items.push(item) : turn.items[index] = item; } }
      this.activeTurn = null;
      this.deliveryUnknown = false; this.pendingDeliveryBaseline = null;
      if (p.turn.error) this.snapshot.notice = bounded(p.turn.error.message);
    } else if (['item/started','item/completed'].includes(message.method)) {
      const item = this._normalize(p.item); if (!item) return;
      const turn = this._turn(turnId);
      if (item.role === 'user') turn.items = turn.items.filter(value => value.id !== `${turnId}:input`);
      const index = turn.items.findIndex(v => v.id === item.id);
      if (index < 0) turn.items.push(item); else turn.items[index] = {...turn.items[index], ...item};
    } else if (['item/agentMessage/delta','item/commandExecution/outputDelta'].includes(message.method)) {
      const turn = this._turn(turnId); let item = turn.items.find(v => v.id === p.itemId);
      if (!item) { item = {id:p.itemId, type:message.method.includes('agentMessage') ? 'agentMessage' : 'commandExecution', role:message.method.includes('agentMessage') ? 'assistant' : 'tool', text:'', phase:null}; turn.items.push(item); }
      item.text += String(p.delta ?? '');
    } else if (message.method === 'error') {
      this.snapshot.notice = `${p.willRetry ? 'Codex 正在重试：' : 'Codex 报告错误，等待回合终态：'}${bounded(p.error?.message)}`;
    } else return;
    this._publish();
    if (message.method === 'turn/completed') { try { this._persist(); } catch { this.snapshot.notice = '回合完成后保存状态失败；请检查私有目录磁盘。'; } }
  }

  async send(text, requestId, {model = this.model, thinking = 'low'} = {}) {
    if (typeof text !== 'string' || !text.trim() || text.length > MAX_TEXT || typeof requestId !== 'string' || !requestId || requestId.length > 200) throw failure('请提供正文（最多 24000 字符）和有效 requestId。', 'INVALID_INPUT', 400);
    if (this.closed) throw failure('会话管理器已关闭。', 'CLOSED', 503);
    const hash = crypto.createHash('sha256').update(JSON.stringify({text, model, thinking})).digest('hex');
    const previous = this.requests.get(requestId);
    if (previous) { if (previous.hash !== hash) throw failure('requestId 已用于不同正文。', 'REQUEST_CONFLICT', 409); if (previous.promise) return previous.promise; throw failure('此请求已送出但接受结果未知，不能重复发送。', 'DELIVERY_UNKNOWN', 409); }
    if (this.sending || this.activeTurn || this.deliveryUnknown) throw failure('当前回合尚未结束或接受结果未知，请等待恢复。', 'BUSY', 409);
    if (this.requests.size >= MAX_REQUESTS) throw failure('此会话的幂等请求记录已达上限，请创建新会话。', 'REQUEST_LIMIT', 409);
    this.sending = true;
    const entry = {hash};
    entry.promise = (async () => {
      let attempted = false;
      try {
        await this._initialize();
        if (this.activeTurn) throw failure('恢复的回合仍在进行。', 'BUSY', 409);
        this.snapshot.status = 'running'; delete this.snapshot.notice; this._publish();
        entry.unknown = true;
        this.pendingDeliveryBaseline = new Set(this.snapshot.turns.map(turn => turn.id));
        entry.baseline = this.pendingDeliveryBaseline; this.inflightDelivery = entry;
        this._persist();
        attempted = true;
        const response = await this._rpc('turn/start', {threadId:this.snapshot.threadId, input:[{type:'text', text}], model, effort:thinking}, 60000);
        const turnId = response.turn?.id;
        if (!turnId) throw failure('Codex 未返回回合 ID。', 'INVALID_TURN', 502);
        const turn = this._turn(turnId);
        if (!['completed','cancelled','failed'].includes(turn.status)) { this.activeTurn = turnId; turn.status = 'running'; this.snapshot.status = 'running'; }
        for (const raw of (response.turn.items ?? [])) { const item = this._normalize(raw); if (item && !turn.items.some(value => value.id === item.id)) turn.items.push(item); }
        entry.unknown = false; entry.result = {threadId:this.snapshot.threadId, turnId, accepted:true};
        this._persist(); this._publish(); return entry.result;
      } catch (error) {
        this.snapshot.notice = error.message;
        if (attempted && !this.activeTurn && this.snapshot.status === 'running') this.snapshot.status = 'unknown';
        this._publish();
        // 已送出的请求可能被上游接受；保留其拒绝 Promise，防止网络重试重复发送。
        if (!attempted) {
          this.requests.delete(requestId);
          if (this.inflightDelivery === entry) this.inflightDelivery = null;
          this.pendingDeliveryBaseline = null;
          this.snapshot.status = this.snapshot.turns.at(-1)?.status ?? 'unknown';
        }
        else if (error.code !== 'RPC_ERROR' && !entry.terminalStatus) { this.deliveryUnknown = true; this._persist(); }
        else {
          // 新回合终态可能先于丢失 ACK 的超时到达；此时保留 receipt 去重，但不能重新锁住已结束的回合。
          if (error.code === 'RPC_ERROR') entry.unknown = false;
          this.deliveryUnknown = false;
          if (this.inflightDelivery === entry) this.inflightDelivery = null;
          this._persist();
        }
        throw error;
      } finally { this.sending = false; }
    })();
    this.requests.set(requestId, entry);
    return entry.promise;
  }

  async rpc(method, params = {}) {
    await this._initialize();
    const response = await this._rpc(method, params);
    if (method === 'thread/fork' && typeof response.thread?.id === 'string' && response.thread.id !== params.threadId) {
      this.writerThreads.add(response.thread.id); this._persist();
    }
    return response;
  }

  async unsubscribeOwned(threadId, {adopt = false} = {}) {
    if (!this.writerThreads.has(threadId)) {
      if (!adopt) throw failure('只能释放本工具加载的会话。', 'NOT_OWNED', 403);
      this.writerThreads.add(threadId); this._persist();
    }
    // adopt 仅供 Runtime 对已持久化 fork ID 的故障恢复，不暴露到业务 API。
    await this._rpc('thread/unsubscribe', {threadId}, 5000);
    this.writerThreads.delete(threadId); this._persist();
  }

  async hibernate() {
    if (this.sending || this.activeTurn || this.deliveryUnknown) throw failure('活跃回合不可回收。', 'BUSY', 409);
    this._persist(); this.hibernating = true;
    try { await this._stopChild(this.child); this.ready = false; this.snapshot.connection = 'disconnected'; }
    finally { this.hibernating = false; }
  }

  async interrupt(turnId) {
    if (!turnId || turnId !== this.activeTurn) throw failure('仅能中断当前回合。', 'TURN_NOT_ACTIVE', 409);
    await this._rpc('turn/interrupt', {threadId:this.snapshot.threadId, turnId}, 15000);
    return {turnId, accepted:true};
  }

  async _stopChild(child) {
    if (!child || child.exited) return;
    let releaseError = null;
    if (child === this.child) for (const threadId of [...this.writerThreads]) {
      if (threadId === this.snapshot.threadId && (this.activeTurn || this.sending || this.deliveryUnknown)) continue;
      try { await this.unsubscribeOwned(threadId); } catch (error) { releaseError ??= error; }
    }
    const wait = ms => new Promise(resolve => { const timer = setTimeout(resolve, ms); child.exitPromise.then(() => { clearTimeout(timer); resolve(); }); });
    try { child.proc.stdin.end(); } catch { /* 已关闭的 stdin 仍需等待进程退出。 */ }
    await wait(3000);
    if (!child.exited) { child.proc.kill(); await wait(2000); }
    if (!child.exited) throw failure(`独立子进程未确认退出（PID ${child.proc.pid ?? 'unknown'}）。`, 'PROCESS_STILL_RUNNING');
    if (releaseError) throw failure(`自有会话 writer 释放未确认：${releaseError.message}`, 'WRITER_RELEASE_UNKNOWN', 503);
  }

  async close() {
    if (this.closePromise) return this.closePromise;
    this.closed = true;
    this.closePromise = (async () => {
      for (const pending of this.pending.values()) { clearTimeout(pending.timer); pending.reject(failure('会话管理器正在关闭。', 'CLOSED', 503)); }
      this.pending.clear();
      await this._stopChild(this.child);
    })();
    try { return await this.closePromise; } catch (error) { this.closePromise = null; throw error; }
  }
}

module.exports = {AppServerSession, OwnedSession:AppServerSession, resolveBinary, failure};
