'use strict';
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const http = require('node:http');
const { spawn, execFileSync } = require('node:child_process');

const ROOT = process.env.LOCALAPPDATA ? path.join(process.env.LOCALAPPDATA, 'CodexRemote', 'windows-agent-v0.6') : path.join(os.homedir(), 'AppData', 'Local', 'CodexRemote', 'windows-agent-v0.6');
const DATA = process.env.CODEX_REMOTE_DATA_DIR ? path.resolve(process.env.CODEX_REMOTE_DATA_DIR) : path.join(ROOT, 'data');
const VAULT = path.join(DATA, 'identity.dpapi');
const SETTINGS = path.join(DATA, 'settings.json');
const LOCATOR = path.join(DATA, 'controller.dpapi');
const PIDFILE = path.join(DATA, 'controller.pid');
const CONFIG = path.join(DATA, 'agent-config.json');
const STATUS = path.join(DATA, 'status.json');
const RELAY_STATUS = path.join(DATA, 'relay-status.json');
const HEARTBEAT = path.join(DATA, 'controller-heartbeat');
const TASK_NAME = 'CodexRemote-WindowsTray';
const QR = require('./qr-vendor.cjs');
const { normalizeRelayUrl, mergeSettings, timeouts, runtimeSettings } = require('./connection-config.cjs');
const RESET_MARKER = path.join(DATA, 'connection-reset.json');
let connectionGeneration = 0;
let connectionResetting = false;
let agentChild = null;
let agentRelayIdentity = null;
let relayRefreshBusy = false;
let pendingRefreshTask = null;
let pendingRefreshGeneration = null;
let phonesRefreshTask = null;
let pairingPoll = null;
let desktopManager;
let desktopLaunchSettings = null;
let desktopActivation = null;
let desktopActivationTask = null;
let desktopActivationFailure = null;

// Node Relay 与 Cloudflare registry 的邀请最长有效期均为 5 分钟；待审批返回自己的 expiresAt。
const PAIRING_INVITE_TTL_MS = 5 * 60_000;
class PairingPollSchedule {
  constructor({refresh, clock = Date.now, setTimer = setTimeout, clearTimer = clearTimeout,
    fastMs = 5000, idleMs = 60000, startupRecoveryMs = PAIRING_INVITE_TTL_MS, panelLeaseMs = 15000} = {}) {
    this.refresh = refresh; this.clock = clock; this.setTimer = setTimer; this.clearTimer = clearTimer;
    this.fastMs = fastMs; this.idleMs = idleMs; this.panelLeaseMs = panelLeaseMs;
    this.recoveryUntil = clock() + startupRecoveryMs; this.inviteUntil = 0; this.pendingUntil = 0; this.panelUntil = 0;
    this.paired = true; this.running = false; this.timer = null; this.nextAt = null; this.task = null;
  }
  delay() { return this.paired && Math.max(this.recoveryUntil, this.inviteUntil, this.pendingUntil, this.panelUntil) > this.clock() ? this.fastMs : this.idleMs; }
  arm(delay = this.delay()) {
    if (!this.running) return;
    if (this.timer !== null) this.clearTimer(this.timer);
    this.nextAt = this.clock() + delay;
    this.timer = this.setTimer(() => { this.timer = null; this.nextAt = null; void this.run().catch(() => {}); }, delay);
    this.timer?.unref?.();
  }
  reconsider() { if (this.running && !this.task && (this.nextAt === null || this.nextAt > this.clock() + this.delay())) this.arm(); }
  setPaired(paired) {
    this.paired = paired;
    if (!paired) { this.inviteUntil = 0; this.pendingUntil = 0; this.panelUntil = 0; }
    this.reconsider();
  }
  observeInvite(expiresAt) {
    if (Number.isFinite(expiresAt) && expiresAt > this.clock()) { this.inviteUntil = expiresAt; this.paired = true; }
    this.reconsider();
  }
  observePending(requests) {
    this.pendingUntil = Math.max(0, ...requests.map(request => Number.isFinite(request?.expiresAt) ? request.expiresAt : 0));
    this.reconsider();
  }
  observePanel(active, wake = true) {
    const wasActive = this.panelUntil > this.clock();
    this.panelUntil = active ? this.clock() + this.panelLeaseMs : 0;
    if (wake && active && !wasActive && this.running && !this.task) this.arm(0); else this.reconsider();
  }
  run() {
    if (this.task) return this.task;
    if (this.timer !== null) this.clearTimer(this.timer);
    this.timer = null; this.nextAt = null;
    const task = Promise.resolve().then(() => this.refresh());
    this.task = task.finally(() => { if (this.task === wrapped) { this.task = null; if (this.running) this.arm(); } });
    const wrapped = this.task; return wrapped;
  }
  start() { this.running = true; return this.run(); }
  stop() { this.running = false; if (this.timer !== null) this.clearTimer(this.timer); this.timer = null; this.nextAt = null; }
}
function relayIdentityKey(settings, vault) {
  return crypto.createHash('sha256').update(JSON.stringify({relayUrl: settings.relayUrl, deviceId: vault.deviceId, token: vault.bridgeToken,
    connectionScope: settings.connectionScope, runtime: runtimeSettings(settings), instance: settings.desktopInstance ?? null})).digest('hex');
}
function recentAgentRelayStatus(runtime, now = Date.now(), identity = null) {
  const at = runtime?.lastPollAt;
  return identity && identity.currentKey === identity.startedKey && Number.isInteger(identity.pid) && identity.pid > 0 && runtime?.pid === identity.pid &&
    Number.isFinite(identity.startedAt) && runtime?.relayConnected === true && Number.isFinite(at) && at >= identity.startedAt && now >= at && now - at < 30000 &&
    Number.isFinite(runtime.updatedAt) && runtime.updatedAt >= at && now >= runtime.updatedAt && now - runtime.updatedAt < 30000 ? {checkedAt: at, error: null} : null;
}

function getDesktopManager() {
  // start() schedules request creation asynchronously. Keep its previous-run
  // snapshot stable while persisted settings advance to the newly accepted run.
  desktopManager ??= require('./desktop-manager.cjs').createDesktopManager({ dataDir: DATA, getSettings: () => desktopLaunchSettings ?? readSettings() });
  return desktopManager;
}
function publicDesktopInstance(instance) {
  if (!instance || typeof instance !== 'object' || Array.isArray(instance)) return null;
  return Object.fromEntries(['id', 'kind', 'name', 'sourcePath', 'desktopExecutable', 'sharedSupported'].filter(key => Object.hasOwn(instance, key)).map(key => [key, instance[key]]));
}

function atomic(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = `${file}.${process.pid}.${crypto.randomBytes(4).toString('hex')}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(value, null, 2), { mode: 0o600 });
  fs.renameSync(tmp, file);
}
function readJson(file, fallback = null) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '')); } catch { return fallback; }
}
function ps(action, input = '') {
  const script = path.join(__dirname, 'dpapi.ps1');
  return execFileSync('powershell.exe', ['-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', script, '-Action', action], {
    input: String(input), encoding: 'utf8', windowsHide: true, timeout: 10000, maxBuffer: 1024 * 1024,
  }).trim();
}
function protect(value) { return ps('protect', JSON.stringify(value)); }
function unprotect(blob) { return JSON.parse(ps('unprotect', blob)); }
function readVault() { return fs.existsSync(VAULT) ? unprotect(fs.readFileSync(VAULT, 'utf8')) : {}; }
function writeVault(value) { fs.mkdirSync(DATA, { recursive: true }); fs.writeFileSync(VAULT, protect(value), { mode: 0o600 }); }
function readSettings() {
  const defaults = readJson(path.join(__dirname, '..', 'public-defaults.json'), null) ?? readJson(path.join(__dirname, 'public-defaults.json'), {});
  return mergeSettings(defaults, readJson(SETTINGS, {}) ?? {}, os.hostname());
}
async function relayRequest(url, endpoint, { method = 'GET', token, body } = {}) {
  if (connectionResetting || fs.existsSync(RESET_MARKER)) throw new Error('Connection reset is incomplete; relay requests are stopped.');
  const generation = connectionGeneration;
  url = normalizeRelayUrl(url);
  const target = new URL(`${url}${endpoint}`);
  if (target.origin !== new URL(url).origin || !target.pathname.startsWith(new URL(url).pathname.replace(/\/$/, '') + '/')) throw new Error('Relay path is outside the configured base URL.');
  const response = await fetch(target, {
    method, redirect: 'error', signal: AbortSignal.timeout(readSettings().requestTimeoutMs),
    headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}), ...(body === undefined ? {} : { 'Content-Type': 'application/json' }) },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
  if (!response.ok) {
    const error = new Error(`Relay returned HTTP ${response.status}.`);
    error.code = `RELAY_${response.status}`;
    throw error;
  }
  const size = Number(response.headers.get('content-length') ?? 0);
  if (size > 512 * 1024) throw new Error('Relay response exceeded the size limit.');
  const data = await response.json();
  if (generation !== connectionGeneration || connectionResetting) throw new Error('Connection changed while request was in flight.');
  if (!data || typeof data !== 'object' || Array.isArray(data)) throw new Error('Relay returned an invalid response.');
  return data;
}
function requireReady() {
  if (connectionResetting || fs.existsSync(RESET_MARKER)) throw new Error('Connection reset is incomplete; call resetConnection to finish it.');
  const settings = readSettings();
  if (!settings.relayUrl) throw new Error('Set the relay URL in Settings first.');
  return settings;
}
function keypair(vault) {
  if (vault.privateKey && vault.publicKey) return vault;
  const pair = crypto.generateKeyPairSync('ed25519');
  vault.privateKey = pair.privateKey.export({ type: 'pkcs8', format: 'pem' });
  vault.publicKey = pair.publicKey.export({ type: 'spki', format: 'pem' });
  writeVault(vault);
  return vault;
}
function qrModules(payload) {
  const code = QR(0, 'M');
  code.addData(payload, 'Byte');
  code.make();
  const size = code.getModuleCount();
  return Array.from({ length: size }, (_, y) => Array.from({ length: size }, (_, x) => code.isDark(y, x)));
}
function signChallenge(privateKey, challenge) { return crypto.sign(null, Buffer.from(String(challenge), 'utf8'), privateKey).toString('base64'); }
function localControlAllowed(peer, host, origin, fetchSite) {
  return peer === '127.0.0.1' && /^127\.0\.0\.1:\d+$/.test(host ?? '') && !origin && !fetchSite;
}
function startAgent() {
  const settings = requireReady();
  if (settings.runtimeMode === 'shared-engine' && !settings.sharedEngineConfigFile) return { awaitingDesktop: true };
  const vault = readVault();
  if (!vault.deviceId || !vault.bridgeToken) throw new Error('Pair this Windows device with the relay first.');
  atomic(CONFIG, { relayUrl: settings.relayUrl, deviceId: vault.deviceId, bridgeTokenFile: VAULT, dataDirectory: DATA, connectionScope: settings.connectionScope, ...runtimeSettings(settings), ...timeouts(settings), controllerHeartbeatFile: HEARTBEAT });
  if (agentChild && agentChild.exitCode === null) return { pid: agentChild.pid };
  agentChild = spawn(process.execPath, [path.join(__dirname, 'agent.cjs'), CONFIG], { windowsHide: true, stdio: 'ignore' });
  const child = agentChild;
  agentRelayIdentity = {child, startedAt: Date.now(), key: relayIdentityKey(settings, vault)};
  child.once('exit', () => { if (agentChild === child) agentChild = null; if (agentRelayIdentity?.child === child) agentRelayIdentity = null; });
  return { pid: agentChild.pid };
}
async function stopAgent() {
  if (agentChild && agentChild.exitCode === null) {
    const child = agentChild, pid = child.pid;
    try { child.kill('SIGTERM'); } catch {}
    const exited = await Promise.race([new Promise(resolve => child.once('exit', () => resolve(true))), new Promise(resolve => setTimeout(() => resolve(false), 3000))]);
    if (agentChild === child) agentChild = null;
    if (exited) return { stopped: true, pid };
  }
  const row = readJson(path.join(DATA, 'agent.lock'));
  if (!row?.pid || !Number.isInteger(row.pid)) return { stopped: false };
  try {
    const result = execFileSync('powershell.exe', ['-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', path.join(__dirname, 'stop-owned-agent.ps1'), '-ProcessId', String(row.pid), '-AgentPath', path.join(__dirname, 'agent.cjs')], { encoding: 'utf8', windowsHide: true, timeout: 10000 }).trim();
    return { stopped: result === 'stopped' };
  } catch { return { stopped: false }; }
}
async function resetConnection(next) {
  if (connectionResetting) throw new Error('A connection reset is already in progress.');
  connectionResetting = true;
  connectionGeneration++;
  try {
    // A durable marker prevents restart/pairing from reusing credentials after a partial reset.
    atomic(RESET_MARKER, { startedAt: Date.now() });
    await requireAgentStopped();
    writeVault({});
    const connectionScope = crypto.randomUUID();
    atomic(SETTINGS, { ...next, connectionScope });
    atomic(STATUS, { updatedAt: Date.now(), lastPollAt: null, relayConnected: false });
    atomic(RELAY_STATUS, { checkedAt: Date.now(), error: 'Windows device is not paired.' });
    atomic(path.join(DATA, 'pending.json'), { checkedAt: Date.now(), requests: [], error: null });
    pairingPoll?.setPaired(false);
    fs.unlinkSync(RESET_MARKER);
    return { reset: true, pairingReset: true, connectionScope, remoteRevocation: 'not-attempted' };
  } finally { connectionResetting = false; }
}
async function requireAgentStopped() {
  const pids = new Set([agentChild?.pid, readJson(path.join(DATA, 'agent.lock'))?.pid].filter(pid => Number.isInteger(pid) && pid > 0));
  await stopAgent();
  for (const pid of pids) {
    try { process.kill(pid, 0); throw new Error('Old bridge is still running; connection change was stopped.'); }
    catch (error) { if (error.code !== 'ESRCH') throw error; }
  }
}
function bridgeStatus(runtime, now = Date.now()) {
  return { running: !!runtime.pid && now - (runtime.updatedAt ?? 0) < 45000, pid: runtime.pid ?? null, lastPollAt: Object.prototype.hasOwnProperty.call(runtime, 'lastPollAt') ? runtime.lastPollAt ?? null : runtime.updatedAt ?? null, relayConnected: !!runtime.relayConnected };
}
function desktopStatus(runtime, now = Date.now()) {
  const desktop = runtime.engine ?? runtime.desktop ?? { connected: false, pid: null, error: 'Bridge has not reported status yet' };
  if (typeof runtime.desktopCheckedAt === 'number' && Number.isFinite(runtime.desktopCheckedAt) && now - runtime.desktopCheckedAt > 30000) return { ...desktop, connected: false, error: 'Codex 引擎状态已过期，请等待重新检查' };
  return desktop;
}
async function status() {
  await advanceDesktopActivation();
  const settings = readSettings();
  const runtime = readJson(STATUS, {});
  const relayState = readJson(RELAY_STATUS, {});
  const now = Date.now();
  const relay = { connected: !!relayState.checkedAt && !relayState.error && now - relayState.checkedAt < 45000, checkedAt: relayState.checkedAt ?? null, error: relayState.error ?? (relayState.checkedAt ? null : 'Windows device is not paired.') };
  const fresh = readJson(STATUS, runtime);
  return {
    version: '0.6.0', settings: { relayUrl: settings.relayUrl, name: settings.name, autoStart: !!settings.autoStart, paused: !!settings.paused, runtimeMode: settings.runtimeMode },
    relay, desktop: desktopStatus(fresh, now), desktopLaunch: desktopActivationFailure ?? getDesktopManager().status(),
    bridge: bridgeStatus(fresh, now),
    paired: !!readVault().deviceId,
  };
}
async function refreshRelayStatus() {
  if (connectionResetting || fs.existsSync(RESET_MARKER)) return;
  if (relayRefreshBusy) return;
  relayRefreshBusy = true;
  const settings = readSettings(), vault = readVault(), checkedAt = Date.now();
  try {
    if (!settings.relayUrl || !vault.bridgeToken) { atomic(RELAY_STATUS, { checkedAt, error: 'Windows device is not paired.' }); return; }
    try {
      const owned = agentRelayIdentity;
      const identity = owned && owned.child === agentChild && agentChild.exitCode === null && !agentChild.killed ?
        {pid: agentChild.pid, startedAt: owned.startedAt, startedKey: owned.key, currentKey: relayIdentityKey(settings, vault)} : null;
      const recent = recentAgentRelayStatus(readJson(STATUS, {}), checkedAt, identity);
      if (recent) { atomic(RELAY_STATUS, recent); return; }
      await readPhones(settings, vault); atomic(RELAY_STATUS, { checkedAt, error: null });
    }
    catch (error) { atomic(RELAY_STATUS, { checkedAt, error: error.message.slice(0, 180) }); }
  } finally { relayRefreshBusy = false; }
}
async function refreshPending() {
  if (connectionResetting || fs.existsSync(RESET_MARKER)) return;
  if (pendingRefreshTask) {
    if (pendingRefreshGeneration === connectionGeneration) return pendingRefreshTask;
    return pendingRefreshTask.catch(() => {}).then(() => refreshPending());
  }
  const generation = connectionGeneration;
  const task = (async () => {
    const settings = readSettings(), vault = readVault();
    if (!settings.relayUrl || !vault.bridgeToken) { pairingPoll?.setPaired(false); atomic(path.join(DATA, 'pending.json'), { checkedAt: Date.now(), requests: [], error: null }); return; }
    pairingPoll?.setPaired(true);
    try { const data = await relayRequest(settings.relayUrl, '/pair/pending', { token: vault.bridgeToken }); if (generation !== connectionGeneration || connectionResetting) return; const requests = Array.isArray(data.requests) ? data.requests : []; pairingPoll?.observePending(requests); atomic(path.join(DATA, 'pending.json'), { checkedAt: Date.now(), requests, error: null }); }
    catch (error) { if (generation === connectionGeneration && !connectionResetting) atomic(path.join(DATA, 'pending.json'), { checkedAt: Date.now(), requests: [], error: error.message.slice(0, 180) }); }
  })();
  pendingRefreshTask = task; pendingRefreshGeneration = generation;
  try { await task; } finally { if (pendingRefreshTask === task) { pendingRefreshTask = null; pendingRefreshGeneration = null; } }
}
async function readPhones(settings = readSettings(), vault = readVault()) {
  const identity = relayIdentityKey(settings, vault);
  if (phonesRefreshTask?.generation === connectionGeneration && phonesRefreshTask.identity === identity) return phonesRefreshTask.task;
  const task = relayRequest(settings.relayUrl, '/pair/phones', { token: vault.bridgeToken });
  const entry = {generation: connectionGeneration, identity, task}; phonesRefreshTask = entry;
  try { return await task; } finally { if (phonesRefreshTask === entry) phonesRefreshTask = null; }
}
async function createInvite() {
  const settings = requireReady();
  const vault = readVault();
  if (!vault.bridgeToken) throw new Error('Pair this Windows device with the relay first.');
  const invite = await relayRequest(settings.relayUrl, '/pair/invites', { method: 'POST', token: vault.bridgeToken, body: {} });
  if (typeof invite.code !== 'string' || !/^\d{8}$/.test(invite.code) || typeof invite.qrPayload !== 'string' || !invite.inviteToken) throw new Error('Relay returned an invalid invitation.');
  pairingPoll?.observeInvite(invite.expiresAt);
  return { ...invite, qrModules: qrModules(invite.qrPayload) };
}
async function pairDevice(name) {
  const settings = requireReady();
  const vault = keypair(readVault());
  const challenge = await relayRequest(settings.relayUrl, '/pair/device/challenge', { method: 'POST', body: { publicKey: vault.publicKey } });
  if (typeof challenge.challengeId !== 'string' || typeof challenge.challenge !== 'string') throw new Error('Relay returned an invalid pairing challenge.');
  const signature = crypto.sign(null, Buffer.from(challenge.challenge, 'utf8'), vault.privateKey).toString('base64');
  const registered = await relayRequest(settings.relayUrl, '/pair/device/register', { method: 'POST', body: { challengeId: challenge.challengeId, signature, name: String(name || settings.name).trim().slice(0, 64) } });
  if (typeof registered.deviceId !== 'string' || typeof registered.bridgeToken !== 'string' || registered.bridgeToken.length < 32) throw new Error('Relay returned invalid device credentials.');
  writeVault({ ...vault, deviceId: registered.deviceId, bridgeToken: registered.bridgeToken });
  if (!readSettings().paused) startAgent();
  return { paired: true, deviceId: registered.deviceId };
}
async function prepareDesktopSettings(current, body, { forLaunch = false } = {}) {
  const selected = Object.hasOwn(body, 'desktopInstance') ? body.desktopInstance : current.desktopInstance;
  if (Object.hasOwn(body, 'desktopInstance') && !selected) throw new Error('请选择可用的 Codex 桌面实例。');
  const differentInstance = selected && current.desktopInstance && selected.id !== current.desktopInstance.id;
  let desktopLaunchConfigFile = differentInstance ? '' : (current.desktopLaunchConfigFile ?? current.sharedEngineConfigFile);
  let desktopInstance = selected;
  if (selected) {
    // The manager reopens the shortcut/package and rejects caller-supplied launch arguments.
    let prepared;
    const runtimeMode = body.runtimeMode ?? current.runtimeMode;
    try { prepared = await getDesktopManager().prepareSelection(selected, { existingSharedConfigFile: desktopLaunchConfigFile, runtimeMode }); }
    catch (error) {
      // 旧连接只服务于当前 Agent；保存入口时单独准备待启动配置。
      // 已保存的待启动配置出错时不得悄悄替换它。
      if (forLaunch || current.desktopLaunchConfigFile || !['DESKTOP_SHARED_SELECTION_MISMATCH', 'DESKTOP_LEGACY_CONNECTION_ONLY'].includes(error.code)) throw error;
      prepared = await getDesktopManager().prepareSelection(selected, { runtimeMode });
    }
    desktopInstance = publicDesktopInstance(prepared.instance);
    desktopLaunchConfigFile = prepared.sharedEngineConfigFile;
  }
  let sharedEngineConfigFile = body.sharedEngineConfigFile ?? current.sharedEngineConfigFile;
  // 保留显式模式切换的既有行为；同模式保存只改变待启动入口。
  if (body.runtimeMode && body.runtimeMode !== current.runtimeMode && body.sharedEngineConfigFile === undefined && body.runtimeMode === 'shared-engine' && current.sharedEngineConfigFile) sharedEngineConfigFile = desktopLaunchConfigFile;
  const runtime = runtimeSettings({ ...current, ...body, sharedEngineConfigFile, desktopLaunchConfigFile, desktopCodexHome: current.desktopCodexHome });
  if (runtime.runtimeMode === 'shared-engine' && selected && !desktopInstance.sharedSupported) throw new Error('所选 Codex 桌面实例不支持共享引擎模式。');
  return { ...runtime, ...(desktopInstance ? { desktopInstance, desktopLaunchConfigFile } : {}) };
}
function previousSharedConfig(current, nextFile) {
  // This private recovery pointer is derived only from saved local settings.
  // Preserve the original prior run across multiple unsent selection changes.
  const previous = current.previousSharedEngineConfigFile || (current.sharedEngineConfigFile !== nextFile ? current.sharedEngineConfigFile : '');
  return runtimeSettings({ runtimeMode: 'desktop-bridge', sharedEngineConfigFile: previous }).sharedEngineConfigFile;
}
async function launchDesktop() {
  const current = readSettings();
  if (!current.desktopInstance) throw new Error('请先检测或导入并保存 Codex 桌面实例。');
  const prepared = await prepareDesktopSettings(current, {}, { forLaunch: true });
  const priorSnapshot = desktopLaunchSettings;
  desktopLaunchSettings = { ...current, sharedEngineConfigFile: current.sharedEngineConfigFile };
  let accepted;
  // Never accept target, arguments, executable or mode overrides on a launch request.
  try {
    accepted = await getDesktopManager().start({ instance: prepared.desktopInstance, runtimeMode: prepared.runtimeMode, sharedEngineConfigFile: prepared.desktopLaunchConfigFile });
    if (accepted?.accepted !== true) throw new Error('Codex 桌面启动请求未被受理。');
  } catch (error) {
    desktopLaunchSettings = priorSnapshot;
    throw error;
  }
  // accepted 只表示已排队。直到本轮桌面启动回执通过，Agent 继续使用旧连接。
  desktopActivationFailure = null;
  desktopActivation = { token: crypto.randomUUID(), instance: prepared.desktopInstance, savedInstance: current.desktopInstance, runtimeMode: prepared.runtimeMode, configFile: prepared.desktopLaunchConfigFile, savedConfigFile: current.desktopLaunchConfigFile, activeConfigFile: current.sharedEngineConfigFile, preferredProfile: current.preferredProfile, desktopCodexHome: current.desktopCodexHome, relayUrl: current.relayUrl, connectionScope: current.connectionScope };
  return accepted;
}
function activationMatches(settings, activation) {
  const saved = activation.savedInstance;
  return settings.desktopInstance?.id === saved.id && settings.desktopInstance?.sourcePath === saved.sourcePath && settings.desktopInstance?.desktopExecutable === saved.desktopExecutable && settings.runtimeMode === activation.runtimeMode && settings.desktopLaunchConfigFile === activation.savedConfigFile && settings.sharedEngineConfigFile === activation.activeConfigFile && settings.preferredProfile === activation.preferredProfile && settings.desktopCodexHome === activation.desktopCodexHome && settings.relayUrl === activation.relayUrl && settings.connectionScope === activation.connectionScope;
}
async function commitDesktopActivation(activation) {
  if (desktopActivation?.token !== activation.token) return;
  const launch = getDesktopManager().status();
  if (['failed', 'needs_exit', 'idle'].includes(launch.phase)) { desktopActivation = null; desktopLaunchSettings = null; return; }
  const complete = launch.instanceId === activation.instance.id && launch.runtimeMode === activation.runtimeMode && Number.isInteger(launch.desktopPid) && launch.desktopPid > 0 && (activation.runtimeMode === 'shared-engine' ? launch.phase === 'awaiting_connection' && launch.brokerReady === true : launch.phase === 'started');
  if (!complete) return;
  let current = readSettings(), stopped = false, written = false;
  if (!activationMatches(current, activation)) { desktopActivation = null; desktopLaunchSettings = null; return; }
  try {
    // 再次读取入口和独立配置指纹，不能用排队前的验证替代启动完成后的验证。
    const validated = await getDesktopManager().prepareSelection(activation.instance, { existingSharedConfigFile: activation.configFile, runtimeMode:activation.runtimeMode });
    if (validated.instance.id !== activation.instance.id || validated.sharedEngineConfigFile !== activation.configFile) throw new Error('DESKTOP_SELECTION_CHANGED');
    if (!activationMatches(readSettings(), activation)) return;
    const next = { ...current, desktopInstance: validated.instance, desktopLaunchConfigFile: activation.configFile, sharedEngineConfigFile: activation.configFile, previousSharedEngineConfigFile: previousSharedConfig(current, activation.configFile) };
    if(validated.preferredProfile!==undefined)next.preferredProfile=validated.preferredProfile;else if(activation.instance.kind==='official')delete next.preferredProfile;else throw new Error('DESKTOP_PROFILE_REQUIRED');
    if(validated.isolatedCodexHome!==undefined)next.desktopCodexHome=validated.isolatedCodexHome;else delete next.desktopCodexHome;
    runtimeSettings(next);
    const changed = current.sharedEngineConfigFile !== activation.configFile || current.preferredProfile !== next.preferredProfile || current.desktopCodexHome !== next.desktopCodexHome;
    if (changed) { await requireAgentStopped(); stopped = true; }
    if (!activationMatches(readSettings(), activation)) { if (stopped && !readSettings().paused && readVault().deviceId) startAgent(); return; }
    atomic(SETTINGS, next); written = true;
    if (changed && !next.paused && readVault().deviceId) startAgent();
  } catch (error) {
    if (written) atomic(SETTINGS, current);
    if (stopped && !current.paused && readVault().deviceId) { try { startAgent(); } catch {} }
    desktopActivationFailure = { ...launch, phase: 'failed', stage: 'failed', error: /^DESKTOP_[A-Z_]+$/.test(error.code ?? error.message) ? (error.code ?? error.message) : 'DESKTOP_ACTIVATION_FAILED' };
  } finally { if (desktopActivation?.token === activation.token) desktopActivation = null; desktopLaunchSettings = null; }
}
function advanceDesktopActivation() {
  if (!desktopActivation) return desktopActivationTask;
  if (!desktopActivationTask) {
    const activation = desktopActivation;
    const task = mutationQueue.then(() => commitDesktopActivation(activation));
    desktopActivationTask = task.finally(() => { desktopActivationTask = null; });
    mutationQueue = desktopActivationTask.catch(() => {});
  }
  return desktopActivationTask;
}
async function dispatch(action, body = {}) {
  switch (action) {
    case 'status': return status();
    case 'refreshRelay': await refreshRelayStatus(); return status();
    case 'refreshPending': if (typeof body.pairingActive === 'boolean') pairingPoll?.observePanel(body.pairingActive, false); await (pairingPoll ? pairingPoll.run() : refreshPending()); return readJson(path.join(DATA, 'pending.json'), { requests: [] });
    case 'settings': { const s = readSettings(); return { relayUrl: s.relayUrl, name: s.name, autoStart: !!s.autoStart, paused: !!s.paused, paired: !!readVault().deviceId, desktopInstance: publicDesktopInstance(s.desktopInstance), ...runtimeSettings(s), ...timeouts(s) }; }
    case 'detectDesktop': { const result = await getDesktopManager().discover(); return { instances: result.instances.map(publicDesktopInstance), running: result.running, processScanFailed: result.processScanFailed }; }
    case 'importDesktop': { const result = await getDesktopManager().importShortcut(body.shortcutPath); return { instance: publicDesktopInstance(result.instance) }; }
    case 'launchDesktop': return launchDesktop();
    case 'saveSettings': {
      if(getDesktopManager().status().phase==='starting')throw new Error('DESKTOP_LAUNCH_BUSY');
      const current = readSettings();
      const relayUrl = normalizeRelayUrl(body.baseUrl ?? body.relayUrl ?? current.relayUrl);
      const name = String(body.name ?? current.name).trim();
      if (!name || name.length > 64) throw new Error('Device name must contain 1–64 characters.');
      const relayChanged = current.relayUrl !== relayUrl;
      const next = { ...current, relayUrl, name, autoStart: body.autoStart === undefined ? current.autoStart : !!body.autoStart, ...timeouts({ ...current, ...body }), ...await prepareDesktopSettings(current, body) };
      next.previousSharedEngineConfigFile = previousSharedConfig(current, next.sharedEngineConfigFile);
      const runtimeChanged = current.runtimeMode !== next.runtimeMode || current.sharedEngineConfigFile !== next.sharedEngineConfigFile || current.preferredProfile !== next.preferredProfile || current.desktopCodexHome !== next.desktopCodexHome;
      if (next.runtimeMode === 'shared-engine') {
        try { if (!fs.statSync(next.sharedEngineConfigFile || next.desktopLaunchConfigFile).isFile()) throw new Error(); }
        catch { throw new Error('共享引擎私有配置文件不存在或无法读取。请先通过共享入口启动桌面。'); }
      }
      // A startup policy failure must not destroy the current device pairing.
      if (next.autoStart) await setAutostart(true); else await setAutostart(false);
      if (relayChanged) await resetConnection(next);
      else {
        if (runtimeChanged || current.requestTimeoutMs !== next.requestTimeoutMs || current.pollTimeoutMs !== next.pollTimeoutMs) await requireAgentStopped();
        atomic(SETTINGS, next);
      }
      const vault = readVault();
      desktopActivation = null; desktopActivationFailure = null;
      if (!relayChanged && vault.deviceId && !next.paused) startAgent();
      return { saved: true, pairingReset: relayChanged, launchPending: !!next.desktopLaunchConfigFile && next.desktopLaunchConfigFile !== next.sharedEngineConfigFile, runtimeRestarted: runtimeChanged && !relayChanged && !!vault.deviceId && !next.paused && (next.runtimeMode !== 'shared-engine' || !!next.sharedEngineConfigFile) };
    }
    case 'resetConnection': return resetConnection(readSettings());
    case 'pairDevice': return pairDevice(body.name);
    case 'connectAndInvite': {
      const vault = readVault();
      if (!vault.deviceId || !vault.bridgeToken) await pairDevice(body.name);
      return createInvite();
    }
    case 'invite': return createInvite();
    case 'pending': if (typeof body.pairingActive === 'boolean') pairingPoll?.observePanel(body.pairingActive); return readJson(path.join(DATA, 'pending.json'), { requests: [], error: null });
    case 'confirm': {
      const s = requireReady(), v = readVault();
      if (typeof body.requestId !== 'string' || typeof body.approve !== 'boolean') throw new Error('Invalid phone request.');
      const result = await relayRequest(s.relayUrl, '/pair/confirm', { method: 'POST', token: v.bridgeToken, body: { requestId: body.requestId, approve: body.approve } });
      // Finish any pre-confirmation refresh before requesting the updated list.
      if (pendingRefreshTask) await pendingRefreshTask;
      await refreshPending();
      return result;
    }
    case 'phones': {
      const s = requireReady(), v = readVault();
      const data = await readPhones(s, v);
      return { phones: Array.isArray(data.phones) ? data.phones : [] };
    }
    case 'revoke': {
      const s = requireReady(), v = readVault();
      if (typeof body.phoneId !== 'string') throw new Error('Select a paired phone first.');
      return relayRequest(s.relayUrl, '/pair/revoke', { method: 'POST', token: v.bridgeToken, body: { phoneId: body.phoneId } });
    }
    case 'pause': { const s = readSettings(); atomic(SETTINGS, { ...s, paused: true }); return stopAgent(); }
    case 'resume': { const s = readSettings(); atomic(SETTINGS, { ...s, paused: false }); return startAgent(); }
    case 'exit': await stopAgent(); return { exit: true };
    default: throw new Error('Unsupported controller action.');
  }
}
let mutationQueue = Promise.resolve();
function handle(action, body = {}) {
  if (!['saveSettings', 'resetConnection', 'pairDevice', 'connectAndInvite', 'invite', 'confirm', 'revoke', 'importDesktop', 'launchDesktop', 'pause', 'resume', 'exit'].includes(action)) return dispatch(action, body);
  const operation = mutationQueue.then(() => dispatch(action, body));
  mutationQueue = operation.catch(() => {});
  return operation;
}
async function setAutostart(enabled) {
  const script = path.join(__dirname, 'tray.ps1');
  const node = process.execPath;
  const escaped = `\"powershell.exe\" -NoLogo -NoProfile -STA -WindowStyle Hidden -ExecutionPolicy Bypass -File \"${script}\" -NodePath \"${node}\"`;
  // HKCU Run is per-user and requires no elevation, unlike ONLOGON task creation
  // on machines whose Task Scheduler policy denies unprivileged registration.
  const key = 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run';
  const options = { encoding: 'utf8', windowsHide: true, timeout: 10000, stdio: ['ignore', 'pipe', 'pipe'] };
  try {
    if (enabled) execFileSync('reg.exe', ['add', key, '/v', TASK_NAME, '/t', 'REG_SZ', '/d', escaped, '/f'], options);
    else {
      let exists = true;
      try { execFileSync('reg.exe', ['query', key, '/v', TASK_NAME], options); } catch (error) { if (error.status === 1) exists = false; else throw error; }
      if (exists) execFileSync('reg.exe', ['delete', key, '/v', TASK_NAME, '/f'], options);
    }
  } catch { throw new Error('无法更新当前用户的登录自启动设置。'); }
}
function readLocator() { return unprotect(fs.readFileSync(LOCATOR, 'utf8')); }
function send(action, body = {}) {
  const locator = readLocator();
  const data = Buffer.from(JSON.stringify(body));
  return new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port: locator.port, path: '/control', method: 'POST', timeout: 125000, headers: { Host: `127.0.0.1:${locator.port}`, 'Content-Type': 'application/json', 'Content-Length': data.length, 'X-CodexRemote-Token': locator.token, 'X-Control-Action': action } }, res => {
      const chunks = []; let size = 0;
      res.on('data', chunk => { size += chunk.length; if (size > 1024 * 1024) req.destroy(new Error('Controller response too large.')); else chunks.push(chunk); });
      res.on('end', () => { try { const result = JSON.parse(Buffer.concat(chunks).toString('utf8')); if (!res.statusCode || res.statusCode >= 400) reject(new Error(result.error ?? 'Controller request failed.')); else resolve(result); } catch (e) { reject(e); } });
    });
    req.on('error', reject); req.on('timeout', () => req.destroy(new Error('Controller timed out.'))); req.end(data);
  });
}
function assertControllerPidStopped(previousPid, probe = process.kill) {
  if (!Number.isSafeInteger(previousPid) || previousPid <= 0) throw new Error('后台进程记录无效，无法安全启动第二个后台。');
  try { probe(previousPid, 0); }
  catch (error) {
    if (error.code === 'ESRCH') return;
    throw new Error('无法确认旧后台是否已经退出，已保留现有连接。');
  }
  // 不同安装目录或 PID 被复用均不能作为抢占依据；只在确认进程不存在后清理旧记录。
  throw new Error('连接中心后台仍在运行，请使用已有后台。');
}
async function daemon() {
  fs.mkdirSync(DATA, { recursive: true });
  let lock;
  try { lock = fs.openSync(PIDFILE, 'wx', 0o600); }
  catch (error) {
    if (error.code !== 'EEXIST') throw error;
    const previousPid = Number(fs.readFileSync(PIDFILE, 'utf8'));
    assertControllerPidStopped(previousPid);
    fs.unlinkSync(PIDFILE);
    lock = fs.openSync(PIDFILE, 'wx', 0o600);
  }
  fs.writeFileSync(lock, String(process.pid));
  fs.closeSync(lock);
  const token = crypto.randomBytes(32).toString('base64url');
  const server = http.createServer(async (req, res) => {
    const peer = req.socket.remoteAddress;
    const host = req.headers.host ?? '';
    if (!localControlAllowed(peer, host, req.headers.origin, req.headers['sec-fetch-site'])) { res.writeHead(403).end(); return; }
    if (req.method !== 'POST' || req.url !== '/control' || req.headers['x-codexremote-token'] !== token) { res.writeHead(404).end(); return; }
    let size = 0, text = '';
    try {
      for await (const chunk of req) { size += chunk.length; if (size > 65536) throw new Error('Request too large.'); text += chunk; }
      const action = req.headers['x-control-action'];
      const result = await handle(action, text ? JSON.parse(text) : {});
      res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }).end(JSON.stringify(result));
      if (action === 'exit') setTimeout(() => server.close(() => process.exit(0)), 100);
    } catch (error) { res.writeHead(400, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }).end(JSON.stringify({ error: error.message.slice(0, 240) })); }
  });
  server.listen(0, '127.0.0.1', async () => {
    const port = server.address().port;
    fs.writeFileSync(LOCATOR, protect({ port, token }), { mode: 0o600 });
    const touch = () => { try { fs.writeFileSync(HEARTBEAT, String(Date.now()), { mode: 0o600 }); } catch {} };
    touch(); setInterval(touch, 3000).unref();
    if (!fs.existsSync(RESET_MARKER) && !readSettings().paused && readVault().deviceId) { try { startAgent(); } catch {} }
    void refreshRelayStatus();
    pairingPoll = new PairingPollSchedule({refresh: refreshPending});
    void pairingPoll.start().catch(() => {});
    setInterval(() => { void refreshRelayStatus(); }, 15000).unref();
  });
  const cleanup = () => { pairingPoll?.stop(); void stopAgent(); try { fs.unlinkSync(HEARTBEAT); } catch {} try { server.close(); } catch {} try { fs.unlinkSync(PIDFILE); } catch {} };
  process.on('SIGINT', cleanup); process.on('SIGTERM', cleanup); process.on('exit', () => { try { fs.unlinkSync(HEARTBEAT); } catch {} try { fs.unlinkSync(PIDFILE); } catch {} });
  await new Promise(resolve => server.on('close', resolve));
}
async function main() {
  const action = process.argv[2];
  if (action === 'daemon') return daemon();
  if (action === 'call') {
    let body = ''; for await (const chunk of process.stdin) body += chunk;
    try { process.stdout.write(JSON.stringify(await send(process.argv[3], body ? JSON.parse(body) : {}))); }
    catch (error) { process.stderr.write(error.message); process.exitCode = 1; }
    return;
  }
  if (action === 'identity') {
    let body = ''; for await (const chunk of process.stdin) body += chunk;
    try { process.stdout.write(JSON.stringify(await pairDevice(JSON.parse(body || '{}').name))); }
    catch (error) { process.stderr.write(error.message); process.exitCode = 1; }
    return;
  }
  throw new Error('Usage: tray-controller.cjs daemon | call <action> | identity');
}
if (require.main === module) main().catch(error => { process.stderr.write(error.message); process.exitCode = 1; });
module.exports = { normalizeRelayUrl, qrModules, relayRequest, handle, readSettings, signChallenge, localControlAllowed, bridgeStatus, desktopStatus, assertControllerPidStopped, PairingPollSchedule, PAIRING_INVITE_TTL_MS, recentAgentRelayStatus, relayIdentityKey };
