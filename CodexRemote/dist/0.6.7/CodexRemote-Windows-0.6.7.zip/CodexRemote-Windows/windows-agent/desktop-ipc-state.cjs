'use strict';
const copy = value => JSON.parse(JSON.stringify(value));
const UUID = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
const active = value => /^(inProgress|in_progress|running|pending|waiting)$/.test(value ?? '');
function approvalInfo(request) {
  const p = request.params ?? {}, meta = p._meta;
  const kind = request.method.includes('commandExecution') ? 'command' : request.method.includes('fileChange') ? 'file' : request.method === 'mcpServer/elicitation/request' ? 'mcp' : 'permissions';
  let origin = null, supported = kind === 'command' && typeof p.command === 'string' && !!p.command.trim() && (p.availableDecisions == null || Array.isArray(p.availableDecisions) && p.availableDecisions.includes('accept'));
  if (kind === 'mcp' && p.mode === 'form' && meta?.codex_approval_kind === 'mcp_tool_call' && meta.connector_id === 'browser-use' && meta.tool_name === 'access_browser_origin') {
    const origins = [meta.origin, meta.tool_params?.origin].filter(value => value !== undefined);
    const schema = p.requestedSchema;
    const simpleSchema = schema?.type === 'object' && schema.properties && typeof schema.properties === 'object' && !Array.isArray(schema.properties) && Object.keys(schema.properties).length === 0 && (!schema.required || Array.isArray(schema.required) && schema.required.length === 0) && (schema.additionalProperties === undefined || schema.additionalProperties === false) && Object.keys(schema).every(key => ['type', 'properties', 'required', 'additionalProperties'].includes(key));
    const simpleParams = meta.tool_params && typeof meta.tool_params === 'object' && !Array.isArray(meta.tool_params) && Object.keys(meta.tool_params).every(key => key === 'origin');
    const verification = Object.keys(meta).some(key => /otp|verification|browser_auth|credential|password|wallet/i.test(key));
    try { if (simpleSchema && simpleParams && !verification && origins.length && origins.every(value => typeof value === 'string' && ['http:', 'https:'].includes(new URL(value).protocol) && new URL(value).origin === value) && origins.every(value => value === origins[0])) { origin = origins[0]; supported = true; } } catch {}
  }
  // 只暴露已实现的单次批准；身份验证、OTP、钱包和任意表单不得套用空 content。
  const bounded = JSON.stringify(p).length < 256 * 1024;
  const canReject = kind === 'command' ? p.availableDecisions == null || Array.isArray(p.availableDecisions) && p.availableDecisions.includes('decline') : supported;
  return {kind, origin, supported: supported && bounded, canApprove: supported && bounded, canReject: canReject && bounded};
}
function reduce(previous, change) {
  if (change?.type === 'snapshot') {
    if (!Number.isSafeInteger(change.revision) || change.revision < 0 || !change.conversationState || typeof change.conversationState !== 'object' || Array.isArray(change.conversationState)) throw Error('INVALID_SNAPSHOT');
    return {revision: change.revision, value: copy(change.conversationState)};
  }
  if (change?.type !== 'patches' || !previous || previous.revision !== change.baseRevision || !Number.isSafeInteger(change.revision) || change.revision <= change.baseRevision || !Array.isArray(change.patches)) throw Error('REVISION_GAP');
  const value = copy(previous.value);
  for (const patch of change.patches) {
    if (!['add', 'remove', 'replace'].includes(patch.op) || !Array.isArray(patch.path) || !patch.path.length || patch.path.some(key => ['__proto__', 'constructor', 'prototype'].includes(key))) throw Error('INVALID_PATCH');
    let parent = value;
    for (const key of patch.path.slice(0, -1)) {
      if (!parent || typeof parent !== 'object' || !Object.hasOwn(parent, key)) throw Error('MISSING_PATH');
      parent = parent[key];
    }
    const key = patch.path.at(-1);
    if (Array.isArray(parent)) {
      if (!Number.isSafeInteger(key) || key < 0 || key > parent.length - (patch.op === 'add' ? 0 : 1)) throw Error('INVALID_INDEX');
      if (patch.op === 'add') parent.splice(key, 0, copy(patch.value));
      else if (patch.op === 'remove') parent.splice(key, 1);
      else parent[key] = copy(patch.value);
    } else if (parent && typeof parent === 'object' && typeof key === 'string') {
      if (patch.op !== 'add' && !Object.hasOwn(parent, key)) throw Error('MISSING_KEY');
      if (patch.op === 'remove') delete parent[key]; else parent[key] = copy(patch.value);
    } else throw Error('INVALID_TARGET');
  }
  return {revision: change.revision, value};
}
function collectTurns(state) {
  const map = new Map();
  for (const [key, turn] of [...Object.entries(state?.turnHistory?.history?.entitiesByKey ?? {}), ...(Array.isArray(state?.turns) ? state.turns : []).map((turn, i) => ['live:' + i, turn])]) {
    if (!turn || !Array.isArray(turn.items)) continue;
    map.set(turn.turnId ?? turn.rootTurnId ?? key, turn);
  }
  return [...map.entries()].map(([key, turn]) => ({...turn, _id: key})).sort((a, b) => (a.turnStartedAtMs ?? 0) - (b.turnStartedAtMs ?? 0));
}
function textOf(value) {
  if (typeof value === 'string') return value;
  if (Array.isArray(value)) return value.map(part => typeof part === 'string' ? part : part?.text ?? (part?.type?.toLowerCase().includes('image') ? '[图片：请通过会话媒体接口读取]' : '')).join('\n');
  return value == null ? '' : JSON.stringify(value, null, 2);
}
function historyPagination(state) {
  const complete = state?.turnHistory?.history?.isComplete;
  // canonical 完整历史完成后，桌面旧分页控制器可能仍保留游标和 hasLoadedOldest=false。
  if (complete === true) return {hasMoreHistory: false, historyComplete: true};
  const pagination = state?.turnsPagination;
  const hasMoreHistory = !!(state?.paginatedHistory?.itemsBackwardsCursor || pagination?.olderCursor
    || pagination?.hasMore === true || pagination?.hasLoadedOldest === false || complete === false);
  // 缺少游标只表示没有续页依据，不能据此宣称整段历史已经完整。
  return {hasMoreHistory, historyComplete: hasMoreHistory ? false : pagination?.hasLoadedOldest === true ? true : null};
}
function viewOf(session) {
  const state = session.current?.value ?? {};
  let truncated = false;
  const bound = value => { const text = textOf(value); if (text.length <= 256 * 1024) return text; truncated = true; return text.slice(0, 256 * 1024) + '\n[单项内容超过 256 Ki 字符，后续内容未展示]'; };
  const rawTurns = collectTurns(state);
  const turns = rawTurns.map(turn => {
    const items = turn.items.filter(item => item && !/reasoning/i.test(item.type ?? '') && !/^(reasoning|analysis)$/i.test(item.phase ?? '')).map((item, index) => {
      const role = item.type === 'userMessage' ? 'user' : item.type === 'agentMessage' ? 'assistant' : 'tool';
      return {id: item.id ?? `${turn._id}:${index}`, type: item.type, role, phase: item.phase ?? null,
        text: bound(role === 'user' ? item.content ?? item.text : role === 'assistant' ? item.text : item.aggregatedOutput ?? item.output ?? item.text ?? item.arguments ?? item.changes ?? ''),
        command: item.command == null ? undefined : bound(item.command), status: item.status ?? (turn.completedItemIds?.[item.id] === true ? 'completed' : turn.completedItemIds?.[item.id] === false ? 'inProgress' : undefined),
        exitCode: item.exitCode, startedAt: item.startedAtMs, durationMs: item.durationMs, changes: item.changes == null ? undefined : bound(item.changes)};
    });
    if (!items.some(item => item.role === 'user') && Array.isArray(turn.params?.input)) {
      const prompt = bound(turn.params.input); if (prompt) items.unshift({id: `${turn._id}:input`, type: 'userMessage', role: 'user', text: prompt});
    }
    return {id: turn.turnId ?? turn._id, clientUserMessageId: turn.params?.clientUserMessageId ?? turn.items.find(i => i.type === 'userMessage')?.clientId ?? null, status: turn.status ?? 'unknown', startedAt: turn.turnStartedAtMs, durationMs: turn.durationMs, items};
  });
  const last = rawTurns.at(-1);
  const approvals = (Array.isArray(state.requests) ? state.requests : []).filter(request =>
    request && request.completed !== true && (/\/requestApproval$/.test(request.method ?? '') || request.method === 'mcpServer/elicitation/request') &&
    (request.params?.threadId == null || request.params.threadId === session.id)
  ).map(request => { const info = approvalInfo(request); return {id: String(request.id), turnId: request.params?.turnId ?? last?.turnId ?? null,
    kind: info.kind, origin: info.origin, title: info.kind === 'command' ? '等待批准执行命令' : info.kind === 'file' ? '等待批准修改文件' : info.kind === 'mcp' ? '等待浏览器 / 工具授权' : '等待权限审批',
    command: bound(request.params?.command ?? request.params?.changes ?? ''), reason: bound(request.params?.reason ?? request.params?.message ?? ''), state: 'pending', canApprove: info.canApprove, canReject: info.canReject}; });
  const questions = (state.requests ?? []).filter(request => request?.completed !== true && request?.method === 'item/tool/requestUserInput' && (request.params?.threadId == null || request.params.threadId === session.id)).map(request => ({id: String(request.id), requestId: String(request.id), turnId: request.params?.turnId ?? last?.turnId ?? null, questions: (request.params?.questions ?? []).map(q => ({id: q.id, header: q.header, question: q.question, options: q.options ?? [], isOther: q.isOther})), canReply: Array.isArray(request.params?.questions) && !request.params.questions.some(q => q.isSecret)}));
  let activity = 'idle';
  if (active(last?.status)) {
    const pending = [...last.items].reverse().find(item => last.completedItemIds?.[item.id] === false || item.status === 'inProgress');
    activity = pending?.type === 'reasoning' ? 'thinking' : pending?.type === 'commandExecution' ? 'command' : pending?.type === 'fileChange' ? 'editing' : pending?.type === 'agentMessage' ? 'responding' : 'processing';
  }
  if ((approvals.length || questions.length) && active(last?.status)) activity = 'waiting';
  return {id: session.id, title: state.title || '未命名对话', model: state.latestModel ?? state.latestThreadSettings?.model ?? '', reasoningEffort: state.latestReasoningEffort ?? '',
    status: activity === 'waiting' ? 'waiting' : last?.status ?? 'unknown', activeTurnId: active(last?.status) ? last?.turnId ?? null : null, activity, approvals, questions, revision: session.current?.revision ?? null, patchCount: session.patchCount, snapshotCount: session.snapshotCount,
    lastEventAt: session.lastEventAt, connected: !!session.connected, notice: session.notice || (truncated ? '部分超长条目达到展示上限，已在条目内标记。' : ''),
    ...historyPagination(state), turns};
}
module.exports = {UUID, reduce, collectTurns, viewOf, approvalInfo, active, historyPagination};
