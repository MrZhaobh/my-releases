'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const {AppServerSession, resolveBinary, failure} = require('./app-server-session.cjs');
const {usageResult} = require('./usage.cjs');

const DEFAULT_MODEL = 'gpt-6-luna';
const TERMINAL = new Set(['completed', 'cancelled', 'failed']);
const CAPABILITIES = Object.freeze({streaming:true, interrupt:true, media:false, visualization:false, attachment:false});
const idOkay = value => typeof value === 'string' && value.length > 0 && value.length <= 200;
const hash = value => crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex');
const threadStatus = snapshot => ['running', 'waiting'].includes(snapshot.status) ? 'active' : snapshot.status === 'unknown' ? 'unknown' : 'idle';

/** 默认只列当前连接拥有的会话；用户主动导入时单独读取全局候选元数据并复制。 */
class CodexRuntime {
  constructor(config = {}) {
    this.config = config;
    this.sandbox = config.runtimeSandbox ?? 'read-only';
    if (!['read-only', 'workspace-write', 'danger-full-access'].includes(this.sandbox)) throw failure('runtimeSandbox 无效。', 'BAD_INPUT', 400);
    this.maxProcesses = config.runtimeMaxProcesses ?? 2;
    if (!Number.isInteger(this.maxProcesses) || this.maxProcesses < 1 || this.maxProcesses > 4) throw failure('runtimeMaxProcesses 必须为 1 至 4。', 'BAD_INPUT', 400);
    this.idleMs = config.runtimeIdleMs ?? 300000;
    if (!Number.isInteger(this.idleMs) || this.idleMs < 1000 || this.idleMs > 86400000) throw failure('runtimeIdleMs 必须为 1000 至 86400000。', 'BAD_INPUT', 400);
    this.scope = hash(config.connectionScope ?? 'default');
    this.root = path.join(path.resolve(config.dataDirectory ?? path.join(__dirname, '..', '.local', 'runtime')), 'owned-v1', this.scope);
    fs.mkdirSync(this.root, {recursive:true});
    this.indexFile = path.join(this.root, 'index.json');
    this.streamId = crypto.randomUUID(); this.sequences = new Map(); this.observed = new Map();
    this.sessions = new Map(); this.leases = new Map(); this.closed = false; this.poolLock = Promise.resolve();
    this.records = new Map(); this.creates = new Map(); this.imports = new Map(); this.createPromises = new Map(); this.importPromises = new Map(); this.cursorSecret = crypto.randomBytes(32).toString('hex');
    this.projects = (config.projects ?? []).map(project => {
      if (!idOkay(project?.id) || typeof project.name !== 'string' || !path.isAbsolute(project.path ?? '')) throw failure('项目配置需要有效的 id、name、绝对 path。', 'BAD_INPUT', 400);
      return {id:project.id, name:project.name, path:path.resolve(project.path)};
    });
    if (new Set(this.projects.map(project => project.id)).size !== this.projects.length) throw failure('项目 ID 重复。', 'BAD_INPUT', 400);
    try {
      const saved = JSON.parse(fs.readFileSync(this.indexFile, 'utf8'));
      if (saved.version !== 1 || !Array.isArray(saved.records) || !Array.isArray(saved.creates) || typeof saved.cursorSecret !== 'string') throw new Error('invalid index');
      this.cursorSecret = saved.cursorSecret;
      for (const record of saved.records) {
        if (!/^[a-f0-9-]{36}$/i.test(record.ownedId ?? '') || (record.threadId !== null && !idOkay(record.threadId)) || typeof record.cwd !== 'string' || !path.isAbsolute(record.cwd)) throw new Error('invalid owned record');
        if (record.status === 'active') { record.status = 'unknown'; record.turnStatus = 'unknown'; }
        this.records.set(record.ownedId, record);
      }
      for (const [id, entry] of saved.creates) {
        if (!idOkay(id) || !this.records.has(entry.ownedId) || typeof entry.hash !== 'string') throw new Error('invalid request record');
        this.creates.set(id, entry);
      }
      for (const [id, entry] of saved.imports ?? []) {
        if (!idOkay(id) || !this.records.has(entry.ownedId) || typeof entry.hash !== 'string' || !['new','forking','releasing','ready'].includes(entry.stage)) throw new Error('invalid import record');
        this.imports.set(id, entry);
      }
    } catch (error) { if (error.code !== 'ENOENT') throw failure('自管会话索引不可读，已停止恢复。', 'STATE_CORRUPT', 503); }
    this.sweeper = setInterval(() => this._reap().catch(error => { this.lastError = error.message; }), Math.min(this.idleMs, 30000));
    this.sweeper.unref?.();
  }

  setEventListener(listener) { this.listener = typeof listener === 'function' ? listener : null; }

  _save() {
    fs.writeFileSync(this.indexFile + '.tmp', JSON.stringify({version:1, cursorSecret:this.cursorSecret, records:[...this.records.values()], creates:[...this.creates], imports:[...this.imports]}), {mode:0o600});
    fs.renameSync(this.indexFile + '.tmp', this.indexFile);
  }

  _cursor(threadId) { return `${this.streamId}:${this.sequences.get(threadId) ?? 0}`; }

  _emit(threadId, data) {
    const seq = (this.sequences.get(threadId) ?? 0) + 1;
    if (!Number.isSafeInteger(seq)) throw failure('事件序列已达上限，请重启运行时。', 'SEQUENCE_LIMIT');
    this.sequences.set(threadId, seq);
    const event = {streamId:this.streamId, seq, threadId, ...data, at:Date.now()};
    try { this.listener?.(event); } catch { /* 消费者故障不能中断 app-server 通知。 */ }
  }

  _snapshot(record, snapshot) {
    if (this.closed || !snapshot.threadId) return;
    const first = !record.threadId;
    if (record.threadId && record.threadId !== snapshot.threadId) throw failure('自管会话标识改变。', 'INVALID_THREAD', 502);
    record.threadId = snapshot.threadId;
    const previous = this.observed.get(record.threadId);
    for (const turn of snapshot.turns) {
      const oldTurn = previous?.turns.find(value => value.id === turn.id);
      // 新回合在条目之前建立；所有终态在条目之后发送。
      if (!TERMINAL.has(turn.status) && (!oldTurn || oldTurn.status !== turn.status)) this._emit(record.threadId, {type:'turn.upsert', turnId:turn.id, turnStatus:turn.status});
      for (const item of turn.items) {
        const old = oldTurn?.items.find(value => value.id === item.id);
        if (old && JSON.stringify(old) === JSON.stringify(item)) continue;
        const {text, ...meta} = item, {text:oldText, ...oldMeta} = old ?? {};
        if (old && typeof text === 'string' && typeof oldText === 'string' && text.startsWith(oldText) && JSON.stringify(meta) === JSON.stringify(oldMeta)) this._emit(record.threadId, {type:'item.delta', turnId:turn.id, itemId:item.id, delta:text.slice(oldText.length)});
        else this._emit(record.threadId, {type:'item.upsert', turnId:turn.id, item:structuredClone(item)});
      }
      if (TERMINAL.has(turn.status) && (!oldTurn || oldTurn.status !== turn.status)) this._emit(record.threadId, {type:'turn.upsert', turnId:turn.id, turnStatus:turn.status});
    }
    if (!previous || previous.status !== snapshot.status || previous.connection !== snapshot.connection || previous.notice !== snapshot.notice) this._emit(record.threadId, {type:'status', status:snapshot.status, notice:snapshot.notice ?? ''});
    this.observed.set(record.threadId, structuredClone(snapshot));
    if (!previous || JSON.stringify(previous.turns) !== JSON.stringify(snapshot.turns)) record.updatedAt = Date.now();
    record.status = threadStatus(snapshot); record.turnStatus = snapshot.turns.at(-1)?.status ?? null;
    if (first || previous?.status !== snapshot.status) this._save();
  }

  _session(record) {
    let session = this.sessions.get(record.ownedId);
    if (!session) {
      const options = {stateDir:path.join(this.root, record.ownedId), model:record.model ?? DEFAULT_MODEL, cwd:record.cwd, sandbox:record.sandbox ?? this.sandbox, threadId:record.threadId ?? undefined, binary:this.config.codexBinary, spawn:this.config.runtimeSpawn, onSnapshot:snapshot => this._snapshot(record, snapshot)};
      session = this.config.runtimeSessionFactory ? this.config.runtimeSessionFactory(options) : new AppServerSession(options);
      this.sessions.set(record.ownedId, session);
      const snapshot = session.getSnapshot();
      if (snapshot.threadId && snapshot.turns.length) this._snapshot(record, snapshot);
    }
    return session;
  }

  _record(threadId) {
    if (!idOkay(threadId)) throw failure('会话 ID 无效。', 'BAD_INPUT', 400);
    const record = [...this.records.values()].find(value => value.threadId === threadId);
    if (!record) throw failure('没有找到当前连接创建的会话。', 'NOT_FOUND', 404);
    return record;
  }

  _running(session) { return !!session.child && !session.child.exited; }
  _busy(session) { return session.sending || session.activeTurn || session.deliveryUnknown || (this.leases.get(session) ?? 0) > 0; }

  async _locked(action) {
    const previous = this.poolLock;
    let unlock; this.poolLock = new Promise(resolve => { unlock = resolve; });
    await previous;
    try { return await action(); } finally { unlock(); }
  }

  async _lease(session, action) {
    await this._locked(async () => {
      if (this.closed) throw failure('自管运行时已关闭。', 'CLOSED', 503);
      if (!this._running(session)) {
        const running = [...this.sessions.values(), ...(this.control ? [this.control] : [])].filter(value => this._running(value));
        if (running.length >= this.maxProcesses) {
          const victim = running.filter(value => value !== session && !this._busy(value)).sort((a, b) => (a.lastUsed ?? 0) - (b.lastUsed ?? 0))[0];
          if (!victim) throw failure('自管 Codex 进程已达并发上限，请等待其他回合完成。', 'PROCESS_LIMIT', 409);
          await victim.hibernate();
        }
      }
      this.leases.set(session, (this.leases.get(session) ?? 0) + 1);
      // 启动在锁内进行，避免两个尚未持有 child 的租约越过进程限额。
      try { await session.connect(); } catch (error) { this.leases.set(session, this.leases.get(session) - 1); throw error; }
    });
    try { if (this.closed) throw failure('自管运行时已关闭。', 'CLOSED', 503); return await action(session); }
    finally { session.lastUsed = Date.now(); this.leases.set(session, (this.leases.get(session) ?? 1) - 1); }
  }

  async _control(action) {
    const connected = [...this.sessions.values()].find(value => this._running(value) && value.ready);
    if (connected) return this._lease(connected, action);
    if (!this.control) {
      const options = {stateDir:path.join(this.root, 'control'), controlOnly:true, binary:this.config.codexBinary, spawn:this.config.runtimeSpawn};
      this.control = this.config.runtimeSessionFactory ? this.config.runtimeSessionFactory(options) : new AppServerSession(options);
    }
    return this._lease(this.control, action);
  }

  async _reap(now = Date.now()) {
    await this._locked(async () => {
      if (this.closed) return;
      for (const session of [...this.sessions.values(), ...(this.control ? [this.control] : [])]) if (this._running(session) && !this._busy(session) && now - (session.lastUsed ?? now) >= this.idleMs) await session.hibernate();
    });
  }

  _encode(value) {
    const body = Buffer.from(JSON.stringify(value)).toString('base64url');
    return body + '.' + crypto.createHmac('sha256', this.cursorSecret).update(body).digest('base64url');
  }

  _decode(cursor, kind, threadId) {
    if (typeof cursor !== 'string' || cursor.length > 2048) throw failure('分页游标无效。', 'BAD_INPUT', 400);
    const [body, signature, extra] = cursor.split('.');
    const expected = crypto.createHmac('sha256', this.cursorSecret).update(body ?? '').digest('base64url');
    if (!body || !signature || extra !== undefined || signature.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) throw failure('分页游标签名无效。', 'BAD_INPUT', 400);
    let data; try { data = JSON.parse(Buffer.from(body, 'base64url').toString('utf8')); } catch { throw failure('分页游标无效。', 'BAD_INPUT', 400); }
    if (data.kind !== kind || data.scope !== this.scope || (threadId !== undefined && data.threadId !== threadId)) throw failure('分页游标不属于此请求。', 'BAD_INPUT', 400);
    return data;
  }

  _threadRow(record) {
    const session = this.sessions.get(record.ownedId);
    const snapshot = session?.getSnapshot();
    return {id:record.threadId, title:record.title || '未命名会话', preview:record.preview ?? '', status:snapshot?.turns.length ? threadStatus(snapshot) : record.status ?? 'unknown', updatedAt:record.updatedAt, cwd:record.cwd, projectName:record.projectName ?? null, pinned:false, ...(record.imported ? {imported:true, originThreadId:record.originThreadId, importState:record.importState} : {})};
  }

  async _models() {
    if (this.modelCache && Date.now() - this.modelCache.fetchedAt < 60000) return this.modelCache;
    const rows = await this._control(async session => {
      const result = []; let cursor;
      for (let page = 0; page < 100; page++) {
        const response = await session.rpc('model/list', {includeHidden:true, ...(cursor ? {cursor} : {})});
        result.push(...(response.data ?? []));
        if (!response.nextCursor) return result;
        if (response.nextCursor === cursor) throw failure('模型目录分页游标没有前进。', 'MODELS_UNAVAILABLE', 502);
        cursor = response.nextCursor;
      }
      throw failure('模型目录超过分页上限。', 'MODELS_UNAVAILABLE', 502);
    });
    const models = rows.map(row => ({id:row.model ?? row.id, displayName:row.displayName ?? row.model ?? row.id, description:row.description ?? '', reasoningEfforts:(row.supportedReasoningEfforts ?? []).map(value => ({value:typeof value === 'string' ? value : value.reasoningEffort, label:typeof value === 'string' ? value : value.reasoningEffort})), defaultReasoningEffort:row.defaultReasoningEffort ?? null, isDefault:(row.model ?? row.id) === DEFAULT_MODEL})).filter(row => idOkay(row.id));
    if (!models.length) throw failure('当前 Codex 未返回可用模型。', 'MODELS_UNAVAILABLE', 503);
    this.modelCache = {models, source:'app-server:model/list', fetchedAt:Date.now(), stale:false, capabilities:{canOverrideModel:true, canOverrideThinking:models.some(model => model.reasoningEfforts.length > 0), canSetSpeed:false}};
    return structuredClone(this.modelCache);
  }

  async _settings(args, defaultModel = DEFAULT_MODEL) {
    if (args.thinking !== undefined && args.model === undefined) throw failure('自定义推理配置需要同时选择模型。', 'INVALID_THINKING', 400);
    const modelId = args.model ?? defaultModel;
    const catalog = await this._models();
    const model = catalog.models.find(value => value.id === modelId);
    if (!model) throw failure('所选模型不可用。', 'INVALID_MODEL', 400);
    const thinking = args.thinking ?? (model.reasoningEfforts.some(value => value.value === 'low') ? 'low' : model.defaultReasoningEffort ?? model.reasoningEfforts[0]?.value ?? 'low');
    if (args.thinking !== undefined && !model.reasoningEfforts.some(value => value.value === args.thinking)) throw failure('所选推理配置不适用于该模型。', 'INVALID_THINKING', 400);
    return {model:modelId, thinking};
  }

  _validateSend(args) {
    if (typeof args.prompt !== 'string' || !args.prompt.trim() || args.prompt.length > 16000 || !idOkay(args.requestId)) throw failure('请输入 1 至 16000 字的消息及有效 requestId。', 'BAD_INPUT', 400);
  }

  async _create(args) {
    this._validateSend(args);
    if (this.imports.has(args.requestId)) throw failure('requestId 已用于导入请求。', 'REQUEST_CONFLICT', 409);
    const fingerprint = hash({prompt:args.prompt, projectId:args.projectId ?? null, model:args.model ?? DEFAULT_MODEL, thinking:args.thinking ?? null, title:args.title ?? null});
    const prior = this.creates.get(args.requestId);
    if (prior && prior.hash !== fingerprint) throw failure('requestId 已用于不同创建请求。', 'REQUEST_CONFLICT', 409);
    if (prior?.result) return structuredClone(prior.result);
    if (this.createPromises.has(args.requestId)) return this.createPromises.get(args.requestId);
    const task = (async () => {
      const settings = await this._settings(args);
      let entry = this.creates.get(args.requestId), record = entry && this.records.get(entry.ownedId);
      if (!record) {
        if (this.creates.size >= 10000) throw failure('创建请求记录已达上限。', 'REQUEST_LIMIT', 409);
        const project = args.projectId == null ? null : this.projects.find(value => value.id === args.projectId);
        if (args.projectId != null && !project) throw failure('项目不在当前配置中。', 'NOT_FOUND', 404);
        const ownedId = crypto.randomUUID();
        record = {ownedId, threadId:null, model:settings.model, title:typeof args.title === 'string' ? args.title.slice(0,120) : args.prompt.trim().slice(0,80), preview:args.prompt.slice(0,240), cwd:project?.path ?? path.join(this.root, ownedId, 'workspace'), projectId:project?.id ?? null, projectName:project?.name ?? null, createdAt:Date.now(), updatedAt:Date.now(), status:'unknown'};
        entry = {hash:fingerprint, ownedId};
        this.records.set(ownedId, record); this.creates.set(args.requestId, entry); this._save();
      }
      const session = this._session(record);
      const accepted = await this._lease(session, value => value.send(args.prompt, args.requestId, settings));
      record.threadId = accepted.threadId;
      entry.result = {...accepted, desktopRegistration:'ready', _submission:{prompt:args.prompt, turnId:accepted.turnId, beforeTurnId:null}};
      this._save(); return structuredClone(entry.result);
    })();
    this.createPromises.set(args.requestId, task);
    try { return await task; } finally { this.createPromises.delete(args.requestId); }
  }

  async _importCandidates(args) {
    const search = args.search ?? '';
    if (typeof search !== 'string' || search.length > 200) throw failure('导入搜索条件最多 200 字。', 'BAD_INPUT', 400);
    const anchor = args.cursor ? this._decode(args.cursor, 'import-candidates') : null;
    if (anchor && (anchor.search !== search || typeof anchor.provider !== 'string' || anchor.provider.length > 800)) throw failure('导入游标与搜索条件不一致。', 'BAD_INPUT', 400);
    const response = await this._control(session => session.rpc('thread/list', {limit:30, archived:false, ...(search ? {searchTerm:search} : {}), ...(anchor ? {cursor:anchor.provider} : {})}));
    if (!Array.isArray(response.data) || response.data.length > 30) throw failure('导入候选目录返回数量或格式无效。', 'INVALID_RESPONSE', 502);
    const provider = response.nextCursor;
    if (provider != null && (typeof provider !== 'string' || !provider || provider.length > 800 || provider === anchor?.provider)) throw failure('导入候选目录分页无效。', 'INVALID_RESPONSE', 502);
    const threads = response.data.filter(row => idOkay(row?.id)).map(row => ({id:row.id, title:typeof row.name === 'string' && row.name ? row.name.slice(0,200) : typeof row.preview === 'string' && row.preview ? row.preview.slice(0,200) : '未命名会话', updatedAt:Number.isFinite(row.updatedAt) ? (row.updatedAt < 1e12 ? row.updatedAt * 1000 : row.updatedAt) : null, cwd:typeof row.cwd === 'string' ? row.cwd : null, ...(typeof row.source === 'string' ? {sourceKind:row.source} : typeof row.source?.type === 'string' ? {sourceKind:row.source.type} : {})}));
    return {threads, hasMore:!!provider, nextCursor:provider ? this._encode({kind:'import-candidates', scope:this.scope, search, provider}) : null};
  }

  async _importThread(args) {
    if (!idOkay(args.requestId) || !idOkay(args.sourceThreadId) || (args.title !== undefined && (typeof args.title !== 'string' || args.title.length > 120))) throw failure('导入需要有效 requestId、源会话 ID，标题最多 120 字。', 'BAD_INPUT', 400);
    if (this.creates.has(args.requestId)) throw failure('requestId 已用于创建请求。', 'REQUEST_CONFLICT', 409);
    const fingerprint = hash({sourceThreadId:args.sourceThreadId, title:args.title ?? null});
    const prior = this.imports.get(args.requestId);
    if (prior && prior.hash !== fingerprint) throw failure('requestId 已用于不同导入请求。', 'REQUEST_CONFLICT', 409);
    if (prior?.result) return structuredClone(prior.result);
    if (this.importPromises.has(args.requestId)) return this.importPromises.get(args.requestId);
    const task = (async () => {
      let entry = this.imports.get(args.requestId), record = entry && this.records.get(entry.ownedId);
      if (!record) {
        if (this.imports.size >= 10000) throw failure('导入请求记录已达上限。', 'REQUEST_LIMIT', 409);
        const ownedId = crypto.randomUUID();
        record = {ownedId, threadId:null, originThreadId:args.sourceThreadId, imported:true, importState:'new', model:DEFAULT_MODEL, sandbox:'read-only', title:args.title || '导入的会话副本', preview:'从桌面历史复制；后续不持续同步。', cwd:path.join(this.root, ownedId, 'workspace'), projectId:null, projectName:null, createdAt:Date.now(), updatedAt:Date.now(), status:'unknown'};
        entry = {hash:fingerprint, ownedId, stage:'new'};
        this.records.set(ownedId, record); this.imports.set(args.requestId, entry); this._save();
      }
      if (entry.stage === 'forking' && !record.threadId) throw failure('上次复制的接受结果未知；已阻止再次分叉，请核对本机导入记录。', 'DELIVERY_UNKNOWN', 409);
      await this._control(async session => {
        if (!record.threadId) {
          fs.mkdirSync(record.cwd, {recursive:true});
          entry.stage = record.importState = 'forking'; this._save();
          let response;
          try {
            response = await session.rpc('thread/fork', {threadId:record.originThreadId, model:DEFAULT_MODEL, cwd:record.cwd, sandbox:'read-only', approvalPolicy:'never', ephemeral:false});
          } catch (error) {
            if (error.code === 'RPC_ERROR') { entry.stage = record.importState = 'new'; this._save(); }
            throw error;
          }
          if (!idOkay(response.thread?.id) || response.thread.id === record.originThreadId) throw failure('Codex 未返回有效副本 ID，复制结果未知。', 'DELIVERY_UNKNOWN', 502);
          record.threadId = response.thread.id; entry.stage = record.importState = 'releasing';
          this._save();
        }
        // 先释放创建副本的 writer，再由专属 Session resume；失败后只重试此 ID。
        try { await session.unsubscribeOwned(record.threadId, {adopt:true}); }
        catch (error) { record.importState = 'uncertain'; entry.stage = 'releasing'; this._save(); throw failure('会话副本已保存，但 writer 释放尚未确认；使用同一请求重试恢复。', 'IMPORT_UNCERTAIN', 503); }
      });
      const session = this._session(record);
      await this._lease(session, () => {});
      record.importState = entry.stage = 'ready';
      entry.result = {threadId:record.threadId, turnId:null, accepted:true, originThreadId:record.originThreadId, imported:true, desktopRegistration:'ready'};
      this._save(); return structuredClone(entry.result);
    })();
    this.importPromises.set(args.requestId, task);
    try { return await task; } finally { this.importPromises.delete(args.requestId); }
  }

  async _read(args) {
    const record = this._record(args.threadId), session = this._session(record);
    const {snapshot, eventCursor} = await this._lease(session, value => ({snapshot:value.getSnapshot(), eventCursor:this._cursor(record.threadId)}));
    const limit = Math.max(1, Math.min(Number.isInteger(args.turnLimit) ? args.turnLimit : 10, 10));
    const anchor = args.cursor ? this._decode(args.cursor, 'history', args.threadId) : null;
    let end = snapshot.turns.length;
    if (anchor) {
      if (!idOkay(anchor.before)) throw failure('历史游标无效。', 'BAD_INPUT', 400);
      end = snapshot.turns.findIndex(turn => turn.id === anchor.before);
      if (end < 0) throw failure('历史游标已失效，请刷新。', 'CURSOR_EXPIRED', 409);
    }
    const start = Math.max(0, end - limit), turns = snapshot.turns.slice(start, end);
    if (Buffer.byteLength(JSON.stringify(turns), 'utf8') > 2 * 1024 * 1024) throw failure('当前历史页超过 2 MiB，请减少 turnLimit；单回合过大时需在本机读取。', 'RESPONSE_TOO_LARGE', 413);
    return {id:record.threadId, title:record.title, status:threadStatus(snapshot), cwd:record.cwd, source:'app-server', turns, hasMore:start > 0, nextCursor:start > 0 ? this._encode({kind:'history', scope:this.scope, threadId:record.threadId, before:turns[0].id}) : null, eventCursor, ...(record.imported ? {imported:true, originThreadId:record.originThreadId, importState:record.importState} : {}), ...(snapshot.notice ? {notice:snapshot.notice} : {})};
  }

  async execute(operation, args = {}) {
    if (this.closed) throw failure('自管运行时已关闭。', 'CLOSED', 503);
    if (operation === 'ping') return {pong:true, fetchedAt:Date.now()};
    if (operation === 'projects') return {projects:structuredClone(this.projects)};
    if (operation === 'models') return this._models();
    if (operation === 'importCandidates') return this._importCandidates(args);
    if (operation === 'importThread') return this._importThread(args);
    if (operation === 'usage') return this._control(async session => usageResult(await session.rpc('account/rateLimits/read')));
    if (operation === 'threads') {
      const anchor = args.cursor ? this._decode(args.cursor, 'threads') : null;
      if (anchor && (!Number.isSafeInteger(anchor.at) || !idOkay(anchor.id))) throw failure('目录游标无效。', 'BAD_INPUT', 400);
      const limit = Math.max(1, Math.min(Number.isInteger(args.limit) ? args.limit : 30, 50));
      const all = [...this.records.values()].filter(record => record.threadId && (!anchor || record.updatedAt < anchor.at || (record.updatedAt === anchor.at && record.threadId < anchor.id))).sort((a,b) => b.updatedAt - a.updatedAt || b.threadId.localeCompare(a.threadId));
      const page = all.slice(0,limit), hasMore = all.length > limit;
      return {threads:page.map(record => this._threadRow(record)), hasMore, nextCursor:hasMore ? this._encode({kind:'threads', scope:this.scope, at:page.at(-1).updatedAt, id:page.at(-1).threadId}) : null, source:'owned-app-server-index', fetchedAt:Date.now()};
    }
    if (operation === 'statuses') {
      const ids = args.threadIds ?? args.ids;
      if (!Array.isArray(ids) || ids.length > 100 || ids.some(id => !idOkay(id))) throw failure('状态查询会话列表无效。', 'BAD_INPUT', 400);
      return {threads:ids.map(id => { const record = this._record(id); const session = this._session(record); const snapshot = session.getSnapshot(); return {id, status:snapshot.turns.length ? threadStatus(snapshot) : record.status ?? 'unknown', turnStatus:snapshot.turns.at(-1)?.status ?? record.turnStatus ?? null, updatedAt:record.updatedAt}; }), fetchedAt:Date.now()};
    }
    if (operation === 'create') return this._create(args);
    if (operation === 'read') return this._read(args);
    if (['media', 'visualization', 'attachment'].includes(operation)) throw failure('自管后端暂不支持此内容能力。', 'UNSUPPORTED_CAPABILITY', 400);
    const record = this._record(args.threadId), session = this._session(record);
    if (operation === 'reconcile') return this._lease(session, () => ({threadId:record.threadId, desktopRegistration:'ready'}));
    if (operation === 'progress') {
      const snapshot = await this._lease(session, value => value.getSnapshot()), turn = snapshot.turns.at(-1), assistant = [...(turn?.items ?? [])].reverse().find(item => item.role === 'assistant');
      return {id:record.threadId, status:threadStatus(snapshot), turnId:turn?.id ?? null, turnStatus:turn?.status ?? null, text:assistant?.text ?? '', phase:assistant?.phase ?? null, cursor:this._cursor(record.threadId), eventCursor:this._cursor(record.threadId), textTruncated:false};
    }
    if (operation === 'interrupt') {
      if (!idOkay(args.requestId) || !idOkay(args.turnId)) throw failure('中断需要有效 requestId 和 turnId。', 'BAD_INPUT', 400);
      return this._lease(session, value => value.interrupt(args.turnId));
    }
    if (operation === 'send') {
      this._validateSend(args);
      const settings = await this._settings(args, record.model ?? DEFAULT_MODEL);
      const beforeTurnId = session.getSnapshot().turns.at(-1)?.id ?? null;
      const accepted = await this._lease(session, value => value.send(args.prompt, args.requestId, settings));
      return {...accepted, _submission:{prompt:args.prompt, turnId:accepted.turnId, beforeTurnId}};
    }
    throw failure('不支持的自管后端操作。', 'BAD_INPUT', 400);
  }

  async getStatus() {
    try {
      if (this.closed) throw failure('自管运行时已关闭。', 'CLOSED', 503);
      if (!this.config.runtimeSpawn && !this.config.runtimeSessionFactory && !this.config.codexBinary) resolveBinary();
      const running = [...this.sessions.values(), ...(this.control ? [this.control] : [])].filter(session => this._running(session));
      // 已建立的所属会话就是当前自有连接证据，心跳不能排队抢占模型运行槽位。
      const ready = running.find(session => session.ready && session.getSnapshot().threadId);
      if (ready) return {backend:'app-server', capabilities:{...CAPABILITIES}, connected:true, authenticated:true, pid:ready.child.proc.pid ?? null, processes:running.length, maxProcesses:this.maxProcesses, atCapacity:running.length >= this.maxProcesses, error:null};
      const account = await this._control(session => session.rpc('account/read', {refreshToken:false}));
      const authenticated = !!account.account || account.requiresOpenaiAuth === false;
      const owned = [...this.sessions.values(), ...(this.control ? [this.control] : [])].filter(session => this._running(session));
      return {backend:'app-server', capabilities:{...CAPABILITIES}, connected:authenticated, authenticated, pid:owned[0]?.child?.proc?.pid ?? null, processes:owned.length, maxProcesses:this.maxProcesses, atCapacity:owned.length >= this.maxProcesses, error:authenticated ? null : 'Codex CLI 尚未登录，请在本机完成登录。'};
    } catch (error) { return {backend:'app-server', capabilities:{...CAPABILITIES}, connected:false, authenticated:false, pid:null, error:error.message}; }
  }

  async close() {
    if (this.closePromise) return this.closePromise;
    this.closed = true; clearInterval(this.sweeper);
    this.closePromise = (async () => {
      const results = await Promise.allSettled([...this.sessions.values(), ...(this.control ? [this.control] : [])].map(session => session.close()));
      this._save();
      const failed = results.filter(result => result.status === 'rejected');
      if (failed.length) throw new AggregateError(failed.map(result => result.reason), '自有进程尚未全部确认退出。');
    })();
    try { await this.closePromise; } catch (error) { this.closePromise = null; throw error; }
  }
}

module.exports = {CodexRuntime};
