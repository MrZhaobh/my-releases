'use strict';

const {BridgeError}=require('./errors.cjs');
const MAX_INDEX_BYTES=2*1024*1024;
const failure=(code,message)=>new BridgeError(code,message);
// 只供判断附件类型，不访问文件、登记媒体或伪造用户条目身份。
const normalizationOptions={registerImage:()=>({name:'图片'}),registerAttachment:()=>({name:'文件'})};

function indexItem(normalized){
 const segments=normalized.segments??[],labels=[];
 if(normalized.images?.length||segments.some(p=>p.type==='image'))labels.push('图片附件');
 if(segments.some(p=>p.type==='file'))labels.push('文件附件');
 // 类型摘要参与索引资格判断，不伪造能被当作下载凭据的附件ID。
 return{type:normalized.type,role:'user',phase:normalized.phase??null,
  text:(normalized.text??'')+(labels.length?'\n\n'+labels.join('、'):''),
  ...(typeof normalized.id==='string'?{id:normalized.id}:{}),
  ...(typeof normalized.clientRequestId==='string'?{clientRequestId:normalized.clientRequestId}:{})};
}

class QuestionIndexBuilder{
 constructor(id,maximum=MAX_INDEX_BYTES){this.id=id;this.maximum=maximum;this.turns=new Map();this.bytes=128+Buffer.byteLength(JSON.stringify(id));}
 touch(turnId){
  let turn=this.turns.get(turnId);
  if(!turn){turn={id:turnId,items:[],seen:new Set()};this.turns.set(turnId,turn);this.bytes+=Buffer.byteLength(JSON.stringify({id:turnId,items:[]}))+1;}
  if(this.bytes>this.maximum)throw failure('RESPONSE_TOO_LARGE','完整提问索引超过2 MiB上限，不能返回部分总数。');
  return turn;
 }
 add(turnId,item,identity){
  const turn=this.touch(turnId);
  if(identity!==undefined&&turn.seen.has(identity))return;
  if(identity!==undefined)turn.seen.add(identity);
  // 保留完整规范化用户文本：实际提问可能在很长的指令封套末尾，不能先截断。
  const value=indexItem(item);
  this.bytes+=Buffer.byteLength(JSON.stringify(value))+1;
  if(this.bytes>this.maximum)throw failure('RESPONSE_TOO_LARGE','完整提问索引超过2 MiB上限，不能返回部分总数。');
  turn.items.push(value);
 }
 finish(order=[...this.turns.keys()]){
  const emitted=new Set(),turns=[];
  for(const key of order){if(emitted.has(key)||!this.turns.has(key))continue;emitted.add(key);const t=this.turns.get(key);turns.push({id:t.id,items:t.items});}
  const result={id:this.id,turns,hasMore:false,nextCursor:null,questionIndexOnly:true};
  if(Buffer.byteLength(JSON.stringify(result))>this.maximum)throw failure('RESPONSE_TOO_LARGE','完整提问索引超过2 MiB上限。');
  return result;
 }
}

function advanceCursor(page,seen){
 if(!page||!Object.hasOwn(page,'nextCursor')||!(page.nextCursor===null||typeof page.nextCursor==='string'&&page.nextCursor.length>0&&page.nextCursor.length<=4096))
  throw failure('INVALID_HISTORY','提问索引分页游标缺失或无效。');
 if(page.nextCursor!==null){if(seen.has(page.nextCursor))throw failure('INVALID_HISTORY','提问索引分页游标循环。');seen.add(page.nextCursor);}
 return page.nextCursor;
}

async function sharedQuestionIndex(client,id,normalizeHistory,maximum=MAX_INDEX_BYTES){
 const builder=new QuestionIndexBuilder(id,maximum),turnCursors=new Set(),seen=new Set();let cursor=null,pages=0;
 // 完全空回合不出现在items/list中，仍须保留其原生身份供已有回执补充提问。
 // 全会话元数据仅扫描一次，不按正文的每十轮分页反复枚举。
 do{
  if(++pages>100000)throw failure('INVALID_HISTORY','提问索引页数超出安全上限。');
  const response=await client.request('thread/turns/list',{threadId:id,limit:50,sortDirection:'asc',itemsView:'notLoaded',...(cursor?{cursor}:{})},60000);
  if(!Array.isArray(response?.data))throw failure('INVALID_HISTORY','提问索引回合元数据无效。');
  const next=advanceCursor(response,turnCursors);
  for(const turn of response.data){
   if(typeof turn?.id!=='string'||!turn.id)throw failure('INVALID_HISTORY','提问索引缺少真实回合身份。');
   builder.touch(turn.id);
  }
  cursor=next;
 }while(cursor!==null);
 pages=0;
 do{
  if(++pages>100000)throw failure('INVALID_HISTORY','提问索引页数超出安全上限。');
  const response=await client.request('thread/items/list',{threadId:id,limit:16,sortDirection:'asc',...(cursor?{cursor}:{})},60000);
  if(!Array.isArray(response?.data))throw failure('INVALID_HISTORY','提问索引条目页无效。');
  const next=advanceCursor(response,seen);
  for(const entry of response.data){
   if(typeof entry?.turnId!=='string'||!entry.turnId||typeof entry.item?.id!=='string'||!entry.item.id)
    throw failure('INVALID_HISTORY','提问索引缺少真实回合或条目身份。');
   if(!builder.turns.has(entry.turnId))throw failure('INVALID_HISTORY','统计期间出现新回合，请重新核验提问索引。');
   if(entry.item.type!=='userMessage')continue;
   const normalized=normalizeHistory({thread:{id},turns:[{id:entry.turnId,items:[entry.item]}]},normalizationOptions).turns[0].items[0];
   if(!normalized||normalized.role!=='user')throw failure('INVALID_HISTORY','用户提问无法规范化。');
   const item={...normalized,id:entry.item.id};
   if(typeof entry.item.clientId==='string'&&/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(entry.item.clientId))item.clientRequestId=entry.item.clientId;
   builder.add(entry.turnId,item,entry.item.id);
  }
  cursor=next;
 }while(cursor!==null);
 return builder.finish();
}

async function bridgeQuestionIndex(read,id,normalizeHistory,maximum=MAX_INDEX_BYTES){
 const seen=new Set(),pages=[],builder=new QuestionIndexBuilder(id,maximum),turnsSeen=new Set();let cursor=null,count=0;
 do{
  if(++count>100000)throw failure('INVALID_HISTORY','提问索引页数超出安全上限。');
  const raw=await read({threadId:id,turnLimit:10,includeOutputs:false,maxOutputCharsPerItem:0,...(cursor?{cursor}:{})});
  if(raw?.thread?.id!==id||raw.thread.kind!=='codex'||raw.thread.hostId!=='local'||!Array.isArray(raw.turns)
    ||typeof raw.page?.hasMore!=='boolean')throw failure('INVALID_HISTORY','Bridge提问索引未返回完整分页信息。');
  const next=advanceCursor(raw.page,seen);
  if(raw.page.hasMore!==(next!==null))throw failure('INVALID_HISTORY','Bridge提问索引分页状态不一致。');
  const turns=raw.turns.map(turn=>{
   if(typeof turn?.id!=='string'||!turn.id||!Array.isArray(turn.items))throw failure('INVALID_HISTORY','Bridge回合条目缺失。');
   return{...turn,items:turn.items.filter(item=>item?.type==='userMessage')};
  });
  const normalized=normalizeHistory({...raw,turns},normalizationOptions).turns,pageOrder=[];
  for(const turn of normalized){
   pageOrder.push(turn.id);
   // 同回合跨页交叠采用较新页的完整条目，沿用普通Bridge的回合内身份规则。
   if(turnsSeen.has(turn.id))continue;turnsSeen.add(turn.id);
   builder.touch(turn.id);
   for(const item of turn.items)builder.add(turn.id,item);
  }
  pages.push(pageOrder);
  cursor=next;
 }while(cursor!==null);
 return builder.finish(pages.reverse().flat());
}

module.exports={MAX_INDEX_BYTES,sharedQuestionIndex,bridgeQuestionIndex};
