'use strict';
const {BridgeError}=require('./errors.cjs');
const {DesktopRuntime}=require('./desktop-runtime.cjs');
function createRuntime(config={}) {
 const mode=config.runtimeMode??'desktop-bridge';
 if(mode==='desktop-bridge')return new DesktopRuntime(config);
 if(mode==='shared-engine')return new (require('./shared-runtime.cjs').SharedRuntime)(config);
 throw new BridgeError('BAD_INPUT','运行模式无效，请选择桌面 Bridge 或共享引擎。');
}
module.exports={createRuntime,DesktopRuntime};
