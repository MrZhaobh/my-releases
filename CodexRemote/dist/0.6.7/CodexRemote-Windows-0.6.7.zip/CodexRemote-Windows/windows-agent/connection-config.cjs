'use strict';
const path = require('node:path');
const DEFAULT_TIMEOUTS = Object.freeze({ requestTimeoutMs: 12000, pollTimeoutMs: 28000 });
const PUBLIC_KEYS = new Set(['schemaVersion', 'baseUrl', 'relayUrl', 'relayURL', 'requestTimeoutMs', 'pollTimeoutMs', 'version']);
function normalizeRelayUrl(value) {
  const raw = String(value ?? '').trim();
  if (!/^https?:\/\/[^/]+/i.test(raw) || /[\\\r\n\t]/.test(raw) || raw.includes('?') || raw.includes('#')) throw new Error('Invalid relay base URL.');
  const pathname = raw.replace(/^https?:\/\/[^/]+/i, '');
  for (const segment of pathname.split('/')) {
    let decoded = segment;
    for (let i = 0; i < 4 && decoded.includes('%'); i++) decoded = decodeURIComponent(decoded);
    if (decoded === '.' || decoded === '..' || /[\\/\u0000-\u0020%]/.test(decoded)) throw new Error('Relay base URL contains an unsafe path segment.');
  }
  const url = new URL(raw);
  if (url.protocol !== 'https:' && !(url.protocol === 'http:' && ['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname))) throw new Error('Relay URL must use HTTPS outside loopback.');
  if (url.username || url.password) throw new Error('Relay URL cannot contain credentials.');
  return url.href.replace(/\/+$/, '');
}
function timeouts(value = {}) {
  const result = {};
  for (const [key, fallback] of Object.entries(DEFAULT_TIMEOUTS)) {
    const number = value[key] === undefined ? fallback : value[key];
    if (!Number.isInteger(number) || number < 1000 || number > 120000) throw new Error(`${key} must be an integer between 1000 and 120000 milliseconds.`);
    result[key] = number;
  }
  return result;
}
function publicDefaults(value = {}) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('Public defaults must be an object.');
  for (const key of Object.keys(value)) if (!PUBLIC_KEYS.has(key)) throw new Error(`Unsupported public configuration field: ${key}`);
  if (value.schemaVersion !== undefined && value.schemaVersion !== 1) throw new Error('Unsupported public configuration schemaVersion.');
  const baseUrl = value.baseUrl ?? value.relayUrl ?? value.relayURL;
  return { schemaVersion: 1, baseUrl: baseUrl ? normalizeRelayUrl(baseUrl) : '', ...timeouts(value), ...(value.version === undefined ? {} : { version: value.version }) };
}
function runtimeSettings(value = {}) {
  const runtimeMode = value.runtimeMode ?? 'desktop-bridge';
  if (!['desktop-bridge', 'shared-engine'].includes(runtimeMode)) throw new Error('Unsupported runtimeMode.');
  const sharedEngineConfigFile = value.sharedEngineConfigFile ?? '';
  if (typeof sharedEngineConfigFile !== 'string' || /[\r\n\0]/.test(sharedEngineConfigFile) || (sharedEngineConfigFile && !path.isAbsolute(sharedEngineConfigFile) && !path.win32.isAbsolute(sharedEngineConfigFile))) throw new Error('Shared engine configuration must be an absolute local file path.');
  const pending = value.desktopLaunchConfigFile ?? '';
  if (typeof pending !== 'string' || /[\r\n\0]/.test(pending) || (pending && !path.isAbsolute(pending) && !path.win32.isAbsolute(pending))) throw new Error('Desktop launch configuration must be an absolute local file path.');
  if (runtimeMode === 'shared-engine' && !sharedEngineConfigFile.trim() && !pending.trim()) throw new Error('共享引擎模式需要既有的私有 broker 配置文件路径。');
  const preferredProfile = value.preferredProfile;
  if (preferredProfile !== undefined && (typeof preferredProfile !== 'string' || !preferredProfile.trim() || /[\r\n\0]/.test(preferredProfile) || (!path.isAbsolute(preferredProfile) && !path.win32.isAbsolute(preferredProfile)))) throw new Error('Desktop profile must be an absolute local directory path.');
  const desktopCodexHome = value.desktopCodexHome;
  if (desktopCodexHome !== undefined && (typeof desktopCodexHome !== 'string' || !desktopCodexHome.trim() || /[\x00-\x1f\x7f]/.test(desktopCodexHome) || (!path.isAbsolute(desktopCodexHome) && !path.win32.isAbsolute(desktopCodexHome)))) throw new Error('Desktop Codex home must be an absolute local directory path.');
  return { runtimeMode, sharedEngineConfigFile, ...(preferredProfile === undefined ? {} : { preferredProfile }), ...(desktopCodexHome === undefined ? {} : { desktopCodexHome }) };
}
function mergeSettings(defaults, local, hostname) {
  const base = publicDefaults(defaults);
  if (!local || typeof local !== 'object' || Array.isArray(local)) throw new Error('Local settings must be an object.');
  if (local.schemaVersion !== undefined && local.schemaVersion !== 1) throw new Error('Unsupported local configuration schemaVersion.');
  const result = { relayUrl: base.baseUrl, name: hostname.slice(0, 64), autoStart: true, paused: false, ...timeouts(base), ...local };
  result.relayUrl = local.baseUrl ?? local.relayUrl ?? local.relayURL ?? base.baseUrl;
  delete result.baseUrl;
  delete result.relayURL;
  if (result.relayUrl) result.relayUrl = normalizeRelayUrl(result.relayUrl);
  Object.assign(result, timeouts(result));
  Object.assign(result, runtimeSettings(result));
  if (result.connectionScope !== undefined && !/^[a-f0-9-]{36}$/i.test(result.connectionScope)) throw new Error('Invalid connection scope.');
  return result;
}
function journalPath(config) {
  if (!config.connectionScope) return path.join(config.dataDirectory, 'mutation-journal.sqlite');
  if (!/^[a-f0-9-]{36}$/i.test(config.connectionScope)) throw new Error('Invalid connection scope.');
  return path.join(config.dataDirectory, 'connections', config.connectionScope, 'mutation-journal.sqlite');
}
module.exports = { DEFAULT_TIMEOUTS, normalizeRelayUrl, timeouts, publicDefaults, mergeSettings, journalPath, runtimeSettings };
if (require.main === module) {
  if (process.argv[2] !== 'export-public') throw new Error('Usage: connection-config.cjs export-public <file|-> <version>');
  const fs = require('node:fs');
  const input = process.argv[3] === '-' ? {} : JSON.parse(fs.readFileSync(process.argv[3], 'utf8').replace(/^\uFEFF/, ''));
  process.stdout.write(JSON.stringify({ ...publicDefaults(input), version: process.argv[4] }, null, 2));
}
