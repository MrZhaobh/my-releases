'use strict';

const UUID=/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
const CHECKPOINTS=[15_000,45_000,120_000];

function safeCode(error){return typeof error?.code==='string'&&/^[A-Z0-9_]{1,48}$/.test(error.code)?error.code:'DESKTOP_ERROR'}
function assignedToProject(assignments,threadId){
 if(!assignments||typeof assignments!=='object'||Array.isArray(assignments))return null;
 if(!Object.prototype.hasOwnProperty.call(assignments,threadId))return false;
 const value=assignments[threadId];if(value===null||value==='')return false;
 if(!value||typeof value!=='object'||Array.isArray(value)||!Object.prototype.hasOwnProperty.call(value,'projectId'))return null;
 if(value.projectId===null||value.projectId==='')return false;
 return typeof value.projectId==='string'?true:null;
}
function readGlobalState(){const fs=require('node:fs'),path=require('node:path'),os=require('node:os');return JSON.parse(fs.readFileSync(path.join(os.homedir(),'.codex','.codex-global-state.json'),'utf8'))}

class RegistrationQueue{
 constructor(db,{clock=()=>Date.now(),globalStateReader=readGlobalState}={}){
  if(!db||typeof db.prepare!=='function')throw new TypeError('A Journal SQLite database is required');
  this.db=db;this.clock=clock;this.globalStateReader=globalStateReader;this.inFlight=null;
  db.exec("CREATE TABLE IF NOT EXISTS registrations(thread_id TEXT PRIMARY KEY,project_id TEXT,created_at INTEGER NOT NULL,attempts INTEGER NOT NULL DEFAULT 0,safety_checks INTEGER NOT NULL DEFAULT 0,state TEXT NOT NULL CHECK(state IN ('pending','done','cancelled')),next_at INTEGER,last_code TEXT)");
  try{db.exec('ALTER TABLE registrations ADD COLUMN safety_checks INTEGER NOT NULL DEFAULT 0')}catch{}
  db.exec('CREATE INDEX IF NOT EXISTS registrations_due ON registrations(state,next_at,created_at)');
 }
 schedule(threadId,projectId=null){
  if(!UUID.test(threadId??''))throw Object.assign(new Error('Invalid thread ID'),{code:'BAD_INPUT'});
  if(projectId!==null) return {scheduled:false,reason:'project-targeted-not-queued'};
  const now=this.clock(),prior=this.db.prepare('SELECT project_id,created_at,attempts,state,next_at FROM registrations WHERE thread_id=?').get(threadId);
  if(prior){if(prior.project_id!==null)throw Object.assign(new Error('Registration target conflict'),{code:'REGISTRATION_CONFLICT'});return{scheduled:false,createdAt:prior.created_at,attempts:prior.attempts,state:prior.state,nextAt:prior.next_at}}
  this.db.prepare("INSERT INTO registrations(thread_id,project_id,created_at,attempts,state,next_at,last_code) VALUES(?,NULL,?,0,'pending',?,NULL)").run(threadId,now,now+CHECKPOINTS[0]);
  return{scheduled:true,createdAt:now,attempts:0,state:'pending',nextAt:now+CHECKPOINTS[0]};
 }
 async currentProjectlessState(desktop,threadId){
  let db;try{db=desktop.db();const row=db.prepare('SELECT project_id,archived FROM threads WHERE id=?').get(threadId);if(!row)return{ok:false,reason:'missing'};if(row.archived!==0)return{ok:false,reason:'archived'};if(row.project_id!==null&&row.project_id!=='')return{ok:false,reason:'project-assigned'}}catch{return{ok:false,reason:'state-unavailable'}}finally{try{db?.close()}catch{}}
  try{
   let thread=null;for(const pipe of await desktop.discover())try{const result=await desktop.tool(pipe,'read_thread',{threadId,turnLimit:1,includeOutputs:false,maxOutputCharsPerItem:0});const candidate=result.thread;if(candidate?.id===threadId&&candidate?.kind==='codex'&&candidate?.hostId==='local'){thread=candidate;break}}catch{}
   if(!thread)return{ok:false,reason:'state-unavailable'};
   if(thread.archived===true)return{ok:false,reason:'archived'};
   if(Object.prototype.hasOwnProperty.call(thread,'projectId')&&thread.projectId!==null&&thread.projectId!=='')return{ok:false,reason:'project-assigned'};
  }catch{return{ok:false,reason:'state-unavailable'}}
  try{const state=this.globalStateReader(),assignments=state?.['thread-project-assignments'];if(!assignments||typeof assignments!=='object')return{ok:false,reason:'state-unavailable'};const assigned=assignedToProject(assignments,threadId);if(assigned===true)return{ok:false,reason:'project-assigned'};if(assigned===null)return{ok:false,reason:'state-unavailable'};return{ok:true}}catch{return{ok:false,reason:'state-unavailable'}}
 }
 claim(row,now){
  this.db.exec('BEGIN IMMEDIATE');try{
   const current=this.db.prepare("SELECT attempts,created_at FROM registrations WHERE thread_id=? AND state='pending' AND next_at<=?").get(row.thread_id,now);
   if(!current){this.db.exec('COMMIT');return null}
   const attempt=current.attempts+1,nextAt=attempt<CHECKPOINTS.length?current.created_at+CHECKPOINTS[attempt]:null;
   this.db.prepare("UPDATE registrations SET attempts=?,next_at=?,last_code=NULL WHERE thread_id=? AND state='pending'").run(attempt,nextAt,row.thread_id);
   this.db.exec('COMMIT');return{attempt,nextAt};
  }catch(error){try{this.db.exec('ROLLBACK')}catch{}throw error}
 }
 async runDue(desktop){
  const now=this.clock(),row=this.db.prepare("SELECT thread_id,project_id,created_at,attempts,safety_checks,state,next_at FROM registrations WHERE state='pending' AND attempts<? AND next_at<=? ORDER BY next_at,created_at,thread_id LIMIT 1").get(CHECKPOINTS.length,now);
  if(!row)return{ran:false};
  const safety=await this.currentProjectlessState(desktop,row.thread_id);
  if(!safety.ok){if(safety.reason==='state-unavailable'){const checks=row.safety_checks+1,nextAt=checks<CHECKPOINTS.length?now+CHECKPOINTS[checks-1]:null;this.db.prepare("UPDATE registrations SET safety_checks=?,next_at=?,last_code='STATE_UNAVAILABLE' WHERE thread_id=? AND state='pending'").run(checks,nextAt,row.thread_id);return{ran:true,threadId:row.thread_id,deferred:true,reason:safety.reason,nextAt}}this.db.prepare("UPDATE registrations SET state='cancelled',next_at=NULL,last_code=? WHERE thread_id=? AND state='pending'").run(`CANCELLED_${safety.reason.toUpperCase().replace(/[^A-Z0-9_]/g,'_')}`,row.thread_id);return{ran:true,threadId:row.thread_id,cancelled:true,reason:safety.reason}}
  this.db.prepare("UPDATE registrations SET safety_checks=0 WHERE thread_id=? AND state='pending'").run(row.thread_id);
  const claim=this.claim(row,now);if(!claim)return{ran:false};
  let ready=false,code=null;try{const result=await desktop.execute('reconcile',{threadId:row.thread_id,projectId:null});ready=result?.desktopRegistration==='ready';if(!ready)code='REGISTRATION_PENDING'}catch(error){code=safeCode(error)}
  const state=claim.attempt===CHECKPOINTS.length&&ready?'done':'pending';
  this.db.prepare("UPDATE registrations SET state=?,last_code=? WHERE thread_id=? AND state='pending'").run(state,ready?null:code,row.thread_id);
  const current=this.db.prepare('SELECT state FROM registrations WHERE thread_id=?').get(row.thread_id);
  return{ran:true,threadId:row.thread_id,attempt:claim.attempt,ready,state:current?.state??state,nextAt:claim.nextAt,errorCode:code};
 }
 kick(desktop){
  if(this.inFlight)return this.inFlight;
  const task=this.runDue(desktop).catch(error=>({ran:false,errorCode:safeCode(error)}));
  this.inFlight=task.finally(()=>{if(this.inFlight===wrapped)this.inFlight=null});
  const wrapped=this.inFlight;return wrapped;
 }
 drain(){return this.inFlight??Promise.resolve()}
}

module.exports={RegistrationQueue,CHECKPOINTS};
