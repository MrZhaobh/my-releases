'use strict';
const {randomUUID}=require('node:crypto');
const WebSocket=require('ws');
const LIMIT=8*1024*1024+68*1024;
const fault=(code,beforeSend=false)=>Object.assign(Error('桥接连接暂不可用'),{code,beforeSend});

// 不重投任何已发送的 RPC；调用方可重投既成 result/events，不能重执行 job。
class BridgeSocket{
 constructor({relayUrl,bridgeKey,WebSocketImpl=WebSocket,clock=Date.now,random=Math.random}={}){this.url=relayUrl.replace(/^http/,'ws').replace(/\/+$/,'')+'/bridge/socket';this.key=bridgeKey;this.WebSocket=WebSocketImpl;this.clock=clock;this.random=random;this.pending=new Map();this.ws=null;this.connecting=null;this.stopped=false;this.retryAt=0;this.backoff=1000;this.heartbeat=null;}
 failConnection(ws){
  if(this.ws!==ws)return;
  this.ws=null;clearInterval(this.heartbeat);this.heartbeat=null;
  this.retryAt=this.clock()+Math.round(this.backoff*(.5+this.random()));this.backoff=Math.min(this.backoff*2,15000);
  for(const [id,entry]of this.pending){clearTimeout(entry.timer);entry.removeAbort();entry.reject(fault('SOCKET_DISCONNECTED'));this.pending.delete(id);}
 }
 connect(){
  if(this.stopped)return Promise.reject(fault('STOPPED',true));
  if(this.ws?.readyState===WebSocket.OPEN)return Promise.resolve(this.ws);
  if(this.connecting)return this.connecting;
  if(this.clock()<this.retryAt)return Promise.reject(fault('SOCKET_BACKOFF',true));
  const ws=new this.WebSocket(this.url,{headers:{Authorization:'Bearer '+this.key},handshakeTimeout:5000,maxPayload:LIMIT,perMessageDeflate:{threshold:64*1024,serverNoContextTakeover:true,clientNoContextTakeover:true}});
  this.ws=ws;
  const connecting=new Promise((resolve,reject)=>{
   let settled=false;
   const fail=()=>{this.failConnection(ws);if(!settled){settled=true;reject(fault('SOCKET_CONNECT_FAILED',true));}};
   ws.on('error',fail);ws.on('close',fail);
   ws.on('open',()=>{
    if(this.stopped){ws.terminate();return fail();}
    settled=true;this.backoff=1000;this.retryAt=0;let alive=true;
    ws.on('pong',()=>{alive=true;});
    this.heartbeat=setInterval(()=>{if(!alive)return ws.terminate();alive=false;ws.ping();},15000);this.heartbeat.unref?.();
    resolve(ws);
   });
   ws.on('message',(data,binary)=>{
    let value;try{if(binary)throw Error();value=JSON.parse(data.toString());}catch{return ws.terminate();}
    if(value?.version!==1||typeof value.id!=='string'||!Number.isInteger(value.status)||!value.body||typeof value.body!=='object')return ws.terminate();
    const entry=this.pending.get(value.id);if(!entry)return;
    this.pending.delete(value.id);clearTimeout(entry.timer);entry.removeAbort();entry.resolve({status:value.status,body:value.body});
   });
   // `error`/`close` listeners above consume all lifecycle failures without exposing URL/key.
  });
  this.connecting=connecting.finally(()=>{if(this.connecting===task)this.connecting=null;});const task=this.connecting;
  return task;
 }
 async request(path,body,{signal,timeout=30000}={}){
  if(signal?.aborted)throw fault('ABORTED',true);
  const ws=await this.connect();if(signal?.aborted||this.stopped)throw fault('ABORTED',true);
  if(this.ws!==ws||ws.readyState!==WebSocket.OPEN)throw fault('SOCKET_DISCONNECTED',true);
  const id=randomUUID(),payload=JSON.stringify({version:1,id,path,body});
  if(Buffer.byteLength(payload)>LIMIT||ws.bufferedAmount+Buffer.byteLength(payload)>2*LIMIT)throw fault('SOCKET_BACKPRESSURE',true);
  return new Promise((resolve,reject)=>{
   const abort=()=>{const entry=this.pending.get(id);if(!entry)return;this.pending.delete(id);clearTimeout(entry.timer);entry.removeAbort();reject(fault('ABORTED'));ws.terminate();};
   const timer=setTimeout(()=>{const entry=this.pending.get(id);if(!entry)return;this.pending.delete(id);entry.removeAbort();reject(fault('SOCKET_TIMEOUT'));ws.terminate();},timeout);
   const removeAbort=()=>signal?.removeEventListener('abort',abort);
   this.pending.set(id,{resolve,reject,timer,removeAbort});signal?.addEventListener('abort',abort,{once:true});
   try{ws.send(payload,error=>{if(error)ws.terminate();});}catch{ws.terminate();}
  });
 }
 stop(){this.stopped=true;clearInterval(this.heartbeat);if(this.ws){const ws=this.ws;this.failConnection(ws);ws.terminate();}}
}
module.exports={BridgeSocket};
