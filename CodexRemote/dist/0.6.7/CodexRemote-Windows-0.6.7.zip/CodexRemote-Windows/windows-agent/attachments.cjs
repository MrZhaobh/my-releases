'use strict';
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const MAX_ATTACHMENT_BYTES=64*1024*1024;
const CHUNK_BYTES=256*1024;
const MAX_ENTRIES=500;
const TTL_MS=2*60*60*1000;
const MIME={'.txt':'text/plain','.md':'text/markdown','.markdown':'text/markdown','.html':'text/html','.htm':'text/html','.json':'application/json','.xml':'application/xml','.java':'text/x-java-source','.js':'text/javascript','.ts':'text/plain','.py':'text/x-python','.css':'text/css','.csv':'text/csv','.pdf':'application/pdf','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp','.gif':'image/gif'};
class AttachmentError extends Error{constructor(code,message){super(message);this.code=code}}
function registerAttachment(cache,threadId,file,now=Date.now()){
 if(typeof file!=='string'||file.length>32768)return null;
 try{
  const canonical=fs.realpathSync(file),st=fs.statSync(canonical,{bigint:true});if(!st.isFile()||st.size>BigInt(MAX_ATTACHMENT_BYTES))return null;
  const id=crypto.createHash('sha256').update(`${threadId}\0${canonical}\0${st.dev}\0${st.ino}\0${st.size}\0${st.mtimeNs}`).digest('hex').slice(0,32);
  const fileId=`${id.slice(0,8)}-${id.slice(8,12)}-4${id.slice(13,16)}-${((parseInt(id[16],16)&3)|8).toString(16)}${id.slice(17,20)}-${id.slice(20,32)}`;
  const name=path.basename(canonical).replace(/[\x00-\x1f\x7f]/g,'').slice(0,255)||'file';
  cache.delete(fileId);cache.set(fileId,{threadId,path:canonical,size:st.size.toString(),mtimeNs:st.mtimeNs.toString(),dev:st.dev.toString(),ino:st.ino.toString(),name,mime:MIME[path.extname(canonical).toLowerCase()]??'application/octet-stream',createdAt:now});
  while(cache.size>MAX_ENTRIES)cache.delete(cache.keys().next().value);
  return{id:fileId,name,mime:MIME[path.extname(canonical).toLowerCase()]??'application/octet-stream',size:Number(st.size),path:canonical};
 }catch{return null}
}
function readAttachmentChunk(cache,threadId,fileId,offset,length,now=Date.now()){
 const e=cache.get(fileId);if(!e||e.threadId!==threadId||now-e.createdAt>TTL_MS)throw new AttachmentError('NOT_FOUND','文件不可用');
 if(!Number.isSafeInteger(offset)||offset<0||!Number.isInteger(length)||length<1||length>CHUNK_BYTES)throw new AttachmentError('BAD_INPUT','文件分块参数无效');
 let fd;try{fd=fs.openSync(e.path,'r');const before=fs.fstatSync(fd,{bigint:true});if(!before.isFile()||before.size.toString()!==e.size||before.mtimeNs.toString()!==e.mtimeNs||before.dev.toString()!==e.dev||before.ino.toString()!==e.ino)throw new AttachmentError('NOT_FOUND','文件版本已变化');if(offset>=before.size&&before.size!==0n)throw new AttachmentError('BAD_INPUT','文件偏移无效');const count=Math.min(length,Number(before.size)-offset);const data=Buffer.alloc(Math.max(0,count));let read=0;while(read<count){const n=fs.readSync(fd,data,read,count-read,offset+read);if(!n)throw new AttachmentError('NOT_FOUND','文件读取不完整');read+=n}const after=fs.fstatSync(fd,{bigint:true});if(after.size.toString()!==e.size||after.mtimeNs.toString()!==e.mtimeNs)throw new AttachmentError('NOT_FOUND','文件版本已变化');return{fileId,name:e.name,mime:e.mime,size:Number(e.size),offset,base64:data.toString('base64'),done:offset+count>=Number(e.size)}}catch(err){if(err instanceof AttachmentError)throw err;throw new AttachmentError('NOT_FOUND','文件不可用')}finally{if(fd!==undefined)fs.closeSync(fd)}
}
module.exports={MAX_ATTACHMENT_BYTES,CHUNK_BYTES,AttachmentError,registerAttachment,readAttachmentChunk};
