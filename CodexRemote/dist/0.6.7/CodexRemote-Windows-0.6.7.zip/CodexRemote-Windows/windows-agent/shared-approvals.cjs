'use strict';
const text = value => typeof value === 'string' ? value.slice(0, 12000) : '';
const REVIEW_LIMIT = 16000;
const presentationText = (value, token) => typeof value === 'string' ? (token ? value.replaceAll(token, '[已隐藏]') : value).slice(0, 12000) : undefined;

function review(fields, token) {
  let complete = true;
  const sections = [];
  for (const [label, value] of fields) {
    if (value == null) continue;
    let rendered;
    try {
      // 先逐字符串脱敏再序列化，避免 token 中引号被转义后漏过过滤。
      const safe = JSON.parse(JSON.stringify(value, (_key, part) => typeof part === 'string' && token ? part.replaceAll(token, '[已隐藏]') : part));
      rendered = typeof safe === 'string' ? safe : JSON.stringify(safe, null, 2);
    } catch { complete = false; rendered = '[参数无法完整显示]'; }
    sections.push(`${label}：${rendered}`);
  }
  let details = sections.join('\n');
  if (details.length > REVIEW_LIMIT) { complete = false; details = details.slice(0, REVIEW_LIMIT) + '\n[内容超出显示上限，请在原客户端审阅]'; }
  return {details, complete};
}

function approvalSpec(method, p, fileContext, token) {
  if (method === 'item/permissions/requestApproval') {
    // 与当前 CLI 生成的 PermissionsRequestApprovalResponse 对齐，仅授予本回合。
    // 响应只复制已展示的原请求，不把一次审批扩大为整个会话。
    const requested=p.permissions, object=v=>v&&typeof v==='object'&&!Array.isArray(v);
    const exact=(v,keys)=>object(v)&&Object.keys(v).every(k=>keys.includes(k));
    const paths=v=>v==null||Array.isArray(v)&&v.every(x=>typeof x==='string'&&x.length>0);
    const special=v=>object(v)&&(['root','minimal','tmpdir','slash_tmp'].includes(v.kind)&&exact(v,['kind'])||v.kind==='project_roots'&&exact(v,['kind','subpath'])&&(v.subpath===null||typeof v.subpath==='string')||v.kind==='unknown'&&exact(v,['kind','path','subpath'])&&typeof v.path==='string'&&(v.subpath===null||typeof v.subpath==='string'));
    const entry=v=>exact(v,['path','access'])&&['read','write','deny'].includes(v.access)&&(exact(v.path,['type','path'])&&v.path.type==='path'&&typeof v.path.path==='string'||exact(v.path,['type','pattern'])&&v.path.type==='glob_pattern'&&typeof v.path.pattern==='string'||exact(v.path,['type','value'])&&v.path.type==='special'&&special(v.path.value));
    const valid=exact(requested,['network','fileSystem'])&&(requested.network==null||exact(requested.network,['enabled'])&&(requested.network.enabled===null||typeof requested.network.enabled==='boolean'))&&(requested.fileSystem==null||exact(requested.fileSystem,['read','write','entries','globScanMaxDepth'])&&paths(requested.fileSystem.read)&&paths(requested.fileSystem.write)&&(requested.fileSystem.entries===undefined||Array.isArray(requested.fileSystem.entries)&&requested.fileSystem.entries.every(entry))&&(requested.fileSystem.globScanMaxDepth===undefined||Number.isSafeInteger(requested.fileSystem.globScanMaxDepth)&&requested.fileSystem.globScanMaxDepth>=0));
    const view=review([['原因',p.reason],['工作目录',p.cwd],['环境',p.environmentId],['请求权限',requested],['授权范围','仅当前回合；拒绝则不授予额外权限']],token);
    const permissions={};if(valid){if(requested.network!=null)permissions.network=structuredClone(requested.network);if(requested.fileSystem!=null)permissions.fileSystem=structuredClone(requested.fileSystem);}
    return {kind:'permissions',title:'额外权限审批',details:view.details,approve:valid&&view.complete?{permissions,scope:'turn'}:null,reject:{permissions:{},scope:'turn'}};
  }
  if (method === 'item/commandExecution/requestApproval') {
    const summary = review([['命令',p.command],['工作目录',p.cwd],['原因',p.reason],['额外权限',p.additionalPermissions],['网络审批',p.networkApprovalContext]],token);
    const view = review([['命令',p.command],['工作目录',p.cwd],['原因',p.reason],['请求类型',p.kind],['额外权限',p.additionalPermissions],['网络审批',p.networkApprovalContext],['命令操作',p.commandActions],['环境',p.environmentId],['提议规则',p.proposedExecpolicyAmendment],['提议网络规则',p.proposedNetworkPolicyAmendments],['允许决策',p.availableDecisions]],token);
    const allows = value => p.availableDecisions == null || (Array.isArray(p.availableDecisions) && p.availableDecisions.includes(value));
    const reject = allows('decline') ? {decision:'decline'} : allows('cancel') ? {decision:'cancel'} : null;
    return {kind:'commandExecution', title:'执行命令审批', command:presentationText(p.command,token), reason:presentationText(p.reason,token), cwd:presentationText(p.cwd,token), summary:summary.details, details:view.details, approve:view.complete && summary.complete && typeof p.command === 'string' && p.command.length > 0 && allows('accept') ? {decision:'accept'} : null, reject, rejectLabel:reject?.decision === 'cancel' ? '拒绝并停止本轮' : '拒绝本次操作'};
  }
  if (method === 'item/fileChange/requestApproval') {
    const view = review([['原因',p.reason],['授权目录',p.grantRoot]],token);
    const canReview = fileContext?.complete && view.complete;
    return {kind:'fileChange', title:'文件修改审批', details:[view.details,fileContext?.details ?? '尚未收到同一回合、同一条目的完整拟修改内容，请在原客户端审阅。'].filter(Boolean).join('\n'), approve:canReview ? {decision:'accept'} : null, reject:{decision:'decline'}};
  }
  if (method === 'mcpServer/elicitation/request') {
    const schema = p.requestedSchema;
    const empty = schema?.type === 'object' && schema.properties && typeof schema.properties === 'object' && !Array.isArray(schema.properties) && !Object.keys(schema.properties).length && (schema.required == null || (Array.isArray(schema.required) && !schema.required.length)) && Object.keys(schema).every(key => ['$schema','type','properties','required'].includes(key));
    const nativePrompt = typeof p.message === 'string' && /^Allow the ([a-zA-Z0-9_.-]{1,128}) MCP server to run tool "([a-zA-Z_][a-zA-Z0-9_]{0,127})"\?$/.exec(p.message);
    const promptTool = nativePrompt && nativePrompt[1] === p.serverName ? nativePrompt[2] : null;
    const structuredTool = typeof p._meta?.tool_name === 'string' && /^[a-zA-Z_][a-zA-Z0-9_]{0,127}$/.test(p._meta.tool_name) ? p._meta.tool_name : null;
    const toolName = structuredTool ?? promptTool;
    const view = review([['MCP服务',p.serverName],['请求说明',p.message],['工具名称',toolName],['工具标题',p._meta?.tool_title],['工具描述',p._meta?.tool_description],['工具参数',p._meta?.tool_params]],token);
    const toolKnown = toolName && (!structuredTool || !promptTool || structuredTool === promptTool) && p._meta?.tool_params && typeof p._meta.tool_params === 'object' && !Array.isArray(p._meta.tool_params);
    const approve = p.mode === 'form' && p._meta?.codex_approval_kind === 'mcp_tool_call' && empty && toolKnown && view.complete ? {action:'accept', content:{}} : null;
    return {kind:approve ? 'mcpToolCall' : 'elicitation', title:approve ? 'MCP 工具调用审批' : 'MCP 交互请求', details:[view.details, ...(approve ? [] : ['此请求需要原客户端处理；网页仅支持拒绝。'])].filter(Boolean).join('\n'), approve, reject:{action:'decline'}};
  }
  return {kind:'unsupported', title:'暂不支持的交互请求', details:`${text(method)}\n请在原客户端处理；网页不能安全构造此请求的响应。`, approve:null, reject:null};
}


module.exports = {review, approvalSpec};
