﻿param([Parameter(Mandatory=$true)][string]$Path)
$ErrorActionPreference='Stop'
$secret=Import-Clixml -LiteralPath $Path
$ptr=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($secret)
try{@{bridgeKey=[Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)}|ConvertTo-Json -Compress}finally{[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)}
